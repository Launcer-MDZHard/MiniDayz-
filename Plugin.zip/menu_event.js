(function () {
  window.MDZ = window.MDZ || {};

  const STORAGE_KEY = 'mdz_lang_selected';
  const MODAL_ID = 'mdz-lang-id-restart-modal';
  const DROPDOWN_ID = 'mdz-lang-dropdown';
  const EVENT_PANEL_ID = 'mdz-event-control-panel';
  const BASE_FILES = ['items', 'ui', 'log', 'new'];
  
  const LANGUAGES = [
    { code: 'en', label: 'English (Default)' },
    { code: 'id', label: 'Bahasa Indonesia' },
  ];

  function getSelectedLang() {
    return localStorage.getItem(STORAGE_KEY) || 'en';
  }

  function setSelectedLang(code) {
    localStorage.setItem(STORAGE_KEY, code);
  }

  function langLabel(code) {
    const found = LANGUAGES.find(l => l.code === code);
    return found ? found.label : code;
  }

 
  if (!window._mdz_lang_xhr_hooked) {
    window._mdz_lang_xhr_hooked = true;

    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      const code = getSelectedLang();
      if (code !== 'en' && typeof url === 'string') {
        for (const base of BASE_FILES) {
          const engFile = 'l_eng_' + base + '.xml';
          if (url.indexOf(engFile) !== -1) {
            url = url.replace(engFile, 'l_' + code + '_' + base + '.xml');
            break;
          }
        }
      }
      return originalOpen.call(this, method, url, ...rest);
    };
  }


  function injectModalStyles() {
    if (document.getElementById('mdz-lang-id-style')) return;
    const style = document.createElement('style');
    style.id = 'mdz-lang-id-style';
    style.textContent = `
      #${MODAL_ID}{position:fixed;inset:0;z-index:999999;display:none;
        align-items:center;justify-content:center;background:rgba(0,0,0,0.55);
        font-family:Georgia,"Times New Roman",serif;}
      #${MODAL_ID} .mdz-box{background:#241a12;border:2px solid #6b4324;border-radius:6px;
        padding:20px 24px;max-width:340px;text-align:center;color:#f5ecd8;
        box-shadow:0 6px 20px rgba(0,0,0,0.6);}
      #${MODAL_ID} .mdz-title{font-size:16px;font-weight:bold;margin-bottom:10px;color:#0f8;}
      #${MODAL_ID} .mdz-text{font-size:13px;line-height:1.5;margin-bottom:16px;}
      #${MODAL_ID} .mdz-btns{display:flex;flex-direction:column;gap:8px;align-items:center;}
      #${MODAL_ID} .mdz-restart-btn{
        width:160px;height:39px;display:flex;align-items:center;justify-content:center;
        font-size:15px;color:#ffffff;cursor:pointer;box-sizing:border-box;
        background:url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;
        text-shadow:1px 1px 1px rgba(0,0,0,0.7);font-family:"Times New Roman",serif;
        letter-spacing:1px;
      }
      #${MODAL_ID} .mdz-restart-btn:hover{background-position:-1px -165px;}
      #${MODAL_ID} .mdz-restart-btn:active{transform:scale(0.97);}

      #${DROPDOWN_ID}{position:fixed;inset:0;z-index:99998;display:none;
        align-items:center;justify-content:center;background:rgba(0,0,0,0.55);
        font-family:Georgia,"Times New Roman",serif;}
      #${DROPDOWN_ID} .mdz-lang-grid{display:grid;grid-template-columns:repeat(2, 160px);
        gap:8px;background:#241a12;border:2px solid #6b4324;border-radius:6px;
        padding:20px;box-shadow:0 6px 20px rgba(0,0,0,0.6);}
      #${DROPDOWN_ID} .mdz-lang-row{
        width:160px;height:39px;display:flex;align-items:center;justify-content:center;
        cursor:pointer;box-sizing:border-box;background:url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;
        color:#fff;font-size:14px;text-shadow:1px 1px 1px rgba(0,0,0,0.7);
        font-family:"Times New Roman",serif;letter-spacing:1px;text-align:center;padding:0 4px;}
      #${DROPDOWN_ID} .mdz-lang-row:hover{background-position:-1px -165px;}
      #${DROPDOWN_ID} .mdz-lang-row:active{transform:scale(0.97);}
      #${DROPDOWN_ID} .mdz-lang-row.active{color:#0f8;}
      #${DROPDOWN_ID} .mdz-event-menu-btn{grid-column:1 / -1;color:#ffd36a;}
      #${EVENT_PANEL_ID}{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.62);font-family:Georgia,"Times New Roman",serif;}
      #${EVENT_PANEL_ID} .mdz-event-box{width:min(92vw,430px);max-height:82vh;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#241a12;border:2px solid #6b4324;border-radius:6px;padding:16px;box-shadow:0 6px 20px rgba(0,0,0,.7);color:#f5ecd8;}
      #${EVENT_PANEL_ID} .mdz-event-title{text-align:center;color:#0f8;font-size:17px;font-weight:bold;margin-bottom:12px;}
      #${EVENT_PANEL_ID} .mdz-event-grid{display:grid;grid-template-columns:1fr;gap:6px;}
      #${EVENT_PANEL_ID} .mdz-event-row{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:36px;padding:4px 8px;background:rgba(0,0,0,.22);border:1px solid #6b4324;border-radius:4px;box-sizing:border-box;}
      #${EVENT_PANEL_ID} .mdz-event-name{font-size:13px;line-height:1.2;}
      #${EVENT_PANEL_ID} .mdz-event-toggle,#${EVENT_PANEL_ID} .mdz-event-action{min-width:78px;height:30px;border:0;border-radius:4px;background:url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;color:#fff;font-family:"Times New Roman",serif;font-size:12px;cursor:pointer;text-shadow:1px 1px 1px rgba(0,0,0,.7);}
      #${EVENT_PANEL_ID} .mdz-event-toggle:hover,#${EVENT_PANEL_ID} .mdz-event-action:hover{background-position:-1px -165px;}
      #${EVENT_PANEL_ID} .mdz-event-toggle.off{color:#ff7777;}
      #${EVENT_PANEL_ID} .mdz-event-toggle.on{color:#0f8;}
      #${EVENT_PANEL_ID} .mdz-event-sep{margin:9px 0 4px;color:#ffd36a;font-size:12px;font-weight:bold;}
      #${EVENT_PANEL_ID} .mdz-event-actions{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-top:10px;}
    `;
    document.head.appendChild(style);
  }

  function createModal() {
    if (document.getElementById(MODAL_ID)) return;
    injectModalStyles();

    const modal = document.createElement('div');
    modal.id = MODAL_ID;
    modal.innerHTML = `
      <div class="mdz-box">
        <div class="mdz-title">Restart Required</div>
        <div class="mdz-text">
          Please restart the game for the language changes to take effect.
        </div>
        <div class="mdz-btns">
          <div class="mdz-restart-btn" id="mdz-lang-id-restart-now">Restart Now</div>
          <div class="mdz-restart-btn mdz-later" id="mdz-lang-id-restart-later">Restart Later</div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('mdz-lang-id-restart-now').onclick = function () {
      location.reload();
    };
    document.getElementById('mdz-lang-id-restart-later').onclick = function () {
      modal.style.display = 'none';
    };

    modal.addEventListener('click', function (e) {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  function showRestartPrompt() {
    try {
      createModal();
      const modal = document.getElementById(MODAL_ID);
      if (modal) modal.style.display = 'flex';
    } catch (err) {
      console.error('[MDZ Bahasa] Gagal menampilkan modal restart:', err);
    }
  }

  function selectLanguage(code) {
    try {
      setSelectedLang(code);
    } catch (err) {
      console.error('[MDZ Bahasa] Gagal menyimpan preferensi:', err);
    }
    hideDropdown();
    updateButtonLabel();
    showRestartPrompt();
  }

  window.MDZ.langId = {
    getSelectedLang,
    selectLanguage,

    isEnabled: () => getSelectedLang() === 'id',
    enableIndonesian: () => selectLanguage('id'),
    disableIndonesian: () => selectLanguage('en')
  };


  function getEventController() {
    return window.MDZRealEvents || null;
  }

  function setAllEventsEnabled(enabled) {
    const c = getEventController();
    if (!c) return false;

    try {
      if (typeof c.setAllEnabled === 'function') c.setAllEnabled(!!enabled);
      if (typeof c.setAllNativeEnabled === 'function') {
        c.setAllNativeEnabled(!!enabled);
      } else if (typeof c.setNativeEnabled === 'function' && c.nativeEventEnabled) {
        ['heliDown', 'convoy', 'toxicGas'].forEach(function (key) {
          c.setNativeEnabled(key, !!enabled);
        });
      }
      return true;
    } catch (err) {
      console.warn('[MDZ EVENT MENU] Gagal mengubah semua event:', err);
      return false;
    }
  }

  function createEventPanel() {
    if (document.getElementById(EVENT_PANEL_ID)) return;
    const panel = document.createElement('div');
    panel.id = EVENT_PANEL_ID;
    panel.innerHTML = `
      <div class="mdz-event-box">
        <div class="mdz-event-title">EVENT CONTROL</div>
        <div class="mdz-event-grid" id="mdz-event-grid"></div>
        <div class="mdz-event-actions">
          <button class="mdz-event-action" id="mdz-event-onall">ON ALL</button>
          <button class="mdz-event-action" id="mdz-event-offall">OFF ALL</button>
          <button class="mdz-event-action" id="mdz-event-close">CLOSE</button>
        </div>
      </div>`;
    document.body.appendChild(panel);

    document.getElementById('mdz-event-onall').addEventListener('click', function () {
      setAllEventsEnabled(true);
      renderEventPanel();
    });
    document.getElementById('mdz-event-offall').addEventListener('click', function () {
      setAllEventsEnabled(false);
      renderEventPanel();
    });
    document.getElementById('mdz-event-close').addEventListener('click', hideEventPanel);
    panel.addEventListener('click', function (e) {
      if (e.target === panel) hideEventPanel();
    });
  }

  function renderEventPanel() {
    createEventPanel();
    const panel = document.getElementById(EVENT_PANEL_ID);
    const grid = document.getElementById('mdz-event-grid');
    const c = getEventController();

    const names = c && c.names ? c.names : {
      burning:'Burning Area', zombie:'Zombie Horde', supply:'Supply Drop',
      radio:'Radio Signal', truck:'Military Supply Truck', airdrop:'AirDrop',
      helicopter:'Helicopter Supply', patrol:'Military Patrol', banditcamp:'Bandit Camp'
    };
    const order = ['burning','zombie','supply','radio','truck','airdrop','helicopter','patrol','banditcamp'];
    const nativeNames = {
      heliDown:'Heli Down',
      convoy:'Convoy',
      toxicGas:'Toxic Gas'
    };

    let html = '';
    if (!c) {
      html += '<div class="mdz-event-row"><span class="mdz-event-name">Event system belum siap</span><button class="mdz-event-toggle off" type="button" disabled>WAIT</button></div>';
    }
    html += '<div class="mdz-event-sep">CUSTOM EVENTS</div>';
    for (const key of order) {
      const enabled = c && typeof c.isEnabled === 'function' ? c.isEnabled(key) : false;
      html += `<div class="mdz-event-row"><span class="mdz-event-name">${names[key] || key}</span><button class="mdz-event-toggle ${enabled?'on':'off'}" data-event="${key}">${enabled?'ON':'OFF'}</button></div>`;
    }
    html += '<div class="mdz-event-sep">CHEST.JS EVENTS</div>';
    for (const key of ['heliDown','convoy','toxicGas']) {
      const enabled = c && c.nativeEventEnabled ? !!c.nativeEventEnabled[key] : false;
      html += `<div class="mdz-event-row"><span class="mdz-event-name">${nativeNames[key]}</span><button class="mdz-event-toggle ${enabled?'on':'off'}" data-native="${key}">${enabled?'ON':'OFF'}</button></div>`;
    }
    grid.innerHTML = html;

    grid.querySelectorAll('[data-event]').forEach(btn => {
      btn.addEventListener('click', function () {
        const controller = getEventController();
        if (controller && typeof controller.setEnabled === 'function') {
          controller.setEnabled(this.dataset.event, !controller.isEnabled(this.dataset.event));
        }
        renderEventPanel();
      });
    });
    grid.querySelectorAll('[data-native]').forEach(btn => {
      btn.addEventListener('click', function () {
        const controller = getEventController();
        const key = this.dataset.native;
        if (controller && typeof controller.setNativeEnabled === 'function') {
          const current = controller.nativeEventEnabled && controller.nativeEventEnabled[key];
          controller.setNativeEnabled(key, !current);
        }
        renderEventPanel();
      });
    });
  }

  function showEventPanel() {
    hideDropdown();
    renderEventPanel();
    const panel = document.getElementById(EVENT_PANEL_ID);
    if (panel) panel.style.display = 'flex';

    // chest_gl.js dapat memasang MDZRealEvents sedikit setelah menu dibuat.
    // Refresh beberapa kali agar tombol langsung tersambung tanpa reload.
    [100, 300, 700, 1200].forEach(function (delay) {
      setTimeout(function () {
        if (document.getElementById(EVENT_PANEL_ID)?.style.display === 'flex') {
          renderEventPanel();
        }
      }, delay);
    });
  }

  function hideEventPanel() {
    const panel = document.getElementById(EVENT_PANEL_ID);
    if (panel) panel.style.display = 'none';
  }

  function createDropdown() {
    if (document.getElementById(DROPDOWN_ID)) return;
    injectModalStyles();

    const dd = document.createElement('div');
    dd.id = DROPDOWN_ID;
    dd.innerHTML = `<div class="mdz-lang-grid"></div>`;
    document.body.appendChild(dd);


    dd.addEventListener('click', function (e) {
      if (e.target === dd) hideDropdown();
    });
  }

  function renderDropdownOptions() {
    const dd = document.getElementById(DROPDOWN_ID);
    if (!dd) return;
    const grid = dd.querySelector('.mdz-lang-grid');
    grid.innerHTML = `<div class="mdz-lang-row mdz-event-menu-btn" id="mdz-open-event-control">⚙ EVENT CONTROL</div>`;
    const eventBtn = document.getElementById('mdz-open-event-control');
    if (eventBtn) eventBtn.addEventListener('click', function () {
      hideDropdown();
      showEventPanel();
    });
  }

  function showDropdown() {
    const dd = document.getElementById(DROPDOWN_ID);
    if (!dd) return;
    renderDropdownOptions();
    dd.style.display = 'flex';
  }

  function hideDropdown() {
    const dd = document.getElementById(DROPDOWN_ID);
    if (dd) dd.style.display = 'none';
  }


  const BTN_ID = 'mdz-menu-under-tutorial';
  const POSITION = { left: '0%', width: '22%', top: '85%', height: '9%' };

  let _cachedPropNames = null;

  function detectPropNames(runtime) {
    if (_cachedPropNames) return;
    const isMinified = 'S' in runtime;
    _cachedPropNames = {
      layout: isMinified ? 'wa' : 'running_layout'
    };
  }

  function getRuntime() {
    const runtime = window.cr_getC2Runtime ? window.cr_getC2Runtime() : null;
    if (runtime && !_cachedPropNames) detectPropNames(runtime);
    return runtime;
  }


  function getGlobalVarsStandalone(rt) {
    for (const key in rt) {
      const arr = rt[key];
      if (Array.isArray(arr) && arr.length > 5 && arr[0] && typeof arr[0].name === 'string' && arr[0].hasOwnProperty('data')) {
        if (arr.some(v => v.name && v.name.toLowerCase().includes('unlock'))) {
          return arr;
        }
      }
    }
    return [];
  }

  function isOnMenuScreen() {
    try {
      const runtime = getRuntime();
      if (!runtime || !_cachedPropNames) return false; 
      const layoutObj = runtime[_cachedPropNames.layout];
      if (!layoutObj || !layoutObj.name) return false;
      if (layoutObj.name !== 'Menu') return false;


      try {
        const vars = getGlobalVarsStandalone(runtime);
        const section = vars.find(v => v.name === 'menu_section');
        if (section && section.data !== 'main') return false;
      } catch (e) { /* kalau gagal baca, biarkan tetap tampil (fallback aman) */ }

      return true;
    } catch (e) {
      return false;
    }
  }

  function injectButtonStyles() {
    if (document.getElementById(BTN_ID + '-style')) return;
    const style = document.createElement('style');
    style.id = BTN_ID + '-style';
    style.textContent = `
      #${BTN_ID} {
        position: fixed;
        left: ${POSITION.left};
        top: ${POSITION.top};
        width: ${POSITION.width};
        height: ${POSITION.height};
        z-index: 99997;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-sizing: border-box;
        background: url('images/menu_btn_wood-sheet0.png') no-repeat -1px -1px;
        background-size: auto;
        color: #ffffff;
        font-family: "Times New Roman", serif;
        font-size: 13px;
        text-shadow: 1px 1px 1px rgba(0,0,0,0.7);
        letter-spacing: 1px;
        text-align: center;
        padding: 0 4px;
      }
      #${BTN_ID}:hover { background-position: -1px -165px; }
      #${BTN_ID}:active { transform: scale(0.97); }
    `;
    document.head.appendChild(style);
  }

  function createButton() {
    injectButtonStyles();
    createDropdown();
    let btn = document.getElementById(BTN_ID);
    if (btn) btn.remove();

    btn = document.createElement('div');
    btn.id = BTN_ID;
    document.body.appendChild(btn);

    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      const dd = document.getElementById(DROPDOWN_ID);
      if (dd && dd.style.display === 'flex') hideDropdown();
      else showDropdown();
    });

    updateButtonLabel();
    return btn;
  }

  function updateButtonLabel() {
    const btn = document.getElementById(BTN_ID);
    if (!btn) return;
    btn.textContent = '⚙ EVENT CONTROL';
  }

  function updateButtonVisibility() {
    const btn = document.getElementById(BTN_ID);
    if (!btn) return;
    const visible = isOnMenuScreen();
    btn.style.display = visible ? 'flex' : 'none';
    if (!visible) hideDropdown();
  }

  createButton();
  updateButtonVisibility();
  setInterval(function () {
    updateButtonVisibility();
    updateButtonLabel();
  }, 500);
  window.addEventListener('resize', function () { hideDropdown(); hideEventPanel(); });
})();
