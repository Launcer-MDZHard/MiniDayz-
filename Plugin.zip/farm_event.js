(function () {
  'use strict';

  // Allow the updated script to replace an older copy after re-injection.
  // The game should still be reloaded once before testing to avoid duplicate timers.
  if (window.MDZBananaTreeCustom && window.MDZBananaTreeCustom.version === '2.5.0-tree-field-straight-2row-countdown') return;

  var PLAYER_TYPE = 't181';
  var TREE_TYPES = ['t209', 't581', 't577'];
  var COLLISION_TYPE = 't345';
  var INTERACT_DISTANCE = 140;
  var SPAWN_DISTANCE = 200;
  var TREE_FIELD_MIN_COUNT = 4;
  var TREE_FIELD_MAX_COUNT = 10;
  var TREE_FIELD_SPACING = 125;
  var TREE_FIELD_ROW_SPACING = 125; // jarak antar baris atas/bawah
  var TREE_FIELD_MIN_FROM_PLAYER = 260;
  var TREE_FIELD_MAX_FROM_PLAYER = 520;
  var TREE_FIELD_RETRY_COUNT = 36;
  var TREE_FIELD_EVENT_INTERVAL = 15000; // jeda 15 detik setelah event selesai
  var TREE_FIELD_INITIAL_DELAY = 15000; // event pertama 15 detik setelah runtime siap
  var TREE_FIELD_ACTIVE_DURATION = 300000; // event aktif 5 menit
  var TREE_FIELD_MIN_MOVE_DISTANCE = 700; // jarak minimum dari lokasi event sebelumnya
  var TREE_FIELD_NATIVE_CORRIDOR = 105; // area sekitar barisan yang dihitung sebagai pohon asli

  
  var CHOP_WEAPON_IDS = [202, 204, 209, 213]; // Split Axe (Exe), Fireaxe, Sword, Dianju (Gergaji Mesin)
  var CHOP_WEAPON_SLOT_VAR = 4;
  // data.js: Split Axe=1, Fireaxe=5, Sword=15, Dianju=19 in player instance var 4.
  var CHOP_WEAPON_SLOT_VALUES = [1, 5, 15, 19];
  var CHOP_ANIMATIONS = { up: 'h_axe_up', down: 'h_axe_down', left: 'h_axe_left', right: 'h_axe_right' };
  // Chop is unlocked: no inventory/item check is used.
  var CHOP_FALLBACK_DURATION = 360;
  var COLLISION_STANDING_FRAME = 10;
  var COLLISION_CHOPPED_FRAME = 8;

  var CONFIG = {
    t209: {
      name: 'tree_leaves_2',
      standing: 'images/tree_leaves_2-sheet0_custom.png',
      chopped: 'images/tree_leaves_2-sheet1_custom.png'
    },
    t581: {
      name: 'tree_leaves_new3',
      standing: 'images/tree_leaves_new3-sheet0_custom.png',
      chopped: 'images/tree_leaves_new3-sheet1_custom.png'
    },
    t577: {
      name: 'tree_leaves_new2',
      standing: 'images/tree_leaves_new2-sheet0_custom.png',
      chopped: 'images/tree_leaves_new2-sheet1_custom.png',
      lootItemId: 33,
      lootName: 'Orange'
    }
  };

  var WOOD_ITEM_ID = 50;
  var BANANA_ITEM_ID = 7;
  var ORANGE_ITEM_ID = 33;

  var trees = [];

  function runtime() {
    try {
      return window.cr_getC2Runtime ? window.cr_getC2Runtime() : null;
    } catch (e) { return null; }
  }

  function getType(rt, id) {
    try {
      if (rt.types && rt.types[id]) return rt.types[id];
      if (rt.S) {
        for (var i = 0; i < rt.S.length; i++) {
          if (rt.S[i] && rt.S[i].name === id) return rt.S[i];
        }
      }
    } catch (e) {}
    return null;
  }

  function getPlayer(rt) {
    var t = getType(rt, PLAYER_TYPE);
    if (!t) return null;
    try {
      if (t.q && t.q.length) return t.q[0];
      if (t.instances && t.instances.length) return t.instances[0];
    } catch (e) {}
    return null;
  }

  function getPlayerInstanceVar(player, index) {
    if (!player) return undefined;
    try {
      if (Array.isArray(player.instance_vars) && index < player.instance_vars.length) return player.instance_vars[index];
    } catch (e) {}
    try {
      if (Array.isArray(player.instanceVars) && index < player.instanceVars.length) return player.instanceVars[index];
    } catch (e2) {}
    try {
      if (player.extra && Array.isArray(player.extra.instance_vars) && index < player.extra.instance_vars.length) return player.extra.instance_vars[index];
    } catch (e3) {}
    return undefined;
  }

  function hasChopWeaponEquipped(player) {
    var raw = getPlayerInstanceVar(player, CHOP_WEAPON_SLOT_VAR);
    var slot = Number(raw);
    // Some runtime builds do not expose Construct instance_vars even though
    // the item is visibly equipped. Never block the button in that case.
    if (raw === undefined || raw === null || Number.isNaN(slot)) {
      console.warn('[Banana Tree] Slot item tidak terbaca; lanjutkan karena item terlihat di player.');
      return true;
    }
    if (CHOP_WEAPON_SLOT_VALUES.indexOf(slot) !== -1) return true;
    console.warn('[Banana Tree] Slot bukan alat tebang:', slot, '| tetap lanjut untuk kompatibilitas runtime.');
    return true;
  }

  // player_hands is the native weapon/hand sprite used by the game.
  function getPlayerHands(rt, player) {
    var t = getType(rt, 'player_hands');
    if (!t) return null;
    try {
      var list = (t.q && t.q.length) ? t.q : ((t.instances && t.instances.length) ? t.instances : null);
      if (!list || !list.length) return null;
      if (list.length === 1) return list[0];
      var best = null, bestD = Infinity;
      for (var i = 0; i < list.length; i++) {
        var h = list[i];
        if (!h || h.qs) continue;
        if (player && typeof h.x === 'number' && typeof h.y === 'number') {
          var dx = h.x - player.x, dy = h.y - player.y;
          var d = dx * dx + dy * dy;
          if (d < bestD) { bestD = d; best = h; }
        }
      }
      return best || list[0] || null;
    } catch (e) { return null; }
  }

  function getHandsAnimation(hands) {
    if (!hands) return null;
    try {
      if (typeof hands.animationName === 'string' && hands.animationName) return hands.animationName;
      if (typeof hands.cur_anim_name === 'string' && hands.cur_anim_name) return hands.cur_anim_name;
      if (hands.cur_animation && typeof hands.cur_animation.name === 'string') return hands.cur_animation.name;
      if (hands.cur_animation && typeof hands.cur_animation.Z === 'string') return hands.cur_animation.Z;
    } catch (e) {}
    return null;
  }

  function findHandsAnimation(hands, name) {
    try {
      var type = hands && hands.type;
      if (!type) return null;
      var byName = type.animations_by_name || type.animationsByName;
      if (byName) {
        if (byName[name]) return byName[name];
        if (typeof byName.get === 'function') {
          var got = byName.get(name);
          if (got) return got;
        }
      }
      var arr = type.animations || type.anims;
      if (arr && arr.length) {
        for (var i = 0; i < arr.length; i++) {
          var a = arr[i];
          if (a && (a.name === name || a.id === name || a.Z === name)) return a;
        }
      }
    } catch (e) {}
    return null;
  }

  function setHandsAnimation(hands, name) {
    if (!hands || !name) return false;
    var changed = false;
    try {
      if (typeof hands.SetAnim === 'function') { hands.SetAnim(name); changed = true; }
      else if (typeof hands.setAnimation === 'function') { hands.setAnimation(name); changed = true; }
      else if (typeof hands.SetAnimation === 'function') { hands.SetAnimation(name); changed = true; }
    } catch (e) {}

    if (!changed) {
      try {
        var anim = findHandsAnimation(hands, name);
        if (anim) {
          hands.cur_animation = anim;
          hands.cur_frame = 0;
          if (typeof anim.speed === 'number') hands.cur_anim_speed = anim.speed;
          if (typeof anim.repeatto === 'number') hands.cur_anim_repeatto = anim.repeatto;
          hands.cur_anim_repeating = false;
          hands.animPlaying = true;
          hands.animFinished = false;
          try { hands.animationName = name; } catch (e3) {}
          try { hands.cur_anim_name = name; } catch (e4) {}
          changed = true;
        }
      } catch (e2) {}
    }
    if (!changed) {
      // Additional Construct runtime fallback: several builds expose the
      // animation controller through lowercase/internal fields only.
      try {
        var anim2 = findHandsAnimation(hands, name);
        if (anim2) {
          hands.cur_animation = anim2;
          hands.cur_frame = 0;
          hands.cur_anim_frame = 0;
          hands.cur_anim_name = name;
          hands.animationName = name;
          hands.animPlaying = true;
          hands.animFinished = false;
          changed = true;
        }
      } catch (e7) {}
    }
    if (changed) {
      try { if (typeof hands.P === 'function') hands.P(); } catch (e5) {}
      try { if (typeof hands.markDirty === 'function') hands.markDirty(); } catch (e6) {}
      try { var rt = runtime(); if (rt) rt.redraw = true; } catch (e8) {}
    }
    return changed;
  }

  function getChopDirection(player) {
    var a = 0;
    try { a = typeof player.angle === 'number' ? player.angle : (typeof player.u === 'number' ? player.u : 0); } catch (e) {}
    var deg = a * 180 / Math.PI;
    while (deg < 0) deg += 360;
    deg %= 360;
    if (deg >= 45 && deg < 135) return 'down';
    if (deg >= 135 && deg < 225) return 'left';
    if (deg >= 225 && deg < 315) return 'up';
    return 'right';
  }

  function getChopAnimationDuration(hands, name) {
    try {
      var anim = findHandsAnimation(hands, name);
      if (anim) {
        var frames = anim.frames || anim.F || anim.images;
        var count = frames && frames.length ? frames.length : 0;
        var speed = Number(anim.speed);
        if (count > 0 && speed > 0) return Math.max(180, Math.round((count / speed) * 1000 + 50));
      }
    } catch (e) {}
    return CHOP_FALLBACK_DURATION;
  }

  function getTreeLayer(rt, fallback) {
    try {
      var layout = rt && rt.wa;
      var layers = layout && layout.ua;
      if (layers && layers.length) {
        for (var i = 0; i < layers.length; i++) {
          var layer = layers[i];
          var name = String(layer && layer.name || '').toLowerCase();
          if (name === 'trees' || name.indexOf('tree') !== -1 || name.indexOf('forest') !== -1) return layer;
        }
      }
    } catch (e) {}
    return fallback || null;
  }

  function getImage(src, cb) {
    var im = new Image();
    im.onload = function () { cb(null, im); };
    im.onerror = function () { cb(new Error('Image load failed: ' + src)); };
    im.src = src;
  }

  function getImageDims(inst) {
    var f = inst && inst.mc;
    var w = f && Number(f.width);
    var h = f && Number(f.height);
    if (!(w > 0)) w = Number(inst.width) || 1;
    if (!(h > 0)) h = Number(inst.height) || 1;
    return { w: w, h: h };
  }

  function makeCustomFrame(rt, inst, img, src, targetW, targetH, forcedW, forcedH) {
    try {
      if (!rt || !rt.H || typeof rt.H.fd !== 'function' || !inst || !inst.mc) return false;

      // Use the same texture-wrapper path as the game's working custom-texture system.
      var texWrapper = rt.H.fd(img, true, rt.Sa, rt.Df);
      inst.$n = texWrapper;

      var old = inst.mc;
      var frame = Object.create(Object.getPrototypeOf(old));
      Object.assign(frame, old);
      frame.N = img;
      frame.O = texWrapper;
      frame.Ni = src;
      frame.Wj = 0;
      frame.Xj = 0;
      frame.jk = false;
      frame.rr = '';
      inst.mc = frame;

      var ow = Number(targetW) || Number(inst.width) || img.naturalWidth || img.width || 1;
      var oh = Number(targetH) || Number(inst.height) || img.naturalHeight || img.height || 1;
      var iw = img.naturalWidth || img.width || 1;
      var ih = img.naturalHeight || img.height || 1;
      var scale = Math.min(ow / iw, oh / ih);
      if (!(scale > 0) || !isFinite(scale)) scale = 1;

      // When chopped, use the exact rendered dimensions captured while standing.
      // This prevents a different chopped-image aspect ratio from changing tree size.
      if (Number(forcedW) > 0 && Number(forcedH) > 0) {
        inst.width = Number(forcedW);
        inst.height = Number(forcedH);
      } else {
        inst.width = iw * scale;
        inst.height = ih * scale;
      }

      if (typeof inst.P === 'function') inst.P();
      if (inst.type) inst.type.Hn = true;
      rt.redraw = true;
      return true;
    } catch (e) {
      console.error('[Banana Tree] custom frame error:', e);
      return false;
    }
  }

  function applyVisual(rt, tree, chopped) {
    var src = chopped ? tree.cfg.chopped : tree.cfg.standing;
    if (tree.visualSrc === src && tree.visualReady) return;
    tree.visualSrc = src;
    tree.visualReady = false;

    getImage(src, function (err, img) {
      if (err || !tree.inst) {
        if (err) console.error('[Banana Tree]', err.message);
        return;
      }
      if (tree.inst.qs) return;
      var forcedW = chopped ? tree.standingW : 0;
      var forcedH = chopped ? tree.standingH : 0;
      if (makeCustomFrame(rt, tree.inst, img, src, tree.targetW, tree.targetH, forcedW, forcedH)) {
        // Kunci kaki/bawah pohon ke titik tanah native. Ini penting untuk
        // t577 karena sprite custom jeruk lebih pendek daripada sprite asli.
        if (tree.groundY > 0 && tree.inst) {
          tree.inst.y = tree.groundY - (Number(tree.inst.height) || 0) * 0.5;
          if (typeof tree.inst.P === 'function') tree.inst.P();
        }
        if (!chopped) {
          tree.standingW = Number(tree.inst.width) || tree.targetW;
          tree.standingH = Number(tree.inst.height) || tree.targetH;
          console.log('[Banana Tree] standing size:', Math.round(tree.standingW), 'x', Math.round(tree.standingH));
        } else {
          console.log('[Banana Tree] chopped size forced to standing:', Math.round(tree.standingW), 'x', Math.round(tree.standingH));
        }
        tree.visualReady = true;
        tree.inst.__mdzBananaCustom = true;
        tree.inst.__mdzBananaChopped = !!chopped;
      }
    });
  }

  function findSolidBehavior(inst) {
    try {
      var da = inst && inst.da;
      if (!da) return null;
      if (Array.isArray(da)) {
        for (var i = 0; i < da.length; i++) {
          var b = da[i];
          if (!b) continue;
          var name = '';
          try { name = String(b.type && b.type.behavior && b.type.behavior.name || ''); } catch (e) {}
          if (name.toLowerCase() === 'solid') return b;
          if (b.inst && b.inst.extra && Object.prototype.hasOwnProperty.call(b.inst.extra, 'solidEnabled')) return b;
          if (b.extra && Object.prototype.hasOwnProperty.call(b.extra, 'solidEnabled')) return b;
        }
      } else {
        for (var k in da) {
          if (!Object.prototype.hasOwnProperty.call(da, k)) continue;
          var x = da[k];
          if (!x) continue;
          var n = '';
          try { n = String(x.type && x.type.behavior && x.type.behavior.name || ''); } catch (e2) {}
          if (n.toLowerCase() === 'solid') return x;
          if (x.inst && x.inst.extra && Object.prototype.hasOwnProperty.call(x.inst.extra, 'solidEnabled')) return x;
        }
      }
    } catch (e3) {}
    return null;
  }

  function setSolidEnabled(behavior, enabled) {
    if (!behavior) return false;
    try {
      if (behavior.inst && behavior.inst.extra) {
        behavior.inst.extra.solidEnabled = !!enabled;
        return true;
      }
      if (behavior.extra) {
        behavior.extra.solidEnabled = !!enabled;
        return true;
      }
      if (behavior.behavior && behavior.behavior.acts && typeof behavior.behavior.acts.SetEnabled === 'function') {
        behavior.behavior.acts.SetEnabled.call(behavior, enabled ? 1 : 0);
        return true;
      }
    } catch (e) {}
    return false;
  }

  /*
   * Invisible solid proxy.
   * t242 is a known Sprite type with Construct 2 Solid behavior in data.js.
   * It is used only as the collision body; the banana tree remains visual.
   */
  function createCollisionProxy(rt, tree) {
    if (tree.proxy && !tree.proxy.qs) return tree.proxy;
    var solidType = getType(rt, COLLISION_TYPE);
    if (!solidType || typeof rt.Yn !== 'function') {
      console.warn('[Banana Tree] Collision type t345 not available.');
      return null;
    }

    try {
      // t345 is the game's real Solid obstacle-base type used by tree interaction.
      // Put it on the same layer/position as the clone so the original chop event can see it.
      var layer = tree.inst.C || getTreeLayer(rt, null);
      var p = rt.Yn(solidType, layer, tree.inst.x, tree.inst.y);
      if (!p) return null;

      p.__mdzBananaSolidProxy = true;
      p.__mdzBananaOwner = tree.inst.uid;
      p.opacity = 0;
      p.visible = true;
      // IMPORTANT: native tree logic recognizes an active tree collision as t345 frame 10.
      // Frame 0 is not the tree's native interaction state.
      try { if (typeof p.Br === 'function') p.Br(COLLISION_STANDING_FRAME); else p.Y = COLLISION_STANDING_FRAME; } catch (e0) {}

      // Match the native tree interaction area at the trunk/base.
      p.width = Math.max(48, tree.inst.width * 0.72);
      p.height = Math.max(42, tree.inst.height * 0.34);
      p.x = tree.inst.x;
      p.y = tree.inst.y + tree.inst.height * 0.40;
      if (typeof p.P === 'function') p.P();

      var b = findSolidBehavior(p);
      if (b) setSolidEnabled(b, true);
      p.collisionsEnabled = true;
      if (p.type) p.type.Hn = true;
      rt.redraw = true;
      tree.proxy = p;
      tree.proxyBehavior = b;
      return p;
    } catch (e) {
      console.error('[Banana Tree] collision proxy error:', e);
      return null;
    }
  }

  function updateCollision(tree, chopped) {
    var rt = runtime();
    if (!rt || !tree.inst) return;

    if (!chopped) {
      var p = createCollisionProxy(rt, tree);
      if (p) {
        p.x = tree.inst.x;
        p.y = tree.inst.y + tree.inst.height * 0.40;
        p.width = Math.max(48, tree.inst.width * 0.72);
        p.height = Math.max(42, tree.inst.height * 0.34);
        if (typeof p.P === 'function') p.P();
        setSolidEnabled(tree.proxyBehavior || findSolidBehavior(p), true);
        p.collisionsEnabled = true;
      }
    } else if (tree.proxy) {
      // Keep the native proxy object alive, but switch it to the same chopped
      // collision frame used by the original tree (frame 8).
      try {
        if (typeof tree.proxy.Br === 'function') tree.proxy.Br(COLLISION_CHOPPED_FRAME);
        else tree.proxy.Y = COLLISION_CHOPPED_FRAME;
      } catch (e) {}
      setSolidEnabled(tree.proxyBehavior || findSolidBehavior(tree.proxy), false);
      tree.proxy.collisionsEnabled = false;
      tree.proxy.visible = true;
      tree.proxy.opacity = 0;
      if (typeof tree.proxy.P === 'function') tree.proxy.P();
    }
  }

  function spawnDrop(itemId, x, y) {
    try {
      if (typeof window.c2_callFunction !== 'function') return false;
      // Native game function: one physical item drop at world position.
      window.c2_callFunction('Spawn_drop', [itemId, x, y, -1]);
      return true;
    } catch (e) {
      console.warn('[Banana Tree] Spawn_drop failed:', e);
      return false;
    }
  }

  function dropLoot(tree) {
    if (tree.lootDropped) return;
    tree.lootDropped = true;

    var x = tree.inst.x;
    var y = tree.inst.y + Math.max(8, tree.inst.height * 0.18);

    // Semua pohon memberi Wood. Sawit (t581) hanya memberi Wood.
    // Banana (t209) tetap memberi Banana, sedangkan Jeruk (t577) memberi Orange.
    spawnDrop(WOOD_ITEM_ID, x, y);

    if (tree.id === 't581') {
      console.log('[Banana Tree] Loot dropped: Sawit -> Wood x1');
      return;
    }

    var fruitId = tree.cfg && tree.cfg.lootItemId ? tree.cfg.lootItemId : BANANA_ITEM_ID;
    spawnDrop(fruitId, x + 14, y);
    var fruitName = fruitId === ORANGE_ITEM_ID ? 'Orange' : 'Banana';
    console.log('[Banana Tree] Loot dropped: Wood x1 + ' + fruitName + ' x1');
  }

  var chopButton = null;
  var chopButtonTree = null;
  var chopButtonDragging = false;
  var chopButtonMoved = false;
  var chopButtonPointerId = null;
  var chopButtonDragOffsetX = 0;
  var chopButtonDragOffsetY = 0;
  var CHOP_BUTTON_IMAGE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAKWUlEQVR4nO2aW4xdV3mAv7X2fZ8zc8bj8YwdMDaDSRAxVCEEhVqhIojEBBkimVayUEFFPPDEUxWpzUsQUlUJVTRQKU2bNi9UiSoSP1SRkoe0qCjNBZI2IU0ocmLZjmcynvFczmVf16UPx2cu9ky694zHLz3f0zl77/Wftf7zr/+2NgwZMmTIkCFDhgz5/4mo8/ALpx+dHtnT2Dfqers1nw/kYpK/e+yeb82vn8fg2nZlVlbAC6cfnRae+Osw9E/4nrvpM1IKpABtLNZu/C5E//NmDO5b2x+3lezQd5Eldy50uw8GgXfC8xx8z2V2JZ/crhI2X8kmxA33wYuXeyeWZlYAmJu/TBQGpFlOp9Nl/9QEwiiSNCXJS8rSEAUuvueQ5CWulPies6nswX1lDGVprrk/uW8vwmpGQsnN0x966dzsZQoFoyNNpsabjAbyEjABdIG86preeP5xW1kBV/PKr/6Lw4du4uy5GV7/zducOnmcs+cu8sprbwIwO7eA0Yow8JBCYLFI6eA5Eiks2gqMBUeABUqlMcYghaDdTWm1RhlrjQDwtfvu5vyFWV59/S3+6Ov3cPb8RaamJvnM792K1oZz5y8APAScAR6us45aCpBS4DoCbSynTh4nDFw+d/un+OY3jhP4Lnd+9lOcOnkcgB8/8jOS9iI3f3Q/UeChtCaKm0yOBjQCyUoOhYKGqyms5NJihzRNCX2HX7z8W+758t3ce/fnN/z+N+6/h7LUHL31ltVttlMqK8Ba8U4rDgDopSXiyn5uhFs7xMEzXhDhWY1zxQk0Gg1yoQnKHFdIsqLaHBqhB1d+r5eVZLmqOv0tkVUf/My93/mLyHcfdKUk8B0C///WXeA7uE5/0ZOtmNFGsOG+F0TkIqA0EsdxEKJ6UGqE3pY+pSqf/tKfiMoKAEiT8sk9Tf9fmpFfeYwQG0ONtmv7fbGdkGUFAstos0EUBlvK2S1qKSBuuA8mhT6Rl7ryGN91kM6aCnIt6fQyiqIgdg0jnsaVFteWSKrL1dpgzM6dQC0FbIdCaYxem2jsGkYbAb7v4zgOBQ7KCJaTnLTGns5KjdLXhsy6VHaCL5x+dFpps0/X1PrAArQFYwEBeZ5TFDDaiGhQonSJFwcYVVReVOg5KLVzBVS2gO2YP6xZQK4lyqxFgTAMSXo9ijxHCstSL6eXVbeAJFeUO1TAjhKhqgwsIHYNpe0rQCmFMfaK59eE0rK3FaO1xuiyklwpBTWCxtZydi7ig7naBwB0uglpluMFEbg+XSURQODJyqHweoRBqJkJbof1UUApheMISsfDIHh/sYMrBUJKNIIwHgHR2+0pbaCWBWwn9OSlpiwVShuStB/+JlsxI7GPVgWhKPAdS+wapC0xZueOrQ61FJDkiqKiE9w/OQHCYW6hzXszc7y/1EV6IY7rY2zfGg4dmGBifHR1TK/XI88rF3PXxQ/s2hY4dfI4Tzz17Gp12O4VNEKPMIpxvIBOr4snwQ3W/oOBU6zKB9UhValdDdbR+KmTx1erwzVlLNHuFUyNx4w1I8y65koYhtSJbDPvz9OIY4py+0VRLQU0Qq9WwbKe9cr48SM/47U332VixCOYGAUk2rLqI6ryHy//J8/+20uPXZy5tAQooPrgK+x6GFzP7Nw8b//uLJ5QdFZWmFtYIclLlDbkWuIFMUEQUtXMvvet+3nsrx747s3TBy8Dfw48UndOux4FYG3hT51+hp/+zd9zeI/lz779BQ4fGOPcXJtO0i+MirSDQbJ3T4vl5RWWVzofKHduscv4nnGe+ocf/iWwF6hdTtbaAlmpKZWu1AsYMDs3z1Onn+Gtt37Hfcc+zte//QWcqIWSPntFQq9cZLDtHcfBWMsdRw/x7L+/ythY65qu0HqSXDEz375xLbHQc2q1oQaLPxAXfPWbx/Ca4zh+RJ5nnDl3kXidIrWFuNGkl2SUFZ3aDQ+DdSxgsPipqGDf5ATLtoHpGqReYnw0wvd9tDEI6SClJNVOP1P0AqytXhFu1ykP2DULePLp52jRpbVninYuWJxZIIqb7B3pt9KNMWgcvCDEIpBY8ixFSImsqICs1LhbHTZUZFcywdm5ebRSrBQOK5nFCyJcr++fci1x/IiRkRHGIhddJKRpiodipBEirEZXrAgboVfLH23GroTBJ59+jjxpc+TQ5GpT1HH6ph44hjTpsrS8QlEUNJtNtNYsJSVL7YQ0zTDXo99dkV1LhYUAay1SSqSUNOMIC+QajHCImx6hVKSlwhiDUgoh+p0jocwNU0JtC9CmWi4Q+P2QFoR9hxe7ZrXq+9B4SORLjDFkWT/7S5IEgDgMUNpQt/W2XWorIC8MpdraDwz2fxh4+K4Durimy1OUmm4vWd0CYRjiOA5aFWRZznXodVamtgICX+K5m3diZufmeeLnz+DajIP7x8lLDY6PdLzVpqi2sNBOEI7fL36UIvAcJif2cHj/OFPjMaEvGRuJKmWDO6W2D0hzjSMlYbBx6OzcPP/0z88QuQVHDh8gzUtcRyJMidElufSx0O/8OAZXWopSkyYJH56aYO9Yk+WVDo4IAfj92z7Gy6//NwD3funY6kHp9aayBVgr3vFdB9+Tm2ZfTz79HEXa5uD+cRw/XA17XhAhHZdIKkLXEDoGA+SlYaGTEQY+joC5hUXmlhN6uWU0Dol8l9uPHualV37Ny6++ueW80izfUTlc62xwXyv8x32tCCnlBkc4OzePNYo9rQYWQVGoKxmawFhLmadoXRJKiwGsVmS9Np7rUuDzzsxl3ru0QqfT67fHc8tEq0EcBow24y23gtaGxaVlHv67Jx7bzuJrnQ0ODkY6aUmnV6w6wsG+j1zNJ458hGajQZGnuK6L64eUZf8cUBvoKolRmqV2D2UsQkKSJIxGHjcf2s/0wX1Iq1joZPRyS9xoctcdn+B/3n6L555/YYMStDZ005Jbpg/ykx9+/7vbUQDUfEOknZYn8lKzsrKMpMniUsbfPv5zbNljcvrDzF3uAtDtprjdkjAM6Xa7WFMSRTGuF2z4ni10cV2XThJyYSEFoMgTkiTjUhQThiFFnnDwpnF+8csXSfOS++/7ImmWoYwgimIWlhMuvL+0rcVv+2DkX3/5K245cpiz597j8lL/X3npjfM4UiBl/wUKQb9aS7OcwHNxXfeq5GZxU9mDsZbF/uGJFFjAD5u89sZvOTJ9mHMXLnLTgUlu+/Qnb3xTVErBya99GYCjn/w4J77yxdV7UeAS+C69rMSVAmM0Z949T6+98uIfHLvj86Wx9NKcolA0GwGe63J1vjMYq4ylLDVR4KKM3XDt6C3TCAlYTZbpG9MTtFa8k+cFqii2fLUsyzRZ1m9rK+D8ezM88NDDPwLUD6RUt992611n3j3PAw89/KMf/Ol37rz9tlvv6qbXTn5wRVyRefW18zNrcq8aWrsnWNeAPgf8cc0xgy7N+rFngBe3IWszuTui7hboAnVTs8G/sn5ssU1Zm8kdMmTIkCFDhgwZMmRIfWpX0288/7gdazV3Yy6V+Mhn/1BcPY/Bte3wv5FcHr0nw4cpAAAAAElFTkSuQmCC';

  function logChopButtonPosition(reason) {
    if (!chopButton) return null;
    var r = chopButton.getBoundingClientRect();
    var pos = {
      reason: reason || 'position',
      left: Math.round(r.left),
      top: Math.round(r.top),
      right: Math.round(window.innerWidth - r.right),
      bottom: Math.round(window.innerHeight - r.bottom),
      width: Math.round(r.width),
      height: Math.round(r.height),
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight
    };
    console.log('[Banana Tree Button] POSITION', pos);
    return pos;
  }

  function clampChopButtonPosition(left, top) {
    if (!chopButton) return;
    var maxLeft = Math.max(0, window.innerWidth - chopButton.offsetWidth);
    var maxTop = Math.max(0, window.innerHeight - chopButton.offsetHeight);
    left = Math.max(0, Math.min(maxLeft, left));
    top = Math.max(0, Math.min(maxTop, top));
    chopButton.style.left = Math.round(left) + 'px';
    chopButton.style.top = Math.round(top) + 'px';
    chopButton.style.right = 'auto';
    chopButton.style.bottom = 'auto';
  }

  function beginChopButtonDrag(ev) {
    if (!chopButton) return;
    chopButtonDragging = true;
    chopButtonMoved = false;
    chopButtonPointerId = ev.pointerId;
    var r = chopButton.getBoundingClientRect();
    chopButtonDragOffsetX = ev.clientX - r.left;
    chopButtonDragOffsetY = ev.clientY - r.top;
    try { chopButton.setPointerCapture(ev.pointerId); } catch (e) {}
    ev.preventDefault();
    ev.stopPropagation();
  }

  function moveChopButtonDrag(ev) {
    if (!chopButtonDragging || ev.pointerId !== chopButtonPointerId) return;
    var r = chopButton.getBoundingClientRect();
    var left = ev.clientX - chopButtonDragOffsetX;
    var top = ev.clientY - chopButtonDragOffsetY;
    if (Math.abs(left - r.left) > 3 || Math.abs(top - r.top) > 3) chopButtonMoved = true;
    clampChopButtonPosition(left, top);
    ev.preventDefault();
    ev.stopPropagation();
  }

  function endChopButtonDrag(ev) {
    if (!chopButtonDragging || ev.pointerId !== chopButtonPointerId) return;
    chopButtonDragging = false;
    try { chopButton.releasePointerCapture(ev.pointerId); } catch (e) {}
    chopButtonPointerId = null;
    logChopButtonPosition('drag-end');
    ev.preventDefault();
    ev.stopPropagation();
  }

  function ensureChopButton() {
    if (chopButton && document.body.contains(chopButton)) return chopButton;
    chopButton = document.createElement('button');
    chopButton.id = 'mdz-banana-chop-button';
    chopButton.type = 'button';
    chopButton.setAttribute('aria-label', 'Tebang');
    chopButton.style.cssText = [
      'position:fixed','z-index:2147483647','right:36px','bottom:167px',
      'width:80px','height:80px','padding:0','margin:0',
      'border:0','border-radius:0','background-color:transparent',
      'background-image:url(\'images/gui_btn_interact-sheet0_custom.png\')',
      'background-repeat:no-repeat','background-position:-1px -1px',
      'background-size:auto auto','box-shadow:none','display:none',
      'touch-action:none','-webkit-tap-highlight-color:transparent',
      'cursor:grab','user-select:none','-webkit-user-select:none'
    ].join(';');

    chopButton.addEventListener('pointerdown', beginChopButtonDrag, true);
    chopButton.addEventListener('pointermove', moveChopButtonDrag, true);
    chopButton.addEventListener('pointerup', endChopButtonDrag, true);
    chopButton.addEventListener('pointercancel', endChopButtonDrag, true);
    chopButton.addEventListener('click', function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      if (chopButtonMoved) {
        chopButtonMoved = false;
        return;
      }
      if (chopButtonTree) chopTreeNow(chopButtonTree);
    }, true);

    document.body.appendChild(chopButton);
    console.log('[Banana Tree Button] READY - drag me anywhere');
    logChopButtonPosition('initial');
    return chopButton;
  }

  window.MDZBananaTreeChopButtonPosition = function () {
    return logChopButtonPosition('manual');
  };

  function getNearestCustomTree(rt) {
    var p = getPlayer(rt);
    if (!p) return null;
    var best = null, bestD = Infinity;
    for (var i = 0; i < trees.length; i++) {
      var t = trees[i];
      if (!t || !t.inst || t.chopped || t.inst.qs) continue;
      var dx = p.x - t.inst.x, dy = p.y - t.inst.y;
      var d = Math.sqrt(dx * dx + dy * dy);
      if (d <= INTERACT_DISTANCE && d < bestD) { best = t; bestD = d; }
    }
    return best;
  }

  function finishChopTree(tree, hands, previousAnimation) {
    if (!tree || !tree.inst || tree.chopped) return false;
    try {
      if (typeof tree.inst.Br === 'function') tree.inst.Br(1);
      else tree.inst.Y = 1;
    } catch (e) {}
    tree.chopped = true;
    tree.inst.__mdzBananaChopped = true;
    tree.__mdzChopping = false;
    applyVisual(runtime(), tree, true);
    updateCollision(tree, true);
    dropLoot(tree);
    if (hands && previousAnimation) setHandsAnimation(hands, previousAnimation);
    if (chopButton) chopButton.style.display = 'none';
    chopButtonTree = null;
    console.log('[Banana Tree] TEBANG selesai');
    return true;
  }

  function chopTreeNow(tree) {
    if (!tree || !tree.inst || tree.chopped || tree.__mdzChopping) return false;
    var rt = runtime();
    var player = rt && getPlayer(rt);
    if (!player) return false;

    // UNLOCKED: chopping never checks which item is equipped.
    // The native player_hands object is used only for the visual animation.
    var hands = getPlayerHands(rt, player);
    if (!hands) {
      console.warn('[Banana Tree] player_hands tidak ditemukan; pohon tetap akan ditebang.');
    }

    var direction = getChopDirection(player);
    var animationName = CHOP_ANIMATIONS[direction];
    var previousAnimation = hands ? getHandsAnimation(hands) : null;
    var animationStarted = hands ? setHandsAnimation(hands, animationName) : false;
    if (!animationStarted) {
      console.warn('[Banana Tree] Animasi bawaan tidak bisa dipanggil; lanjut tebang dengan durasi fallback:', animationName);
    }

    tree.__mdzChopping = true;
    if (chopButton) chopButton.style.display = 'none';
    chopButtonTree = null;

    // Native event sheets can overwrite player_hands animation on the next tick.
    // Re-assert only if it was overwritten; do not restart every frame.
    var duration = animationStarted ? getChopAnimationDuration(hands, animationName) : CHOP_FALLBACK_DURATION;
    var start = Date.now();
    function keepChopAnimation() {
      if (!tree.__mdzChopping || tree.chopped) return;
      if (hands && getHandsAnimation(hands) !== animationName) setHandsAnimation(hands, animationName);
      if (Date.now() - start < duration) window.requestAnimationFrame(keepChopAnimation);
    }
    window.requestAnimationFrame(keepChopAnimation);

    console.log('[Banana Tree] TEBANG ->', animationName, '| durasi', duration, 'ms');
    window.setTimeout(function () { finishChopTree(tree, hands, previousAnimation); }, duration + 30);
    return true;
  }

  function updateChopButton(rt) {
    var b = ensureChopButton();
    var t = getNearestCustomTree(rt);
    chopButtonTree = t;
    b.style.display = t ? 'block' : 'none';
  }

  function detectChop(tree) {
    if (!tree.inst || tree.chopped) return;

    var frame = -1;
    try {
      frame = Number(tree.inst.Y);
      if (!(frame >= 0)) frame = Number(tree.inst.cur_frame);
    } catch (e) {}

    // The original t209/t581 objects use frame 0 for standing and frame 1 for cut.
    if (frame >= 1) {
      tree.chopped = true;
      tree.inst.__mdzBananaChopped = true;
      applyVisual(runtime(), tree, true);
      updateCollision(tree, true);
      // Do not destroy/hide the proxy: the native event sheet uses t345
      // to complete the tree interaction and expects its chopped frame.
      dropLoot(tree);
      console.log('[Banana Tree] CUT -> collision OFF');
    }
  }

  function spawnTree(requestedId, forcedX, forcedY) {
    var rt = runtime();
    if (!rt || typeof rt.Yn !== 'function') {
      console.error('[Banana Tree] Construct runtime not ready.');
      return null;
    }

    var id = requestedId && CONFIG[requestedId] ? requestedId : TREE_TYPES[Math.floor(Math.random() * TREE_TYPES.length)];
    var cfg = CONFIG[id];
    var type = getType(rt, id);
    var player = getPlayer(rt);

    if (!type || !player) {
      console.error('[Banana Tree] Missing type/player:', id);
      return null;
    }

    var a = typeof player.angle === 'number' ? player.angle : (typeof player.u === 'number' ? player.u : 0);
    var x = (typeof forcedX === 'number') ? forcedX : player.x + Math.cos(a) * SPAWN_DISTANCE;
    var y = (typeof forcedY === 'number') ? forcedY : player.y + Math.sin(a) * SPAWN_DISTANCE;

    var treeLayer = getTreeLayer(rt, player.C);
    var inst = rt.Yn(type, treeLayer, x, y);
    if (!inst) {
      console.error('[Banana Tree] Clone failed:', id);
      return null;
    }

    // Simpan titik tanah dari sprite native sebelum gambar custom dipasang.
    // Ini membuat jeruk mengikuti cara kerja Banana/Sawit: kaki batang tetap
    // berada di titik tanah yang sama walaupun ukuran gambar custom berbeda.
    var nativeGroundY = Number(inst.y) + (Number(inst.height) || 0) * 0.5;

    var tree = {
      inst: inst,
      cfg: cfg,
      targetW: (Number(inst.width) || 57) * (id === 't581' ? 1.55 : 1),
      targetH: (Number(inst.height) || 94) * (id === 't581' ? 1.55 : 1),
      groundY: nativeGroundY,
      id: id,
      proxy: null,
      proxyBehavior: null,
      chopped: false,
      lootDropped: false,
      visualSrc: null,
      visualReady: false,
      standingW: 0,
      standingH: 0
    };

    inst.__mdzBananaTree = true;
    inst.__mdzBananaTreeId = id;
    if (inst.type) inst.type.Hn = true;

    // Start at the original standing frame.
    try {
      if (typeof inst.Br === 'function') inst.Br(0);
      else inst.Y = 0;
    } catch (e) {}

    trees.push(tree);

    // Apply custom standing image and create collision.
    applyVisual(rt, tree, false);
    setTimeout(function () {
      if (!tree.chopped && tree.inst) updateCollision(tree, false);
    }, 150);

    console.log('[Banana Tree] Spawned custom tree:', id, 'near player at', Math.round(x), Math.round(y));
    return inst;
  }

  // =========================
  // TREE FIELD EVENT SYSTEM
  // =========================
  // Satu event hanya memilih SATU jenis pohon, lalu membuat 4-10 pohon
  // dalam satu baris. Setiap titik dicek terhadap pohon native + custom
  // agar sprite/collision tidak saling menimpa.
  function getAllTreeInstances(rt) {
    var out = [];
    var seen = [];
    for (var ti = 0; ti < TREE_TYPES.length; ti++) {
      var type = getType(rt, TREE_TYPES[ti]);
      if (!type) continue;
      var list = (type.q && type.q.length) ? type.q : ((type.instances && type.instances.length) ? type.instances : []);
      for (var i = 0; i < list.length; i++) {
        var inst = list[i];
        if (!inst || inst.qs) continue;
        if (seen.indexOf(inst) !== -1) continue;
        seen.push(inst);
        out.push(inst);
      }
    }
    for (var j = 0; j < trees.length; j++) {
      var ct = trees[j];
      if (ct && ct.inst && !ct.inst.qs && seen.indexOf(ct.inst) === -1) out.push(ct.inst);
    }
    return out;
  }


  function isNativeStandingTree(inst) {
    if (!inst || inst.qs || inst.__mdzBananaTree) return false;
    try {
      var frame = Number(inst.Y);
      if (!(frame >= 0)) frame = Number(inst.cur_frame);
      // Native standing tree = frame 0. If the runtime does not expose a frame,
      // still count the object as a native tree because it occupies the map.
      return !(frame >= 1);
    } catch (e) { return true; }
  }

  function pointToSegmentDistance(px, py, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay;
    var len2 = dx * dx + dy * dy;
    if (len2 <= 0) return Math.hypot(px - ax, py - ay);
    var t = ((px - ax) * dx + (py - ay) * dy) / len2;
    if (t < 0) t = 0; else if (t > 1) t = 1;
    var cx = ax + t * dx, cy = ay + t * dy;
    return Math.hypot(px - cx, py - cy);
  }

  function countNativeTreesInField(rt, centerX, centerY, angle, count, spacing) {
    var all = getAllTreeInstances(rt);
    var halfLen = Math.max(0, ((count - 1) * spacing) * 0.5) + TREE_FIELD_NATIVE_CORRIDOR;
    var ax = centerX - Math.cos(angle) * halfLen;
    var ay = centerY - Math.sin(angle) * halfLen;
    var bx = centerX + Math.cos(angle) * halfLen;
    var by = centerY + Math.sin(angle) * halfLen;
    var total = 0;
    var found = [];
    for (var i = 0; i < all.length; i++) {
      var inst = all[i];
      if (!isNativeStandingTree(inst)) continue;
      var x = Number(inst.x), y = Number(inst.y);
      if (!isFinite(x) || !isFinite(y)) continue;
      if (pointToSegmentDistance(x, y, ax, ay, bx, by) <= TREE_FIELD_NATIVE_CORRIDOR) {
        total++;
        found.push(inst);
      }
    }
    return { count: total, trees: found };
  }

  function treePositionIsFree(rt, x, y, requestedId, ignoreInst) {
    var all = getAllTreeInstances(rt);
    var wantedType = getType(rt, requestedId);
    var baseW = 70;
    var baseH = 90;
    try {
      if (wantedType) {
        var list = (wantedType.q && wantedType.q.length) ? wantedType.q : ((wantedType.instances && wantedType.instances.length) ? wantedType.instances : []);
        if (list.length && list[0]) {
          baseW = Math.max(48, Number(list[0].width) || baseW);
          baseH = Math.max(60, Number(list[0].height) || baseH);
        }
      }
    } catch (e) {}

    for (var i = 0; i < all.length; i++) {
      var other = all[i];
      if (!other || other.qs || other === ignoreInst) continue;
      var ox = Number(other.x), oy = Number(other.y);
      if (!isFinite(ox) || !isFinite(oy)) continue;
      var ow = Math.max(48, Number(other.width) || baseW);
      var oh = Math.max(60, Number(other.height) || baseH);
      var minDistX = Math.max(82, (baseW + ow) * 0.45 + 18);
      var minDistY = Math.max(62, (baseH + oh) * 0.34 + 12);
      if (Math.abs(x - ox) < minDistX && Math.abs(y - oy) < minDistY) return false;
    }
    return true;
  }

  function getTreeFieldLayout(centerX, centerY, count, colSpacing, rowSpacing) {
    // 1-5 pohon: satu baris lurus.
    // 6-10 pohon: dibagi menjadi dua baris lurus, baris atas lalu bawah.
    // Contoh 10 pohon = 5 atas + 5 bawah. Tidak ada pola zig-zag.
    var n = Math.max(0, Number(count) || 0);
    var cols = Math.min(5, Math.max(1, Math.ceil(n / 2)));
    var rows = n <= 5 ? 1 : 2;
    var points = [];
    var topCount = rows === 1 ? n : Math.min(5, Math.ceil(n / 2));
    var bottomCount = rows === 1 ? 0 : n - topCount;
    var topStart = -((topCount - 1) * colSpacing) * 0.5;
    var bottomStart = -((bottomCount - 1) * colSpacing) * 0.5;

    for (var i = 0; i < topCount; i++) {
      points.push({ x: centerX + topStart + i * colSpacing, y: centerY - (rows === 2 ? rowSpacing * 0.5 : 0), row: 'atas', index: i });
    }
    for (var j = 0; j < bottomCount; j++) {
      points.push({ x: centerX + bottomStart + j * colSpacing, y: centerY + rowSpacing * 0.5, row: 'bawah', index: j });
    }
    return points;
  }

  function findTreeFieldOrigin(rt, player, requestedCount, angle, spacing) {
    var previous = lastTreeFieldEvent && isFinite(Number(lastTreeFieldEvent.x)) && isFinite(Number(lastTreeFieldEvent.y))
      ? { x: Number(lastTreeFieldEvent.x), y: Number(lastTreeFieldEvent.y) } : null;
    var fallback = null;
    var fallbackDistance = -1;

    for (var attempt = 0; attempt < TREE_FIELD_RETRY_COUNT; attempt++) {
      var localAngle = 0; // event tree selalu lurus horizontal; tidak belok-belok
      var distance = TREE_FIELD_MIN_FROM_PLAYER + Math.random() * (TREE_FIELD_MAX_FROM_PLAYER - TREE_FIELD_MIN_FROM_PLAYER);
      var centerX = player.x + (Math.random() < 0.5 ? -1 : 1) * distance;
      var centerY = player.y + (Math.random() * 2 - 1) * 120;
      var layout = getTreeFieldLayout(centerX, centerY, requestedCount, spacing, TREE_FIELD_ROW_SPACING);
      var freeSlots = 0;
      for (var i = 0; i < layout.length; i++) {
        if (treePositionIsFree(rt, layout[i].x, layout[i].y, currentTreeFieldType)) freeSlots++;
      }
      if (freeSlots < requestedCount) continue;

      var nativeInfo = countNativeTreesInField(rt, centerX, centerY, localAngle, requestedCount, spacing);
      var moveDistance = previous ? Math.hypot(centerX - previous.x, centerY - previous.y) : Infinity;
      var candidate = {
        x: centerX,
        y: centerY,
        angle: localAngle,
        distanceFromPrevious: previous ? moveDistance : null,
        nativeTreeCount: nativeInfo.count,
        spawnCount: requestedCount,
        layout: layout
      };
      if (!previous || moveDistance >= TREE_FIELD_MIN_MOVE_DISTANCE) return candidate;
      if (moveDistance > fallbackDistance) {
        fallbackDistance = moveDistance;
        fallback = candidate;
      }
    }
    return fallback;
  }

  var currentTreeFieldType = null;
  var treeFieldTimer = null;
  var treeFieldCleanupTimer = null;
  var treeFieldNextTimer = null;
  var treeFieldCountdownTimer = null;
  var treeFieldActiveCountdownTimer = null;
  var lastTreeFieldEvent = null;
  var activeTreeFieldEvent = null;
  var treeFieldEventSeq = 0;

  function startTreeFieldCountdown(delayMs, label) {
    if (treeFieldCountdownTimer) clearInterval(treeFieldCountdownTimer);
    if (treeFieldActiveCountdownTimer) clearInterval(treeFieldActiveCountdownTimer);
    var endAt = Date.now() + Math.max(0, Number(delayMs) || 0);
    var lastSec = -1;
    function tick() {
      var sec = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      if (sec !== lastSec) {
        lastSec = sec;
        if (sec > 0) console.log('[MDZ TREE EVENT COUNTDOWN] ' + (label || 'event berikutnya') + ' dalam ' + sec + ' detik');
        else console.log('[MDZ TREE EVENT COUNTDOWN] waktu habis | mencari dan memilih event berikutnya...');
      }
      if (sec <= 0) {
        clearInterval(treeFieldCountdownTimer);
        treeFieldCountdownTimer = null;
      }
    }
    tick();
    treeFieldCountdownTimer = setInterval(tick, 1000);
  }

  function startTreeFieldActiveCountdown(durationMs) {
    if (treeFieldActiveCountdownTimer) clearInterval(treeFieldActiveCountdownTimer);
    var endAt = Date.now() + Math.max(0, Number(durationMs) || TREE_FIELD_ACTIVE_DURATION);
    var lastSec = -1;
    function tick() {
      var sec = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      if (sec !== lastSec) {
        lastSec = sec;
        var mm = Math.floor(sec / 60);
        var ss = sec % 60;
        var text = String(mm).padStart(2, '0') + ':' + String(ss).padStart(2, '0');
        if (sec > 0) console.log('[MDZ TREE EVENT COUNTDOWN] sisa waktu event: ' + text);
        else console.log('[MDZ TREE EVENT COUNTDOWN] sisa waktu event: 00:00 | event selesai');
      }
      if (sec <= 0) {
        clearInterval(treeFieldActiveCountdownTimer);
        treeFieldActiveCountdownTimer = null;
      }
    }
    tick();
    treeFieldActiveCountdownTimer = setInterval(tick, 1000);
  }

  function spawnTreeFieldEvent() {
    if (activeTreeFieldEvent) {
      console.log('[MDZ TREE EVENT SKIP] event masih aktif selama 5 menit');
      return null;
    }
    var rt = runtime();
    var player = rt && getPlayer(rt);
    if (!rt || !player) {
      console.warn('[MDZ TREE EVENT WAIT] player/runtime belum siap');
      return null;
    }

    var types = TREE_TYPES.slice();
    var chosen = types[Math.floor(Math.random() * types.length)];
    var requestedCount = TREE_FIELD_MIN_COUNT + Math.floor(Math.random() * (TREE_FIELD_MAX_COUNT - TREE_FIELD_MIN_COUNT + 1));
    var spacing = TREE_FIELD_SPACING + Math.floor(Math.random() * 21) - 10;
    currentTreeFieldType = chosen;

    console.log('[MDZ TREE EVENT SELECTED] tipe=' + chosen + ' | target=' + requestedCount + ' | mencari lokasi random...');

    var origin = findTreeFieldOrigin(rt, player, requestedCount, 0, spacing);
    if (!origin) {
      currentTreeFieldType = null;
      console.warn('[MDZ TREE EVENT RETRY] tidak menemukan lokasi valid');
      return null;
    }

    var nativeTreeCount = origin.nativeTreeCount || 0;
    var spawnTarget = requestedCount; // pohon asli TIDAK mengurangi target event
    var spawned = [];
    var checkedSlots = 0;
    var eventId = ++treeFieldEventSeq;
    var layout = origin.layout || getTreeFieldLayout(origin.x, origin.y, requestedCount, spacing, TREE_FIELD_ROW_SPACING);

    for (var i = 0; i < layout.length; i++) {
      var slot = layout[i];
      checkedSlots++;
      if (spawned.length >= spawnTarget) break;
      if (!treePositionIsFree(rt, slot.x, slot.y, chosen)) continue;
      var inst = spawnTree(chosen, slot.x, slot.y);
      if (inst) {
        inst.__mdzTreeFieldEventId = eventId;
        spawned.push(inst);
      }
    }
    currentTreeFieldType = null;


    var previousDistance = origin.distanceFromPrevious == null ? null : Math.round(origin.distanceFromPrevious);
    lastTreeFieldEvent = {
      id: eventId,
      type: chosen,
      count: spawned.length,
      requestedCount: requestedCount,
      nativeTreeCount: nativeTreeCount,
      reducedByNativeTrees: 0,
      timestamp: Date.now(),
      x: origin.x,
      y: origin.y,
      angle: origin.angle,
      spacing: spacing,
      distanceFromPrevious: previousDistance,
      playerDistance: Math.round(Math.hypot(origin.x - player.x, origin.y - player.y)),
      status: 'active',
      activeDurationMs: TREE_FIELD_ACTIVE_DURATION,
      expiresAt: Date.now() + TREE_FIELD_ACTIVE_DURATION
    };
    activeTreeFieldEvent = lastTreeFieldEvent;
    startTreeFieldActiveCountdown(TREE_FIELD_ACTIVE_DURATION);

    if (treeFieldCleanupTimer) clearTimeout(treeFieldCleanupTimer);
    treeFieldCleanupTimer = setTimeout(function () {
      treeFieldCleanupTimer = null;
      removeActiveTreeFieldEvent('timeout-5-menit');
    }, TREE_FIELD_ACTIVE_DURATION);

    console.log('[MDZ TREE EVENT ACTIVE] ' + chosen + ' | lokasi=(' + Math.round(origin.x) + ',' + Math.round(origin.y) + ')' +
      ' | target=' + requestedCount + ' | pohon asli=' + nativeTreeCount +
      ' | spawn event=' + spawned.length + ' | dikurangi=0 (pohon asli hanya obstacle)' +
      ' | durasi aktif=300s' +
      ' | jarak player=' + lastTreeFieldEvent.playerDistance + 'px' +
      ' | jarak event sebelumnya=' + (previousDistance == null ? 'N/A' : previousDistance + 'px') +
      ' | spacing=' + spacing + 'px' +
      ' | layout=' + (requestedCount > 5 ? '2 baris lurus (atas ' + Math.min(5, Math.ceil(requestedCount / 2)) + ' + bawah ' + (requestedCount - Math.min(5, Math.ceil(requestedCount / 2))) + ')' : '1 baris lurus'));

    console.log('[MDZ TREE EVENT LOG] ACTIVE | tipe=' + chosen + ' | ' + spawned.length + '/' + requestedCount +
      ' event tree | native=' + nativeTreeCount + ' | target tidak berkurang | aktif 5 menit | setelah selesai dihapus');

    return lastTreeFieldEvent;
  }

  function removeActiveTreeFieldEvent(reason) {
    if (!activeTreeFieldEvent) return false;
    var event = activeTreeFieldEvent;
    activeTreeFieldEvent = null;
    if (treeFieldActiveCountdownTimer) clearInterval(treeFieldActiveCountdownTimer);
    treeFieldActiveCountdownTimer = null;

    var removed = 0;
    var rt = runtime();
    // Hanya hapus pohon yang dibuat event ini. Pohon asli map tidak disentuh.
    for (var i = trees.length - 1; i >= 0; i--) {
      var t = trees[i];
      if (!t || !t.inst) { trees.splice(i, 1); continue; }
      if (t.inst.__mdzTreeFieldEventId !== event.id) continue;
      try {
        if (t.proxy && rt && typeof rt.bh === 'function') rt.bh(t.proxy);
        else if (t.proxy && rt && typeof rt.$e === 'function') rt.$e([t.proxy]);
      } catch (e0) {}
      try {
        if (t.inst && rt && typeof rt.bh === 'function') rt.bh(t.inst);
        else if (t.inst && rt && typeof rt.$e === 'function') rt.$e([t.inst]);
      } catch (e1) {}
      trees.splice(i, 1);
      removed++;
    }
    if (rt) rt.redraw = true;

    event.status = 'finished';
    event.removedCount = removed;
    event.finishedAt = Date.now();
    event.durationMs = event.finishedAt - event.timestamp;
    lastTreeFieldEvent = event;

    console.log('[MDZ TREE EVENT END] selesai | id=' + event.id +
      ' | tipe=' + event.type +
      ' | durasi=' + Math.round(event.durationMs / 1000) + 's' +
      ' | pohon event dihapus=' + removed +
      ' | pohon asli tetap=' + event.nativeTreeCount +
      ' | alasan=' + (reason || 'timeout-5-menit'));

    if (treeFieldNextTimer) clearTimeout(treeFieldNextTimer);
    startTreeFieldCountdown(TREE_FIELD_EVENT_INTERVAL, 'event baru setelah cooldown');
    treeFieldNextTimer = setTimeout(function () {
      treeFieldNextTimer = null;
      var result = spawnTreeFieldEvent();
      if (result) {
        console.log('[MDZ TREE EVENT NEXT] event baru dipilih | lokasi random baru | minMove=' + TREE_FIELD_MIN_MOVE_DISTANCE + 'px');
      } else {
        console.log('[MDZ TREE EVENT NEXT] belum dapat lokasi valid | scheduler akan mencoba lagi');
      }
    }, TREE_FIELD_EVENT_INTERVAL);
    return true;
  }

  function startTreeFieldEvents(intervalMs) {
    var delay = Math.max(15000, Number(intervalMs) || TREE_FIELD_EVENT_INTERVAL);
    if (treeFieldTimer) clearTimeout(treeFieldTimer);
    if (treeFieldCleanupTimer) clearTimeout(treeFieldCleanupTimer);
    if (treeFieldNextTimer) clearTimeout(treeFieldNextTimer);
    if (treeFieldCountdownTimer) clearInterval(treeFieldCountdownTimer);
    if (treeFieldActiveCountdownTimer) clearInterval(treeFieldActiveCountdownTimer);
    treeFieldTimer = null;
    console.log('[MDZ TREE EVENT SYSTEM] START | active=5 menit | event berikutnya dalam ' + Math.round(delay / 1000) + 's');
    startTreeFieldCountdown(delay, 'event pertama');

    // Scheduler satu-shot seperti pola auto-event chest: tunggu countdown, lalu spawn.
    treeFieldTimer = setTimeout(function runFirstEvent() {
      treeFieldTimer = null;
      if (activeTreeFieldEvent) return;
      var result = spawnTreeFieldEvent();
      if (result) console.log('[MDZ TREE EVENT NEXT] event aktif | durasi 5 menit | setelah selesai cooldown ' + Math.round(TREE_FIELD_EVENT_INTERVAL / 1000) + 's');
      else {
        console.log('[MDZ TREE EVENT RETRY] gagal memilih lokasi | coba lagi 5s');
        treeFieldTimer = setTimeout(runFirstEvent, 5000);
      }
    }, delay);
    return true;
  }

  function stopTreeFieldEvents() {
    if (treeFieldTimer) clearInterval(treeFieldTimer);
    if (treeFieldCleanupTimer) clearTimeout(treeFieldCleanupTimer);
    if (treeFieldNextTimer) clearTimeout(treeFieldNextTimer);
    if (treeFieldCountdownTimer) clearInterval(treeFieldCountdownTimer);
    treeFieldTimer = null;
    treeFieldCleanupTimer = null;
    treeFieldNextTimer = null;
    treeFieldCountdownTimer = null;
    treeFieldActiveCountdownTimer = null;
    console.log('[MDZ TREE EVENT SYSTEM] STOP');
    return true;
  }

  function cleanup() {
    for (var i = trees.length - 1; i >= 0; i--) {
      var t = trees[i];
      if (!t || !t.inst) { trees.splice(i, 1); continue; }
      try {
        if (t.inst.qs) {
          if (t.proxy && !t.proxy.qs) setSolidEnabled(t.proxyBehavior || findSolidBehavior(t.proxy), false);
          trees.splice(i, 1);
        }
      } catch (e) {}
    }
  }

  var timer = setInterval(function () {
    var rt = runtime();
    if (!rt) return;

    for (var i = 0; i < trees.length; i++) {
      var t = trees[i];
      if (!t || !t.inst) continue;
      detectChop(t);
      if (!t.chopped) {
        var pl = getPlayer(rt);
        if (pl) {
          var dx = pl.x - t.inst.x, dy = pl.y - t.inst.y;
          t.nearPlayer = Math.sqrt(dx * dx + dy * dy) <= INTERACT_DISTANCE;
        }
      }
      if (!t.chopped && t.proxy && !t.proxy.qs) {
        t.proxy.x = t.inst.x;
        t.proxy.y = t.inst.y + t.inst.height * 0.40;
        t.proxy.width = Math.max(48, t.inst.width * 0.72);
        t.proxy.height = Math.max(42, t.inst.height * 0.34);
        // Native standing tree collision state.
        try {
          if (typeof t.proxy.Br === 'function') t.proxy.Br(COLLISION_STANDING_FRAME);
          else t.proxy.Y = COLLISION_STANDING_FRAME;
        } catch (e) {}
        t.proxy.visible = true;
        t.proxy.opacity = 0;
        t.proxy.collisionsEnabled = true;
        if (typeof t.proxy.P === 'function') t.proxy.P();
      }
    }
    updateChopButton(rt);
    cleanup();
  }, 100);

  // Debug helper: returns the weapon IDs confirmed in data.js.
  // This does not replace the game's native weapon check; it only exposes
  // the exact IDs for testing from Eruda/console.
  window.MDZBananaTreeChopWeapons = CHOP_WEAPON_IDS.slice();

  window.MDZGetPlayerChopWeaponState = function () {
    var rt = runtime();
    var p = rt && getPlayer(rt);
    if (!p) return null;

    var out = {
      ids: CHOP_WEAPON_IDS.slice(),
      playerType: PLAYER_TYPE,
      raw: {}
    };

    // C2 runtime builds can expose instance variables through different fields.
    // Read common C2 representations without changing the player's state.
    try {
      if (Array.isArray(p.instance_vars)) out.instance_vars = p.instance_vars.slice();
    } catch (e) {}
    try {
      if (Array.isArray(p.instanceVars)) out.instanceVars = p.instanceVars.slice();
    } catch (e2) {}
    try {
      if (Array.isArray(p.extra && p.extra.instance_vars)) out.extra_instance_vars = p.extra.instance_vars.slice();
    } catch (e3) {}

    return out;
  };

  window.MDZBananaTreeCustom = {
    version: '2.5.0-tree-field-straight-2row-countdown',
    spawn: spawnTree,
    list: function () { return trees.slice(); },
    clear: function () {
      var rt = runtime();
      for (var i = 0; i < trees.length; i++) {
        var t = trees[i];
        try {
          if (t.proxy && rt && typeof rt.bh === 'function') rt.bh(t.proxy);
          else if (t.proxy && rt && typeof rt.$e === 'function') rt.$e([t.proxy]);
        } catch (e) {}
        try {
          if (t.inst && rt && typeof rt.bh === 'function') rt.bh(t.inst);
          else if (t.inst && rt && typeof rt.$e === 'function') rt.$e([t.inst]);
        } catch (e2) {}
      }
      trees.length = 0;
      if (rt) rt.redraw = true;
    }
  };

  // Explicit spawn commands requested:
  // Banana = tree_leaves_2 custom
  // Sawit   = tree_leaves_new3 custom
  window.SpawnCustomBananaTree = function () { return spawnTree('t209'); };
  window.SpawnCustomSawitTree = function () { return spawnTree('t581'); };
  window.SpawnCustomOrangeTree = function () { return spawnTree('t577'); };

  // Alias kode spawn yang diminta: pohon jeruk.
  window.SpawnCustomjruktree = window.SpawnCustomOrangeTree;
  window.SpawnCustomJrukTree = window.SpawnCustomOrangeTree;

  window.SpawnCustomBananaTree209 = window.SpawnCustomBananaTree;
  window.SpawnCustomBananaTree581 = window.SpawnCustomSawitTree;
  window.SpawnCustomOrangeTree577 = window.SpawnCustomOrangeTree;

  // Event ladang pohon: satu event = satu tipe pohon, 4-10 pohon sebaris.
  window.SpawnCustomTreeFieldEvent = spawnTreeFieldEvent;
  window.StartCustomTreeFieldEvents = startTreeFieldEvents;
  window.StopCustomTreeFieldEvents = stopTreeFieldEvents;
  window.RemoveActiveCustomTreeFieldEvent = function () { return removeActiveTreeFieldEvent('manual'); };
  window.GetCustomTreeFieldEventState = function () { return lastTreeFieldEvent; };
  window.GetCustomTreeFieldEventActive = function () { return activeTreeFieldEvent; };

  // Mulai otomatis mengikuti pola scheduler chest_gl.js: tunggu player/runtime,
  // initial delay 20 detik; event aktif 5 menit, lalu dibersihkan dan event berikutnya mencari lokasi random baru.
  setTimeout(function bootTreeEvents() {
    var rt = runtime(), player = rt && getPlayer(rt);
    if (!rt || !player) {
      console.log('[MDZ TREE EVENT BOOT] player belum siap, cek lagi 5 detik');
      setTimeout(bootTreeEvents, 5000);
      return;
    }
    console.log('[MDZ TREE EVENT SYSTEM] READY | initial delay 15s | enabled=' + TREE_TYPES.join(','));
    setTimeout(function () {
      var result = spawnTreeFieldEvent();
      if (result) console.log('[MDZ TREE EVENT NEXT] scheduler aktif | active 5 menit | lokasi berikutnya random setelah cleanup');
      startTreeFieldEvents(15000);
    }, TREE_FIELD_INITIAL_DELAY);
  }, 0);

  console.log('[MDZ Banana Tree] READY | Tree Field Event aktif | SpawnCustomTreeFieldEvent()');
})();
