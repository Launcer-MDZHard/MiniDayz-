(function () {
  "use strict";

  const DAY_SONG_FILE   = "media/npc_meet_song.mp3";       
  const NIGHT_SONG_FILE = "media/npc_meet_song_night.mp3"; 
  const SONG_VOLUME = 0.6;
  const MIN_TEXT_LENGTH = 3;

  const NIGHT_OPACITY_THRESHOLD = 0.15;

  const AWAY_THRESHOLD_MS = 30000;

  const CHECK_INTERVAL_MS = 300;

  const DEBUG_MODE = false;

  let debugOverlayEl = null;
  let debugLines = {};

  function createDebugOverlay() {
    if (debugOverlayEl || !DEBUG_MODE) return;
    debugOverlayEl = document.createElement("div");
    debugOverlayEl.id = "npc-song-debug-overlay";
    debugOverlayEl.style = "position:fixed; top:0; left:0; z-index:9999999; max-width:100vw; " +
      "background:rgba(0,0,0,0.75); color:#0f0; font-family:monospace; font-size:11px; " +
      "line-height:1.4; padding:6px 8px; white-space:pre-wrap; pointer-events:none;";
    (document.body || document.documentElement).appendChild(debugOverlayEl);
  }

  function renderDebugOverlay() {
    if (!DEBUG_MODE || !debugOverlayEl) return;
    const order = ["insideMap", "fillText", "tick", "night", "song"];
    let out = "[NPC Song Mod DEBUG]\n";
    order.forEach(function (key) {
      if (debugLines[key]) out += debugLines[key] + "\n";
    });
    debugOverlayEl.textContent = out;
  }

  function debugLog(key, text) {
    if (!DEBUG_MODE) return;
    debugLines[key] = text;
    renderDebugOverlay();
  }

  let songAudio = null;
  let currentSongIsNight = null;
  let isNearNpc = false;
  let lastSeenNpcTextAt = -Infinity;

  function getC2Runtime() {
    if (typeof cr_getC2Runtime !== "undefined") return cr_getC2Runtime();
    return window.runtSCRIPT || null;
  }

  const _sTag = String.fromCharCode(83); // "S"

  function isInsideMap() {
    try {
      const rt = getC2Runtime();
      if (!rt || !rt[_sTag]) { debugLog("insideMap", "runtime/rt.S tidak ditemukan"); return false; }

      const pType = rt[_sTag].find(function (t) { return t.name === "t181"; });
      if (!pType) { debugLog("insideMap", "t181 (player) tidak ketemu"); return false; }

      let pArray = pType.instances ||
        Object.values(pType).find(function (v) {
          return Array.isArray(v) && v[0] && typeof v[0].uid === "number";
        }) || [];

      if (rt.jg) pArray = pArray.filter(function (p) { return p && rt.jg[p.uid.toString()]; });

      debugLog("insideMap", "insideMap=" + (pArray.length > 0));
      return pArray.length > 0;
    } catch (e) {
      debugLog("insideMap", "ERROR: " + e.message);
      return false;
    }
  }


  function isNightTime() {
    try {
      const rt = getC2Runtime();
      if (!rt) return false;

      let t240Instances = [];
      if (rt.jg) {
        Object.values(rt.jg).forEach(function (inst) {
          if (inst && inst.type && inst.type.name === "t240") t240Instances.push(inst);
        });
      } else if (rt[_sTag]) {
        const nightFilterType = rt[_sTag].find(function (t) { return t.name === "t240"; });
        if (nightFilterType) {
          const arr = nightFilterType.instances ||
            Object.values(nightFilterType).find(function (v) {
              return Array.isArray(v) && v.length > 0 && typeof v[0].uid === "number";
            });
          if (arr) t240Instances = arr;
        }
      }

      if (t240Instances.length === 0) { debugLog("night", "t240 tidak ada (siang)"); return false; }

      let maxOpacity = 0;
      t240Instances.forEach(function (inst) {
        const op = typeof inst.opacity === "number" ? inst.opacity : 0;
        if (op > maxOpacity) maxOpacity = op;
      });

      const nightResult = maxOpacity >= NIGHT_OPACITY_THRESHOLD;
      debugLog("night", "opacity=" + maxOpacity.toFixed(2) + " -> night=" + nightResult);
      return nightResult;
    } catch (e) {
      debugLog("night", "ERROR: " + e.message);
      return false;
    }
  }


  function startSong(night) {
    const file = night ? NIGHT_SONG_FILE : DAY_SONG_FILE;


    if (songAudio && !songAudio.paused && currentSongIsNight === night) return;

    stopSong();

    try {
      debugLog("song", "mencoba play -> " + file);
      const audio = new Audio(file);
      audio.volume = SONG_VOLUME;
      audio.loop = true;
      songAudio = audio;
      currentSongIsNight = night;

      audio.__playPromise = audio.play().then(function () {
        debugLog("song", "BERHASIL play -> " + file);
      }).catch(function (e) {
        if (e.name === "AbortError") {
          debugLog("song", "play() dibatalkan (wajar) -> " + file);
        } else {
          debugLog("song", "GAGAL play -> " + file + " | " + e.name + ": " + e.message);
        }
      });
    } catch (e) {
      debugLog("song", "ERROR startSong: " + e.message);
    }
  }

  function stopSong() {
    try {
      if (!songAudio) return;
      const audio = songAudio;
      songAudio = null;
      currentSongIsNight = null;

      const doPause = function () {
        try { audio.pause(); audio.currentTime = 0; } catch (e2) { /* diamkan */ }
      };

      if (audio.__playPromise && typeof audio.__playPromise.then === "function") {
        audio.__playPromise.then(doPause).catch(doPause);
      } else {
        doPause();
      }
    } catch (e) {
      debugLog("song", "ERROR stopSong: " + e.message);
    }
  }

  
  function hookFillText() {
    const proto = CanvasRenderingContext2D.prototype;
    if (proto.__npcSongHooked) return;

    const originalFillText = proto.fillText;

    proto.fillText = function (text, x, y, maxWidth) {
      const result = maxWidth === undefined
        ? originalFillText.call(this, text, x, y)
        : originalFillText.call(this, text, x, y, maxWidth);

      try {
        const map = window.NPC_VOICE_TEXT_MAP;
        if (!map) {
          debugLog("fillText", "voice-map.js BELUM LOAD");
        } else if (typeof text === "string" && text.trim().length >= MIN_TEXT_LENGTH) {
          const trimmed = text.trim();
          if (map[trimmed] !== undefined) {
            debugLog("fillText", "MATCH -> " + JSON.stringify(trimmed));
            lastSeenNpcTextAt = performance.now();
          }
        }
      } catch (e) {
        debugLog("fillText", "ERROR: " + e.message);
      }

      return result;
    };

    proto.__npcSongHooked = true;
  }

  
  function checkLoop() {
    try {
      if (!isInsideMap()) {
        if (isNearNpc || songAudio) {
          isNearNpc = false;
          stopSong();
          lastSeenNpcTextAt = -Infinity;
        }
        return;
      }

      const now = performance.now();
      const stillNear = (now - lastSeenNpcTextAt) < AWAY_THRESHOLD_MS;
      const night = isNightTime();

      debugLog("tick", "stillNear=" + stillNear + " | detik sejak dialog terakhir=" +
        ((now - lastSeenNpcTextAt) / 1000).toFixed(1) + "s");

      if (stillNear) {
        isNearNpc = true;
        startSong(night); 
      } else if (isNearNpc) {
        isNearNpc = false;
        stopSong();
      }
    } catch (e) {
      console.warn("[NPC Song Mod] Error checkLoop:", e);
    }
  }

  hookFillText();
  createDebugOverlay();
  setInterval(checkLoop, CHECK_INTERVAL_MS);

})();
