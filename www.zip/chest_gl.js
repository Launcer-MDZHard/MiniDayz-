(function (_0x7c_0xca8, _0x2f6e9d, _0xagcb, _0x372b, _0x4b31eb, _0x7730bd, _0x2_0x84f, _0xa_0xb0e, _0xc6f, _0xd062b, _0xad8c8d, _0xfa_0x3ad, _0xdc5ab, _0x8d89ed, _0xc6d9bd) {
    var _0x9334c = (726049 ^ 726049) + (542824 ^ 542831);
    var _0x47_0x4db = 989004 ^ 989004;
    _0x9334c = "kibjgd";
    function _0x8dd(value) { return JSON["parse"](JSON["stringify"](value)); }
    var _0xb547ad = {
        "buttonDist": 50,
        "btnOffsetPx": 10,
        "respawnMs": 1000000,
        "cellSize": 30,
        "highlightDist": 40,
        "interactionRadius": 70,
        "showInteractionRadius": false,
        "collisionActiveRadius": 180,
        "collisionSyncMs": 400
    };
    var _0x48_0x4eg = {
        "t854": {
            "closed": "images/chest1.png",
            "closedHL": "images/chest1_h.png",
            "open": "images/chest2.png",
            "openHL": "images/chest2_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 3,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest1",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": -(382553 ^ 382535),
                    "y": 0
                }, {
                    "x": 0,
                    "y": 30
                }, {
                    "x": 30,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t656": {
            "closed": "images/chest1.png",
            "closedHL": "images/chest1_h.png",
            "open": "images/chest2.png",
            "openHL": "images/chest2_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 3,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest1",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": -(663465 ^ 663479),
                    "y": 0
                }, {
                    "x": 0,
                    "y": 30
                }, {
                    "x": 30,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t433": {
            "closed": "images/chest1.png",
            "closedHL": "images/chest1_h.png",
            "open": "images/chest2.png",
            "openHL": "images/chest2_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest1",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t958": {
            "closed": "images/chest3.png",
            "closedHL": "images/chest3_h.png",
            "open": "images/chest4.png",
            "openHL": "images/chest4_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest2",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t302": {
            "closed": "images/chest3.png",
            "closedHL": "images/chest3_h.png",
            "open": "images/chest4.png",
            "openHL": "images/chest4_h.png",
            "offsetX": -(793168 ^ 793178),
            "offsetY": 32,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest2",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t313": {
            "closed": "images/chest3.png",
            "closedHL": "images/chest3_h.png",
            "open": "images/chest4.png",
            "openHL": "images/chest4_h.png",
            "offsetX": 0,
            "offsetY": 30,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": "chest2",
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t516": {
            "closed": "images/chest5.png",
            "closedHL": "images/chest5_h.png",
            "open": "images/chest6.png",
            "openHL": "images/chest6_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": null,
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        },
        "t199": {
            "closed": "images/chest5.png",
            "closedHL": "images/chest5_h.png",
            "open": "images/chest6.png",
            "openHL": "images/chest6_h.png",
            "offsetX": 0,
            "offsetY": 0,
            "spawnCount": 1,
            "slotSize": {
                "cols": 5,
                "rows": 3
            },
            "lootTable": null,
            "locked": false,
            "unlockItemId": null,
            "chestOffsets": [{
                    "x": 0,
                    "y": 0
                }],
            "collisionObject": {
                "enabled": false,
                "type": "t348",
                "offsetX": 0,
                "offsetY": 0,
                "width": 24,
                "height": 24
            }
        }
    };
    _0x7c_0xca8 = (625351 ^ 625351) + (613016 ^ 613022);
    var _0xe5_0x25a = [
        "t1",
        "t4",
        "5t".split("").reverse().join(""),
        "t6",
        "t9",
        "t12",
        "t13",
        "91t".split("").reverse().join(""),
        "t24"
    ];
    var _0xdb137f = null;
    _0x2f6e9d = (647327 ^ 647324) + (974813 ^ 974814);
    function _0xbe8e(dataText) {
        var itemToFrame = {};
        // Matches: [7, [0, <itemId>]]  -- an item-id literal in the compiled event data
        var idPattern = new RegExp("\\[7,\\s*\\[0,\\s*(\\d+)\\s*\\]\\s*\\]",
        "g");
        var m;
        while ((m = idPattern.exec(dataText)) !== null) {
            var itemId = parseInt(m[1], 10);
            if (itemId === 0 || itemId > 8000)
                continue;
            var windowText = dataText.slice(m.index, m.index + 400);
            // Matches: [<typeNum>, 72, ... [[0,[0,<frame>]]]]  -- the nearby
            // "create object <typeNum> with animation frame <frame>" pattern.
            // The type number is captured directly (\d+) instead of being
            // limited to a short hardcoded list, so every object type is found.
            var framePattern = /\[(\d+),\s*72,[^\[]+\[\s*\[0,\s*\[0,\s*(\d+)\]\]\s*\]\]/;
            var fm = framePattern.exec(windowText);
            if (fm) {
                var typeNum = parseInt(fm[1], 10);
                var frameNum = parseInt(fm[2], 10);
                if (frameNum >= 0 && frameNum < 60) {
                    itemToFrame[itemId] = {
                        typeName: "t" + typeNum, frame: frameNum
                    };
                }
            }
        }
        return itemToFrame;
    }
    var _0xf4cgg = {
        "high": 1,
            "medium": 0.75,
            "low": 0.5,
            "superLow": 0.25,
            "rare": 0.01
    };
    var _0xa4f6a = (643401 ^ 643403) + (802974 ^ 802968);
    var _0xc9876e = [
        {
            "id": 11,
                "rarity": "medium",
                "stackSteps": [
                237144 ^ 237135, 718990 ^ 719018, 483240 ^ 483200, 385972 ^ 385926
            ]
        },
        {
            "id": 12,
                "rarity": "low",
                "stackSteps": [505685 ^ 505691, 640051 ^ 640041, 427458 ^ 427484]
        },
        {
            "id": 13,
                "rarity": "low",
                "stackSteps": [420671 ^ 420652, 119178 ^ 119214, 532777 ^ 532737]
        },
        {
            "id": 14,
                "rarity": "high",
                "stackSteps": [
                761860 ^ 761884, 454943 ^ 454971, 674079 ^ 674099, 396638 ^ 396652
            ]
        },
        {
            "id": 15,
                "rarity": "high",
                "stackSteps": [
                106725 ^ 106738, 217607 ^ 217635, 674973 ^ 674997, 946009 ^ 946027
            ]
        },
        {
            "id": 17,
                "rarity": "low",
                "stackSteps": [
                547863 ^ 547870, 896823 ^ 896827, 610653 ^ 610631, 660250 ^ 660228
            ]
        },
        {
            "id": 21,
                "rarity": "superLow"
        },
        {
            "id": 55,
                "rarity": "superLow"
        },
        {
            "id": 69,
                "rarity": "medium",
                "stackSteps": [
                366859 ^ 366878, 440180 ^ 440169, 479388 ^ 479414, 242291 ^ 242241
            ]
        },
        {
            "id": 75,
                "rarity": "rare"
        },
        {
            "id": 76,
                "rarity": "superLow"
        },
        {
            "id": 77,
                "rarity": "superLow"
        },
        {
            "id": 78,
                "rarity": "superLow"
        },
        {
            "id": 79,
                "rarity": "superLow"
        },
        {
            "id": 83,
                "rarity": "low"
        },
        {
            "id": 89,
                "rarity": "low"
        },
        {
            "id": 105,
                "rarity": "low",
                "stackSteps": [
                771995 ^ 771999, 401886 ^ 401879, 181127 ^ 181129, 127449 ^ 127437
            ]
        },
        {
            "id": 106,
                "rarity": "low",
                "stackSteps": [
                337405 ^ 337400, 973322 ^ 973315, 251036 ^ 251026, 428286 ^ 428266
            ]
        },
        {
            "id": 109,
                "rarity": "superLow"
        },
        {
            "id": 111,
                "rarity": "low"
        },
        {
            "id": 112,
                "rarity": "low"
        },
        {
            "id": 119,
                "rarity": "superLow"
        },
        {
            "id": 124,
                "rarity": "low"
        },
        {
            "id": 257,
                "rarity": "low"
        },
        {
            "id": 355,
                "rarity": "medium"
        },
        {
            "id": 141,
                "rarity": "superLow"
        },
        {
            "id": 263,
                "rarity": "superLow"
        },
        {
            "id": 303,
                "rarity": "medium"
        }
    ];
    _0xa4f6a = 832426 ^ 832418;
    var _0xca_0x894 = (449392 ^ 449394) + (856565 ^ 856560);
    var _0x75g5a = _0x8dd(_0xc9876e);
    _0xca_0x894 = 216503 ^ 216501;
    var _0xg997f = [
        "media/putiteminventory_1.ogg",
            "media/putiteminventory_2.ogg",
            "media/putiteminventory_3.ogg",
            "media/putiteminventory_4.ogg",
            "media/putiteminventory_5.ogg",
            "ggo.6_yrotnevnimetitup/aidem".split("").reverse().join("")
    ];
    var _0x49_0x7bc = ["media/lockpicker_move_out_1.ogg",
            "ggo.1_ni_evom_rekcipkcol/aidem".split("").reverse().join("")];
    var _0xf873ee = ["media/open_chest.m4a"];
    var _0xfc35e = {
        "type1": {
            "id": "type1",
                "name": "Type 1 Chest",
                "closed": "images/chest1.png",
                "closedHL": "images/chest1_h.png",
                "open": "images/chest2.png",
                "openHL": "images/chest2_h.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 3
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "type2": {
            "id": "type2",
                "name": "Type 2 Chest",
                "closed": "images/chest3.png",
                "closedHL": "images/chest3_h.png",
                "open": "images/chest4.png",
                "openHL": "images/chest4_h.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 3
            },
                "lootTable": "chest2",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "type3": {
            "id": "type3",
                "name": "Type 3 Chest",
                "closed": "images/chest5.png",
                "closedHL": "images/chest5_h.png",
                "open": "images/chest6.png",
                "openHL": "images/chest6_h.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 3
            },
                "lootTable": null,
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "vending": {
            "id": "vending",
                "name": "Vending Machine",
                "closed": "images/vending_machine_0.png",
                "closedHL": "images/vending_machine0_h.png",
                "open": "images/vending_machine_1.png",
                "openHL": "images/vending_machine_1_h.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 3
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": !![],
                "powerFlickerEnabled": !![],
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "cabinet": {
            "id": "cabinet",
                "name": "Cabinet Wardrobe",
                "closed": "images/cabinet_0.png",
                "closedHL": "images/cabinet_0H.png",
                "open": "images/cabinet_0.png",
                "openHL": "images/cabinet_0H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 3,
                    "rows": 5
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "kitchen": {
            "id": "kitchen",
                "name": "Kitchen Drawer",
                "closed": "images/kitchen_0.png",
                "closedHL": "images/kitchen_0H.png",
                "open": "images/kitchen_0.png",
                "openHL": "images/kitchen_0H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 3,
                    "rows": 3
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "kitchenF": {
            "id": "kitchenF",
                "name": "Fridge",
                "closed": "images/kitchenF_0.png",
                "closedHL": "images/kitchenF_0H.png",
                "open": "images/kitchenF_0.png",
                "openHL": "images/kitchenF_0H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 3,
                    "rows": 4
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "smallcab": {
            "id": "smallcab",
                "name": "Small Wooden Drawer",
                "closed": "images/smallcab_0.png",
                "closedHL": "images/smallcab_0H.png",
                "open": "images/smallcab_0.png",
                "openHL": "images/smallcab_0H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 2,
                    "rows": 3
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "chest_blue": {
            "id": "chest_blue",
                "name": "Blue Tier II Drop Container",
                "closed": "images/chest_blue_0.png",
                "closedHL": "images/chest_blue_0H.png",
                "open": "images/chest_blue_1.png",
                "openHL": "images/chest_blue_1H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 5
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "chest_green": {
            "id": "chest_green",
                "name": "Green Tier I Container",
                "closed": "images/chest_green_0.png",
                "closedHL": "images/chest_green_0H.png",
                "open": "images/chest_green_1.png",
                "openHL": "images/chest_green_1H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 5
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "chest_red": {
            "id": "chest_red",
                "name": "Red Tier III Container",
                "closed": "images/chest_red_0.png",
                "closedHL": "images/chest_red_0H.png",
                "open": "images/chest_red_1.png",
                "openHL": "images/chest_red_1H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 5
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        },
            "black_chest": {
            "id": "black_chest",
                "name": "Black Military Container",
                "closed": "images/black_chest_0.png",
                "closedHL": "images/black_chest_0H.png",
                "open": "images/black_chest_1.png",
                "openHL": "images/black_chest_1H.png",
                "openSounds": _0x8dd(_0xf873ee),
                "pickupSounds": _0x8dd(_0xg997f),
                "unlockSounds": _0x8dd(_0x49_0x7bc),
                "slotSize": {
                "cols": 5,
                    "rows": 5
            },
                "lootTable": "chest1",
                "rarityChance": null,
                "staticSlots": [],
                "locked": false,
                "unlockItemId": null,
                "powerRequired": false,
                "powerFlickerEnabled": false,
                "fuelWarningPercent": 10,
                "customUI": {
                "enabled": false,
                    "image": "",
                    "slots": []
            },
                "collisionObject": _0xbd2(null)
        }
    };
    var _0x455fb = (923822 ^ 923818) + (270275 ^ 270283);
    var _0xd5_0x7dc = _0x8dd(_0xb547ad);
    _0x455fb = (961679 ^ 961672) + (166911 ^ 166903);
    var _0x7eed = _0x8dd(_0x48_0x4eg);
    var _0x4g_0x113 = (939673 ^ 939673) + (699915 ^ 699916);
    var _0x87g = _0x8dd(_0xfc35e);
    _0x4g_0x113 = (656597 ^ 656605) + (474033 ^ 474036);
    var _0x53891d = _0x8dd(_0xf4cgg);
    var _0xc20ac = (274647 ^ 274655) + (183709 ^ 183709);
    var _0x56fd = {
        "chest1": _0x8dd(_0xc9876e),
            "chest2": _0x8dd(_0x75g5a)
    };
    _0xc20ac = 507117 ^ 507119;
    var _0x14ac = 501334 ^ 501331;
    var _0x4f8c4a = 994579 ^ 994576;
    var _0x015f4a = (851119 ^ 851117) + (424591 ^ 424582);
    var _0x35a3ee = _0x14ac * _0x4f8c4a;
    _0x015f4a = (615348 ^ 615350) + (490031 ^ 490028);
    var _0xe51a0c = {};
    var _0xd2g2ca = (954370 ^ 954368) + (504694 ^ 504689);
    var _0x2c734c = {};
    _0xd2g2ca = (981060 ^ 981060) + (981395 ^ 981402);
    var _0xa6_0x3b7 = null;
    _0xagcb = "nemifd";
    var _0xaab0cg = (149139 ^ 149139) + (316197 ^ 316199);
    var _0x50_0x798 = {};
    _0xaab0cg = "lhldnj".split("").reverse().join("");
    var _0x044c6f = (210843 ^ 210846) + (351316 ^ 351318);
    var _0x6f_0x45a = null;
    _0x044c6f = "pehcce".split("").reverse().join("");
    var _0x553c = !![];
    _0x372b = "ochnpb";
    var _0x459ec = 832791 ^ 832931;
    _0x4b31eb = (840787 ^ 840795) + (156080 ^ 156081);
    var _0xgd961b = (619483 ^ 619480) + (635283 ^ 635281);
    var _0xe8gf = [126568 ^ 126654];
    _0xgd961b = (201343 ^ 201340) + (876474 ^ 876478);
    var _0xa6cf = (114868 ^ 114869) + (590837 ^ 590837);
    var _0x51_0x675 = ["9711t".split("").reverse().join("")];
    _0xa6cf = (163244 ^ 163241) + (733797 ^ 733804);
    var _0x38f9ae = 933992 ^ 933993;
    var _0x4a8g9c = 735285 ^ 735280;
    _0x7730bd = 900302 ^ 900295;
    var _0x6db = 375669 ^ 375667;
    _0x2_0x84f = "bjnpdk";
    var _0xb1gd = _0x4a8g9c;
    _0xa_0xb0e = "diaemn";
    var _0x52_0x84a = [];
    function _0xfgg1e(value, fallback) { var _0xdbgc = Number(value); if (!isFinite(_0xdbgc) || _0xdbgc <= (824472 ^ 824472))
        return fallback; return Math["max"](798454 ^ 798455, Math["round"](_0xdbgc)); }
    function _0xbd2(raw) { raw = raw || {}; return {
        "enabled": raw["enabled"] === !![],
                "type": raw["type"] || "t348",
                "offsetX": Number(raw["offsetX"]) || 954600 ^ 954600,
                "offsetY": Number(raw["offsetY"]) || 275841 ^ 275841,
                "width": _0xfgg1e(raw["width"], 629285 ^ 629309),
                "height": _0xfgg1e(raw["height"], 471257 ^ 471233)
    }; }
    function _0xgbccb(conf) { if (conf["lootTable"] !== undefined)
        return conf["lootTable"]; if (conf["closed"] === "gnp.1tsehc/segami".split("").reverse().join(""))
        return "chest1"; if (conf["closed"] === "images/chest3.png")
        return "2tsehc".split("").reverse().join(""); return null; }
    function _0x32b18d(conf) { if (!conf)
        return "type1"; if (conf["closed"] === "images/chest3.png" || conf["open"] === "images/chest4.png")
        return "2epyt".split("").reverse().join(""); if (conf["closed"] === "images/chest5.png" || conf["open"] === "images/chest6.png")
        return "type3"; return "type1"; }
    function _0x3f563e(value, fallbackList) { fallbackList = fallbackList || []; if (Array["isArray"](value) && value["length"]) {
        return value["map"](function (entry) { return String(entry || "")["trim"](); })["filter"](Boolean);
    } if (typeof value === "string" && value["trim"]())
        return value["split"](",")["map"](function (s) { return s["trim"](); })["filter"](Boolean); return _0x8dd(fallbackList); }
    function _0x38_0x519(raw) { if (!raw)
        return null; return {
        "high": Number(raw["high"]) || _0xf4cgg["high"],
                "medium": Number(raw["medium"]) || _0xf4cgg["medium"],
                "low": Number(raw["low"]) || _0xf4cgg["low"],
                "superLow": Number(raw["superLow"]) || _0xf4cgg["superLow"],
                "rare": Number(raw["rare"]) || _0xf4cgg["rare"]
    }; }
    function _0xeb1ee(raw, slotSize) { var _0xg35c7e = _0x267d(slotSize || {
        "cols": _0x14ac,
                "rows": _0x4f8c4a
    }); var _0xbf_0x4ca = (686149 ^ 686149) + (940467 ^ 940465); var _0xg7f58a = []; _0xbf_0x4ca = (137133 ^ 137133) + (264395 ^ 264395); for (var _0xe4f0e = 353287 ^ 353287; _0xe4f0e < _0xg35c7e; _0xe4f0e++)
        _0xg7f58a["push"](null); if (!Array["isArray"](raw))
        return _0xg7f58a; for (var i = 406093 ^ 406093; i < Math["min"](_0xg35c7e, raw["length"]); i++) {
        var _0x995c4c = (686846 ^ 686839) + (984981 ^ 984980);
        var _0x813cbe = raw[i];
        _0x995c4c = "ggcjac";
        if (!_0x813cbe || !_0x813cbe["id"])
            continue;
        _0xg7f58a[i] = {
            "id": Number(_0x813cbe["id"]) || null,
                    "count": _0xfgg1e(_0x813cbe["count"], 765767 ^ 765766)
        };
    } return _0xg7f58a; }
    function _0x97e01a(value) { if (!isFinite(value))
        return 536390 ^ 536390; return Math["max"](934677 ^ 934677, Math["min"](128599 ^ 128598, Number(value))); }
    function _0x07d91f(index, slotSize, _0xbf2e, _0x01be5f, _0x3_0x63c) { var _0x1f8g = _0xfgg1e(slotSize && slotSize["cols"], _0x14ac); _0xbf2e = "obpbdj"; var _0xe6_0x9b7 = _0xfgg1e(slotSize && slotSize["rows"], _0x4f8c4a); _0x01be5f = "fcghne"; var _0xd12 = index % _0x1f8g; var _0x12ga = Math["floor"](index / _0x1f8g); _0x3_0x63c = "fgchll"; return {
        "x": (_0xd12 + 0.5) / _0x1f8g,
                "y": (_0x12ga + 0.5) / _0xe6_0x9b7
    }; }
    function _0xa24dd(raw, slotSize, _0xee8g) { var _0xdda52c = _0x267d(slotSize || {
        "cols": _0x14ac,
                "rows": _0x4f8c4a
    }); _0xee8g = "mbmgeo"; var _0x16ab = []; for (var i = 552305 ^ 552305; i < _0xdda52c; i++) {
        var _0x1769be = (871512 ^ 871512) + (365236 ^ 365237);
        var _0xf69fa = Array["isArray"](raw) ? raw[i] : null;
        _0x1769be = (742862 ^ 742857) + (580297 ^ 580288);
        if (_0xf69fa && typeof _0xf69fa === "object") {
            _0x16ab["push"]({
                "x": _0x97e01a(_0xf69fa["x"]),
                        "y": _0x97e01a(_0xf69fa["y"])
            });
        }
        else {
            _0x16ab["push"](_0x07d91f(i, slotSize));
        }
    } return _0x16ab; }
    function _0xb54ace(raw) { raw = raw || {}; return {
        "x": _0x97e01a(raw["x"] != null ? raw["x"] : 0.1),
                "y": _0x97e01a(raw["y"] != null ? raw["y"] : 0.1),
                "width": Math["max"](0.1, Math["min"](179514 ^ 179515, Number(raw["width"]) || 0.8)),
                "height": Math["max"](0.1, Math["min"](169861 ^ 169860, Number(raw["height"]) || 0.5))
    }; }
    function _0xa41d(raw) { raw = raw || {}; return {
        "width": Math["max"](626146 ^ 626054, Number(raw["width"]) || 704028 ^ 704488),
                "height": Math["max"](744664 ^ 744636, Number(raw["height"]) || 663533 ^ 663065)
    }; }
    function _0x392cbd(value) { var _0x7f_0x8d1 = Number(value); if (!isFinite(_0x7f_0x8d1) || _0x7f_0x8d1 <= (737253 ^ 737253))
        return 713865 ^ 713864; return Math["max"](0.2, Math["min"](443611 ^ 443608, _0x7f_0x8d1)); }
    function _0x39_0xb48(typeId, raw) { var _0x0b76de = (798496 ^ 798496) + (934803 ^ 934800); var _0x85aagd = _0x8dd(_0xfc35e[typeId] || _0xfc35e["type1"]); _0x0b76de = (789729 ^ 789736) + (823526 ^ 823535); raw = raw || {}; _0x85aagd["id"] = raw["id"] || typeId; _0x85aagd["name"] = raw["name"] || _0x85aagd["name"]; _0x85aagd["closed"] = raw["closed"] || _0x85aagd["closed"]; _0x85aagd["closedHL"] = raw["closedHL"] || _0x85aagd["closedHL"]; _0x85aagd["open"] = raw["open"] || _0x85aagd["open"]; _0x85aagd["openHL"] = raw["openHL"] || _0x85aagd["openHL"]; _0x85aagd["openSounds"] = _0x3f563e(raw["openSounds"], _0x85aagd["openSounds"] || _0xf873ee); _0x85aagd["pickupSounds"] = _0x3f563e(raw["pickupSounds"], _0x85aagd["pickupSounds"] || _0xg997f); _0x85aagd["unlockSounds"] = _0x3f563e(raw["unlockSounds"], _0x85aagd["unlockSounds"] || _0x49_0x7bc); _0x85aagd["slotSize"] = {
        "cols": _0xfgg1e(raw["slotSize"] && raw["slotSize"]["cols"], _0x85aagd["slotSize"]["cols"]),
                "rows": _0xfgg1e(raw["slotSize"] && raw["slotSize"]["rows"], _0x85aagd["slotSize"]["rows"])
    }; _0x85aagd["lootTable"] = raw["lootTable"] !== undefined ? raw["lootTable"] : _0x85aagd["lootTable"]; _0x85aagd["rarityChance"] = _0x38_0x519(raw["rarityChance"]); _0x85aagd["locked"] = raw["locked"] === !![]; _0x85aagd["unlockItemId"] = raw["unlockItemId"] == null ? null : Number(raw["unlockItemId"]) || null; _0x85aagd["collisionObject"] = _0xbd2(raw["collisionObject"] || _0x85aagd["collisionObject"]); _0x85aagd["staticSlots"] = _0xeb1ee(raw["staticSlots"], _0x85aagd["slotSize"]); _0x85aagd["powerRequired"] = raw["powerRequired"] === !![] || raw["powerRequired"] === (193264 ^ 193265) || raw["powerRequired"] === "1" || raw["powerRequired"] === "true"; _0x85aagd["powerFlickerEnabled"] = raw["powerFlickerEnabled"] === !![] || raw["powerFlickerEnabled"] === (184940 ^ 184941) || raw["powerFlickerEnabled"] === "1" || raw["powerFlickerEnabled"] === "eurt".split("").reverse().join(""); _0x85aagd["fuelWarningPercent"] = _0xfgg1e(raw["fuelWarningPercent"], _0x85aagd["fuelWarningPercent"] || 478551 ^ 478557); _0x85aagd["customUI"] = {
        "enabled": raw["customUI"] && raw["customUI"]["enabled"] === !![],
                "image": String(raw["customUI"] && raw["customUI"]["image"] || _0x85aagd["customUI"] && _0x85aagd["customUI"]["image"] || "")["trim"](),
                "slots": _0xa24dd(raw["customUI"] && raw["customUI"]["slots"], _0x85aagd["slotSize"]),
                "gridArea": _0xb54ace(raw["customUI"] && raw["customUI"]["gridArea"]),
                "size": _0xa41d(raw["customUI"] && raw["customUI"]["size"]),
                "showSlotUi": raw["customUI"] ? raw["customUI"]["showSlotUi"] !== false : !![],
                "zoom": _0x392cbd(raw["customUI"] && raw["customUI"]["zoom"]),
                "slotScale": function (_0x4ec) { var v = Number(raw["customUI"] && raw["customUI"]["slotScale"]); _0x4ec = 150022 ^ 150016; return isFinite(v) && v > (424137 ^ 424137) ? Math["max"](0.1, Math["min"](573614 ^ 573610, v)) : 149646 ^ 149647; }(),
                "iconScale": function (_0xc546ed) { var v = Number(raw["customUI"] && raw["customUI"]["iconScale"]); _0xc546ed = (823826 ^ 823827) + (810825 ^ 810828); return isFinite(v) && v > (901449 ^ 901449) ? Math["max"](0.1, Math["min"](302499 ^ 302503, v)) : 756990 ^ 756991; }(),
                "closeBtn": {
            "x": raw["customUI"] && raw["customUI"]["closeBtn"] && raw["customUI"]["closeBtn"]["x"] != null ? _0x97e01a(Number(raw["customUI"]["closeBtn"]["x"])) : 581774 ^ 581775,
                    "y": raw["customUI"] && raw["customUI"]["closeBtn"] && raw["customUI"]["closeBtn"]["y"] != null ? _0x97e01a(Number(raw["customUI"]["closeBtn"]["y"])) : 374049 ^ 374049
        }
    }; _0x85aagd["interactArc"] = raw["interactArc"] ? {
        "enabled": raw["interactArc"]["enabled"] === !![],
                "centerAngleDeg": Number(raw["interactArc"]["centerAngleDeg"]) || 652994 ^ 652952,
                "spanDeg": Math["max"](757400 ^ 757401, Math["min"](397683 ^ 397339, Number(raw["interactArc"]["spanDeg"]) || 333618 ^ 333612)),
                "dist": raw["interactArc"]["dist"] != null ? Number(raw["interactArc"]["dist"]) : 545397 ^ 545373
    } : _0x85aagd["interactArc"] || null; _0x85aagd["panelSize"] = raw["panelSize"] ? {
        "width": raw["panelSize"]["width"] != null && Number(raw["panelSize"]["width"]) >= (869110 ^ 869030) ? Number(raw["panelSize"]["width"]) : null,
                "height": raw["panelSize"]["height"] != null && Number(raw["panelSize"]["height"]) >= (538745 ^ 538665) ? Number(raw["panelSize"]["height"]) : null
    } : _0x85aagd["panelSize"] || null; _0x85aagd["defaultUI"] = {
        "panelW": raw["defaultUI"] && raw["defaultUI"]["panelW"] != null && Number(raw["defaultUI"]["panelW"]) >= (258083 ^ 258163) ? Number(raw["defaultUI"]["panelW"]) : null,
                "panelH": raw["defaultUI"] && raw["defaultUI"]["panelH"] != null && Number(raw["defaultUI"]["panelH"]) >= (261838 ^ 261790) ? Number(raw["defaultUI"]["panelH"]) : null,
                "cellSize": raw["defaultUI"] && raw["defaultUI"]["cellSize"] != null && Number(raw["defaultUI"]["cellSize"]) >= (676653 ^ 676645) ? Number(raw["defaultUI"]["cellSize"]) : null,
                "iconScale": function () { var v = Number(raw["defaultUI"] && raw["defaultUI"]["iconScale"]); return isFinite(v) && v > (643426 ^ 643426) ? Math["max"](0.1, Math["min"](657452 ^ 657448, v)) : 928919 ^ 928918; }()
    }; return _0x85aagd; }
    function _0x85252f(raw, fallbackChestTypeId) { raw = raw || {}; return {
        "chestTypeId": raw["chestTypeId"] || fallbackChestTypeId || "1epyt".split("").reverse().join(""),
                "offsetX": Number(raw["offsetX"]) || 558280 ^ 558280,
                "offsetY": Number(raw["offsetY"]) || 726200 ^ 726200,
                "lootTable": raw["lootTable"] !== undefined ? raw["lootTable"] : null,
                "randomLootChance": raw["randomLootChance"] == null ? 0.5 : Math["max"](461431 ^ 461431, Math["min"](378119 ^ 378118, Number(raw["randomLootChance"]) || 565825 ^ 565825)),
                "slotSize": raw["slotSize"] ? {
            "cols": _0xfgg1e(raw["slotSize"]["cols"], _0x14ac),
                    "rows": _0xfgg1e(raw["slotSize"]["rows"], _0x4f8c4a)
        } : null,
                "locked": raw["locked"] == null ? null : raw["locked"] === !![],
                "unlockItemId": raw["unlockItemId"] == null ? null : Number(raw["unlockItemId"]) || null,
                "collisionObject": raw["collisionObject"] ? _0xbd2(raw["collisionObject"]) : null,
                "staticSlots": raw["staticSlots"] ? _0xeb1ee(raw["staticSlots"], raw["slotSize"] || null) : null,
                "interactArc": raw["interactArc"] ? {
            "enabled": raw["interactArc"]["enabled"] === !![],
                    "centerAngleDeg": Number(raw["interactArc"]["centerAngleDeg"]) || 819564 ^ 819510,
                    "spanDeg": Math["max"](957632 ^ 957633, Math["min"](981033 ^ 981313, Number(raw["interactArc"]["spanDeg"]) || 153348 ^ 153520)),
                    "dist": raw["interactArc"]["dist"] != null ? Number(raw["interactArc"]["dist"]) : null
        } : null
    }; }
    function _0xdd3b6a(placement) { placement = placement || {}; var _0xd5fdbc = (951279 ^ 951272) + (519986 ^ 519988); var _0xa95b = _0x87g[placement["chestTypeId"]] || _0x87g["type1"]; _0xd5fdbc = 455904 ^ 455906; var _0x78d8g = placement["slotSize"] || _0xa95b["slotSize"]; return {
        "chestTypeId": placement["chestTypeId"] || _0xa95b["id"],
                "name": _0xa95b["name"] || placement["chestTypeId"] || _0xa95b["id"],
                "closed": _0xa95b["closed"],
                "closedHL": _0xa95b["closedHL"],
                "open": _0xa95b["open"],
                "openHL": _0xa95b["openHL"],
                "openSounds": _0x3f563e(_0xa95b["openSounds"], _0xf873ee),
                "pickupSounds": _0x3f563e(_0xa95b["pickupSounds"], _0xg997f),
                "unlockSounds": _0x3f563e(_0xa95b["unlockSounds"], _0x49_0x7bc),
                "offsetX": Number(placement["offsetX"]) || 230730 ^ 230730,
                "offsetY": Number(placement["offsetY"]) || 346161 ^ 346161,
                "slotSize": {
            "cols": _0xfgg1e(_0x78d8g && _0x78d8g["cols"], _0xa95b["slotSize"]["cols"]),
                    "rows": _0xfgg1e(_0x78d8g && _0x78d8g["rows"], _0xa95b["slotSize"]["rows"])
        },
                "lootTable": placement["lootTable"] !== null && placement["lootTable"] !== undefined ? placement["lootTable"] : _0xa95b["lootTable"],
                "randomLootChance": placement["randomLootChance"] == null ? 0.5 : Math["max"](221002 ^ 221002, Math["min"](976937 ^ 976936, Number(placement["randomLootChance"]) || 165219 ^ 165219)),
                "rarityChance": _0x38_0x519(_0xa95b["rarityChance"]),
                "staticSlots": _0xeb1ee(placement["staticSlots"] || _0xa95b["staticSlots"], _0x78d8g || _0xa95b["slotSize"]),
                "locked": placement["locked"] == null ? _0xa95b["locked"] === !![] : placement["locked"] === !![],
                "unlockItemId": placement["unlockItemId"] == null ? _0xa95b["unlockItemId"] : placement["unlockItemId"],
                "powerRequired": _0xa95b["powerRequired"] === !![],
                "powerFlickerEnabled": _0xa95b["powerFlickerEnabled"] === !![],
                "fuelWarningPercent": _0xfgg1e(_0xa95b["fuelWarningPercent"], 201613 ^ 201607),
                "customUI": _0x8dd(_0xa95b["customUI"] || {
            "enabled": false,
                    "image": "",
                    "slots": []
        }),
                "collisionObject": _0xbd2(placement["collisionObject"] || _0xa95b["collisionObject"]),
                "interactArc": function () { var _0xfba = (329694 ^ 329688) + (126877 ^ 126876); var _0x26c = placement["interactArc"] || _0xa95b["interactArc"]; _0xfba = (135681 ^ 135682) + (852312 ^ 852315); return _0x26c ? {
            "enabled": _0x26c["enabled"] === !![],
                        "centerAngleDeg": Number(_0x26c["centerAngleDeg"]) || 297317 ^ 297279,
                        "spanDeg": Math["max"](329983 ^ 329982, Math["min"](773343 ^ 773559, Number(_0x26c["spanDeg"]) || 962264 ^ 962156)),
                        "dist": _0x26c["dist"] != null ? Number(_0x26c["dist"]) : null
        } : null; }(),
                "panelSize": function () { var _0x54_0x81e = _0xa95b["panelSize"]; return _0x54_0x81e ? {
            "width": Number(_0x54_0x81e["width"]) || null,
                        "height": Number(_0x54_0x81e["height"]) || null
        } : null; }(),
                "defaultUI": _0x8dd(_0xa95b["defaultUI"] || {
            "panelW": null,
                    "panelH": null,
                    "cellSize": null,
                    "iconScale": 1
        })
    }; }
    function _0x118a(typeName, raw, _0x86dcb, _0xc8c36c) { raw = raw || {}; if (Array["isArray"](raw["placements"])) {
        return { "placements": raw["placements"]["map"](function (placement) { return _0x85252f(placement, _0x32b18d(raw)); }) };
    } var _0x8gf19c = _0x8dd(_0x48_0x4eg[typeName] || {
        "offsetX": 0,
                "offsetY": 0,
                "spawnCount": 1,
                "slotSize": {
            "cols": _0x14ac,
                    "rows": _0x4f8c4a
        },
                "lootTable": "chest1",
                "locked": false,
                "unlockItemId": null,
                "chestOffsets": [{
                "x": 0,
                        "y": 0
            }],
                "collisionObject": _0xbd2(null)
    }); var _0xc3ed8d = (888520 ^ 888512) + (960411 ^ 960402); var _0x8d44b = Array["isArray"](raw["chestOffsets"]) && raw["chestOffsets"]["length"] ? raw["chestOffsets"] : _0x8gf19c["chestOffsets"]; _0xc3ed8d = 867690 ^ 867682; var _0xe56a = Math["min"](_0xfgg1e(raw["spawnCount"], _0x8gf19c["spawnCount"] || _0x8d44b["length"] || 432126 ^ 432127), _0x8d44b["length"] || 259418 ^ 259419); _0x86dcb = (372903 ^ 372911) + (787666 ^ 787669); var _0xd08c = _0x32b18d(raw["closed"] ? raw : _0x8gf19c); _0xc8c36c = "fdemln"; var _0x076fae = (420169 ^ 420170) + (543194 ^ 543193); var _0xc982e = []; _0x076fae = "fokeod"; for (var _0x16d = 354431 ^ 354431; _0x16d < _0xe56a; _0x16d++) {
        var _0x67ce = (515393 ^ 515401) + (825634 ^ 825633);
        var _0x9966b = _0x8d44b[_0x16d] || {
            "x": 0,
                    "y": 0
        };
        _0x67ce = (885231 ^ 885222) + (820176 ^ 820182);
        _0xc982e["push"](_0x85252f({
            "chestTypeId": _0xd08c,
                    "offsetX": (Number(raw["offsetX"]) || _0x8gf19c["offsetX"] || 871294 ^ 871294) + (Number(_0x9966b["x"]) || 278877 ^ 278877),
                    "offsetY": (Number(raw["offsetY"]) || _0x8gf19c["offsetY"] || 337672 ^ 337672) + (Number(_0x9966b["y"]) || 437515 ^ 437515),
                    "lootTable": _0xgbccb(raw["closed"] ? raw : _0x8gf19c),
                    "slotSize": raw["slotSize"] || _0x8gf19c["slotSize"],
                    "locked": raw["locked"],
                    "unlockItemId": raw["unlockItemId"],
                    "collisionObject": raw["collisionObject"] || _0x8gf19c["collisionObject"]
        }, _0xd08c));
    } return { "placements": _0xc982e }; }
    function _0x3f9d(conf) { conf = conf || {}; return {
        "cols": _0xfgg1e(conf["slotSize"] && conf["slotSize"]["cols"], _0x14ac),
                "rows": _0xfgg1e(conf["slotSize"] && conf["slotSize"]["rows"], _0x4f8c4a)
    }; }
    function _0x5af(locker) { return _0x3f9d(locker && locker["conf"] ? locker["conf"] : locker); }
    function _0x267d(grid) { return grid["cols"] * grid["rows"]; }
    function _0xc1a(locker) { if (locker && Array["isArray"](locker["inventory"]))
        return locker["inventory"]["length"]; return _0x267d(_0x5af(locker)); }
    function _0xe77c1b(conf) { var _0x4a3 = _0xgbccb(conf || {}); return _0x4a3 && _0x56fd[_0x4a3] ? _0x56fd[_0x4a3] : []; }
    function _0x356f2c() { for (var _0x1054ed in _0xe51a0c) {
        _0xecfce(_0xe51a0c[_0x1054ed]);
    } _0xe51a0c = {}; _0xa6_0x3b7 = null; _0x6f_0x45a = null; if (typeof _0x8dfcf === "function") {
        _0x8dfcf();
    } }
    function _0x5425bb() { return {
        "version": 2,
                "runtime": {
            "buttonDist": _0xd5_0x7dc["buttonDist"],
                    "btnOffsetPx": _0xd5_0x7dc["btnOffsetPx"],
                    "respawnMs": _0xd5_0x7dc["respawnMs"],
                    "highlightDist": _0xd5_0x7dc["highlightDist"],
                    "interactionRadius": _0xd5_0x7dc["interactionRadius"],
                    "showInteractionRadius": _0xd5_0x7dc["showInteractionRadius"],
                    "collisionActiveRadius": _0xd5_0x7dc["collisionActiveRadius"],
                    "collisionSyncMs": _0xd5_0x7dc["collisionSyncMs"]
        },
                "grid": {
            "cols": _0x14ac,
                    "rows": _0x4f8c4a,
                    "cellSize": _0xd5_0x7dc["cellSize"]
        },
                "rarityChance": _0x8dd(_0x53891d),
                "chestTypes": _0x8dd(_0x87g),
                "lootTables": _0x8dd(_0x56fd),
                "structures": _0x8dd(_0x7eed),
                "gasEvent": _0x8dd(_0xfa3),
                "convoyEvent": {
            "enabled": _0x06cd7a["enabled"],
                    "spawnInterval": _0x06cd7a["spawnInterval"],
                    "duration": _0x06cd7a["duration"],
                    "despawnRadius": _0x06cd7a["despawnRadius"],
                    "convoyHudVisible": _0x06cd7a["convoyHudVisible"],
                    "obstacleRadius": _0xfcc29d,
                    "chestLayout": _0x8dd(_0xg63c7a["chests"]),
                    "itemSpawnLayout": _0x8dd(_0xg63c7a["itemSpawns"])
        },
                "heliEvent": {
            "enabled": _0xcdafb["enabled"],
                    "spawnInterval": _0xcdafb["spawnInterval"],
                    "duration": _0xcdafb["duration"],
                    "despawnRadius": _0xcdafb["despawnRadius"],
                    "heliHudVisible": _0xcdafb["heliHudVisible"],
                    "smokeScale": _0xcdafb["smokeScale"],
                    "useT344": _0xcdafb["useT344"],
                    "heliTypeIdx": _0xcdafb["heliTypeIdx"],
                    "debrisCount": _0xcdafb["debrisCount"],
                    "soundDelay": _0xcdafb["soundDelay"],
                    "debrisOpacity": _0xcdafb["debrisOpacity"],
                    "debrisLayout": _0x8dd(_0x78_0x5ca),
                    "chestLayout": _0x8dd(_0x8d7eb["chests"]),
                    "itemSpawnLayout": _0x8dd(_0x8d7eb["itemSpawns"])
        }
    }; }
    function _0xb8bf0a(rawConfig, _0x269c5a, _0x7ecc5a) { rawConfig = rawConfig || {}; var _0x65a = rawConfig["runtime"] || {}; var _0x55ff = rawConfig["grid"] || {}; _0xd5_0x7dc["buttonDist"] = Number(_0x65a["buttonDist"]) || _0xb547ad["buttonDist"]; _0xd5_0x7dc["btnOffsetPx"] = Number(_0x65a["btnOffsetPx"]) || _0xb547ad["btnOffsetPx"]; _0xd5_0x7dc["respawnMs"] = Number(_0x65a["respawnMs"]) || _0xb547ad["respawnMs"]; _0xd5_0x7dc["cellSize"] = Number(_0x55ff["cellSize"]) || _0xb547ad["cellSize"]; _0xd5_0x7dc["highlightDist"] = Number(_0x65a["highlightDist"]) || _0xb547ad["highlightDist"];
        _0xd5_0x7dc["interactionRadius"] = Math.max(10, Number(_0x65a["interactionRadius"]) || _0xb547ad["interactionRadius"]);
        _0xd5_0x7dc["showInteractionRadius"] = false;
        _0xd5_0x7dc["collisionActiveRadius"] = Math.max(_0xd5_0x7dc["interactionRadius"], Number(_0x65a["collisionActiveRadius"]) || _0xb547ad["collisionActiveRadius"]);
        _0xd5_0x7dc["collisionSyncMs"] = Math.max(100, Number(_0x65a["collisionSyncMs"]) || _0xb547ad["collisionSyncMs"]); _0x14ac = _0xfgg1e(_0x55ff["cols"], 201044 ^ 201041); _0x4f8c4a = _0xfgg1e(_0x55ff["rows"], 104502 ^ 104501); _0x35a3ee = _0x14ac * _0x4f8c4a; _0x53891d = _0x8dd(rawConfig["rarityChance"] || _0xf4cgg); _0x87g = _0x8dd(_0xfc35e); if (rawConfig["chestTypes"]) {
        var _0x0c70eb = {};
        for (var _0x8509g in rawConfig["chestTypes"]) {
            _0x0c70eb[_0x8509g] = _0x39_0xb48(_0x8509g, rawConfig["chestTypes"][_0x8509g]);
        }
        _0x87g = _0x0c70eb;
    } _0x56fd = _0x8dd(rawConfig["lootTables"] || {
        "chest1": _0xc9876e,
                "chest2": _0x75g5a
    }); var _0x71917e = {}; _0x269c5a = (485033 ^ 485037) + (707676 ^ 707673); var _0xaa16ef = rawConfig["structures"] || _0x48_0x4eg; for (var _0x348cg in _0xaa16ef) {
        _0x71917e[_0x348cg] = _0x118a(_0x348cg, _0xaa16ef[_0x348cg]);
    } _0x7eed = _0x71917e; if (rawConfig["gasEvent"] && typeof rawConfig["gasEvent"] === "tcejbo".split("").reverse().join("")) {
        let _0xad455d;
        var _0x51e5ef = rawConfig["gasEvent"];
        _0xad455d = 184781 ^ 184781;
        if (typeof _0x51e5ef["spawnInterval"] === "rebmun".split("").reverse().join("") && _0x51e5ef["spawnInterval"] >= (426764 ^ 426765))
            _0xfa3["spawnInterval"] = _0x51e5ef["spawnInterval"];
        if (typeof _0x51e5ef["duration"] === "rebmun".split("").reverse().join("") && _0x51e5ef["duration"] >= (174270 ^ 174271))
            _0xfa3["duration"] = _0x51e5ef["duration"];
        if (typeof _0x51e5ef["stopAtTimer"] === "number")
            _0xfa3["stopAtTimer"] = _0x51e5ef["stopAtTimer"];
        if (typeof _0x51e5ef["fadeDuration"] === "rebmun".split("").reverse().join("") && _0x51e5ef["fadeDuration"] >= (748269 ^ 748169))
            _0xfa3["fadeDuration"] = _0x51e5ef["fadeDuration"];
        if (Array["isArray"](_0x51e5ef["maxPerIsland"]) && _0x51e5ef["maxPerIsland"]["length"] === (306946 ^ 306951))
            _0xfa3["maxPerIsland"] = _0x51e5ef["maxPerIsland"];
        if (typeof _0x51e5ef["unlimitedMax"] === "number" && _0x51e5ef["unlimitedMax"] >= (742529 ^ 742528))
            _0xfa3["unlimitedMax"] = _0x51e5ef["unlimitedMax"];
        if (typeof _0x51e5ef["randomizeCount"] === "boolean")
            _0xfa3["randomizeCount"] = _0x51e5ef["randomizeCount"];
        _0x9gf();
    } if (rawConfig["convoyEvent"] && typeof rawConfig["convoyEvent"] === "object") {
        var _0x7535ae = (387958 ^ 387967) + (333970 ^ 333969);
        var _0x15fa5f = rawConfig["convoyEvent"];
        _0x7535ae = "jiqhhm";
        if (typeof _0x15fa5f["enabled"] === "boolean")
            _0x06cd7a["enabled"] = _0x15fa5f["enabled"];
        if (typeof _0x15fa5f["spawnInterval"] === "rebmun".split("").reverse().join("") && _0x15fa5f["spawnInterval"] >= (591813 ^ 591812))
            _0x06cd7a["spawnInterval"] = _0x15fa5f["spawnInterval"];
        if (typeof _0x15fa5f["duration"] === "number" && _0x15fa5f["duration"] >= (105076 ^ 105077))
            _0x06cd7a["duration"] = _0x15fa5f["duration"];
        if (typeof _0x15fa5f["despawnRadius"] === "number" && _0x15fa5f["despawnRadius"] >= (667837 ^ 667791))
            _0x06cd7a["despawnRadius"] = _0x15fa5f["despawnRadius"];
        if (typeof _0x15fa5f["convoyHudVisible"] === "naeloob".split("").reverse().join(""))
            _0x06cd7a["convoyHudVisible"] = _0x15fa5f["convoyHudVisible"];
        if (typeof _0x15fa5f["obstacleRadius"] === "number" && _0x15fa5f["obstacleRadius"] >= (137980 ^ 137980))
            _0xfcc29d = _0x15fa5f["obstacleRadius"];
        if (Array["isArray"](_0x15fa5f["chestLayout"]))
            _0xg63c7a["chests"] = _0x15fa5f["chestLayout"];
        if (Array["isArray"](_0x15fa5f["itemSpawnLayout"]))
            _0xg63c7a["itemSpawns"] = _0x15fa5f["itemSpawnLayout"];
        _0x1d5a();
        _0xb1b6b();
    } if (rawConfig["heliEvent"] && typeof rawConfig["heliEvent"] === "object") {
        let _0x996cf;
        var _0x1591f = rawConfig["heliEvent"];
        _0x996cf = "enlcgo";
        if (typeof _0x1591f["enabled"] === "naeloob".split("").reverse().join(""))
            _0xcdafb["enabled"] = _0x1591f["enabled"];
        if (typeof _0x1591f["spawnInterval"] === "rebmun".split("").reverse().join("") && _0x1591f["spawnInterval"] >= (900775 ^ 900774))
            _0xcdafb["spawnInterval"] = _0x1591f["spawnInterval"];
        if (typeof _0x1591f["duration"] === "number" && _0x1591f["duration"] >= (908766 ^ 908767))
            _0xcdafb["duration"] = _0x1591f["duration"];
        if (typeof _0x1591f["despawnRadius"] === "rebmun".split("").reverse().join("") && _0x1591f["despawnRadius"] >= (362281 ^ 362267))
            _0xcdafb["despawnRadius"] = _0x1591f["despawnRadius"];
        if (typeof _0x1591f["heliHudVisible"] === "boolean")
            _0xcdafb["heliHudVisible"] = _0x1591f["heliHudVisible"];
        if (typeof _0x1591f["smokeScale"] === "number" && _0x1591f["smokeScale"] > (448972 ^ 448972))
            _0xcdafb["smokeScale"] = _0x1591f["smokeScale"];
        if (typeof _0x1591f["useT344"] === "naeloob".split("").reverse().join(""))
            _0xcdafb["useT344"] = _0x1591f["useT344"];
        if (typeof _0x1591f["heliTypeIdx"] === "number")
            _0xcdafb["heliTypeIdx"] = _0x1591f["heliTypeIdx"];
        if (typeof _0x1591f["debrisCount"] === "number" && _0x1591f["debrisCount"] >= (833738 ^ 833738))
            _0xcdafb["debrisCount"] = _0x1591f["debrisCount"];
        if (typeof _0x1591f["soundDelay"] === "number" && _0x1591f["soundDelay"] >= (897978 ^ 897978))
            _0xcdafb["soundDelay"] = _0x1591f["soundDelay"];
        if (typeof _0x1591f["debrisOpacity"] === "rebmun".split("").reverse().join(""))
            _0xcdafb["debrisOpacity"] = Math["max"](699731 ^ 699731, Math["min"](912442 ^ 912443, _0x1591f["debrisOpacity"]));
        if (Array["isArray"](_0x1591f["debrisLayout"]))
            _0x78_0x5ca = _0x1591f["debrisLayout"];
        if (Array["isArray"](_0x1591f["chestLayout"]))
            _0x8d7eb["chests"] = _0x1591f["chestLayout"];
        if (Array["isArray"](_0x1591f["itemSpawnLayout"]))
            _0x8d7eb["itemSpawns"] = _0x1591f["itemSpawnLayout"];
        _0xbbb11d();
        _0xf7b77b();
    } _0x356f2c(); if (typeof _0x45_0x6f4 === "noitcnuf".split("").reverse().join(""))
        _0x45_0x6f4(); var _0x95eb6a = _0x6ec34e(); _0x7ecc5a = (206329 ^ 206333) + (847809 ^ 847814); if (_0x95eb6a)
        _0x95eb6a[K["redraw"]] = !![]; }
    function _0x4ae(locker) { return locker["x"] + locker["conf"]["offsetX"] + (locker["posOffX"] || 812537 ^ 812537); }
    var _0x7a5b = "mdz_chest_config";
    _0xc6f = (515028 ^ 515030) + (400757 ^ 400752);
    var _0xce_0xf18 = (586362 ^ 586365) + (854978 ^ 854983);
    var _0x4g431f = "gifnoc".split("").reverse().join("");
    _0xce_0xf18 = "ckijbn";
    var _0x28ad8c = (737269 ^ 737269) + (832994 ^ 832993);
    var _0x3564fb = "current";
    _0x28ad8c = (487300 ^ 487303) + (173878 ^ 173886);
    function _0x81c5e(callback) { var _0xf1f41f = indexedDB["open"](_0x7a5b, 108560 ^ 108561); _0xf1f41f["onupgradeneeded"] = function (e) { e["target"]["result"]["createObjectStore"](_0x4g431f); }; _0xf1f41f["onsuccess"] = function (e) { callback(null, e["target"]["result"]); }; _0xf1f41f["onerror"] = function (e) { callback(e["target"]["error"], null); }; }
    function _0x79gea(config) { _0x81c5e(function (err, db) { if (err || !db)
        return; var _0xe1032a = db["transaction"](_0x4g431f,
                "readwrite"); _0xe1032a["objectStore"](_0x4g431f)["put"](config, _0x3564fb); }); }
    function _0xad52e(callback) { _0x81c5e(function (err, db, _0x8bd) { if (err || !db) {
        callback(null);
        return;
    } var _0xa80e1b = db["transaction"](_0x4g431f,
                "ylnodaer".split("").reverse().join("")); var _0xb18 = _0xa80e1b["objectStore"](_0x4g431f)["get"](_0x3564fb); _0x8bd = 751079 ^ 751073; _0xb18["onsuccess"] = function () { callback(_0xb18["result"] || null); }; _0xb18["onerror"] = function () { callback(null); }; }); }
    function _0x40_0xg74(locker) { return locker["y"] + locker["conf"]["offsetY"] + (locker["posOffY"] || 866052 ^ 866052); }
    function _0xb55c3f(locker) { if (locker["conf"]["locked"] && !locker["unlocked"])
        return "images/button_chest_unlock.png"; return "gnp.nottub/segami".split("").reverse().join(""); }
    function _0x41_0x938(baseKey, index) { return baseKey + "_" + index; }
    function _0x63f36d(typeName, _0x93a) { var _0x6b8fbd = _0x6ec34e(); _0x93a = (785794 ^ 785796) + (535590 ^ 535591); if (!_0x6b8fbd)
        return null; var _0xe14 = _0x6b8fbd[K["types"]]; for (var i = 811590 ^ 811590; i < _0xe14["length"]; i++) {
        if (_0xe14[i]["name"] === typeName)
            return _0xe14[i];
    } return null; }
    function _0xgfc8ea(instance) { if (!instance)
        return; instance["opacity"] = 514263 ^ 514263; instance["collisionsEnabled"] = false; instance["x"] = -99999; instance["y"] = -99999; if (typeof instance[K["bboxFn"]] === "function")
        instance[K["bboxFn"]](); }
    function _0xecfce(locker) { if (!locker || !locker["collisionInstances"])
        return; for (var i = 286698 ^ 286698; i < locker["collisionInstances"]["length"]; i++) {
        _0xgfc8ea(locker["collisionInstances"][i]);
    } }
    function _0x8e3dg(locker, layer, _0x279gd, _0x5b3c) { if (!locker)
        return; var _0xa3872b = locker["conf"] && locker["conf"]["collisionObject"] ? _0xbd2(locker["conf"]["collisionObject"]) : null; _0x279gd = "mfldmo"; if (!_0xa3872b || !_0xa3872b["enabled"] || !layer) {
        _0xecfce(locker);
        return;
    } var _0x54603e = (406921 ^ 406913) + (450824 ^ 450816); var _0x6266f = _0x6ec34e(); _0x54603e = "dcfklm"; if (!_0x6266f || typeof _0x6266f[K["createFn"]] !== "function")
        return; var _0x957da = _0x63f36d(_0xa3872b["type"] || "t348"); if (!_0x957da)
        return; if (!locker["collisionInstances"])
        locker["collisionInstances"] = []; while (locker["collisionInstances"]["length"] < (498860 ^ 498862)) {
        var _0x5398c = _0x6266f[K["createFn"]](_0x957da, layer, -99999, -99999);
        if (!_0x5398c)
            break;
        locker["collisionInstances"]["push"](_0x5398c);
    } var _0x1b5c6b = _0x4ae(locker) + _0xa3872b["offsetX"]; _0x5b3c = 839973 ^ 839980; var _0xc56b = (651846 ^ 651844) + (113810 ^ 113813); var _0xab0e = _0x40_0xg74(locker) + _0xa3872b["offsetY"]; _0xc56b = 276870 ^ 276864; for (var i = 566558 ^ 566558; i < locker["collisionInstances"]["length"]; i++) {
        var _0x5be76d = locker["collisionInstances"][i];
        _0x5be76d["x"] = _0x1b5c6b;
        _0x5be76d["y"] = _0xab0e;
        _0x5be76d["width"] = i === (514667 ^ 514667) ? _0xa3872b["width"] : -_0xa3872b["width"];
        _0x5be76d["height"] = i === (966270 ^ 966270) ? _0xa3872b["height"] : -_0xa3872b["height"];
        _0x5be76d["opacity"] = 0.01;
        _0x5be76d["collisionsEnabled"] = !![];
        if (typeof _0x5be76d[K["bboxFn"]] === "noitcnuf".split("").reverse().join(""))
            _0x5be76d[K["bboxFn"]]();
    } }
    function _0x6ae0c(baseKey, markerIndex, x, y, conf, structureType, marker) { var _0xfdeafa = _0x41_0x938(baseKey, markerIndex); _0xe51a0c[_0xfdeafa] = {
        "state": "closed",
                "lootTime": 0,
                "x": x,
                "y": y,
                "conf": conf,
                "showButton": false,
                "mapKey": _0xfdeafa,
                "baseMapKey": baseKey,
                "markerIndex": markerIndex,
                "structureType": structureType,
                "chestTypeId": conf["chestTypeId"] || null,
                "inventory": _0xf5_0x8d8(conf),
                "posOffX": marker["x"],
                "posOffY": marker["y"],
                "searched": false,
                "unlocked": conf["locked"] !== !![],
                "collisionInstances": []
    }; return _0xe51a0c[_0xfdeafa]; }
    function _0x29a0b(instance, conf, structureType, _0x7d18b) { var _0x7dda = Math["round"](instance["x"]) + "_" + Math["round"](instance["y"]); var _0xd077e = Array["isArray"](conf["placements"]) && conf["placements"]["length"] ? conf["placements"] : _0x118a(structureType, conf)["placements"]; _0x7d18b = 228533 ^ 228541; var _0xab3f1f = _0xd077e["length"]; var _0x3beed = Object["create"](null); for (var _0x80432b = 160320 ^ 160320; _0x80432b < _0xab3f1f; _0x80432b++) {
        var _0x3c0f7d = _0xd077e[_0x80432b] || {
            "chestTypeId": "type1",
                    "offsetX": 0,
                    "offsetY": 0
        };
        var _0x278gf = _0xdd3b6a(_0x3c0f7d);
        var _0xea8d9f = {
            "x": 0,
                    "y": 0
        };
        let _0x1ef;
        var _0xb03ec = _0x41_0x938(_0x7dda, _0x80432b);
        _0x1ef = "olpmip";
        _0x3beed[_0xb03ec] = !![];
        var _0x19e4a = (580378 ^ 580381) + (601073 ^ 601078);
        var _0x5428e = _0x278gf["randomLootChance"] != null ? _0x278gf["randomLootChance"] : 0.5;
        _0x19e4a = (660144 ^ 660147) + (150626 ^ 150634);
        if (!_0x2c734c[_0xb03ec]) {
            _0x2c734c[_0xb03ec] = Math["random"]() < _0x5428e ? "spawn" : "skip";
        }
        if (_0x2c734c[_0xb03ec] === "skip") {
            if (_0xe51a0c[_0xb03ec]) {
                if (_0xa6_0x3b7 === _0xb03ec)
                    _0x8dfcf();
                _0xecfce(_0xe51a0c[_0xb03ec]);
                delete _0xe51a0c[_0xb03ec];
            }
            continue;
        }
        let _0x7fc;
        var _0xe3g = _0xe51a0c[_0xb03ec];
        _0x7fc = (452058 ^ 452050) + (995053 ^ 995055);
        if (!_0xe3g) {
            _0xe3g = _0x6ae0c(_0x7dda, _0x80432b, instance["x"], instance["y"], _0x278gf, structureType, _0xea8d9f);
        }
        _0xe3g["x"] = instance["x"];
        _0xe3g["y"] = instance["y"];
        _0xe3g["conf"] = _0x278gf;
        _0xe3g["structureType"] = structureType;
        _0xe3g["chestTypeId"] = _0x278gf["chestTypeId"] || null;
        _0xe3g["baseMapKey"] = _0x7dda;
        _0xe3g["markerIndex"] = _0x80432b;
        _0xe3g["posOffX"] = Number(_0xea8d9f["x"]) || 475829 ^ 475829;
        _0xe3g["posOffY"] = Number(_0xea8d9f["y"]) || 449999 ^ 449999;
        if (!_0xe3g["unlocked"] && _0x278gf["locked"] !== !![])
            _0xe3g["unlocked"] = !![];
    } for (var _0x129 in _0xe51a0c) {
        var _0xc5c = _0xe51a0c[_0x129];
        if (_0xc5c["baseMapKey"] === _0x7dda && !_0x3beed[_0x129]) {
            if (_0xa6_0x3b7 === _0x129)
                _0x8dfcf();
            _0xecfce(_0xc5c);
            delete _0xe51a0c[_0x129];
        }
    } return _0x3beed; }
    function _0x0e958f(lockerKey, _0x394cd) { var _0x8ab2f = _0xe51a0c[lockerKey]; if (!_0x8ab2f)
        return false; var _0xb2462d = _0x4ae(_0x8ab2f); var _0xf9eb = _0x40_0xg74(_0x8ab2f); _0x394cd = (417299 ^ 417299) + (401574 ^ 401570); if (window["MDZ"] && typeof window["MDZ"]["tp"] === "noitcnuf".split("").reverse().join("")) {
        window["MDZ"]["tp"](_0xb2462d, _0xf9eb);
        return !![];
    } var _0x80bc6a = _0x5e9e6g("t181")[440307 ^ 440307]; if (!_0x80bc6a)
        return false; var _0xf8ac6b = _0x6ec34e(); setTimeout(function () { _0x80bc6a["x"] = _0xb2462d; _0x80bc6a["y"] = _0xf9eb; if (typeof _0x80bc6a[K["bboxFn"]] === "function")
        _0x80bc6a[K["bboxFn"]](); if (_0xf8ac6b && _0xf8ac6b[K["layout"]]) {
        _0xf8ac6b[K["layout"]]["scrollX"] = _0xb2462d;
        _0xf8ac6b[K["layout"]]["scrollY"] = _0xf9eb;
    } if (_0xf8ac6b)
        _0xf8ac6b[K["redraw"]] = !![]; }, 142472 ^ 142522); return !![]; }
    function _0x623bd(locker) { if (!locker || locker["unlocked"] || locker["conf"]["locked"] !== !![])
        return !![]; var _0x3ed = (792621 ^ 792617) + (279550 ^ 279547); var _0x55_0xc16 = window["MDZChestConsumeUnlock"]; _0x3ed = (602630 ^ 602639) + (970774 ^ 970768); if (typeof _0x55_0xc16 === "function") {
        if (_0x55_0xc16(locker["conf"]["unlockItemId"], locker) === false) {
            return false;
        }
    } _0x4ee8f(locker["conf"]["unlockSounds"], _0x49_0x7bc); locker["unlocked"] = !![]; return !![]; }
    window["MDZChestRuntime"] = {
        "getConfig": function () { return _0x8dd(_0x5425bb()); },
            "setConfig": function (config) { _0xb8bf0a(config); return _0x8dd(_0x5425bb()); },
            "getActiveLockers": function () { var _0xa4db = []; for (var _0xd14 in _0xe51a0c) {
            var _0x456f = (821691 ^ 821683) + (255584 ^ 255589);
            var _0x8fb24e = _0xe51a0c[_0xd14];
            _0x456f = 540555 ^ 540552;
            var _0xggcbbe = _0x5af(_0x8fb24e);
            _0xa4db["push"]({
                "mapKey": _0x8fb24e["mapKey"],
                        "structureType": _0x8fb24e["structureType"] || null,
                        "chestTypeId": _0x8fb24e["chestTypeId"] || null,
                        "worldX": Math["round"](_0x4ae(_0x8fb24e)),
                        "worldY": Math["round"](_0x40_0xg74(_0x8fb24e)),
                        "state": _0x8fb24e["state"],
                        "itemCount": _0x8fb24e["inventory"]["filter"](function (item) { return !!item; })["length"],
                        "slotCols": _0xggcbbe["cols"],
                        "slotRows": _0xggcbbe["rows"],
                        "searched": _0x8fb24e["searched"],
                        "locked": _0x8fb24e["conf"]["locked"] === !![] && !_0x8fb24e["unlocked"]
            });
        } return _0xa4db; },
            "teleportToLocker": function (lockerKey) { return _0x0e958f(lockerKey); },
            "tryUnlockLocker": function (lockerKey) { return _0x623bd(_0xe51a0c[lockerKey]); },
            "setRequireGeneratorPower": function (enabled) { _0x553c = enabled === !![]; _0x5aa1a(); return _0x553c; },
            "setPowerRadius": function (radius) { _0x459ec = _0xfgg1e(radius, _0x459ec); return _0x459ec; },
            "setPowerSourceIds": function (ids) { if (Array["isArray"](ids)) {
            _0xe8gf = ids["map"](function (v) { return Number(v); })["filter"](function (v) { return isFinite(v); });
        } _0x5aa1a(); return _0xe8gf["slice"](); },
            "setPowerSourceTypeNames": function (names) { if (Array["isArray"](names)) {
            _0x51_0x675 = names["map"](function (v) { return String(v); });
        } _0x5aa1a(); return _0x51_0x675["slice"](); },
            "setChestPowerRequirement": function (lockerKey, enabled) { var _0x3d4b4b = (791591 ^ 791585) + (694516 ^ 694512); var _0xcb39e = _0xe51a0c[lockerKey]; _0x3d4b4b = "gjdpjm".split("").reverse().join(""); if (!_0xcb39e || !_0xcb39e["conf"])
            return false; _0xcb39e["conf"]["powerRequired"] = enabled === !![]; return !![]; },
            "isLockerPowered": function (lockerKey) { var _0xbbac7b = _0xe51a0c[lockerKey]; return !!_0xbbac7b && _0x7e2(_0xbbac7b); },
            "getPowerStatus": function () { return _0x3f872d(); },
            "openDebugWindow": function () { _0xfgge(); return !![]; }
    };
    window["MDZChestConsumeUnlock"] = function (unlockItemId) { var _0x73c27c = {
        786: "Red Key", 787: "Blue Key", 788: "Black Key"
    }; var _0x28b84d = _0x73c27c[unlockItemId] || "the matching key"; _0xdd_0xag1(_0xcf313g(843052 ^ 843315, _0x28b84d),
            "#ffcc44"); return false; };
    function _0xcf2() { if (_0x47_0x4db !== (736992 ^ 736993))
        return; if (document["getElementById"]("rehcnual-gubed-tsehc-zdm".split("").reverse().join("")))
        return; var _0x56_0x26e = document["createElement"]("button"); _0x56_0x26e["id"] = "mdz-chest-debug-launcher"; _0x56_0x26e["textContent"] = "Chest Debug"; _0x56_0x26e["style"]["position"] = "dexif".split("").reverse().join(""); _0x56_0x26e["style"]["top"] = "xp21".split("").reverse().join(""); _0x56_0x26e["style"]["right"] = "12px"; _0x56_0x26e["style"]["zIndex"] = "2147483647"; _0x56_0x26e["style"]["padding"] = "8px 12px"; _0x56_0x26e["style"]["border"] = "1px solid rgba(255,255,255,0.35)"; _0x56_0x26e["style"]["background"] = ")9.0,82,42,02(abgr".split("").reverse().join(""); _0x56_0x26e["style"]["color"] = "#f3ead5"; _0x56_0x26e["style"]["font"] = "IU eogeS xp21".split("").reverse().join(""); _0x56_0x26e["style"]["cursor"] = "pointer"; _0x56_0x26e["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xfgge(); }); document["body"]["appendChild"](_0x56_0x26e); }
    var _0x827a = (516313 ^ 516317) + (164655 ^ 164652);
    var _0xdc93b = {
        "loaded": false,
            "structureData": null,
            "items": [],
            "itemIndex": {},
            "tab": "types",
            "selectedChestTypeId": "type1",
            "selectedStructureType": null,
            "selectedPlacementIndex": -(745879 ^ 745878),
            "imageCache": {},
            "ui": null,
            "drawMetrics": null,
            "picker": null,
            "statusText": "Editor ready.",
            "structureSearch": "",
            "placementEditMode": !![],
            "canvasDrag": null,
            "highlightStructures": false,
            "showGeneratorDebug": false,
            "showArcOverlay": false,
            "realTimePlacement": false,
            "convoyLayoutMode": false,
            "heliLayoutMode": false,
            "heliDebrisMode": false
    };
    _0x827a = (288115 ^ 288116) + (771040 ^ 771045);
    function _0xfgge() { if (!_0xdc93b["ui"])
        _0x96a61b(); var _0x4edb = (175891 ^ 175899) + (767955 ^ 767957); var _0xd1d7c = _0xdc93b["ui"]["root"]; _0x4edb = "gkdpph"; var _0x1c68e = _0xd1d7c["style"]["display"] !== "grid"; _0xd1d7c["style"]["display"] = _0x1c68e ? "grid" : "none"; if (_0x1c68e)
        _0x77agaa(); }
    function _0x96a61b(_0x4_0xb7b) { if (!document["getElementById"]("elyts-gubed-tsehc-zdm".split("").reverse().join(""))) {
        var _0xd8f = (453681 ^ 453683) + (505149 ^ 505148);
        var _0x392f4f = document["createElement"]("elyts".split("").reverse().join(""));
        _0xd8f = 701574 ^ 701570;
        _0x392f4f["id"] = "mdz-chest-debug-style";
        _0x392f4f["textContent"] = "" + "}fires-snas,IU eogeS xp21:tnof{aeratxet toor-gubed-tsehc-zdm#,tceles toor-gubed-tsehc-zdm#,tupni toor-gubed-tsehc-zdm#,nottub toor-gubed-tsehc-zdm#".split("").reverse().join("") + "#mdz-chest-debug-root button{border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.06);color:#f3ead5;border-radius:10px;cursor:pointer}" + "#mdz-chest-debug-root button:hover{background:rgba(255,255,255,0.12)}" + "}xob-redrob:gnizis-xob;xp8 xp7:gniddap;xp8:suidar-redrob;5dae3f#:roloc;)22.0,0,0,0(abgr:dnuorgkcab;)21.0,552,552,552(abgr dilos xp1:redrob;%001:htdiw{aeratxet toor-gubed-tsehc-zdm#,tceles toor-gubed-tsehc-zdm#,tupni toor-gubed-tsehc-zdm#".split("").reverse().join("") + "#mdz-chest-debug-root .mdz-card{border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.04);border-radius:12px;padding:10px}" + "#mdz-chest-debug-root .mdz-picker{position:absolute;inset:24px;display:none;grid-template-rows:auto auto auto 1fr;background:rgba(11,13,16,0.98);border:1px solid rgba(255,255,255,0.12);border-radius:16px;overflow:hidden;z-index:3}" + "}xp21:gniddap;neddih:x-wolfrevo;otua:y-wolfrevo;xp8:pag;))rf1,xp022(xamnim,llif-otua(taeper:snmuloc-etalpmet-dirg;dirg:yalpsid{dirg-rekcip-zdm. toor-gubed-tsehc-zdm#".split("").reverse().join("") + "})80.0,552,552,552(abgr dilos xp1:mottob-redrob;xp41 xp8:gniddap;xp6:pag;parw:parw-xelf;xelf:yalpsid{stac-rekcip-zdm. toor-gubed-tsehc-zdm#".split("").reverse().join("") + "#mdz-chest-debug-root .mdz-picker-cat{padding:3px 10px;border-radius:20px;font-size:11px;cursor:pointer;border:1px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.04)}" + "#mdz-chest-debug-root .mdz-picker-cat.active{background:rgba(90,180,255,0.18);border-color:#5ab4ff;color:#5ab4ff}" + "})40.0,552,552,552(abgr:dnuorgkcab;)80.0,552,552,552(abgr dilos xp1:redrob;xp21:suidar-redrob;xp8:gniddap;retnec:smeti-ngila;xp01:pag;otua rf1 xp86:snmuloc-etalpmet-dirg;dirg:yalpsid{drac-meti-zdm. toor-gubed-tsehc-zdm#".split("").reverse().join("") + "})52.0,0,0,0(abgr:dnuorgkcab;)80.0,552,552,552(abgr dilos xp1:redrob;xp8:suidar-redrob;xp04:thgieh;xp04:htdiw{noci-meti-zdm. toor-gubed-tsehc-zdm#".split("").reverse().join("") + "#mdz-chest-debug-root .mdz-thumb{width:64px;height:64px;border-radius:10px;object-fit:contain;background:rgba(0,0,0,0.25);border:1px solid rgba(255,255,255,0.08)}";
        document["head"]["appendChild"](_0x392f4f);
    } var _0xf7fe = document["createElement"]("vid".split("").reverse().join("")); _0xf7fe["id"] = "mdz-chest-debug-root"; _0xf7fe["style"]["position"] = "fixed"; _0xf7fe["style"]["inset"] = "18px"; _0xf7fe["style"]["zIndex"] = "2147483646"; _0xf7fe["style"]["display"] = "enon".split("").reverse().join(""); _0xf7fe["style"]["gridTemplateRows"] = "rf1 otua otua".split("").reverse().join(""); _0xf7fe["style"]["background"] = ")59.0,81,41,01(abgr".split("").reverse().join(""); _0xf7fe["style"]["border"] = "1px solid rgba(255,255,255,0.12)"; _0xf7fe["style"]["borderRadius"] = "xp41".split("").reverse().join(""); _0xf7fe["style"]["overflow"] = "hidden"; _0xf7fe["style"]["color"] = "5dae3f#".split("").reverse().join(""); _0xf7fe["style"]["font"] = "IU eogeS xp21".split("").reverse().join(""); _0xf7fe["innerHTML"] = "" + "<div style=\"display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid rgba(255,255,255,0.1);background:rgba(22,28,34,0.96)\">" + "<div style=\"display:flex;gap:8px;align-items:center;flex-wrap:wrap\">" + ">gnorts/<lenaP gubeD tsehC>\"xp41:ezis-tnof\"=elyts gnorts<".split("").reverse().join("") + "<span data-role=\"lang-badge\" style=\"font-size:11px;background:rgba(255,200,60,0.15);border:1px solid rgba(255,200,60,0.3);border-radius:6px;padding:2px 8px;color:#ffd966;margin-left:4px\">?</span>" + "<button data-tab=\"types\" style=\"padding:6px 10px\">Chest Types</button>" + "<button data-tab=\"structures\" style=\"padding:6px 10px\">Chest Configuration</button>" + "<button data-tab=\"active\" style=\"padding:6px 10px\">Active Chests</button>" + ">nottub/<renwapS tnevE>\"xp01 xp6:gniddap\"=elyts \"tneve\"=bat-atad nottub<".split("").reverse().join("") + "</div>" + ">\"xp8:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + "<button data-action=\"apply\" style=\"padding:6px 10px\">Apply Runtime</button>" + "gubed-rotareneg-elggot-atad \"xobkcehc\"=epyt tupni<>\"49eacb#:roloc;xp21:ezis-tnof;xp6:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (_0xdc93b["showGeneratorDebug"] ? " checked" : "") + "> Generator Debug</label>" + "yalrevo-cra-elggot-atad \"xobkcehc\"=epyt tupni<>\"49eacb#:roloc;xp21:ezis-tnof;xp6:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (_0xdc93b["showArcOverlay"] ? "dekcehc ".split("").reverse().join("") : "") + "> Arc Overlay</label>" + "<label style=\"display:flex;align-items:center;gap:6px;font-size:12px;color:#bcae94\"><input type=\"checkbox\" data-toggle-lang-xml" + (_0x3e5f ? " checked" : "") + "> Lang XML</label>" + "<button data-action=\"import\" style=\"padding:6px 10px\">Import JSON</button>" + "<button data-action=\"copy\" style=\"padding:6px 10px\">Copy JSON</button>" + "<button data-action=\"download\" style=\"padding:6px 10px\">Download JSON</button>" + ">nottub/<devaS raelC>\"xp01 xp6:gniddap\"=elyts \"bdi-raelc\"=noitca-atad nottub<".split("").reverse().join("") + ">nottub/<esolC>\"xp01 xp6:gniddap\"=elyts \"esolc\"=noitca-atad nottub<".split("").reverse().join("") + "</div>" + ">vid/<".split("").reverse().join("") + "<div data-role=\"status\" style=\"padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.08);color:#bcae94\">Editor ready.</div>" + ">\"0:thgieh-nim;xp063 rf1 xp082:snmuloc-etalpmet-dirg;dirg:yalpsid;evitaler:noitisop\"=elyts vid<".split("").reverse().join("") + ">vid/<>\"xp01:gniddap;)80.0,552,552,552(abgr dilos xp1:thgir-redrob;otua:wolfrevo\"=elyts \"tfel\"=elor-atad vid<".split("").reverse().join("") + "<div data-role=\"center\" style=\"overflow:auto;padding:10px\"></div>" + "<div data-role=\"right\" style=\"overflow:auto;border-left:1px solid rgba(255,255,255,0.08);padding:10px\"></div>" + "<div class=\"mdz-picker\" data-role=\"picker\"></div>" + ">vid/<".split("").reverse().join(""); document["body"]["appendChild"](_0xf7fe); _0xf7fe["addEventListener"]("keydown", function (e) { e["stopPropagation"](); }); _0xf7fe["addEventListener"]("puyek".split("").reverse().join(""), function (e) { e["stopPropagation"](); }); _0xf7fe["addEventListener"]("sserpyek".split("").reverse().join(""), function (e) { e["stopPropagation"](); }); _0xdc93b["ui"] = {
        "root": _0xf7fe,
                "left": _0xf7fe["querySelector"]("[data-role=\"left\"]"),
                "center": _0xf7fe["querySelector"]("[data-role=\"center\"]"),
                "right": _0xf7fe["querySelector"]("]\"thgir\"=elor-atad[".split("").reverse().join("")),
                "status": _0xf7fe["querySelector"]("[data-role=\"status\"]"),
                "picker": _0xf7fe["querySelector"]("]\"rekcip\"=elor-atad[".split("").reverse().join(""))
    }; _0xf7fe["querySelector"]("[data-action=\"close\"]")["addEventListener"]("click", _0xfgge); _0xf7fe["querySelector"]("]\"ylppa\"=noitca-atad[".split("").reverse().join(""))["addEventListener"]("click", function () { var _0xa1gbc = _0x5425bb(); _0xb8bf0a(_0xa1gbc); _0x79gea(_0xa1gbc); _0xdc93b["statusText"] = "Runtime config applied and saved to IndexedDB."; _0x1f051d(); }); var _0xda389c = _0xf7fe["querySelector"]("]gubed-rotareneg-elggot-atad[".split("").reverse().join("")); if (_0xda389c) {
        _0xda389c["addEventListener"]("change", function () { _0xdc93b["showGeneratorDebug"] = this["checked"]; _0x1f051d(); });
    } var _0x810cc = _0xf7fe["querySelector"]("[data-toggle-arc-overlay]"); _0x4_0xb7b = (444500 ^ 444496) + (859575 ^ 859569); if (_0x810cc) {
        _0x810cc["addEventListener"]("egnahc".split("").reverse().join(""), function () { _0xdc93b["showArcOverlay"] = this["checked"]; });
    } var _0x3e3cdf = _0xf7fe["querySelector"]("[data-toggle-lang-xml]"); if (_0x3e3cdf) {
        _0x3e3cdf["addEventListener"]("egnahc".split("").reverse().join(""), function () { _0x3e5f = this["checked"]; });
    } _0xf7fe["querySelector"]("]\"ypoc\"=noitca-atad[".split("").reverse().join(""))["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0x053cd = JSON["stringify"](_0x5425bb(), null, 682781 ^ 682783); if (navigator["clipboard"] && navigator["clipboard"]["writeText"])
        navigator["clipboard"]["writeText"](_0x053cd)["catch"](function () { }); _0xdc93b["statusText"] = "Config JSON copied to clipboard."; _0x1f051d(); }); _0xf7fe["querySelector"]("]\"daolnwod\"=noitca-atad[".split("").reverse().join(""))["addEventListener"]("click", function (_0x1fe33f) { var _0x1d11a = (399172 ^ 399174) + (198951 ^ 198947); var _0x131 = JSON["stringify"](_0x5425bb(), null, 213336 ^ 213338); _0x1d11a = "ngljco".split("").reverse().join(""); var _0x3feg0e = new Blob([_0x131], { "type": "application/json" }); var _0x514e5a = URL["createObjectURL"](_0x3feg0e); _0x1fe33f = "dgcboj"; var _0x6e9b = (477844 ^ 477842) + (522673 ^ 522680); var _0xc93bd = document["createElement"]("a"); _0x6e9b = (126966 ^ 126974) + (910194 ^ 910195); _0xc93bd["href"] = _0x514e5a; _0xc93bd["download"] = "chest_config.json"; _0xc93bd["click"](); setTimeout(function () { URL["revokeObjectURL"](_0x514e5a); }, 627765 ^ 628701); _0xdc93b["statusText"] = "Config JSON downloaded."; _0x1f051d(); }); _0xf7fe["querySelector"]("[data-action=\"import\"]")["addEventListener"]("click", function (_0x9ced) { var _0xfebdf = document["createElement"]("tupni".split("").reverse().join("")); _0x9ced = (670105 ^ 670108) + (683379 ^ 683386); _0xfebdf["type"] = "file"; _0xfebdf["accept"] = "nosj.".split("").reverse().join(""); _0xfebdf["addEventListener"]("change", function () { if (!_0xfebdf["files"]["length"])
        return; var _0x6a1ef = new FileReader(); _0x6a1ef["onload"] = function () { try {
        var _0xcf98e = (133381 ^ 133389) + (946216 ^ 946208);
        var _0x92b1eg = JSON["parse"](_0x6a1ef["result"]);
        _0xcf98e = "jimheo".split("").reverse().join("");
        _0xb8bf0a(_0x92b1eg);
        _0x79gea(_0x92b1eg);
        _0xdc93b["statusText"] = ".elif morf gifnoc deilppa dna detropmI".split("").reverse().join("");
        _0x1f051d();
    }
    catch (e) {
        _0xdc93b["statusText"] = " :deliaf tropmI".split("").reverse().join("") + e["message"];
        _0x1f051d();
    } }; _0x6a1ef["readAsText"](_0xfebdf["files"][526369 ^ 526369]); }); _0xfebdf["click"](); }); _0xf7fe["querySelector"]("[data-action=\"clear-idb\"]")["addEventListener"]("click", function () { _0x81c5e(function (err, db, _0x3fb) { if (err || !db)
        return; var _0x8f4be = db["transaction"](_0x4g431f,
                    "etirwdaer".split("").reverse().join("")); _0x3fb = (209085 ^ 209082) + (404353 ^ 404359); _0x8f4be["objectStore"](_0x4g431f)["delete"](_0x3564fb); }); _0xdc93b["statusText"] = "Cleared saved config from IndexedDB. Next reload will use chest_config.json."; _0x1f051d(); }); var _0x01f4c = (656924 ^ 656927) + (983708 ^ 983711); var _0x133cca = _0xf7fe["querySelectorAll"]("]bat-atad[".split("").reverse().join("")); _0x01f4c = 381618 ^ 381623; for (var i = 734911 ^ 734911; i < _0x133cca["length"]; i++) {
        _0x133cca[i]["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xdc93b["tab"] = this["getAttribute"]("bat-atad".split("").reverse().join("")); _0x1f051d(); });
    } }
    function _0xf3bcbf(xmlText) { var _0xfa8e = (343047 ^ 343046) + (906843 ^ 906842); var _0x4a92c = new DOMParser()["parseFromString"](xmlText,
            "application/xml"); _0xfa8e = "gcnbel".split("").reverse().join(""); var _0xbb_0x353 = (316593 ^ 316593) + (782256 ^ 782257); var _0x0be77d = _0x4a92c["querySelectorAll"]("item"); _0xbb_0x353 = 119767 ^ 119775; var _0xc9c = (808526 ^ 808524) + (898952 ^ 898956); var _0x2gdf8a = []; _0xc9c = 160909 ^ 160906; for (var i = 716909 ^ 716909; i < _0x0be77d["length"]; i++) {
        var _0xedg5c = _0x0be77d[i]["querySelector"]("id");
        var _0x6affgf = _0x0be77d[i]["querySelector"]("eman".split("").reverse().join(""));
        var _0x67f09a = (822279 ^ 822287) + (834460 ^ 834461);
        var _0x2d7g = Number(_0xedg5c ? _0xedg5c["textContent"] : 357329 ^ 357329);
        _0x67f09a = "knoefe";
        if (!_0x2d7g)
            continue;
        _0x2gdf8a["push"]({
            "id": _0x2d7g,
                    "name": (_0x6affgf ? _0x6affgf["textContent"] : "")["trim"]()
        });
    } return _0x2gdf8a; }
    function _0x0d5eg(value) { return String(value)["replace"](new RegExp("&",
            "g"),
            "&amp;")["replace"](new RegExp("<",
            "g"),
            "&lt;")["replace"](new RegExp(">",
            "g"),
            ";tg&".split("").reverse().join(""))["replace"](new RegExp("\\\"",
            "g"),
            "&quot;")["replace"](new RegExp("'",
            "g"),
            "&#39;"); }
    // Loader inti (structure_loader_data.json + l_eng_items.xml -> itemIndex)
    // dipisah dari fungsi toggle debug panel, supaya bisa dipanggil OTOMATIS
    // saat script start -- SEBELUMNYA fungsi ini cuma jalan kalau debug panel
    // manual dibuka (lewat _0xfgge), artinya _0xdc93b.itemIndex TIDAK PERNAH
    // ke-populate di gameplay normal, dan _0xresolveByName() (sistem icon
    // berbasis nama yang jauh lebih akurat) selalu return null sejak baris
    // pertamanya -- semua icon jatuh ke sistem lama (_0xdb137f / t6[itemId])
    // yang berbasis data.js LAMA. Ini akar masalah SEBENARNYA dari bug icon
    // yang salah, bukan cuma soal algoritma fuzzy-match.
    function _0xloadItemIndex() {
        if (_0xdc93b["loaded"])
            return Promise.resolve();

        // PENTING: dipisah jadi 2 request MANDIRI (bukan Promise.all lagi).
        // Item index (dari l_eng_items.xml) itu yang KRITIS buat sistem
        // icon berbasis nama -- structureData (dari structure_loader_data.json)
        // cuma dipakai fitur debug panel ("Chest Configuration" tab), TIDAK
        // ada hubungannya dengan resolusi icon sama sekali. Sebelumnya
        // keduanya digabung lewat Promise.all(), yang artinya kalau
        // structure_loader_data.json gagal/tidak ada (atau file APA SAJA
        // yang jelas TIDAK DIBUTUHKAN buat icon), l_eng_items.xml yang
        // BERHASIL dimuat pun ikut dianggap gagal total -- itemIndex
        // TIDAK PERNAH ke-set, dan semua icon jatuh ke fallback lama.
        var itemsPromise = _0x1c05af("./l_eng_items.xml", "text").then(function (itemsXmlText) {
            _0xdc93b["items"] = _0xf3bcbf(itemsXmlText);
            _0xdc93b["itemIndex"] = {};
            for (var i = 0; i < _0xdc93b["items"]["length"]; i++) {
                _0xdc93b["itemIndex"][_0xdc93b["items"][i]["id"]] = _0xdc93b["items"][i];
            }
            _0xdc93b["loaded"] = true; // <-- ini yang bikin _0xresolveByName() aktif
        }).catch(function (error) {
            var errMsg = 'chest_gl: GAGAL load l_eng_items.xml -- icon berbasis nama TIDAK AKAN AKTIF. Error: ' +
                (error && error.message ? error.message : String(error));
            console.warn(errMsg);
            try {
                _0xdebugEnsureUI();
                _0xdebugLogLines.unshift('❌❌❌ ' + errMsg + ' ❌❌❌');
                _0xdebugOverlayEl.textContent = _0xdebugLogLines.join('\n');
                _0xdebugToggleBtn.style.borderColor = '#f44336';
                _0xdebugToggleBtn.style.color = '#f44336';
            } catch (e2) { /* overlay belum siap di titik ini, diamkan */ }
        });

        // structureData -- OPSIONAL, cuma dipakai debug panel. Gagal di
        // sini TIDAK BOLEH mempengaruhi itemsPromise di atas sama sekali.
        var structurePromise = _0x1c05af("./structure_loader_data.json", "json").then(function (data) {
            _0xdc93b["structureData"] = data;
            if (!_0xdc93b["selectedStructureType"] && data && data["structures"] && data["structures"]["length"]) {
                _0xdc93b["selectedStructureType"] = data["structures"][0]["typeName"];
            }
        }).catch(function (error) {
            console.warn('chest_gl: structure_loader_data.json tidak dimuat (opsional, cuma buat debug panel, TIDAK memengaruhi icon):', error && error.message);
        });

        return Promise.all([itemsPromise, structurePromise]);
    }
    // Trigger otomatis begitu script ini jalan -- tidak perlu tunggu debug
    // panel dibuka. Kalau nanti debug panel BENERAN dibuka, _0x77agaa() akan
    // lihat _0xdc93b.loaded sudah true dan langsung skip ke render (perilaku
    // lama tetap utuh untuk debug panel, cuma sekarang datanya sudah siap
    // dari awal).
    _0xloadItemIndex();

    // ================================================================
    // ====== PANEL DIAGNOSTIK ICON (untuk debug bug icon salah) ======
    // ================================================================
    // Karena akses console browser tidak bisa diandalkan di WebView APK
    // ini, panel ini nampilkan status resolusi icon LANGSUNG DI LAYAR --
    // supaya kelihatan persis: apakah l_eng_items.xml berhasil dimuat,
    // dan untuk tiap item, jalur mana yang dipakai (nama/legacy/index)
    // serta file gambar apa yang dihasilkan.
    //
    // CARA PAKAI: panggil MDZChestIconDebug.show() dari mana saja
    // setelah beberapa detik masuk game (tunggu chest sempat dibuka
    // minimal 1x supaya ada data buat dibandingkan).
    var _0xDEBUG_ITEM_IDS = [36, 35, 23, 40, 41, 100, 53, 49, 26, 24, 32, 25, 45, 54, 55, 37, 38, 50, 39, 110];

    function _0xshowIconDebugPanel() {
        var old = document.getElementById('mdz-icon-debug-panel');
        if (old) old.remove();

        var panel = document.createElement('div');
        panel.id = 'mdz-icon-debug-panel';
        panel.style.cssText = [
            'position:fixed', 'top:8px', 'left:8px', 'right:8px', 'z-index:2147483647',
            'max-height:85vh', 'overflow-y:auto',
            'background:rgba(10,10,10,0.96)', 'color:#e8dcc0',
            'font-family:monospace', 'font-size:10px', 'line-height:1.5',
            'padding:10px', 'border:2px solid #4caf50', 'border-radius:10px',
        ].join(';');

        var lines = [];
        lines.push('<div style="display:flex;justify-content:space-between;margin-bottom:8px;">' +
            '<b style="color:#4caf50;font-size:13px;">Icon Debug Panel</b>' +
            '<span id="mdz-icon-debug-close" style="cursor:pointer;background:#333;padding:2px 10px;border-radius:6px;">Tutup</span></div>');

        // Status loading utama
        var loaded = !!(_0xdc93b && _0xdc93b.loaded);
        var hasIndex = !!(_0xdc93b && _0xdc93b.itemIndex);
        var indexCount = hasIndex ? Object.keys(_0xdc93b.itemIndex).length : 0;
        lines.push('<div style="margin-bottom:8px;padding:6px;background:rgba(255,255,255,0.06);border-radius:6px;">' +
            '_0xdc93b.loaded = <b style="color:' + (loaded ? '#4caf50' : '#f44336') + ';">' + loaded + '</b><br>' +
            'itemIndex = ' + (hasIndex ? indexCount + ' item ter-load' : '<b style="color:#f44336;">KOSONG/BELUM ADA</b>') + '<br>' +
            '_0xad7gb (atlas gambar) = ' + (typeof _0xad7gb !== 'undefined' && _0xad7gb ? Object.keys(_0xad7gb).length + ' tipe' : '<b style="color:#f44336;">BELUM SIAP</b>') + '<br>' +
            '_0xdb137f (legacy fallback) = ' + (typeof _0xdb137f !== 'undefined' && _0xdb137f ? 'ADA (aktif kalau nama gagal)' : 'tidak ada') +
            '</div>');

        if (!loaded) {
            lines.push('<div style="color:#f44336;margin-bottom:8px;">⚠ itemIndex BELUM loaded -- semua icon di bawah ini PASTI masih pakai sistem lama (salah). Tunggu beberapa detik lalu buka lagi panel ini.</div>');
        }

        // Detail per item
        lines.push('<table style="width:100%;border-collapse:collapse;font-size:9px;">');
        lines.push('<tr style="color:#4caf50;border-bottom:1px solid #444;"><td>ID</td><td>Nama</td><td>Jalur</td><td>File</td></tr>');

        _0xDEBUG_ITEM_IDS.forEach(function (itemId) {
            var name = (hasIndex && _0xdc93b.itemIndex[itemId]) ? _0xdc93b.itemIndex[itemId].name : '(nama blm ada)';
            var path = 'null';
            var fileOut = '-';
            try {
                var byName = loaded ? _0xresolveByName(itemId) : null;
                if (byName) {
                    path = '<span style="color:#4caf50;">by-name</span>';
                    fileOut = byName.src || '?';
                } else if (typeof _0xdb137f !== 'undefined' && _0xdb137f && _0xdb137f[itemId]) {
                    path = '<span style="color:#ff9800;">LEGACY</span>';
                    var bm = _0xdb137f[itemId];
                    var frames = (typeof _0xad7gb !== 'undefined' && _0xad7gb) ? (_0xad7gb[bm.typeName] || []) : [];
                    fileOut = (frames[bm.frame] && frames[bm.frame].src) || (bm.typeName + '#' + bm.frame);
                } else if (typeof _0xad7gb !== 'undefined' && _0xad7gb) {
                    var t6 = _0xad7gb['t6'] || [];
                    if (itemId >= 0 && itemId < t6.length && t6[itemId]) {
                        path = '<span style="color:#f44336;">T6-INDEX (paling primitif)</span>';
                        fileOut = t6[itemId].src || '?';
                    } else {
                        path = '<span style="color:#888;">tidak ada sama sekali</span>';
                    }
                }
            } catch (e) {
                path = '<span style="color:#f44336;">ERROR: ' + e.message + '</span>';
            }
            lines.push('<tr style="border-bottom:1px solid #222;"><td>' + itemId + '</td><td>' + name +
                '</td><td>' + path + '</td><td style="word-break:break-all;">' + fileOut + '</td></tr>');
        });
        lines.push('</table>');

        panel.innerHTML = lines.join('');
        document.body.appendChild(panel);

        document.getElementById('mdz-icon-debug-close').addEventListener('click', function () { panel.remove(); });
    }

    window.MDZChestIconDebug = {
        show: _0xshowIconDebugPanel,
        itemIds: _0xDEBUG_ITEM_IDS,
    };
    // ================================================================
    // ====== AKHIR PANEL DIAGNOSTIK ===================================
    // ================================================================

    function _0x77agaa() { if (_0xdc93b["loaded"]) {
        _0x1f051d();
        return;
    } _0xloadItemIndex().then(function () { _0x1f051d(); }).catch(function (error) { if (_0xdc93b["ui"] && _0xdc93b["ui"]["center"]) _0xdc93b["ui"]["center"]["textContent"] = "Failed to load debug data: " + (error && error["message"]); }); }
    function _0xf51d(itemId) { if (_0xdc93b["itemIndex"][itemId])
        return _0xdc93b["itemIndex"][itemId]["name"]; return "Item " + itemId; }
    function _0xe546b(value) { if (!value)
        return []; if (Array["isArray"](value))
        return value; var _0x136fcb = (720729 ^ 720735) + (603828 ^ 603827); var _0x137 = String(value)["split"](new RegExp("[,\\s]+",
            "")); _0x136fcb = "bfeagm".split("").reverse().join(""); var _0x151d = (902758 ^ 902756) + (735107 ^ 735105); var _0x5g05be = []; _0x151d = (678109 ^ 678109) + (993529 ^ 993535); for (var i = 401113 ^ 401113; i < _0x137["length"]; i++) {
        var _0x0cbec = Number(_0x137[i]);
        if (_0x0cbec > (542874 ^ 542874))
            _0x5g05be["push"](_0x0cbec);
    } return _0x5g05be; }
    function _0x6fa(chestTypeId) { var _0x4g23a = (760692 ^ 760694) + (585151 ^ 585143); var _0xac901d = _0x87g[chestTypeId]; _0x4g23a = "fpqcom".split("").reverse().join(""); if (!_0xac901d)
        return null; var _0xb4df = _0xac901d["lootTable"] || chestTypeId + "tool_".split("").reverse().join(""); _0xac901d["lootTable"] = _0xb4df; if (!_0x56fd[_0xb4df])
        _0x56fd[_0xb4df] = []; return _0xb4df; }
    function _0x2d3e7c(canvas, itemId, _0x73cfg, _0xafa65d) { var _0x3c2c = canvas["getContext"]("2d"); _0x73cfg = (522773 ^ 522770) + (220560 ^ 220567); _0x3c2c["clearRect"](729654 ^ 729654, 833485 ^ 833485, canvas["width"], canvas["height"]); _0x3c2c["fillStyle"] = "rgba(255,255,255,0.03)"; _0x3c2c["fillRect"](974593 ^ 974593, 391736 ^ 391736, canvas["width"], canvas["height"]); var _0x1d449e = _0x2cb69e(itemId); if (!_0x1d449e) {
        _0x3c2c["fillStyle"] = "49eafb#".split("").reverse().join("");
        _0x3c2c["font"] = "10px Segoe UI";
        _0x3c2c["textAlign"] = "center";
        _0x3c2c["fillText"](String(itemId), canvas["width"] / (374823 ^ 374821), canvas["height"] / (897507 ^ 897505) + (518603 ^ 518607));
        return;
    } var _0x869b = (979905 ^ 979913) + (720695 ^ 720692); var _0x935ffb = _0xdg0b(_0x1d449e["src"]); _0x869b = (960986 ^ 960988) + (320291 ^ 320294); if (!_0x935ffb["complete"] || !_0x935ffb["naturalWidth"]) {
        _0x935ffb["onload"] = function () { _0x2d3e7c(canvas, itemId); };
        return;
    } var _0x194a = Math["min"]((canvas["width"] - (708445 ^ 708437)) / _0x1d449e["w"], (canvas["height"] - (359045 ^ 359053)) / _0x1d449e["h"]) * (_0x1d449e["typeName"] === "5t".split("").reverse().join("") ? 1.5 : 714634 ^ 714635); var _0xg378f = (196144 ^ 196153) + (528142 ^ 528141); var _0x23g94e = Math["max"](150991 ^ 150990, Math["floor"](_0x1d449e["w"] * _0x194a)); _0xg378f = 268369 ^ 268369; var _0x6a7e = Math["max"](502917 ^ 502916, Math["floor"](_0x1d449e["h"] * _0x194a)); _0xafa65d = (347709 ^ 347700) + (101991 ^ 101987); var _0xgefae = (831803 ^ 831800) + (902459 ^ 902461); var _0x8c0bb = Math["floor"]((canvas["width"] - _0x23g94e) / (784019 ^ 784017)); _0xgefae = 663089 ^ 663095; var _0xbad0c = Math["floor"]((canvas["height"] - _0x6a7e) / (116149 ^ 116151)); _0x3c2c["imageSmoothingEnabled"] = false; _0x3c2c["drawImage"](_0x935ffb, _0x1d449e["x"], _0x1d449e["y"], _0x1d449e["w"], _0x1d449e["h"], _0x8c0bb, _0xbad0c, _0x23g94e, _0x6a7e); }
    function _0x53262g(scope) { var _0x61a2 = scope || _0xdc93b["ui"]["root"]; if (!_0x61a2)
        return; var _0x63cdb = _0x61a2["querySelectorAll"]("canvas[data-item-id], canvas[data-preview-item-id]"); for (var i = 319479 ^ 319479; i < _0x63cdb["length"]; i++) {
        var _0x38ade = (109527 ^ 109524) + (852690 ^ 852691);
        var _0x64598d = Number(_0x63cdb[i]["getAttribute"]("data-item-id") || _0x63cdb[i]["getAttribute"]("di-meti-weiverp-atad".split("").reverse().join(""))) || 373467 ^ 373467;
        _0x38ade = (179790 ^ 179790) + (359059 ^ 359058);
        _0x2d3e7c(_0x63cdb[i], _0x64598d);
    } }
    var _0x3e2c3f = [
        "llA".split("").reverse().join(""),
            "Firearms",
            "Melee",
            "Food",
            "Medical",
            "Ammo",
            "Clothing",
            "slooT".split("").reverse().join(""),
            "General"
    ];
    function _0x74e8a(name, _0xef_0xbe6) { var n = (name || "")["toLowerCase"](); _0xef_0xbe6 = 367756 ^ 367748; if (new RegExp("rifle|carbine|sniper|shotgun|smg|submachine|\\bak\\b|\\bm4\\b|\\bm16\\b|scar|svd|rpk|sg5|\\bfal\\b|aug|uzi|mp5|mossberg|saiga|spas|ksg|assault|machine gun",
            "")["test"](n))
        return "smraeriF".split("").reverse().join(""); if (new RegExp("pistol|revolver|glock|colt|beretta|makarov|tec-9|desert eagle|handgun",
            "")["test"](n))
        return "smraeriF".split("").reverse().join(""); if (new RegExp("knife|axe|hatchet|machete|crowbar|\\bbat\\b|sword|cleaver|shiv|katana|kukri|melee|blade",
            "")["test"](n))
        return "Melee"; if (new RegExp("\\bfood\\b|bread|\\bcan\\b|canned|meat|jerky|berries|mushroom|tomato|apple|corn|beans|rice|noodle|tuna|sardine|crackers|cookie|chips|ration",
            "")["test"](n))
        return "Food"; if (new RegExp("ksalf|elttob|b\\knirdb\\|ados|aloc|eciuj|retaw".split("").reverse().join(""),
            "")["test"](n))
        return "dooF".split("").reverse().join(""); if (new RegExp("bandage|splint|morphine|painkiller|blood|syringe|surgical|epinephrine|antibiotics|saline|disinfect|iv bag|pills|vitamins|medkit|first aid|tourniquet",
            "")["test"](n))
        return "Medical"; if (new RegExp("\\bammo\\b|rounds|shell|bullet|magazine|cartridge|7\\.62|5\\.56|9mm|\\.45|12ga|12g\\b|slugs",
            "")["test"](n))
        return "Ammo"; if (new RegExp("helmet|jacket|vest|pants|shirt|boots|gloves|backpack|hoodie|gorka|ghillie|balaclava|armor|carrier|plate|\\bcap\\b|beanie|ushanka|beret|bandana",
            "")["test"](n))
        return "gnihtolC".split("").reverse().join(""); if (new RegExp("flashlight|radio|walkie|toolkit|toolbox|wrench|screwdriver|pliers|binoculars|lockpick|matches|lighter|torch|rope|\\bwire\\b|\\btape\\b|compass|\\bmap\\b",
            "")["test"](n))
        return "Tools"; return "General"; }
    function _0xf3_0x194(target) { _0xdc93b["picker"] = {
        "target": target,
                "search": "",
                "rarity": "medium",
                "stackSteps": "",
                "staticCount": "1",
                "category": "All"
    }; _0x193dbe(); }
    function _0x3da5fc() { _0xdc93b["picker"] = null; _0x193dbe(); }
    function _0xb63a(itemId) { if (!_0xdc93b["picker"])
        return; var _0x62gf = (908761 ^ 908766) + (582031 ^ 582025); var _0x9479b = _0xdc93b["picker"]["target"] || {}; _0x62gf = (378241 ^ 378248) + (872781 ^ 872777); if (_0x9479b["kind"] === "loot") {
        var _0x139 = _0x6fa(_0x9479b["chestTypeId"]);
        _0x56fd[_0x139]["push"]({
            "id": itemId,
                    "rarity": _0xdc93b["picker"]["rarity"] || "medium",
                    "stackSteps": _0xe546b(_0xdc93b["picker"]["stackSteps"])
        });
        _0xdc93b["statusText"] = "Added item " + itemId + " ot ".split("").reverse().join("") + _0x139 + ".";
    }
    else if (_0x9479b["kind"] === "tolScitats".split("").reverse().join("")) {
        var _0xb_0x7af = (762710 ^ 762709) + (201679 ^ 201677);
        var _0x88gc = _0x87g[_0x9479b["chestTypeId"]];
        _0xb_0x7af = "bhepch";
        if (_0x88gc) {
            var _0xf6e30c = _0x267d(_0x3f9d(_0x88gc));
            var _0xa05ae = _0xeb1ee(_0x88gc["staticSlots"], _0x88gc["slotSize"]);
            while (_0xa05ae["length"] < _0xf6e30c)
                _0xa05ae["push"](null);
            _0xa05ae[_0x9479b["slotIndex"]] = {
                "id": itemId,
                        "count": Math["max"](460699 ^ 460698, Number(_0xdc93b["picker"]["staticCount"]) || 174789 ^ 174788)
            };
            _0x88gc["staticSlots"] = _0xa05ae;
            _0xdc93b["statusText"] = "Assigned item " + itemId + " to static slot " + (_0x9479b["slotIndex"] + (515834 ^ 515835)) + ".";
        }
    }
    else if (_0x9479b["kind"] === "unlock") {
        if (_0x9479b["scope"] === "type") {
            _0x87g[_0x9479b["chestTypeId"]]["unlockItemId"] = itemId;
        }
        else if (_0x9479b["scope"] === "placement") {
            var _0x9abc = (328089 ^ 328093) + (625491 ^ 625491);
            var _0x2g7ffe = _0x7eed[_0xdc93b["selectedStructureType"]] && _0x7eed[_0xdc93b["selectedStructureType"]]["placements"][_0xdc93b["selectedPlacementIndex"]];
            _0x9abc = (374156 ^ 374152) + (398923 ^ 398925);
            if (_0x2g7ffe)
                _0x2g7ffe["unlockItemId"] = itemId;
        }
        _0xdc93b["statusText"] = "Selected unlock item " + itemId + ".";
    }
    else if (_0x9479b["kind"] === "placementLoot") {
        if (!_0x56fd[_0x9479b["lootTable"]])
            _0x56fd[_0x9479b["lootTable"]] = [];
        _0x56fd[_0x9479b["lootTable"]]["push"]({
            "id": itemId,
                    "rarity": _0xdc93b["picker"]["rarity"] || "medium",
                    "stackSteps": _0xe546b(_0xdc93b["picker"]["stackSteps"])
        });
        _0xdc93b["statusText"] = " meti deddA".split("").reverse().join("") + itemId + " to placement loot table " + _0x9479b["lootTable"] + ".";
    }
    else if (_0x9479b["kind"] === "tooLyovnoc".split("").reverse().join("")) {
        var _0xabdbf = _0xg63c7a["itemSpawns"][_0x9479b["spawnIdx"]];
        if (_0xabdbf) {
            if (!_0xabdbf["loot"])
                _0xabdbf["loot"] = [];
            _0xabdbf["loot"]["push"]({
                "id": itemId,
                        "weight": 1
            });
            _0xc9dab = {
                "type": "itemSpawn",
                        "idx": _0x9479b["spawnIdx"]
            };
            _0xdc93b["statusText"] = "Added item " + itemId + " to convoy spawn loot.";
        }
    } _0xdc93b["picker"] = null; _0x1f051d(); }
    function _0xe6326g(chestType) { var _0xcbe0c = chestType["rarityChance"] || _0x8dd(_0xf4cgg); return "<div style=\"display:grid;gap:8px\"><strong>Rarity Chances</strong><div style=\"color:#bcae94\">Override per-type rarity weights (leave blank for global defaults).</div>" + "<div style=\"display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr;gap:6px\">" + "<label>High<input data-rarity=\"high\" type=\"number\" step=\"0.01\" min=\"0\" max=\"1\" value=\"" + _0xcbe0c["high"] + "\"></label>" + "\"=eulav \"1\"=xam \"0\"=nim \"10.0\"=pets \"rebmun\"=epyt \"muidem\"=ytirar-atad tupni<muideM>lebal<".split("").reverse().join("") + _0xcbe0c["medium"] + "\"></label>" + "\"=eulav \"1\"=xam \"0\"=nim \"10.0\"=pets \"rebmun\"=epyt \"wol\"=ytirar-atad tupni<woL>lebal<".split("").reverse().join("") + _0xcbe0c["low"] + "\"></label>" + "\"=eulav \"1\"=xam \"0\"=nim \"10.0\"=pets \"rebmun\"=epyt \"woLrepus\"=ytirar-atad tupni<woL repuS>lebal<".split("").reverse().join("") + _0xcbe0c["superLow"] + ">lebal/<>\"".split("").reverse().join("") + "\"=eulav \"1\"=xam \"0\"=nim \"10.0\"=pets \"rebmun\"=epyt \"erar\"=ytirar-atad tupni<eraR>lebal<".split("").reverse().join("") + _0xcbe0c["rare"] + ">lebal/<>\"".split("").reverse().join("") + ">vid/<>nottub/<stluafeD labolG ot teseR>ytirar-raelc-atad nottub<>vid/<".split("").reverse().join(""); }
    function _0x3569ab(col) { col = _0xbd2(col); return ">gnorts/<tcejbO noisilloC>gnorts<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + "<div style=\"display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px\">" + "<label>Enabled<select data-col=\"enabled\"><option value=\"0\"" + (col["enabled"] ? "" : " selected") + ">false</option><option value=\"1\"" + (col["enabled"] ? " selected" : "") + ">true</option></select></label>" + "<label>Type<input data-col=\"type\" value=\"" + _0x0d5eg(col["type"]) + "\"></label>" + "<label>Offset X<input data-col=\"offsetX\" type=\"number\" value=\"" + col["offsetX"] + ">lebal/<>\"".split("").reverse().join("") + "</div><div style=\"display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px\">" + "<label>Offset Y<input data-col=\"offsetY\" type=\"number\" value=\"" + col["offsetY"] + "\"></label>" + "\"=eulav \"1\"=nim \"rebmun\"=epyt \"htdiw\"=loc-atad tupni<htdiW>lebal<".split("").reverse().join("") + col["width"] + ">lebal/<>\"".split("").reverse().join("") + "\"=eulav \"1\"=nim \"rebmun\"=epyt \"thgieh\"=loc-atad tupni<thgieH>lebal<".split("").reverse().join("") + col["height"] + ">lebal/<>\"".split("").reverse().join("") + ">vid/<>vid/<".split("").reverse().join(""); }
    function _0xa9b94b(chestType) { var _0x7f904a = _0x3f9d(chestType); var _0x0bf9c = (912300 ^ 912303) + (385342 ^ 385339); var _0xd62ded = _0x267d(_0x7f904a); _0x0bf9c = (919697 ^ 919704) + (681093 ^ 681100); var _0x021ef = _0xeb1ee(chestType["staticSlots"], chestType["slotSize"]); while (_0x021ef["length"] < _0xd62ded)
        _0x021ef["push"](null); var _0x9e24aa = (159028 ^ 159025) + (708727 ^ 708735); var _0xe8af = "<div style=\"display:grid;gap:8px\"><strong>Static Slot Preview</strong><div style=\"display:grid;grid-template-columns:repeat(" + _0x7f904a["cols"] + ",52px);gap:6px\">"; _0x9e24aa = 619242 ^ 619240; for (var i = 481764 ^ 481764; i < _0xd62ded; i++) {
        var _0x59_0xabg = _0x021ef[i];
        _0xe8af += "\"=tols-citats-atad nottub<".split("").reverse().join("") + i + "\" style=\"position:relative;width:52px;height:52px;padding:0;border-radius:10px;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.05)\"><span style=\"position:absolute;left:4px;top:4px;font-size:10px;color:#bcae94\">" + (i + (719209 ^ 719208)) + "</span>";
        if (_0x59_0xabg && _0x59_0xabg["id"]) {
            _0xe8af += "\"=di-meti-atad \"82\"=thgieh \"82\"=htdiw savnac<".split("").reverse().join("") + _0x59_0xabg["id"] + "\"></canvas>";
        }
        else {
            _0xe8af += "<span style=\"color:#bcae94\">+</span>";
        }
        _0xe8af += "</button>";
    } _0xe8af += "</div><div style=\"display:flex;gap:8px\"><button data-clear-static-slots>Clear Static Slots</button></div></div>"; return _0xe8af; }
    function _0x193dbe(_0xedfe, _0x884adb, _0x5_0x328) { if (!_0xdc93b["ui"] || !_0xdc93b["ui"]["picker"])
        return; var _0x682gf = _0xdc93b["ui"]["picker"]; if (!_0xdc93b["picker"]) {
        _0x682gf["style"]["display"] = "none";
        _0x682gf["innerHTML"] = "";
        return;
    } var _0x8137e = null; var _0x4363g = null; var _0xeb666a = null; if (document["activeElement"] && document["activeElement"]["getAttribute"]) {
        if (document["activeElement"]["hasAttribute"]("data-picker-search")) {
            _0x8137e = "hcraes-rekcip-atad".split("").reverse().join("");
        }
        else if (document["activeElement"]["hasAttribute"]("data-picker-meta")) {
            _0x8137e = "data-picker-meta";
        }
        if (_0x8137e) {
            _0x4363g = document["activeElement"]["selectionStart"];
            _0xeb666a = document["activeElement"]["selectionEnd"];
        }
    } var _0x9e259g = (362808 ^ 362815) + (915936 ^ 915942); var _0xeb_0x683 = _0xdc93b["picker"]; _0x9e259g = "fklhjk"; var _0x29ca = (168290 ^ 168294) + (955593 ^ 955597); var _0xf545f = String(_0xeb_0x683["search"] || "")["toLowerCase"](); _0x29ca = "kdklhf"; var _0xa2_0xe71 = (695524 ^ 695521) + (678421 ^ 678428); var _0x232edf = _0xeb_0x683["category"] || "llA".split("").reverse().join(""); _0xa2_0xe71 = 977959 ^ 977955; var _0x47eed = ""; for (var i = 147858 ^ 147858; i < _0xdc93b["items"]["length"]; i++) {
        var _0x0a_0xc39 = _0xdc93b["items"][i];
        if (_0xf545f && String(_0x0a_0xc39["id"])["indexOf"](_0xf545f) === -(889787 ^ 889786) && _0x0a_0xc39["name"]["toLowerCase"]()["indexOf"](_0xf545f) === -(203294 ^ 203295))
            continue;
        if (_0x232edf !== "llA".split("").reverse().join("") && _0x74e8a(_0x0a_0xc39["name"]) !== _0x232edf)
            continue;
        _0x47eed += "\"=meti-rekcip-atad \"drac-meti-zdm\"=ssalc nottub<".split("").reverse().join("") + _0x0a_0xc39["id"] + "\"><canvas class=\"mdz-item-icon\" width=\"40\" height=\"40\" data-item-id=\"" + _0x0a_0xc39["id"] + "\"></canvas><div><div style=\"font-weight:700\">" + _0x0d5eg(_0x0a_0xc39["name"]) + "</div><div style=\"color:#bfae94\">ID " + _0x0a_0xc39["id"] + "</div></div><span>Use</span></button>";
    } var _0x9082g = ""; _0xedfe = 603267 ^ 603270; for (var _0xc8172e = 985857 ^ 985857; _0xc8172e < _0x3e2c3f["length"]; _0xc8172e++) {
        _0x9082g += "tac-rekcip-zdm\"=ssalc nottub<".split("").reverse().join("") + (_0x232edf === _0x3e2c3f[_0xc8172e] ? " active" : "") + "\" data-picker-cat=\"" + _0x3e2c3f[_0xc8172e] + ">\"".split("").reverse().join("") + _0x3e2c3f[_0xc8172e] + ">nottub/<".split("").reverse().join("");
    } var _0x287f = _0xeb_0x683["target"]["kind"] === "loot" || _0xeb_0x683["target"]["kind"] === "tooLtnemecalp".split("").reverse().join(""); _0x884adb = "ppekmk".split("").reverse().join(""); _0x682gf["innerHTML"] = "" + "<div style=\"display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.08)\"><strong>Item Picker</strong><button data-picker-close>Close</button></div>" + ">\"stac-rekcip-zdm\"=ssalc vid<".split("").reverse().join("") + _0x9082g + "</div>" + ":snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + (_0x287f ? "rf1 rf1".split("").reverse().join("") : "rf1".split("").reverse().join("")) + ">\")80.0,552,552,552(abgr dilos xp1:mottob-redrob;xp41 xp8:gniddap;xp8:pag;".split("").reverse().join("") + "<label>Search<input data-picker-search value=\"" + _0x0d5eg(_0xeb_0x683["search"]) + ">lebal/<>\"DI ro eman meti yb hcraeS\"=redlohecalp \"".split("").reverse().join("") + (_0x287f ? "<label>Rarity / Stack Steps<input data-picker-meta value=\"" + _0x0d5eg((_0xeb_0x683["rarity"] || "medium") + "|" + (_0xeb_0x683["stackSteps"] || "")) + "\" placeholder=\"medium|10,20,30\"></label>" : "") + ">vid/<".split("").reverse().join("") + "<div class=\"mdz-picker-grid\">" + _0x47eed + ">vid/<".split("").reverse().join(""); _0x682gf["style"]["display"] = "dirg".split("").reverse().join(""); _0x682gf["querySelector"]("[data-picker-close]")["addEventListener"]("click", _0x3da5fc); _0x682gf["querySelector"]("[data-picker-search]")["addEventListener"]("input", function () { _0xdc93b["picker"]["search"] = this["value"]; _0x193dbe(); }); var _0x123be = _0x682gf["querySelector"]("]atem-rekcip-atad[".split("").reverse().join("")); if (_0x123be)
        _0x123be["addEventListener"]("tupni".split("").reverse().join(""), function () { if (_0xdc93b["picker"]["target"]["kind"] === "loot" || _0xdc93b["picker"]["target"]["kind"] === "tooLtnemecalp".split("").reverse().join("")) {
            var _0x7gaf5b = this["value"]["split"]("|");
            _0xdc93b["picker"]["rarity"] = (_0x7gaf5b[435648 ^ 435648] || "muidem".split("").reverse().join(""))["trim"]() || "medium";
            _0xdc93b["picker"]["stackSteps"] = (_0x7gaf5b[367500 ^ 367501] || "")["trim"]();
        } }); var _0x07bdee = _0x682gf["querySelectorAll"]("[data-picker-cat]"); for (var _0x2352b = 672092 ^ 672092; _0x2352b < _0x07bdee["length"]; _0x2352b++) {
        _0x07bdee[_0x2352b]["addEventListener"]("click", function (el) { return function () { _0xdc93b["picker"]["category"] = el["getAttribute"]("data-picker-cat"); _0x193dbe(); }; }(_0x07bdee[_0x2352b]));
    } var _0xf766c = _0x682gf["querySelectorAll"]("[data-picker-item]"); _0x5_0x328 = (918878 ^ 918876) + (691041 ^ 691043); for (var b = 360473 ^ 360473; b < _0xf766c["length"]; b++) {
        _0xf766c[b]["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xb63a(Number(this["getAttribute"]("meti-rekcip-atad".split("").reverse().join(""))) || 872712 ^ 872712); });
    } if (_0x8137e) {
        var _0x7442f = (472160 ^ 472166) + (240160 ^ 240166);
        var _0x7abb9c = _0x682gf["querySelector"]("[" + _0x8137e + "]");
        _0x7442f = "mpgoel".split("").reverse().join("");
        if (_0x7abb9c) {
            _0x7abb9c["focus"]();
            try {
                if (_0x4363g != null && _0xeb666a != null) {
                    _0x7abb9c["setSelectionRange"](_0x4363g, _0xeb666a);
                }
            }
            catch (e) { }
        }
    } _0x53262g(_0x682gf); }
    function _0x1f051d() { if (!_0xdc93b["ui"])
        return; var _0xc_0xec8 = (467755 ^ 467758) + (439768 ^ 439761); var _0x5fe = _0x6ec34e(); _0xc_0xec8 = "iedpjg"; var _0xec6e3b = _0xdc93b["ui"]["root"]["querySelector"]("]\"egdab-gnal\"=elor-atad[".split("").reverse().join("")); if (_0xec6e3b) {
        var _0x44fd = (249329 ^ 249330) + (851105 ^ 851108);
        var _0xc1f = _0x5fe && _0xg84a(_0x5fe,
                "Language") || "?";
        _0x44fd = "ejhfhe".split("").reverse().join("");
        _0xec6e3b["textContent"] = "Lang: " + _0xc1f;
    } if (!_0xdc93b["loaded"]) {
        _0xdc93b["ui"]["left"]["textContent"] = "...gnidaoL".split("").reverse().join("");
        _0xdc93b["ui"]["center"]["textContent"] = "Loading...";
        _0xdc93b["ui"]["right"]["textContent"] = "...gnidaoL".split("").reverse().join("");
        return;
    } _0xdc93b["ui"]["status"]["textContent"] = _0xdc93b["statusText"] || "Editor ready."; if (_0xdc93b["tab"] === "types")
        _0xef2();
    else if (_0xdc93b["tab"] === "structures")
        _0x97cg();
    else if (_0xdc93b["tab"] === "event")
        _0x1728b();
    else
        _0x68ade(); _0x193dbe(); }
    function _0xef2(_0x78f) { var _0xb552aa = (212683 ^ 212683) + (306429 ^ 306431); var _0xb19 = _0xdc93b["ui"]["left"]; _0xb552aa = "efpcaq"; var _0x10c93c = (528882 ^ 528887) + (529680 ^ 529689); var _0x4a4 = _0xdc93b["ui"]["center"]; _0x10c93c = (989079 ^ 989076) + (418580 ^ 418588); var _0xc41f5a = _0xdc93b["ui"]["right"]; _0x78f = "lcpjle"; var _0x69f63c = (125294 ^ 125290) + (633043 ^ 633046); var _0x4bg = "<div style=\"display:grid;gap:8px\">"; _0x69f63c = (884986 ^ 884979) + (270082 ^ 270086); for (var _0x4e6a in _0x87g) {
        var _0x218a = _0x87g[_0x4e6a];
        _0x4bg += "\"=epyt-tsehc-atad \"drac-meti-zdm\"=ssalc nottub<".split("").reverse().join("") + _0x4e6a + "\" style=\"text-align:left;background:" + (_0xdc93b["selectedChestTypeId"] === _0x4e6a ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.04)") + "\"><img class=\"mdz-thumb\" src=\"" + _0x0d5eg(_0x218a["closed"]) + "\" alt=\"\"><div><div style=\"font-weight:700\">" + _0x0d5eg(_0x218a["name"]) + "</div><div style=\"color:#bcae94\">" + _0x0d5eg(_0x4e6a) + " · ".split("").reverse().join("") + _0x218a["slotSize"]["cols"] + "x" + _0x218a["slotSize"]["rows"] + "</div><div style=\"color:#ffb86c;font-size:11px\">" + (_0x218a["powerRequired"] ? "deriuqeR rewoP rotareneG".split("").reverse().join("") : "No Generator Power") + "</div></div><span>Select</span></button>";
    } _0x4bg += "<button data-add-chest-type style=\"padding:8px\">+ Add Chest Type</button>"; _0x4bg += ">vid/<>nottub/<detceleS etacilpuD ;5469#&>\"0a0602# dilos xp1:redrob;)2.0,002,021,06(abgr:dnuorgkcab;xp8:gniddap\"=elyts epyt-tsehc-pud-atad nottub<".split("").reverse().join(""); _0xb19["innerHTML"] = _0x4bg; var _0xa54d = _0x87g[_0xdc93b["selectedChestTypeId"]] || _0x87g["type1"]; var _0xgbf = (998693 ^ 998691) + (743192 ^ 743184); var _0xbea68a = _0xa9b94b(_0xa54d); _0xgbf = "ookoep".split("").reverse().join(""); _0x4a4["innerHTML"] = "<div class=\"mdz-card\" style=\"display:grid;gap:8px\">" + "<label>Name<input data-field=\"name\" value=\"" + _0x0d5eg(_0xa54d["name"]) + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + "<label>Closed Image<input data-field=\"closed\" value=\"" + _0x0d5eg(_0xa54d["closed"]) + "\" style=\"width:100%\"></label>" + "<label>Closed Highlight<input data-field=\"closedHL\" value=\"" + _0x0d5eg(_0xa54d["closedHL"]) + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + "<label>Open Image<input data-field=\"open\" value=\"" + _0x0d5eg(_0xa54d["open"]) + "\" style=\"width:100%\"></label>" + "<label>Open Highlight<input data-field=\"openHL\" value=\"" + _0x0d5eg(_0xa54d["openHL"]) + "\" style=\"width:100%\"></label>" + "<label>Open Sounds<input data-field=\"openSounds\" value=\"" + _0x0d5eg(_0xa54d["openSounds"]["join"](",")) + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + "<label>Pickup Sounds<input data-field=\"pickupSounds\" value=\"" + _0x0d5eg(_0xa54d["pickupSounds"]["join"](",")) + "\" style=\"width:100%\"></label>" + "\"=eulav \"sdnuoSkcolnu\"=dleif-atad tupni<sdnuoS kcolnU>lebal<".split("").reverse().join("") + _0x0d5eg(_0xa54d["unlockSounds"]["join"](",")) + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + "\"=eulav \"rebmun\"=epyt \"sloc\"=dleif-atad tupni<sloC>lebal<>\"xp8:pag;rf1 rf1:snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + _0xa54d["slotSize"]["cols"] + "\"=eulav \"rebmun\"=epyt \"swor\"=dleif-atad tupni<swoR>lebal<>lebal/<>\"".split("").reverse().join("") + _0xa54d["slotSize"]["rows"] + "\"></label></div>" + "<label>Loot Table<input data-field=\"lootTable\" value=\"" + _0x0d5eg(_0xa54d["lootTable"] || "") + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px\"><label>Locked Default<select data-field=\"locked\"><option value=\"0\"" + (_0xa54d["locked"] ? "" : " selected") + ">false</option><option value=\"1\"" + (_0xa54d["locked"] ? "detceles ".split("").reverse().join("") : "") + ">true</option></select></label><label>Unlock Item ID<input data-field=\"unlockItemId\" type=\"number\" value=\"" + (_0xa54d["unlockItemId"] == null ? "" : _0xa54d["unlockItemId"]) + ">vid/<>lebal/<>\"".split("").reverse().join("") + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px\"><label>Generator Power Required<select data-field=\"powerRequired\"><option value=\"0\"" + (_0xa54d["powerRequired"] ? "" : " selected") + ">false</option><option value=\"1\"" + (_0xa54d["powerRequired"] ? " selected" : "") + ">true</option></select></label><label>Power Flicker Enabled<select data-field=\"powerFlickerEnabled\"><option value=\"0\"" + (_0xa54d["powerFlickerEnabled"] ? "" : " selected") + ">false</option><option value=\"1\"" + (_0xa54d["powerFlickerEnabled"] ? " selected" : "") + ">true</option></select></label></div>" + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px\"><label>Fuel Warning %<input data-field=\"fuelWarningPercent\" type=\"number\" min=\"1\" max=\"100\" value=\"" + (_0xa54d["fuelWarningPercent"] == null ? 137570 ^ 137576 : _0xa54d["fuelWarningPercent"]) + "\"0\"=eulav noitpo<>\"delbanEIUmotsuc\"=dleif-atad tceles<IU motsuC elbanE>lebal<>lebal/<>\"".split("").reverse().join("") + (_0xa54d["customUI"] && _0xa54d["customUI"]["enabled"] ? "" : " selected") + ">false</option><option value=\"1\"" + (_0xa54d["customUI"] && _0xa54d["customUI"]["enabled"] ? " selected" : "") + ">vid/<>lebal/<>tceles/<>noitpo/<eurt>".split("").reverse().join("") + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px\"><label>Custom UI Image<input data-field=\"customUIImage\" value=\"" + _0x0d5eg(_0xa54d["customUI"] && _0xa54d["customUI"]["image"] || "") + ">\"%001:htdiw\"=elyts \"".split("").reverse().join("") + (_0xa54d["customUI"] && _0xa54d["customUI"]["image"] ? "<img data-customui-preview src=\"" + _0x0d5eg(_0xa54d["customUI"]["image"]) + "\" style=\"display:block;margin-top:4px;max-width:100%;max-height:80px;border-radius:6px;border:1px solid rgba(255,255,255,0.15);object-fit:contain;background:#111\">" : ">vid/<>\"enon:yalpsid\"=elyts weiverp-iumotsuc-atad vid<".split("").reverse().join("")) + ">vid/<>nottub/<IU erugifnoC>\"parwon:ecaps-etihw\"=elyts iu-erugifnoc-atad nottub<>lebal/<".split("").reverse().join("") + _0xe6326g(_0xa54d) + _0x3569ab(_0xa54d["collisionObject"]) + _0xbea68a + "<div style=\"display:grid;gap:6px\"><strong>Interaction Arc <span style=\"color:#bcae94;font-weight:400\">(default for all placements of this type)</span></strong>" + "<div style=\"display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px\">" + "\"0\"=eulav noitpo<>\"delbane\"=dleif-cra-tc-atad tceles<delbanE>lebal<".split("").reverse().join("") + (!(_0xa54d["interactArc"] && _0xa54d["interactArc"]["enabled"]) ? "detceles ".split("").reverse().join("") : "") + ">Off</option><option value=\"1\"" + (_0xa54d["interactArc"] && _0xa54d["interactArc"]["enabled"] ? "detceles ".split("").reverse().join("") : "") + ">On</option></select></label>" + "<label>Span (°)<input data-ct-arc-field=\"spanDeg\" type=\"number\" min=\"1\" max=\"360\" value=\"" + (_0xa54d["interactArc"] ? _0xa54d["interactArc"]["spanDeg"] : 572505 ^ 572487) + ">lebal/<>\"".split("").reverse().join("") + "<label>Center Angle (°)<input data-ct-arc-field=\"centerAngleDeg\" type=\"number\" min=\"0\" max=\"359\" value=\"" + (_0xa54d["interactArc"] ? _0xa54d["interactArc"]["centerAngleDeg"] : 279908 ^ 279870) + "\"></label>" + "\"=eulav \"1\"=nim \"rebmun\"=epyt \"tsid\"=dleif-cra-tc-atad tupni<)xp( tsiD>lebal<".split("").reverse().join("") + (_0xa54d["interactArc"] && _0xa54d["interactArc"]["dist"] != null ? _0xa54d["interactArc"]["dist"] : 734763 ^ 734723) + "\"></label>" + "</div></div>" + "<div style=\"display:grid;gap:6px\"><strong>Default UI <span style=\"color:#bcae94;font-weight:400\">(panel · slots · icons — default chest only)</span></strong>" + "<div style=\"display:flex;gap:8px;align-items:center;flex-wrap:wrap\">" + ">nottub/<IU tluafeD erugifnoC>\"parwon:ecaps-etihw\"=elyts iu-tluafed-erugifnoc-atad nottub<".split("").reverse().join("") + ">\"xp21:ezis-tnof;49eacb#:roloc\"=elyts naps<".split("").reverse().join("") + function (_0x4a67e) { var _0xc8_0x503 = _0xa54d["defaultUI"]; if (!_0xc8_0x503)
        return "auto"; var _0xe62cb = []; _0x4a67e = (711320 ^ 711320) + (625437 ^ 625436); if (_0xc8_0x503["panelW"] != null)
        _0xe62cb["push"](" lenaP".split("").reverse().join("") + _0xc8_0x503["panelW"] + "×" + _0xc8_0x503["panelH"]); if (_0xc8_0x503["cellSize"] != null)
        _0xe62cb["push"](" lleC".split("").reverse().join("") + _0xc8_0x503["cellSize"] + "xp".split("").reverse().join("")); _0xe62cb["push"]("Icon ×" + (_0xc8_0x503["iconScale"] || 321015 ^ 321014)); return _0xe62cb["join"](" · "); }() + ">naps/<".split("").reverse().join("") + "</div></div>" + ">vid/<>nottub/<epyT tsehC evomeR>epyt-tsehc-evomer-atad nottub<>nottub/<erutcurtS oT tsehC ddA>erutcurts-ot-dda-atad nottub<>nottub/<metI kcolnU kciP>kcolnu-kcip-atad nottub<>nottub/<epyT tsehC ylppA>epyt-tsehc-evas-atad nottub<>\"parw:parw-xelf;xp8:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + "</div>"; var _0xbd4 = _0xa54d["lootTable"] || ""; var _0xd2bb = _0xbd4 && _0x56fd[_0xbd4] ? _0x56fd[_0xbd4] : []; var _0xb510d = (758441 ^ 758447) + (923800 ^ 923802); var _0xf6_0xa78 = "<div style=\"display:grid;gap:6px\"><strong>Loot Table</strong><div style=\"color:#bcae94\">Use the icon-based picker to add loot. Each entry keeps its own rarity and stack step list.</div>"; _0xb510d = (723835 ^ 723837) + (951747 ^ 951744); for (var i = 853779 ^ 853779; i < _0xd2bb["length"]; i++) {
        _0xf6_0xa78 += "\"=di-meti-atad \"04\"=thgieh \"04\"=htdiw \"noci-meti-zdm\"=ssalc savnac<>\"drac-meti-zdm\"=ssalc vid<".split("").reverse().join("") + _0xd2bb[i]["id"] + "\"></canvas><div><div style=\"font-weight:700\">" + _0x0d5eg(_0xf51d(_0xd2bb[i]["id"])) + " DI>\"49eacb#:roloc\"=elyts naps< ".split("").reverse().join("") + _0xd2bb[i]["id"] + "</span></div><div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px\"><label>Rarity<input data-loot-rarity=\"" + i + "\"=eulav \"".split("").reverse().join("") + _0x0d5eg(_0xd2bb[i]["rarity"] || "medium") + "\"=spets-tool-atad tupni<spetS kcatS>lebal<>lebal/<>\"".split("").reverse().join("") + i + "\" value=\"" + _0x0d5eg((_0xd2bb[i]["stackSteps"] || [])["join"](",")) + "\"></label></div></div><button data-remove-loot=\"" + i + ">vid/<>nottub/<evomeR>\"".split("").reverse().join("");
    } _0xf6_0xa78 += "<button data-open-loot-picker>Open Item Picker</button></div>"; _0xc41f5a["innerHTML"] = _0xf6_0xa78; if (_0xdc93b["defaultUiEditor"] && _0xdc93b["defaultUiEditor"]["active"] && _0xdc93b["defaultUiEditor"]["chestTypeId"] === _0xa54d["id"]) {
        _0x4a4["innerHTML"] += _0xd846f(_0xa54d);
    } if (_0xdc93b["customUiEditor"] && _0xdc93b["customUiEditor"]["active"] && _0xdc93b["customUiEditor"]["chestTypeId"] === _0xa54d["id"]) {
        _0x4a4["innerHTML"] += _0x6ee5c(_0xa54d);
    } _0xb2fg2e(); _0x53262g(_0xdc93b["ui"]["root"]); }
    function _0x6ee5c(selected, _0xc02f) { var _0xb4f3b = selected["customUI"] && Array["isArray"](selected["customUI"]["slots"]) ? selected["customUI"]["slots"] : _0xa24dd(null, selected["slotSize"]); var _0x0d2g3a = selected["customUI"] && selected["customUI"]["gridArea"] ? selected["customUI"]["gridArea"] : _0xb54ace(null); var _0xdda2 = selected["customUI"] && selected["customUI"]["size"] ? selected["customUI"]["size"] : _0xa41d(null); _0xc02f = "kolffe"; var _0x76626b = (877829 ^ 877829) + (400534 ^ 400529); var _0x0915c = selected["customUI"] ? selected["customUI"]["showSlotUi"] !== false : !![]; _0x76626b = 365428 ^ 365424; var _0x81dg = selected["customUI"] && selected["customUI"]["closeBtn"] && selected["customUI"]["closeBtn"]["x"] != null ? selected["customUI"]["closeBtn"]["x"] : 478424 ^ 478425; var _0xbe2b = (215924 ^ 215920) + (140737 ^ 140738); var _0x61_0xdee = selected["customUI"] && selected["customUI"]["closeBtn"] && selected["customUI"]["closeBtn"]["y"] != null ? selected["customUI"]["closeBtn"]["y"] : 328778 ^ 328778; _0xbe2b = 810995 ^ 811003; var _0x78cc = _0xdc93b["customUiEditor"] && _0xdc93b["customUiEditor"]["pan"] ? _0xdc93b["customUiEditor"]["pan"] : {
        "x": 0,
                "y": 0
    }; var _0xe1fb = selected["customUI"] && typeof selected["customUI"]["zoom"] === "rebmun".split("").reverse().join("") ? selected["customUI"]["zoom"] : 713532 ^ 713533; var _0xge_0x2ad = (840592 ^ 840593) + (758934 ^ 758935); var _0x12411e = _0x0d5eg(selected["customUI"] && selected["customUI"]["image"] || ""); _0xge_0x2ad = 101202 ^ 101200; var _0xf7768c = (811226 ^ 811230) + (555772 ^ 555765); var _0x4e5bc = ""; _0xf7768c = (873469 ^ 873471) + (951991 ^ 951986); for (var i = 875878 ^ 875878; i < _0xb4f3b["length"]; i++) {
        var _0x3232eb = (623434 ^ 623433) + (854307 ^ 854307);
        var _0xgcc0b = selected["staticSlots"] && selected["staticSlots"][i] && selected["staticSlots"][i]["id"] ? selected["staticSlots"][i]["id"] : "";
        _0x3232eb = 696735 ^ 696735;
        _0x4e5bc += "<div data-ui-slot=\"" + i + ":tfel;etulosba:noitisop\"=elyts \"".split("").reverse().join("") + _0xb4f3b[i]["x"] * (360520 ^ 360492) + "%;top:" + _0xb4f3b[i]["y"] * (677316 ^ 677280) + ">\"otua:stneve-retniop;)%05-,%05-(etalsnart:mrofsnart;xp65:thgieh;xp65:htdiw;%".split("").reverse().join("") + (_0x0915c ? "<div style=\"position:absolute;inset:0;background:url(images/cell.png) center/contain no-repeat;background-color:rgba(0,0,0,0.25);\"></div>" : "") + (_0xgcc0b ? "<canvas class=\"mdz-item-icon\" width=\"44\" height=\"44\" data-preview-item-id=\"" + _0xgcc0b + "\" style=\"position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:44px;height:44px;\"></canvas>" : "") + "<div style=\"position:absolute;right:-8px;top:-8px;width:18px;height:18px;border-radius:50%;background:rgba(0,0,0,0.65);color:#fff;font-size:10px;line-height:18px;text-align:center;\">" + (i + (399705 ^ 399704)) + "</div>" + "</div>";
    } return "<div class=\"mdz-card\" style=\"display:grid;gap:8px;margin-top:12px\">" + "<div style=\"display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px\">" + "<strong>Configure UI</strong>" + "<div style=\"display:flex;align-items:center;gap:8px;flex-wrap:wrap\">" + ">nottub/<->\"xp82:thgieh;xp82:htdiw\"=elyts tuo-mooz-iu-motsuc-atad nottub<".split("").reverse().join("") + ">\"retnec:ngila-txet;xp04:htdiw-nim\"=elyts yalpsid-mooz-iu-motsuc-atad naps<".split("").reverse().join("") + Math["round"](_0xe1fb * (147094 ^ 147186)) + ">naps/<%".split("").reverse().join("") + ">nottub/<+>\"xp82:thgieh;xp82:htdiw\"=elyts ni-mooz-iu-motsuc-atad nottub<".split("").reverse().join("") + " \"xobkcehc\"=epyt iutols-wohs-iu-motsuc-atad tupni<>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (_0x0915c ? "checked" : "") + ">lebal/<IU tols wohS>".split("").reverse().join("") + "\"=eulav \"50.0\"=pets \"4\"=xam \"1.0\"=nim \"rebmun\"=epyt elacs-tols-iu-motsuc-atad tupni<elacS tolS>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (selected["customUI"] && selected["customUI"]["slotScale"] != null ? selected["customUI"]["slotScale"] : 197858 ^ 197859) + "\" style=\"width:56px\"></label>" + "\"=eulav \"50.0\"=pets \"4\"=xam \"1.0\"=nim \"rebmun\"=epyt elacs-noci-iu-motsuc-atad tupni<elacS nocI>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (selected["customUI"] && selected["customUI"]["iconScale"] != null ? selected["customUI"]["iconScale"] : 671983 ^ 671982) + ">lebal/<>\"xp65:htdiw\"=elyts \"".split("").reverse().join("") + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">UI W<input data-custom-ui-size-width type=\"number\" min=\"100\" max=\"2000\" value=\"" + _0xdda2["width"] + "\" style=\"width:64px\"></label>" + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">UI H<input data-custom-ui-size-height type=\"number\" min=\"100\" max=\"2000\" value=\"" + _0xdda2["height"] + ">lebal/<>\"xp46:htdiw\"=elyts \"".split("").reverse().join("") + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">X<input data-custom-ui-grid-x type=\"number\" min=\"0\" max=\"100\" value=\"" + Math["round"](_0x0d2g3a["x"] * (316951 ^ 317043)) + ">lebal/<>\"xp65:htdiw\"=elyts \"".split("").reverse().join("") + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">Y<input data-custom-ui-grid-y type=\"number\" min=\"0\" max=\"100\" value=\"" + Math["round"](_0x0d2g3a["y"] * (951411 ^ 951319)) + "\" style=\"width:56px\"></label>" + "\"=eulav \"001\"=xam \"01\"=nim \"rebmun\"=epyt htdiw-dirg-iu-motsuc-atad tupni<W>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + Math["round"](_0x0d2g3a["width"] * (968375 ^ 968403)) + "\" style=\"width:56px\"></label>" + "\"=eulav \"001\"=xam \"01\"=nim \"rebmun\"=epyt thgieh-dirg-iu-motsuc-atad tupni<H>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + Math["round"](_0x0d2g3a["height"] * (746012 ^ 746104)) + "\" style=\"width:56px\"></label>" + ">vid/<".split("").reverse().join("") + ">vid/<".split("").reverse().join("") + "<div data-custom-ui-editor style=\"position:relative;width:100%;height:320px;border:1px solid rgba(255,255,255,0.12);background:#111;overflow:auto\">" + ":htdiw;0:pot;0:tfel;etulosba:noitisop\"=elyts weiverp-iu-motsuc-atad vid<".split("").reverse().join("") + _0xdda2["width"] + "px;height:" + _0xdda2["height"] + "px;transform:translate(" + _0x78cc["x"] + "px, " + _0x78cc["y"] + "px) scale(" + _0xe1fb + ");transform-origin:0 0;pointer-events:auto;display:block\">" + "\"=crs egami-iu-motsuc-atad gmi<".split("").reverse().join("") + _0x12411e + "\" alt=\"\" style=\"display:block;width:100%;height:100%;object-fit:fill;pointer-events:none\">" + "<div data-ui-closebtn style=\"position:absolute;left:" + _0x81dg * (308463 ^ 308363) + "%;top:" + _0x61_0xdee * (978870 ^ 978898) + ">vid/<>\"01:xedni-z;enon:tceles-resu;xob-redrob:gnizis-xob;)8.0,001,001,552(abgr dilos xp2:redrob;barg:rosruc;xp5:suidar-redrob;)53.0,0,0,0(abgr taeper-on niatnoc/retnec )gnp.kram_x/segami(lru:dnuorgkcab;otua:stneve-retniop;)%05-,%05-(etalsnart:mrofsnart;xp84:thgieh;xp84:htdiw;%".split("").reverse().join("") + ":tfel;etulosba:noitisop\"=elyts dirg-iu-motsuc-atad vid<".split("").reverse().join("") + _0x0d2g3a["x"] * (285130 ^ 285102) + "%;top:" + _0x0d2g3a["y"] * (847931 ^ 847967) + "%;width:" + _0x0d2g3a["width"] * (654582 ^ 654482) + ":thgieh;%".split("").reverse().join("") + _0x0d2g3a["height"] * (304499 ^ 304407) + "%;border:2px dashed rgba(255,255,255,0.9);box-sizing:border-box;pointer-events:auto;background-image:linear-gradient(rgba(255,255,255,0.12) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.12) 1px, transparent 1px);background-size:20% 20%;\">" + _0x4e5bc + ">vid/<>\"xob-redrob:gnizis-xob;)4.0,0,0,0(abgr dilos xp1:redrob;)9.0,552,552,552(abgr:dnuorgkcab;eziser-es:rosruc;xp02:thgieh;xp02:htdiw;0:mottob;0:thgir;etulosba:noitisop\"=elyts eldnah-eziser-iu-motsuc-atad vid<".split("").reverse().join("") + "</div>" + ">vid/<".split("").reverse().join("") + ">vid/<".split("").reverse().join("") + "<div style=\"display:flex;gap:8px;flex-wrap:wrap\"><button data-custom-ui-save>Save</button><button data-custom-ui-cancel>Cancel</button></div>" + "<div style=\"color:#bcae94;font-size:12px\">Drag slots and resize the dashed grid to match your background. Use zoom to inspect the layout at scale.</div>" + "</div>"; }
    function _0xd846f(selected, _0xdc6e2d, _0xgfc) { var _0xaddf = selected["defaultUI"] || {
        "panelW": null,
                "panelH": null,
                "cellSize": null,
                "iconScale": 1
    }; _0xdc6e2d = (792533 ^ 792532) + (740609 ^ 740611); var _0xcg921a = (857665 ^ 857665) + (730107 ^ 730110); var _0xd7bdd = selected["slotSize"] || {
        "cols": 5,
                "rows": 3
    }; _0xcg921a = 653422 ^ 653414; var _0x8c49b = 788795 ^ 788785; var _0x1048db = _0xaddf["cellSize"] != null ? _0xaddf["cellSize"] : Math["round"](_0xd5_0x7dc["cellSize"] * 1.15); var _0x9cbae = (356323 ^ 356324) + (458773 ^ 458771); var _0xfc53a = _0xd7bdd["cols"] * _0x1048db; _0x9cbae = 779063 ^ 779061; var _0x674d8d = (753775 ^ 753768) + (123159 ^ 123156); var _0x62_0x0e1 = _0xd7bdd["rows"] * _0x1048db; _0x674d8d = "jgabgd".split("").reverse().join(""); var _0xb8g = _0xaddf["panelW"] != null ? _0xaddf["panelW"] : Math["round"]((_0xfc53a + _0x8c49b * (935660 ^ 935662)) * 1.15); var _0xc98f4b = _0xaddf["panelH"] != null ? _0xaddf["panelH"] : Math["round"]((_0x62_0x0e1 + _0x8c49b * (892858 ^ 892856)) * 1.15); var _0x4d84fc = _0xaddf["iconScale"] != null ? _0xaddf["iconScale"] : 752899 ^ 752898; var _0xa41e = (655014 ^ 655011) + (187924 ^ 187921); var _0x6838ea = _0xdc93b["defaultUiEditor"] || {}; _0xa41e = (250006 ^ 250015) + (588480 ^ 588483); var _0x3d2 = _0x6838ea["zoom"] || 202885 ^ 202884; var _0xd65f = _0x6838ea["pan"] || {
        "x": 0,
                "y": 0
    }; _0xgfc = 575638 ^ 575636; var _0x8fb = ""; for (var _0x3cac3b = 704807 ^ 704807; _0x3cac3b < _0xd7bdd["rows"]; _0x3cac3b++) {
        for (var _0xf85efa = 244827 ^ 244827; _0xf85efa < _0xd7bdd["cols"]; _0xf85efa++) {
            var _0x25409f = (822544 ^ 822546) + (815754 ^ 815746);
            var _0xee_0x387 = _0x3cac3b === (967622 ^ 967622) && _0xf85efa === (942101 ^ 942101);
            _0x25409f = 875691 ^ 875693;
            var _0xe5b8e = _0x8c49b + _0xf85efa * _0x1048db;
            let _0x29dge;
            var _0x778bc = _0x8c49b + _0x3cac3b * _0x1048db;
            _0x29dge = (181436 ^ 181428) + (883407 ^ 883398);
            _0x8fb += ":tfel;etulosba:noitisop\"=elyts vid<".split("").reverse().join("") + _0xe5b8e + "px;top:" + _0x778bc + ":htdiw;xp".split("").reverse().join("") + _0x1048db + ":thgieh;xp".split("").reverse().join("") + _0x1048db + "px;background:url(images/cell.png) center/contain no-repeat rgba(0,0,0,0.3);box-sizing:border-box;" + (_0xee_0x387 ? "border:2px solid rgba(0,220,100,0.9)" : "border:1px solid rgba(255,255,255,0.12)") + ">\"enon:stneve-retniop;".split("").reverse().join("") + (_0xee_0x387 ? "<div data-default-ui-cell-resize style=\"position:absolute;right:0;bottom:0;width:14px;height:14px;cursor:se-resize;background:rgba(0,220,100,0.95);pointer-events:auto;z-index:5\"></div>" : "") + "</div>";
        }
    } var _0x2ee = (494133 ^ 494135) + (210260 ^ 210261); var _0xc6c6d = Math["round"](_0x1048db * 0.7 * _0x4d84fc); _0x2ee = "lbclbf"; _0x8fb += "<div style=\"position:absolute;left:" + (_0x8c49b + _0x1048db / (833132 ^ 833134)) + "px;top:" + (_0x8c49b + _0x1048db / (860462 ^ 860460)) + ":htdiw;)%05-,%05-(etalsnart:mrofsnart;xp".split("").reverse().join("") + _0xc6c6d + "px;height:" + _0xc6c6d + "px;background:rgba(255,200,50,0.45);border-radius:50%;pointer-events:none;border:2px solid rgba(255,200,50,0.9)\"></div>"; return "<div class=\"mdz-card\" style=\"display:grid;gap:8px;margin-top:12px\">" + ">\"xp8:pag;parw:parw-xelf;retnec:smeti-ngila;neewteb-ecaps:tnetnoc-yfitsuj;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + ">gnorts/<IU tluafeD erugifnoC>gnorts<".split("").reverse().join("") + ">\"parw:parw-xelf;xp8:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + ">nottub/<->\"xp82:thgieh;xp82:htdiw\"=elyts tuo-mooz-iu-tluafed-atad nottub<".split("").reverse().join("") + "<span data-default-ui-zoom-display style=\"min-width:40px;text-align:center\">" + Math["round"](_0x3d2 * (929620 ^ 929584)) + "%</span>" + "<button data-default-ui-zoom-in style=\"width:28px;height:28px\">+</button>" + "\"=eulav \"0002\"=xam \"08\"=nim \"rebmun\"=epyt w-lenap-iu-tluafed-atad tupni<W lenaP>\"xp21:ezis-tnof;xp4:pag;retnec:smeti-ngila;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + _0xb8g + ">lebal/<>\"xp46:htdiw\"=elyts \"".split("").reverse().join("") + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">Panel H<input data-default-ui-panel-h type=\"number\" min=\"80\" max=\"2000\" value=\"" + _0xc98f4b + ">lebal/<>\"xp46:htdiw\"=elyts \"".split("").reverse().join("") + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">Cell Size<input data-default-ui-cell-size type=\"number\" min=\"8\" max=\"200\" value=\"" + _0x1048db + "\" style=\"width:56px\"></label>" + "<label style=\"display:flex;align-items:center;gap:4px;font-size:12px\">Icon Scale<input data-default-ui-icon-scale type=\"number\" min=\"0.1\" max=\"4\" step=\"0.05\" value=\"" + _0x4d84fc + "\" style=\"width:56px\"></label>" + "</div>" + "</div>" + ">\"barg:rosruc;neddih:wolfrevo;111#:dnuorgkcab;)21.0,552,552,552(abgr dilos xp1:redrob;xp023:thgieh;%001:htdiw;evitaler:noitisop\"=elyts rotide-iu-tluafed-atad vid<".split("").reverse().join("") + "<div data-default-ui-preview style=\"position:absolute;left:0;top:0;transform:translate(" + _0xd65f["x"] + ",xp".split("").reverse().join("") + _0xd65f["y"] + "(elacs )xp".split("").reverse().join("") + _0x3d2 + ");transform-origin:0 0;width:" + _0xb8g + "px;height:" + _0xc98f4b + ">\"otua:stneve-retniop;xob-redrob:gnizis-xob;)53.0,041,002,552(abgr dilos xp2:redrob;)29.0,02,82,04(abgr:dnuorgkcab;xp".split("").reverse().join("") + _0x8fb + ">vid/<>\"otua:stneve-retniop;5:xedni-z;)59.0,05,002,552(abgr:dnuorgkcab;eziser-es:rosruc;xp02:thgieh;xp02:htdiw;0:mottob;0:thgir;etulosba:noitisop\"=elyts eziser-lenap-iu-tluafed-atad vid<".split("").reverse().join("") + "</div>" + "</div>" + "<div style=\"color:#bcae94;font-size:12px\">Drag <span style=\"color:#ffc832\">&#9632; yellow</span> corner to resize panel. Drag <span style=\"color:#00dc64\">&#9632; green</span> corner (top-left cell) to resize slots. Yellow circle = item icon at current scale.</div>" + ">vid/<>nottub/<otuA ot teseR>teser-iu-tluafed-atad nottub<>nottub/<lecnaC>lecnac-iu-tluafed-atad nottub<>nottub/<evaS>evas-iu-tluafed-atad nottub<>\"parw:parw-xelf;xp8:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + ">vid/<".split("").reverse().join(""); }
    function _0xb2fg2e(_0xd9576a, _0xb2_0xba9, _0x7_0x84f, _0x7921b) { var _0x2b_0x0g6 = _0xdc93b["ui"]["left"]; var _0xa7e = _0xdc93b["ui"]["center"]; _0xd9576a = (851087 ^ 851080) + (975825 ^ 975829); var _0xba27fa = _0xdc93b["ui"]["right"]; _0xb2_0xba9 = "dgnoej"; var _0xc65b = _0x2b_0x0g6["querySelectorAll"]("[data-chest-type]"); for (var i = 678248 ^ 678248; i < _0xc65b["length"]; i++) {
        _0xc65b[i]["addEventListener"]("click", function () { _0xdc93b["selectedChestTypeId"] = this["getAttribute"]("epyt-tsehc-atad".split("").reverse().join("")); _0x1f051d(); });
    } var _0x2fe7fa = (689984 ^ 689989) + (388052 ^ 388050); var _0x97d6da = _0x2b_0x0g6["querySelector"]("[data-add-chest-type]"); _0x2fe7fa = "jjngif"; if (_0x97d6da)
        _0x97d6da["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0xc2e = "type" + (Object["keys"](_0x87g)["length"] + (256176 ^ 256177)); _0x87g[_0xc2e] = _0x39_0xb48(_0xc2e, {
            "id": _0xc2e,
                    "name": " tsehC motsuC".split("").reverse().join("") + Object["keys"](_0x87g)["length"]
        }); _0xdc93b["selectedChestTypeId"] = _0xc2e; _0xdc93b["statusText"] = "Added chest type " + _0xc2e + "."; _0x1f051d(); }); var _0xgb33b = _0x2b_0x0g6["querySelector"]("[data-dup-chest-type]"); if (_0xgb33b)
        _0xgb33b["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0xa1270c = _0xdc93b["selectedChestTypeId"]; var _0xac3b1f = _0x87g[_0xa1270c]; if (!_0xac3b1f)
            return; var _0x5acfc = _0xa1270c + "ypoc_".split("").reverse().join(""); var _0xb6ec2f = (630759 ^ 630766) + (342642 ^ 342651); var n = 467732 ^ 467734; _0xb6ec2f = (107540 ^ 107541) + (208645 ^ 208644); while (_0x87g[_0x5acfc]) {
            _0x5acfc = _0xa1270c + "ypoc_".split("").reverse().join("") + n;
            n++;
        } _0x87g[_0x5acfc] = _0x8dd(_0xac3b1f); _0x87g[_0x5acfc]["id"] = _0x5acfc; _0x87g[_0x5acfc]["name"] = (_0xac3b1f["name"] || _0xa1270c) + " (Copy)"; _0xdc93b["selectedChestTypeId"] = _0x5acfc; _0xdc93b["statusText"] = "Duplicated “" + (_0xac3b1f["name"] || _0xa1270c) + " → ”".split("").reverse().join("") + _0x5acfc; _0x1f051d(); }); var _0x59037c = _0xa7e["querySelector"]("]kcolnu-kcip-atad[".split("").reverse().join("")); if (_0x59037c)
        _0x59037c["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xf3_0x194({
            "kind": "unlock",
                    "scope": "type",
                    "chestTypeId": _0xdc93b["selectedChestTypeId"]
        }); }); var _0x6_0xag5 = (957916 ^ 957913) + (165141 ^ 165149); var _0xcf87a = _0xa7e["querySelector"]("]\"egamIIUmotsuc\"=dleif-atad[".split("").reverse().join("")); _0x6_0xag5 = 821753 ^ 821756; if (_0xcf87a)
        _0xcf87a["addEventListener"]("input", function () { var _0xc537db = _0xa7e["querySelector"]("[data-customui-preview]"); if (!_0xc537db)
            return; var _0xc0aee = (248954 ^ 248952) + (249668 ^ 249677); var _0x82bgad = this["value"]["trim"](); _0xc0aee = (591188 ^ 591186) + (310875 ^ 310878); if (_0x82bgad) {
            _0xc537db["style"]["display"] = "kcolb".split("").reverse().join("");
            if (_0xc537db["tagName"] === "IMG") {
                _0xc537db["src"] = _0x82bgad;
            }
            else {
                _0xc537db["outerHTML"] = "\"=crs weiverp-iumotsuc-atad gmi<".split("").reverse().join("") + _0x0d5eg(_0x82bgad) + "\" style=\"display:block;margin-top:4px;max-width:100%;max-height:80px;border-radius:6px;border:1px solid rgba(255,255,255,0.15);object-fit:contain;background:#111\">";
            }
        }
        else {
            _0xc537db["style"]["display"] = "none";
            if (_0xc537db["tagName"] === "IMG")
                _0xc537db["src"] = "";
        } }); var _0xc7ab = _0xa7e["querySelector"]("]iu-tluafed-erugifnoc-atad[".split("").reverse().join("")); if (_0xc7ab)
        _0xc7ab["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0x8bc65g = (440071 ^ 440078) + (179773 ^ 179768); var _0x7d7gdf = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x8bc65g = (968177 ^ 968181) + (172537 ^ 172542); if (!_0x7d7gdf)
            return; _0x7d7gdf["defaultUI"] = _0x7d7gdf["defaultUI"] || {
            "panelW": null,
                    "panelH": null,
                    "cellSize": null,
                    "iconScale": 1
        }; _0xdc93b["defaultUiEditor"] = {
            "active": !![],
                    "chestTypeId": _0x7d7gdf["id"],
                    "orig": _0x8dd(_0x7d7gdf["defaultUI"]),
                    "drag": null,
                    "zoom": 0.8,
                    "pan": {
                "x": 8,
                        "y": 8
            }
        }; _0x1f051d(); }); var _0x5a2 = _0xa7e["querySelector"]("[data-default-ui-editor]"); _0x7_0x84f = 419981 ^ 419973; if (_0x5a2) {
        var _0xc3_0xe62 = _0x87g[_0xdc93b["selectedChestTypeId"]];
        var _0xa8_0xge5 = _0x5a2["querySelector"]("[data-default-ui-preview]");
        let _0x1g6bb;
        var _0x29e = function () { var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
            return {}; var _0xba73b = (632529 ^ 632529) + (979900 ^ 979903); var _0xcd_0xa02 = s["defaultUI"] || {}; _0xba73b = (548814 ^ 548813) + (509461 ^ 509463); var _0x3ccf = (691143 ^ 691136) + (643922 ^ 643920); var _0x840ac = s["slotSize"] || {
            "cols": 5,
                        "rows": 3
        }; _0x3ccf = (443559 ^ 443553) + (130253 ^ 130254); var _0xeabbe = (453246 ^ 453241) + (721430 ^ 721428); var _0x5f2 = _0xcd_0xa02["cellSize"] != null ? _0xcd_0xa02["cellSize"] : Math["round"](_0xd5_0x7dc["cellSize"] * 1.15); _0xeabbe = (945816 ^ 945820) + (342068 ^ 342066); var _0xd3966a = 124111 ^ 124101; return {
            "panelW": _0xcd_0xa02["panelW"] != null ? _0xcd_0xa02["panelW"] : Math["round"]((_0x840ac["cols"] * _0x5f2 + _0xd3966a * (405163 ^ 405161)) * 1.15),
                        "panelH": _0xcd_0xa02["panelH"] != null ? _0xcd_0xa02["panelH"] : Math["round"]((_0x840ac["rows"] * _0x5f2 + _0xd3966a * (525840 ^ 525842)) * 1.15),
                        "cellSize": _0x5f2
        }; };
        _0x1g6bb = (498243 ^ 498251) + (281013 ^ 281009);
        var _0x2b748b = _0xa7e["querySelector"]("[data-default-ui-zoom-in]");
        if (_0x2b748b)
            _0x2b748b["addEventListener"]("click", function () { if (!_0xdc93b["defaultUiEditor"])
                return; _0xdc93b["defaultUiEditor"]["zoom"] = Math["min"](747536 ^ 747539, Math["round"](((_0xdc93b["defaultUiEditor"]["zoom"] || 394500 ^ 394501) + 0.1) * (860995 ^ 860967)) / (536648 ^ 536620)); _0x1f051d(); });
        var _0xg3_0xab0 = _0xa7e["querySelector"]("]tuo-mooz-iu-tluafed-atad[".split("").reverse().join(""));
        if (_0xg3_0xab0)
            _0xg3_0xab0["addEventListener"]("click", function () { if (!_0xdc93b["defaultUiEditor"])
                return; _0xdc93b["defaultUiEditor"]["zoom"] = Math["max"](0.1, Math["round"](((_0xdc93b["defaultUiEditor"]["zoom"] || 861361 ^ 861360) - 0.1) * (753835 ^ 753871)) / (454350 ^ 454314)); _0x1f051d(); });
        let _0xe7e78g;
        var _0xa4b4b = _0xa7e["querySelector"]("[data-default-ui-panel-w]");
        _0xe7e78g = (368369 ^ 368369) + (165038 ^ 165032);
        if (_0xa4b4b)
            _0xa4b4b["addEventListener"]("change", function () { var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
                return; s["defaultUI"] = s["defaultUI"] || {}; s["defaultUI"]["panelW"] = Math["max"](267470 ^ 267422, Number(this["value"]) || 734562 ^ 734634); _0x1f051d(); });
        var _0x8e02e = _0xa7e["querySelector"]("[data-default-ui-panel-h]");
        if (_0x8e02e)
            _0x8e02e["addEventListener"]("change", function () { var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
                return; s["defaultUI"] = s["defaultUI"] || {}; s["defaultUI"]["panelH"] = Math["max"](408508 ^ 408556, Number(this["value"]) || 819105 ^ 819049); _0x1f051d(); });
        let _0xb4d8c;
        var _0x1ea03b = _0xa7e["querySelector"]("[data-default-ui-cell-size]");
        _0xb4d8c = 278004 ^ 278001;
        if (_0x1ea03b)
            _0x1ea03b["addEventListener"]("egnahc".split("").reverse().join(""), function () { var _0xb0acb = (845476 ^ 845473) + (214220 ^ 214219); var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0xb0acb = (502386 ^ 502387) + (375424 ^ 375428); if (!s)
                return; s["defaultUI"] = s["defaultUI"] || {}; s["defaultUI"]["cellSize"] = Math["max"](508485 ^ 508493, Math["min"](907062 ^ 907262, Number(this["value"]) || 856316 ^ 856270)); _0x1f051d(); });
        let _0x576f;
        var _0x5a2ag = _0xa7e["querySelector"]("]elacs-noci-iu-tluafed-atad[".split("").reverse().join(""));
        _0x576f = "jmqajd";
        if (_0x5a2ag)
            _0x5a2ag["addEventListener"]("change", function () { var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
                return; s["defaultUI"] = s["defaultUI"] || {}; s["defaultUI"]["iconScale"] = Math["max"](0.1, Math["min"](487897 ^ 487901, Number(this["value"]) || 312076 ^ 312077)); _0x1f051d(); });
        var _0x8651a = _0x5a2["querySelector"]("[data-default-ui-cell-resize]");
        if (_0x8651a)
            _0x8651a["addEventListener"]("nwodretniop".split("").reverse().join(""), function (e, _0xc73a) { var _0x41ab = _0x29e(); _0xc73a = "ceikme"; _0x5a2["setPointerCapture"](e["pointerId"]); _0xdc93b["defaultUiEditor"]["drag"] = {
                "kind": "cell",
                        "startX": e["clientX"],
                        "startY": e["clientY"],
                        "origCellSz": _0x41ab["cellSize"]
            }; e["preventDefault"](); e["stopPropagation"](); });
        var _0x388ga = _0x5a2["querySelector"]("[data-default-ui-panel-resize]");
        if (_0x388ga)
            _0x388ga["addEventListener"]("nwodretniop".split("").reverse().join(""), function (e, _0x8_0x66d) { var _0xc0e = _0x29e(); _0x8_0x66d = (755418 ^ 755418) + (692710 ^ 692707); _0x5a2["setPointerCapture"](e["pointerId"]); _0xdc93b["defaultUiEditor"]["drag"] = {
                "kind": "panel",
                        "startX": e["clientX"],
                        "startY": e["clientY"],
                        "origPanelW": _0xc0e["panelW"],
                        "origPanelH": _0xc0e["panelH"]
            }; e["preventDefault"](); e["stopPropagation"](); });
        _0x5a2["addEventListener"]("nwodretniop".split("").reverse().join(""), function (e) { if (e["target"]["closest"]("[data-default-ui-panel-resize],[data-default-ui-cell-resize]"))
            return; _0x5a2["setPointerCapture"](e["pointerId"]); _0xdc93b["defaultUiEditor"]["drag"] = {
            "kind": "pan",
                        "startX": e["clientX"],
                        "startY": e["clientY"],
                        "origPanX": _0xdc93b["defaultUiEditor"]["pan"] ? _0xdc93b["defaultUiEditor"]["pan"]["x"] : 145198 ^ 145198,
                        "origPanY": _0xdc93b["defaultUiEditor"]["pan"] ? _0xdc93b["defaultUiEditor"]["pan"]["y"] : 245570 ^ 245570
        }; e["preventDefault"](); });
        _0x5a2["addEventListener"]("pointermove", function (e) { var _0xc8ac = (657640 ^ 657645) + (944662 ^ 944662); var _0xd5b8d = _0xdc93b["defaultUiEditor"] && _0xdc93b["defaultUiEditor"]["drag"]; _0xc8ac = (282671 ^ 282663) + (891764 ^ 891773); if (!_0xd5b8d)
            return; var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
            return; s["defaultUI"] = s["defaultUI"] || {}; var _0x5e12f = _0xdc93b["defaultUiEditor"]["zoom"] || 827120 ^ 827121; var _0xbbg = e["clientX"] - _0xd5b8d["startX"], _0x9ac19e = e["clientY"] - _0xd5b8d["startY"]; if (_0xd5b8d["kind"] === "lenap".split("").reverse().join("")) {
            s["defaultUI"]["panelW"] = Math["max"](161724 ^ 161772, Math["round"](_0xd5b8d["origPanelW"] + _0xbbg / _0x5e12f));
            s["defaultUI"]["panelH"] = Math["max"](749762 ^ 749714, Math["round"](_0xd5b8d["origPanelH"] + _0x9ac19e / _0x5e12f));
            if (_0xa8_0xge5) {
                _0xa8_0xge5["style"]["width"] = s["defaultUI"]["panelW"] + "px";
                _0xa8_0xge5["style"]["height"] = s["defaultUI"]["panelH"] + "px";
            }
            var _0xc09f6c = (742203 ^ 742202) + (276240 ^ 276241);
            var _0xc8b63e = _0xa7e["querySelector"]("]w-lenap-iu-tluafed-atad[".split("").reverse().join(""));
            _0xc09f6c = 746065 ^ 746069;
            if (_0xc8b63e)
                _0xc8b63e["value"] = s["defaultUI"]["panelW"];
            var _0x6c5caf = _0xa7e["querySelector"]("[data-default-ui-panel-h]");
            if (_0x6c5caf)
                _0x6c5caf["value"] = s["defaultUI"]["panelH"];
        }
        else if (_0xd5b8d["kind"] === "llec".split("").reverse().join("")) {
            s["defaultUI"]["cellSize"] = Math["max"](625731 ^ 625739, Math["min"](653912 ^ 653968, Math["round"](_0xd5b8d["origCellSz"] + (_0xbbg + _0x9ac19e) / (148034 ^ 148032) / _0x5e12f)));
            _0x1f051d();
        }
        else if (_0xd5b8d["kind"] === "pan") {
            _0xdc93b["defaultUiEditor"]["pan"] = {
                "x": _0xd5b8d["origPanX"] + _0xbbg,
                            "y": _0xd5b8d["origPanY"] + _0x9ac19e
            };
            if (_0xa8_0xge5)
                _0xa8_0xge5["style"]["transform"] = "(etalsnart".split("").reverse().join("") + _0xdc93b["defaultUiEditor"]["pan"]["x"] + "px," + _0xdc93b["defaultUiEditor"]["pan"]["y"] + "px) scale(" + _0x5e12f + ")";
        } });
        _0x5a2["addEventListener"]("pointerup", function () { if (_0xdc93b["defaultUiEditor"])
            _0xdc93b["defaultUiEditor"]["drag"] = null; });
        _0x5a2["addEventListener"]("pointercancel", function () { if (_0xdc93b["defaultUiEditor"])
            _0xdc93b["defaultUiEditor"]["drag"] = null; });
        let _0xc3c4a;
        var _0xfcf7f = _0xa7e["querySelector"]("[data-default-ui-save]");
        _0xc3c4a = "lifdqb".split("").reverse().join("");
        if (_0xfcf7f)
            _0xfcf7f["addEventListener"]("kcilc".split("").reverse().join(""), function (_0x3a52b) { var _0xd17cff = (707179 ^ 707176) + (814267 ^ 814258); var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0xd17cff = 264704 ^ 264705; if (!s)
                return; s["defaultUI"] = s["defaultUI"] || {}; var _0x07bc = _0xa7e["querySelector"]("[data-default-ui-panel-w]"); if (_0x07bc)
                s["defaultUI"]["panelW"] = Math["max"](842218 ^ 842170, Number(_0x07bc["value"])); var _0x246e2f = _0xa7e["querySelector"]("[data-default-ui-panel-h]"); if (_0x246e2f)
                s["defaultUI"]["panelH"] = Math["max"](513473 ^ 513425, Number(_0x246e2f["value"])); var _0x1088e = _0xa7e["querySelector"]("]ezis-llec-iu-tluafed-atad[".split("").reverse().join("")); _0x3a52b = 406951 ^ 406946; if (_0x1088e)
                s["defaultUI"]["cellSize"] = Math["max"](244740 ^ 244748, Math["min"](302857 ^ 303041, Number(_0x1088e["value"]))); var _0x995d1f = _0xa7e["querySelector"]("[data-default-ui-icon-scale]"); if (_0x995d1f)
                s["defaultUI"]["iconScale"] = Math["max"](0.1, Math["min"](334726 ^ 334722, Number(_0x995d1f["value"]) || 227125 ^ 227124)); _0xdc93b["defaultUiEditor"] = null; _0xdc93b["statusText"] = ".devas IU tluafeD".split("").reverse().join(""); _0x1f051d(); });
        var _0xc4_0xbef = _0xa7e["querySelector"]("[data-default-ui-cancel]");
        if (_0xc4_0xbef)
            _0xc4_0xbef["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0xf74ae = (918233 ^ 918234) + (525950 ^ 525946); var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0xf74ae = 293929 ^ 293930; if (s && _0xdc93b["defaultUiEditor"] && _0xdc93b["defaultUiEditor"]["orig"])
                s["defaultUI"] = _0x8dd(_0xdc93b["defaultUiEditor"]["orig"]); _0xdc93b["defaultUiEditor"] = null; _0xdc93b["statusText"] = "Default UI edit canceled."; _0x1f051d(); });
        var _0x08e18d = _0xa7e["querySelector"]("]teser-iu-tluafed-atad[".split("").reverse().join(""));
        if (_0x08e18d)
            _0x08e18d["addEventListener"]("click", function () { var s = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!s)
                return; s["defaultUI"] = {
                "panelW": null,
                        "panelH": null,
                        "cellSize": null,
                        "iconScale": 1
            }; _0xdc93b["statusText"] = ".otua ot teser IU tluafeD".split("").reverse().join(""); _0x1f051d(); });
    } var _0x146bda = _0xa7e["querySelector"]("[data-configure-ui]"); _0x7921b = "ekfnek"; if (_0x146bda)
        _0x146bda["addEventListener"]("click", function () { var _0x72d4c = (810602 ^ 810605) + (354912 ^ 354918); var _0xd80bde = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x72d4c = "phpobb".split("").reverse().join(""); if (!_0xd80bde)
            return; _0xd80bde["customUI"] = _0xd80bde["customUI"] || {
            "enabled": false,
                    "image": "",
                    "slots": [],
                    "gridArea": _0xb54ace(null),
                    "zoom": 1
        }; if (!Array["isArray"](_0xd80bde["customUI"]["slots"]) || _0xd80bde["customUI"]["slots"]["length"] !== _0x267d(_0xd80bde["slotSize"])) {
            _0xd80bde["customUI"]["slots"] = _0xa24dd(_0xd80bde["customUI"]["slots"], _0xd80bde["slotSize"]);
        } if (!_0xd80bde["customUI"]["gridArea"]) {
            _0xd80bde["customUI"]["gridArea"] = _0xb54ace(null);
        } _0xd80bde["customUI"]["size"] = _0xd80bde["customUI"]["size"] || _0xa41d(null); if (typeof _0xd80bde["customUI"]["showSlotUi"] === "undefined")
            _0xd80bde["customUI"]["showSlotUi"] = !![]; if (!_0xd80bde["customUI"]["closeBtn"] || typeof _0xd80bde["customUI"]["closeBtn"]["x"] === "undefined")
            _0xd80bde["customUI"]["closeBtn"] = {
                "x": 1,
                    "y": 0
            }; _0xd80bde["customUI"]["zoom"] = _0x392cbd(_0xd80bde["customUI"]["zoom"]); _0xdc93b["customUiEditor"] = {
            "active": !![],
                    "chestTypeId": _0xd80bde["id"],
                    "originalSlots": _0x8dd(_0xd80bde["customUI"]["slots"]),
                    "originalGridArea": _0x8dd(_0xd80bde["customUI"]["gridArea"]),
                    "originalCloseBtn": _0x8dd(_0xd80bde["customUI"]["closeBtn"]),
                    "drag": null,
                    "pan": {
                "x": 0,
                        "y": 0
            }
        }; _0x1f051d(); }); var _0x9_0x9af = (199460 ^ 199457) + (815217 ^ 815224); var _0x1b1e8f = _0xa7e["querySelectorAll"]("[data-static-slot]"); _0x9_0x9af = (905884 ^ 905886) + (610015 ^ 610006); for (var _0xae6bce = 407754 ^ 407754; _0xae6bce < _0x1b1e8f["length"]; _0xae6bce++) {
        _0x1b1e8f[_0xae6bce]["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xf3_0x194({
            "kind": "staticSlot",
                        "chestTypeId": _0xdc93b["selectedChestTypeId"],
                        "slotIndex": Number(this["getAttribute"]("data-static-slot")) || 743725 ^ 743725
        }); });
    } var _0x4d_0xe46 = (926902 ^ 926902) + (948545 ^ 948548); var _0x2dc = _0xa7e["querySelector"]("]stols-citats-raelc-atad[".split("").reverse().join("")); _0x4d_0xe46 = (263277 ^ 263273) + (554959 ^ 554959); if (_0x2dc)
        _0x2dc["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0x87g[_0xdc93b["selectedChestTypeId"]]["staticSlots"] = []; _0xdc93b["statusText"] = ".stols citats deraelC".split("").reverse().join(""); _0x1f051d(); }); var _0x9b11b = _0xa7e["querySelector"]("]rotide-iu-motsuc-atad[".split("").reverse().join("")); if (_0x9b11b) {
        var _0x10_0xbf0 = (567229 ^ 567225) + (228909 ^ 228908);
        var selected = _0x87g[_0xdc93b["selectedChestTypeId"]];
        _0x10_0xbf0 = "kldmql".split("").reverse().join("");
        var _0x998f6e = _0xa7e["querySelector"]("[data-custom-ui-grid]");
        var _0xd9a2e = _0x9b11b["querySelector"]("[data-custom-ui-preview]");
        var _0x6e_0xe90 = _0x9b11b["querySelector"]("]egami-iu-motsuc-atad[".split("").reverse().join(""));
        let _0xb3_0x28b;
        var _0x70c19b = function (_0x98d) { if (!_0xd9a2e || !_0x6e_0xe90)
            return; if (selected && selected["customUI"] && selected["customUI"]["size"]) {
            _0xd9a2e["style"]["width"] = Math["max"](377335 ^ 377235, Number(selected["customUI"]["size"]["width"]) || 322295 ^ 322307) + "xp".split("").reverse().join("");
            _0xd9a2e["style"]["height"] = Math["max"](279064 ^ 279164, Number(selected["customUI"]["size"]["height"]) || 563727 ^ 564219) + "xp".split("").reverse().join("");
            return;
        } var _0x671b3b = _0x6e_0xe90["naturalWidth"] || _0x6e_0xe90["width"] || 728417 ^ 728417; var _0x28cf4b = _0x6e_0xe90["naturalHeight"] || _0x6e_0xe90["height"] || 180308 ^ 180308; _0x98d = 632671 ^ 632662; if (_0x671b3b > (405634 ^ 405634) && _0x28cf4b > (150153 ^ 150153)) {
            _0xd9a2e["style"]["width"] = _0x671b3b + "xp".split("").reverse().join("");
            _0xd9a2e["style"]["height"] = _0x28cf4b + "px";
        } };
        _0xb3_0x28b = (241116 ^ 241109) + (518517 ^ 518514);
        if (_0x6e_0xe90) {
            if (_0x6e_0xe90["complete"] && _0x6e_0xe90["naturalWidth"]) {
                _0x70c19b();
            }
            else {
                _0x6e_0xe90["onload"] = _0x70c19b;
            }
        }
        var _0x322c = (579019 ^ 579016) + (718134 ^ 718142);
        var _0x3639cg = _0x9b11b["querySelectorAll"]("]tols-iu-atad[".split("").reverse().join(""));
        _0x322c = (779795 ^ 779796) + (666939 ^ 666942);
        for (var _0x29be = 539281 ^ 539281; _0x29be < _0x3639cg["length"]; _0x29be++) {
            (function (slotEl) { slotEl["addEventListener"]("nwodretniop".split("").reverse().join(""), function (event) { var _0x4c_0x3b8 = (814222 ^ 814222) + (269701 ^ 269708); var _0x57eb = Number(this["getAttribute"]("tols-iu-atad".split("").reverse().join(""))) || 606517 ^ 606517; _0x4c_0x3b8 = (537815 ^ 537815) + (140416 ^ 140416); var _0x9c1e9c = _0x998f6e ? _0x998f6e["getBoundingClientRect"]() : _0x9b11b["getBoundingClientRect"](); _0x9b11b["setPointerCapture"](event["pointerId"]); _0xdc93b["customUiEditor"]["drag"] = {
                "kind": "slot",
                                "slotIndex": _0x57eb,
                                "startX": event["clientX"],
                                "startY": event["clientY"],
                                "rect": _0x9c1e9c,
                                "origX": selected["customUI"]["slots"][_0x57eb]["x"],
                                "origY": selected["customUI"]["slots"][_0x57eb]["y"]
            }; event["preventDefault"](); }); })(_0x3639cg[_0x29be]);
        }
        let _0x11_0xb24;
        var _0x65_0x3d7 = _0xa7e["querySelector"]("[data-ui-closebtn]");
        _0x11_0xb24 = 816367 ^ 816365;
        if (_0x65_0x3d7) {
            _0x65_0x3d7["addEventListener"]("pointerdown", function (event, _0x83d7g) { var _0x46efb = _0xd9a2e ? _0xd9a2e["getBoundingClientRect"]() : _0x9b11b["getBoundingClientRect"](); _0x83d7g = (421143 ^ 421138) + (558217 ^ 558218); _0x9b11b["setPointerCapture"](event["pointerId"]); _0xdc93b["customUiEditor"]["drag"] = {
                "kind": "closebtn",
                            "startX": event["clientX"],
                            "startY": event["clientY"],
                            "rect": _0x46efb,
                            "origX": selected["customUI"]["closeBtn"] ? selected["customUI"]["closeBtn"]["x"] : 889769 ^ 889768,
                            "origY": selected["customUI"]["closeBtn"] ? selected["customUI"]["closeBtn"]["y"] : 527142 ^ 527142
            }; event["preventDefault"](); event["stopPropagation"](); });
        }
        var _0x47699b = (363664 ^ 363664) + (447939 ^ 447947);
        var _0xcb_0xa6d = _0xa7e["querySelector"]("]eldnah-eziser-iu-motsuc-atad[".split("").reverse().join(""));
        _0x47699b = (261663 ^ 261659) + (903798 ^ 903795);
        _0x9b11b["addEventListener"]("nwodretniop".split("").reverse().join(""), function (event) { if (event["target"]["closest"]("[data-ui-slot], [data-custom-ui-resize-handle], [data-ui-closebtn]"))
            return; _0x9b11b["setPointerCapture"](event["pointerId"]); _0xdc93b["customUiEditor"]["drag"] = {
            "kind": "pan",
                        "startX": event["clientX"],
                        "startY": event["clientY"],
                        "origPanX": _0xdc93b["customUiEditor"]["pan"] ? _0xdc93b["customUiEditor"]["pan"]["x"] : 942595 ^ 942595,
                        "origPanY": _0xdc93b["customUiEditor"]["pan"] ? _0xdc93b["customUiEditor"]["pan"]["y"] : 634359 ^ 634359
        }; event["preventDefault"](); event["stopPropagation"](); });
        if (_0xcb_0xa6d) {
            _0xcb_0xa6d["addEventListener"]("nwodretniop".split("").reverse().join(""), function (event, _0xcgcfd) { var _0x4a_0x655 = _0x9b11b["getBoundingClientRect"](); _0xcgcfd = "cpoilh"; _0x9b11b["setPointerCapture"](event["pointerId"]); _0xdc93b["customUiEditor"]["drag"] = {
                "kind": "resize",
                            "startX": event["clientX"],
                            "startY": event["clientY"],
                            "rect": _0x4a_0x655,
                            "origGridArea": _0x8dd(selected["customUI"]["gridArea"] || _0xb54ace(null))
            }; event["preventDefault"](); event["stopPropagation"](); });
        }
        _0x9b11b["addEventListener"]("pointermove", function (event) { var _0xgfd3c = _0xdc93b["customUiEditor"] && _0xdc93b["customUiEditor"]["drag"]; if (!_0xgfd3c)
            return; var _0x9f2fb = (524596 ^ 524594) + (936289 ^ 936295); var _0x2824d = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x9f2fb = 107259 ^ 107260; if (!_0x2824d)
            return; if (_0xgfd3c["kind"] === "tols".split("").reverse().join("")) {
            let _0x9a_0xd36;
            var rect = _0xgfd3c["rect"];
            _0x9a_0xd36 = 102273 ^ 102273;
            var _0xb3cg = (719561 ^ 719560) + (401038 ^ 401031);
            var dx = event["clientX"] - _0xgfd3c["startX"];
            _0xb3cg = 892916 ^ 892915;
            var dy = event["clientY"] - _0xgfd3c["startY"];
            var _0xfe21b = (400487 ^ 400484) + (967666 ^ 967669);
            var newX = (_0xgfd3c["origX"] * rect["width"] + dx) / rect["width"];
            _0xfe21b = (697823 ^ 697815) + (660419 ^ 660416);
            var newY = (_0xgfd3c["origY"] * rect["height"] + dy) / rect["height"];
            _0x2824d["customUI"]["slots"][_0xgfd3c["slotIndex"]]["x"] = _0x97e01a(newX);
            _0x2824d["customUI"]["slots"][_0xgfd3c["slotIndex"]]["y"] = _0x97e01a(newY);
            var _0x022e8g = (866479 ^ 866474) + (415004 ^ 415001);
            var _0x84d36g = _0x9b11b["querySelector"]("[data-ui-slot=\"" + _0xgfd3c["slotIndex"] + "]\"".split("").reverse().join(""));
            _0x022e8g = (520534 ^ 520528) + (419757 ^ 419754);
            if (_0x84d36g) {
                _0x84d36g["style"]["left"] = _0x2824d["customUI"]["slots"][_0xgfd3c["slotIndex"]]["x"] * (278203 ^ 278239) + "%";
                _0x84d36g["style"]["top"] = _0x2824d["customUI"]["slots"][_0xgfd3c["slotIndex"]]["y"] * (870755 ^ 870663) + "%";
            }
        }
        else if (_0xgfd3c["kind"] === "closebtn") {
            let _0x32981b;
            var rect = _0xgfd3c["rect"];
            _0x32981b = (940601 ^ 940606) + (694643 ^ 694641);
            var _0xc70f4g = (263537 ^ 263543) + (579842 ^ 579846);
            var dx = event["clientX"] - _0xgfd3c["startX"];
            _0xc70f4g = 438591 ^ 438590;
            var dy = event["clientY"] - _0xgfd3c["startY"];
            var newX = _0x97e01a((_0xgfd3c["origX"] * rect["width"] + dx) / rect["width"]);
            var newY = _0x97e01a((_0xgfd3c["origY"] * rect["height"] + dy) / rect["height"]);
            _0x2824d["customUI"]["closeBtn"] = _0x2824d["customUI"]["closeBtn"] || {
                "x": 1,
                            "y": 0
            };
            _0x2824d["customUI"]["closeBtn"]["x"] = newX;
            _0x2824d["customUI"]["closeBtn"]["y"] = newY;
            var _0x4c2c4a = _0x9b11b["querySelector"]("[data-ui-closebtn]");
            if (_0x4c2c4a) {
                _0x4c2c4a["style"]["left"] = newX * (530377 ^ 530349) + "%";
                _0x4c2c4a["style"]["top"] = newY * (387057 ^ 386965) + "%";
            }
        }
        else if (_0xgfd3c["kind"] === "eziser".split("").reverse().join("") && _0x998f6e) {
            var rect = _0xgfd3c["rect"];
            let _0x8331cf;
            var dx = event["clientX"] - _0xgfd3c["startX"];
            _0x8331cf = (617047 ^ 617043) + (725137 ^ 725141);
            var _0x555a = (426568 ^ 426575) + (614224 ^ 614231);
            var dy = event["clientY"] - _0xgfd3c["startY"];
            _0x555a = (987866 ^ 987867) + (448486 ^ 448487);
            _0x2824d["customUI"]["gridArea"]["width"] = Math["max"](0.1, _0x97e01a((_0xgfd3c["origGridArea"]["width"] * rect["width"] + dx) / rect["width"]));
            _0x2824d["customUI"]["gridArea"]["height"] = Math["max"](0.1, _0x97e01a((_0xgfd3c["origGridArea"]["height"] * rect["height"] + dy) / rect["height"]));
            _0x998f6e["style"]["width"] = _0x2824d["customUI"]["gridArea"]["width"] * (884810 ^ 884782) + "%";
            _0x998f6e["style"]["height"] = _0x2824d["customUI"]["gridArea"]["height"] * (579962 ^ 579870) + "%";
        }
        else if (_0xgfd3c["kind"] === "pan") {
            var dx = event["clientX"] - _0xgfd3c["startX"];
            var _0x8g37d = (659842 ^ 659847) + (485457 ^ 485458);
            var dy = event["clientY"] - _0xgfd3c["startY"];
            _0x8g37d = "chqomd";
            _0xdc93b["customUiEditor"]["pan"] = {
                "x": _0xgfd3c["origPanX"] + dx,
                            "y": _0xgfd3c["origPanY"] + dy
            };
            _0x1f051d();
        } });
        _0x9b11b["addEventListener"]("pointerup", function () { if (_0xdc93b["customUiEditor"])
            _0xdc93b["customUiEditor"]["drag"] = null; });
        _0x9b11b["addEventListener"]("lecnacretniop".split("").reverse().join(""), function () { if (_0xdc93b["customUiEditor"])
            _0xdc93b["customUiEditor"]["drag"] = null; });
        var _0x44665e = (682657 ^ 682662) + (747622 ^ 747620);
        var _0x039f = _0xa7e["querySelector"]("[data-custom-ui-zoom-in]");
        _0x44665e = 901523 ^ 901530;
        if (_0x039f)
            _0x039f["addEventListener"]("click", function () { var _0x59fcee = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0x59fcee || !_0x59fcee["customUI"])
                return; _0x59fcee["customUI"]["zoom"] = _0x392cbd((_0x59fcee["customUI"]["zoom"] || 169727 ^ 169726) + 0.05); _0x1f051d(); });
        let _0xag_0x584;
        var _0x991ccc = _0xa7e["querySelector"]("]tuo-mooz-iu-motsuc-atad[".split("").reverse().join(""));
        _0xag_0x584 = "iebeel";
        if (_0x991ccc)
            _0x991ccc["addEventListener"]("kcilc".split("").reverse().join(""), function (_0x8f947b) { var _0x9a8ebc = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x8f947b = (619408 ^ 619412) + (115362 ^ 115365); if (!_0x9a8ebc || !_0x9a8ebc["customUI"])
                return; _0x9a8ebc["customUI"]["zoom"] = _0x392cbd((_0x9a8ebc["customUI"]["zoom"] || 703810 ^ 703811) - 0.05); _0x1f051d(); });
        var _0xc8e6g = _0xa7e["querySelector"]("[data-custom-ui-grid-x]");
        if (_0xc8e6g)
            _0xc8e6g["addEventListener"]("egnahc".split("").reverse().join(""), function () { var _0x65ee = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0x65ee || !_0x65ee["customUI"])
                return; _0x65ee["customUI"]["gridArea"]["x"] = _0x97e01a(Number(this["value"]) / (201613 ^ 201705)); _0x1f051d(); });
        var _0xc128c = (992340 ^ 992340) + (699103 ^ 699097);
        var _0x3a9b = _0xa7e["querySelector"]("]y-dirg-iu-motsuc-atad[".split("").reverse().join(""));
        _0xc128c = (535476 ^ 535478) + (594900 ^ 594909);
        if (_0x3a9b)
            _0x3a9b["addEventListener"]("egnahc".split("").reverse().join(""), function () { var _0xcaae8e = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0xcaae8e || !_0xcaae8e["customUI"])
                return; _0xcaae8e["customUI"]["gridArea"]["y"] = _0x97e01a(Number(this["value"]) / (288107 ^ 288015)); _0x1f051d(); });
        var _0xf53a8d = (118513 ^ 118518) + (235717 ^ 235714);
        var _0xa8de = _0xa7e["querySelector"]("]htdiw-dirg-iu-motsuc-atad[".split("").reverse().join(""));
        _0xf53a8d = (547080 ^ 547084) + (899045 ^ 899041);
        if (_0xa8de)
            _0xa8de["addEventListener"]("change", function () { var _0x6cfg = (246352 ^ 246359) + (413667 ^ 413674); var _0x8deebg = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x6cfg = "plefno".split("").reverse().join(""); if (!_0x8deebg || !_0x8deebg["customUI"])
                return; _0x8deebg["customUI"]["gridArea"]["width"] = Math["max"](0.1, _0x97e01a(Number(this["value"]) / (591867 ^ 591775))); _0x1f051d(); });
        var _0xdda6a = _0xa7e["querySelector"]("]thgieh-dirg-iu-motsuc-atad[".split("").reverse().join(""));
        if (_0xdda6a)
            _0xdda6a["addEventListener"]("change", function () { var _0x556dbf = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0x556dbf || !_0x556dbf["customUI"])
                return; _0x556dbf["customUI"]["gridArea"]["height"] = Math["max"](0.1, _0x97e01a(Number(this["value"]) / (878516 ^ 878544))); _0x1f051d(); });
        let _0x02gd4a;
        var _0x826f4f = _0xa7e["querySelector"]("[data-custom-ui-show-slotui]");
        _0x02gd4a = "lgggil".split("").reverse().join("");
        if (_0x826f4f)
            _0x826f4f["addEventListener"]("change", function () { var _0x49b = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0x49b || !_0x49b["customUI"])
                return; _0x49b["customUI"]["showSlotUi"] = this["checked"]; _0x1f051d(); });
        var _0xfedc7b = _0xa7e["querySelector"]("]htdiw-ezis-iu-motsuc-atad[".split("").reverse().join(""));
        if (_0xfedc7b)
            _0xfedc7b["addEventListener"]("change", function () { var _0x81agd = (952939 ^ 952930) + (766916 ^ 766919); var _0x16819f = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x81agd = (657766 ^ 657760) + (518246 ^ 518254); if (!_0x16819f || !_0x16819f["customUI"])
                return; _0x16819f["customUI"]["size"] = _0x16819f["customUI"]["size"] || _0xa41d(null); _0x16819f["customUI"]["size"]["width"] = Math["max"](288462 ^ 288426, Number(this["value"]) || 535279 ^ 535323); _0x1f051d(); });
        var _0x67_0x838 = _0xa7e["querySelector"]("]thgieh-ezis-iu-motsuc-atad[".split("").reverse().join(""));
        if (_0x67_0x838)
            _0x67_0x838["addEventListener"]("change", function () { var _0xa15 = _0x87g[_0xdc93b["selectedChestTypeId"]]; if (!_0xa15 || !_0xa15["customUI"])
                return; _0xa15["customUI"]["size"] = _0xa15["customUI"]["size"] || _0xa41d(null); _0xa15["customUI"]["size"]["height"] = Math["max"](826772 ^ 826864, Number(this["value"]) || 479683 ^ 479287); _0x1f051d(); });
        var _0x64fbac = _0xa7e["querySelector"]("]evas-iu-motsuc-atad[".split("").reverse().join(""));
        if (_0x64fbac)
            _0x64fbac["addEventListener"]("click", function () { _0xdc93b["customUiEditor"] = null; _0xdc93b["statusText"] = "Custom UI layout saved."; _0x1f051d(); });
        var _0xc2f = _0xa7e["querySelector"]("[data-custom-ui-cancel]");
        if (_0xc2f)
            _0xc2f["addEventListener"]("kcilc".split("").reverse().join(""), function (_0x65a6c) { var _0x4a3d9d = _0x87g[_0xdc93b["selectedChestTypeId"]]; _0x65a6c = 726016 ^ 726018; if (_0x4a3d9d && _0xdc93b["customUiEditor"]) {
                _0x4a3d9d["customUI"]["slots"] = _0x8dd(_0xdc93b["customUiEditor"]["originalSlots"] || _0x4a3d9d["customUI"]["slots"]);
                _0x4a3d9d["customUI"]["gridArea"] = _0x8dd(_0xdc93b["customUiEditor"]["originalGridArea"] || _0x4a3d9d["customUI"]["gridArea"]);
                if (_0xdc93b["customUiEditor"]["originalCloseBtn"])
                    _0x4a3d9d["customUI"]["closeBtn"] = _0x8dd(_0xdc93b["customUiEditor"]["originalCloseBtn"]);
            } _0xdc93b["customUiEditor"] = null; _0xdc93b["statusText"] = "Custom UI edit canceled."; _0x1f051d(); });
    } var _0x470g = _0xa7e["querySelector"]("[data-clear-rarity]"); if (_0x470g)
        _0x470g["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0x87g[_0xdc93b["selectedChestTypeId"]]["rarityChance"] = null; _0xdc93b["statusText"] = ".stluafed labolg ot ytirar teseR".split("").reverse().join(""); _0x1f051d(); }); var _0xefa = _0xa7e["querySelector"]("]epyt-tsehc-evas-atad[".split("").reverse().join("")); if (_0xefa)
        _0xefa["addEventListener"]("click", function (_0xdf54d) { var _0x5g_0x6ag = _0x87g[_0xdc93b["selectedChestTypeId"]] || _0x39_0xb48(_0xdc93b["selectedChestTypeId"], {}); _0x5g_0x6ag["name"] = _0xa7e["querySelector"]("[data-field=\"name\"]")["value"]["trim"]() || _0x5g_0x6ag["name"]; _0x5g_0x6ag["closed"] = _0xa7e["querySelector"]("[data-field=\"closed\"]")["value"]["trim"]() || _0x5g_0x6ag["closed"]; _0x5g_0x6ag["closedHL"] = _0xa7e["querySelector"]("[data-field=\"closedHL\"]")["value"]["trim"]() || _0x5g_0x6ag["closedHL"]; _0x5g_0x6ag["open"] = _0xa7e["querySelector"]("]\"nepo\"=dleif-atad[".split("").reverse().join(""))["value"]["trim"]() || _0x5g_0x6ag["open"]; _0x5g_0x6ag["openHL"] = _0xa7e["querySelector"]("]\"LHnepo\"=dleif-atad[".split("").reverse().join(""))["value"]["trim"]() || _0x5g_0x6ag["openHL"]; _0x5g_0x6ag["openSounds"] = _0x3f563e(_0xa7e["querySelector"]("]\"sdnuoSnepo\"=dleif-atad[".split("").reverse().join(""))["value"], _0xf873ee); _0x5g_0x6ag["pickupSounds"] = _0x3f563e(_0xa7e["querySelector"]("]\"sdnuoSpukcip\"=dleif-atad[".split("").reverse().join(""))["value"], _0xg997f); _0x5g_0x6ag["unlockSounds"] = _0x3f563e(_0xa7e["querySelector"]("]\"sdnuoSkcolnu\"=dleif-atad[".split("").reverse().join(""))["value"], _0x49_0x7bc); _0x5g_0x6ag["slotSize"] = {
            "cols": _0xfgg1e(_0xa7e["querySelector"]("[data-field=\"cols\"]")["value"], 189267 ^ 189270),
                    "rows": _0xfgg1e(_0xa7e["querySelector"]("[data-field=\"rows\"]")["value"], 559813 ^ 559814)
        }; _0x5g_0x6ag["lootTable"] = _0xa7e["querySelector"]("]\"elbaTtool\"=dleif-atad[".split("").reverse().join(""))["value"]["trim"]() || null; _0x5g_0x6ag["locked"] = _0xa7e["querySelector"]("]\"dekcol\"=dleif-atad[".split("").reverse().join(""))["value"] === "1"; var _0xfgad = (410635 ^ 410634) + (379503 ^ 379495); var _0x50d4f = _0xa7e["querySelector"]("[data-field=\"unlockItemId\"]")["value"]; _0xfgad = 558513 ^ 558512; _0x5g_0x6ag["unlockItemId"] = _0x50d4f === "" ? null : Number(_0x50d4f) || null; _0x5g_0x6ag["powerRequired"] = _0xa7e["querySelector"]("[data-field=\"powerRequired\"]")["value"] === "1"; _0x5g_0x6ag["powerFlickerEnabled"] = _0xa7e["querySelector"]("[data-field=\"powerFlickerEnabled\"]")["value"] === "1"; _0x5g_0x6ag["fuelWarningPercent"] = _0xfgg1e(_0xa7e["querySelector"]("]\"tnecrePgninraWleuf\"=dleif-atad[".split("").reverse().join(""))["value"], 590738 ^ 590744); _0x5g_0x6ag["customUI"] = _0x5g_0x6ag["customUI"] || {
            "enabled": false,
                    "image": "",
                    "slots": [],
                    "gridArea": _0xb54ace(null),
                    "size": _0xa41d(null),
                    "showSlotUi": !![],
                    "zoom": 1
        }; _0x5g_0x6ag["customUI"]["enabled"] = _0xa7e["querySelector"]("[data-field=\"customUIEnabled\"]")["value"] === "1"; _0x5g_0x6ag["customUI"]["image"] = _0xa7e["querySelector"]("]\"egamIIUmotsuc\"=dleif-atad[".split("").reverse().join(""))["value"]["trim"](); _0x5g_0x6ag["customUI"]["gridArea"] = _0x5g_0x6ag["customUI"]["gridArea"] || _0xb54ace(null); _0x5g_0x6ag["customUI"]["size"] = _0x5g_0x6ag["customUI"]["size"] || _0xa41d(null); _0x5g_0x6ag["customUI"]["showSlotUi"] = _0x5g_0x6ag["customUI"]["showSlotUi"] !== false; _0x5g_0x6ag["customUI"]["zoom"] = _0x392cbd(_0x5g_0x6ag["customUI"]["zoom"]); var _0xf593d = _0xa7e["querySelector"]("]elacs-tols-iu-motsuc-atad[".split("").reverse().join("")); _0xdf54d = (993799 ^ 993792) + (688291 ^ 688293); _0x5g_0x6ag["customUI"]["slotScale"] = _0xf593d ? Math["max"](0.1, Math["min"](967700 ^ 967696, Number(_0xf593d["value"]) || 184307 ^ 184306)) : _0x5g_0x6ag["customUI"]["slotScale"] || 998969 ^ 998968; var _0xae2 = _0xa7e["querySelector"]("[data-custom-ui-icon-scale]"); _0x5g_0x6ag["customUI"]["iconScale"] = _0xae2 ? Math["max"](0.1, Math["min"](406375 ^ 406371, Number(_0xae2["value"]) || 963650 ^ 963651)) : _0x5g_0x6ag["customUI"]["iconScale"] || 689882 ^ 689883; _0x5g_0x6ag["customUI"]["slots"] = _0xa24dd(_0x5g_0x6ag["customUI"]["slots"], _0x5g_0x6ag["slotSize"]); _0x5g_0x6ag["staticSlots"] = _0xeb1ee(_0x5g_0x6ag["staticSlots"], _0x5g_0x6ag["slotSize"]); var _0xeda3e = _0xa7e["querySelector"]("]\"hgih\"=ytirar-atad[".split("").reverse().join("")); if (_0xeda3e) {
            _0x5g_0x6ag["rarityChance"] = {
                "high": Number(_0xa7e["querySelector"]("[data-rarity=\"high\"]")["value"]) || _0xf4cgg["high"],
                        "medium": Number(_0xa7e["querySelector"]("[data-rarity=\"medium\"]")["value"]) || _0xf4cgg["medium"],
                        "low": Number(_0xa7e["querySelector"]("[data-rarity=\"low\"]")["value"]) || _0xf4cgg["low"],
                        "superLow": Number(_0xa7e["querySelector"]("]\"woLrepus\"=ytirar-atad[".split("").reverse().join(""))["value"]) || _0xf4cgg["superLow"],
                        "rare": Number(_0xa7e["querySelector"]("]\"erar\"=ytirar-atad[".split("").reverse().join(""))["value"]) || _0xf4cgg["rare"]
            };
        } var _0xbd6f7g = _0xa7e["querySelector"]("[data-col=\"enabled\"]"); if (_0xbd6f7g) {
            _0x5g_0x6ag["collisionObject"] = _0xbd2({
                "enabled": _0xbd6f7g["value"] === "1",
                        "type": _0xa7e["querySelector"]("]\"epyt\"=loc-atad[".split("").reverse().join(""))["value"]["trim"]() || "843t".split("").reverse().join(""),
                        "offsetX": Number(_0xa7e["querySelector"]("[data-col=\"offsetX\"]")["value"]) || 941189 ^ 941189,
                        "offsetY": Number(_0xa7e["querySelector"]("[data-col=\"offsetY\"]")["value"]) || 624687 ^ 624687,
                        "width": Number(_0xa7e["querySelector"]("[data-col=\"width\"]")["value"]) || 421511 ^ 421535,
                        "height": Number(_0xa7e["querySelector"]("[data-col=\"height\"]")["value"]) || 753187 ^ 753211
            });
        } var _0xf184g = (116784 ^ 116793) + (523763 ^ 523764); var _0x4bd07a = _0xa7e["querySelector"]("]\"delbane\"=dleif-cra-tc-atad[".split("").reverse().join("")); _0xf184g = (899992 ^ 899994) + (842149 ^ 842157); if (_0x4bd07a) {
            var _0x4a6bd = (460306 ^ 460310) + (916158 ^ 916151);
            var _0xg83a = Math["max"](190034 ^ 190035, Math["min"](167571 ^ 167931, Number(_0xa7e["querySelector"]("[data-ct-arc-field=\"spanDeg\"]")["value"]) || 865001 ^ 865015));
            _0x4a6bd = "obqhgq".split("").reverse().join("");
            var _0xb10 = Number(_0xa7e["querySelector"]("[data-ct-arc-field=\"centerAngleDeg\"]")["value"]) || 217273 ^ 217315;
            var _0x7feef = _0xa7e["querySelector"]("]\"tsid\"=dleif-cra-tc-atad[".split("").reverse().join(""));
            var _0x4f7e = _0x7feef && _0x7feef["value"]["trim"]() !== "" ? Number(_0x7feef["value"]) : null;
            _0x5g_0x6ag["interactArc"] = {
                "enabled": _0x4bd07a["value"] === "1",
                        "spanDeg": _0xg83a,
                        "centerAngleDeg": _0xb10,
                        "dist": _0x4f7e
            };
        } _0x5g_0x6ag["panelSize"] = null; _0x5g_0x6ag["defaultUI"] = _0x5g_0x6ag["defaultUI"] || {
            "panelW": null,
                    "panelH": null,
                    "cellSize": null,
                    "iconScale": 1
        }; if (_0xdc93b["defaultUiEditor"] && _0xdc93b["defaultUiEditor"]["active"]) {
            var _0xc7c = (439151 ^ 439146) + (622190 ^ 622188);
            var _0x9b847b = _0xa7e["querySelector"]("]w-lenap-iu-tluafed-atad[".split("").reverse().join(""));
            _0xc7c = 438153 ^ 438153;
            var _0x4d20af = _0xa7e["querySelector"]("]h-lenap-iu-tluafed-atad[".split("").reverse().join(""));
            var _0xff464b = (928413 ^ 928408) + (817854 ^ 817854);
            var _0x652bcc = _0xa7e["querySelector"]("]ezis-llec-iu-tluafed-atad[".split("").reverse().join(""));
            _0xff464b = (837312 ^ 837317) + (349589 ^ 349591);
            let _0x9d5e;
            var _0x29a = _0xa7e["querySelector"]("[data-default-ui-icon-scale]");
            _0x9d5e = (295335 ^ 295342) + (983278 ^ 983272);
            if (_0x9b847b)
                _0x5g_0x6ag["defaultUI"]["panelW"] = Math["max"](161429 ^ 161477, Number(_0x9b847b["value"]));
            if (_0x4d20af)
                _0x5g_0x6ag["defaultUI"]["panelH"] = Math["max"](292956 ^ 292876, Number(_0x4d20af["value"]));
            if (_0x652bcc)
                _0x5g_0x6ag["defaultUI"]["cellSize"] = Math["max"](610294 ^ 610302, Math["min"](118277 ^ 118477, Number(_0x652bcc["value"])));
            if (_0x29a)
                _0x5g_0x6ag["defaultUI"]["iconScale"] = Math["max"](0.1, Math["min"](113435 ^ 113439, Number(_0x29a["value"]) || 654270 ^ 654271));
        } _0x87g[_0xdc93b["selectedChestTypeId"]] = _0x5g_0x6ag; _0x45_0x6f4(); _0xdc93b["statusText"] = "Applied chest type " + _0x5g_0x6ag["name"] + "."; _0x1f051d(); }); var _0xbfaf = _0xa7e["querySelector"]("[data-add-to-structure]"); if (_0xbfaf)
        _0xbfaf["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xdc93b["tab"] = "structures"; var _0x75eac = (844895 ^ 844887) + (824025 ^ 824030); var _0x170g = null; _0x75eac = (734436 ^ 734435) + (130826 ^ 130829); for (var _0xb21 in _0x7eed) {
            var _0x907ab = _0x7eed[_0xb21]["placements"] || [];
            for (var _0x9f9c = 596742 ^ 596742; _0x9f9c < _0x907ab["length"]; _0x9f9c++) {
                if (_0x907ab[_0x9f9c]["chestTypeId"] === _0xdc93b["selectedChestTypeId"]) {
                    _0x170g = _0xb21;
                    break;
                }
            }
            if (_0x170g)
                break;
        } if (_0x170g)
            _0xdc93b["selectedStructureType"] = _0x170g; _0xdc93b["structureSearch"] = ""; _0xdc93b["statusText"] = " ecalp ot erutcurts a tceleS".split("").reverse().join("") + _0xdc93b["selectedChestTypeId"] + ".pord-gard ro \"epyT tsehC detceleS ddA\" esU .otni ".split("").reverse().join(""); _0x1f051d(); }); var _0xbb96d = (956229 ^ 956229) + (209782 ^ 209780); var _0x3864cd = _0xa7e["querySelector"]("]epyt-tsehc-evomer-atad[".split("").reverse().join("")); _0xbb96d = (845067 ^ 845067) + (635384 ^ 635377); if (_0x3864cd)
        _0x3864cd["addEventListener"]("kcilc".split("").reverse().join(""), function () { if (Object["keys"](_0x87g)["length"] <= (479974 ^ 479975))
            return; delete _0x87g[_0xdc93b["selectedChestTypeId"]]; _0xdc93b["selectedChestTypeId"] = Object["keys"](_0x87g)[138401 ^ 138401]; _0xdc93b["statusText"] = "Removed chest type."; _0x1f051d(); }); var _0xbccc5c = _0xba27fa["querySelector"]("]rekcip-tool-nepo-atad[".split("").reverse().join("")); if (_0xbccc5c)
        _0xbccc5c["addEventListener"]("click", function () { _0xf3_0x194({
            "kind": "loot",
                    "chestTypeId": _0xdc93b["selectedChestTypeId"]
        }); }); var _0x83fbb = (806146 ^ 806149) + (381691 ^ 381692); var _0x7cc6ba = _0xba27fa["querySelectorAll"]("[data-loot-rarity]"); _0x83fbb = (263402 ^ 263400) + (613259 ^ 613261); for (var r = 756686 ^ 756686; r < _0x7cc6ba["length"]; r++) {
        _0x7cc6ba[r]["addEventListener"]("input", function (_0x4df) { var _0xbee = _0x6fa(_0xdc93b["selectedChestTypeId"]); _0x4df = "hckqio"; var _0xcdbebc = Number(this["getAttribute"]("ytirar-tool-atad".split("").reverse().join(""))) || 365186 ^ 365186; if (_0x56fd[_0xbee][_0xcdbebc])
            _0x56fd[_0xbee][_0xcdbebc]["rarity"] = this["value"]["trim"]() || "muidem".split("").reverse().join(""); });
    } var _0xe_0x803 = (563631 ^ 563625) + (107395 ^ 107394); var _0xc39d3d = _0xba27fa["querySelectorAll"]("[data-loot-steps]"); _0xe_0x803 = (621599 ^ 621594) + (171444 ^ 171447); for (var s = 489495 ^ 489495; s < _0xc39d3d["length"]; s++) {
        _0xc39d3d[s]["addEventListener"]("tupni".split("").reverse().join(""), function () { var _0xa891d = _0x6fa(_0xdc93b["selectedChestTypeId"]); var _0x1e1dff = Number(this["getAttribute"]("data-loot-steps")) || 954049 ^ 954049; if (_0x56fd[_0xa891d][_0x1e1dff])
            _0x56fd[_0xa891d][_0x1e1dff]["stackSteps"] = _0xe546b(this["value"]); });
    } var _0x754e = _0xba27fa["querySelectorAll"]("]tool-evomer-atad[".split("").reverse().join("")); for (var x = 711895 ^ 711895; x < _0x754e["length"]; x++) {
        _0x754e[x]["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0x6bb5f = _0x6fa(_0xdc93b["selectedChestTypeId"]); _0x56fd[_0x6bb5f]["splice"](Number(this["getAttribute"]("tool-evomer-atad".split("").reverse().join(""))) || 923871 ^ 923871, 559871 ^ 559870); _0xdc93b["statusText"] = ".yrtne tool devomeR".split("").reverse().join(""); _0x1f051d(); });
    } if (_0xbccc5c)
        _0xbccc5c["addEventListener"]("click", function () { _0xf3_0x194({
            "kind": "loot",
                    "chestTypeId": _0xdc93b["selectedChestTypeId"]
        }); }); }
    function _0x97cg(_0xe82bcb) { var _0x69bd = _0xdc93b["ui"]["left"]; var _0x8g_0x1eb = (983831 ^ 983826) + (270202 ^ 270202); var _0xd658be = _0xdc93b["ui"]["center"]; _0x8g_0x1eb = 691010 ^ 691012; var _0xf977f = _0xdc93b["ui"]["right"]; var _0x598d1b = _0xdc93b["structureData"]["structures"] || []; _0xe82bcb = "anmfjp".split("").reverse().join(""); var _0xcbbb = (185914 ^ 185916) + (351620 ^ 351623); var _0xd5ad = String(_0xdc93b["structureSearch"] || "")["toLowerCase"](); _0xcbbb = "fcmmbi"; var _0x816c = "\"=eulav hcraes-erutcurts-atad tupni<serutcurtS hcraeS>lebal<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + _0x0d5eg(_0xdc93b["structureSearch"]) + "\" placeholder=\"type, label, image, category\"></label>" + ">\"parw:parw-xelf;xp4:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + ">nottub/<llA>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"lla\"=retlif-tac-atad nottub<".split("").reverse().join("") + "<button data-cat-filter=\"building-interior\" style=\"padding:3px 6px;font-size:10px\">Interior</button>" + ">nottub/<roiretxE>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"roiretxe-gnidliub\"=retlif-tac-atad nottub<".split("").reverse().join("") + ">nottub/<elciheV>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"elcihev\"=retlif-tac-atad nottub<".split("").reverse().join("") + ">nottub/<eerT>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"eert\"=retlif-tac-atad nottub<".split("").reverse().join("") + "<button data-cat-filter=\"bush\" style=\"padding:3px 6px;font-size:10px\">Bush</button>" + "<button data-cat-filter=\"world-prop\" style=\"padding:3px 6px;font-size:10px\">World Prop</button>" + "<button data-cat-filter=\"landmark\" style=\"padding:3px 6px;font-size:10px\">Landmark</button>" + ">nottub/<erutcurtS>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"erutcurts\"=retlif-tac-atad nottub<".split("").reverse().join("") + ">nottub/<hsarC ileH>\"xp01:ezis-tnof;xp6 xp3:gniddap\"=elyts \"hsarc-ileh\"=retlif-tac-atad nottub<".split("").reverse().join("") + "<button data-cat-filter=\"configured\" style=\"padding:3px 6px;font-size:10px;color:#c3ff72\">Configured</button>" + "</div>"; for (var i = 248286 ^ 248286; i < _0x598d1b["length"]; i++) {
        let _0xa12bc;
        var _0x13a = _0x598d1b[i];
        _0xa12bc = 379819 ^ 379819;
        var _0xdf87b = (_0x13a["typeName"] + " " + _0x13a["image"] + " " + (_0x13a["category"] || "") + " " + (_0x13a["labels"] && _0x13a["labels"]["join"](" ") || ""))["toLowerCase"]();
        if (_0xd5ad === "derugifnoc:".split("").reverse().join("")) {
            if (!_0x7eed[_0x13a["typeName"]])
                continue;
        }
        else if (_0xd5ad && _0xdf87b["indexOf"](_0xd5ad) === -(931139 ^ 931138))
            continue;
        var _0xc93eb = !!_0x7eed[_0x13a["typeName"]];
        var _0xc93f = _0x13a["category"] === "building-interior";
        let _0x2e2dd;
        var _0xa9e2a = "<span style=\"font-size:9px;padding:2px 4px;border-radius:4px;background:" + (_0xc93f ? "rgba(135,217,199,0.3)" : ")80.0,552,552,552(abgr".split("").reverse().join("")) + "\">" + _0x0d5eg(_0x13a["category"] || "nwonknu".split("").reverse().join("")) + ">naps/<".split("").reverse().join("");
        _0x2e2dd = (554916 ^ 554915) + (537863 ^ 537858);
        var _0xecadd = _0xc93eb ? ">naps/<derugifnoc>\")3.0,411,552,591(abgr:dnuorgkcab;xp4:suidar-redrob;xp4 xp2:gniddap;xp9:ezis-tnof\"=elyts naps< ".split("").reverse().join("") : "";
        _0x816c += "<button data-structure-type=\"" + _0x13a["typeName"] + ":dnuorgkcab;)1.0,552,552,552(abgr dilos xp1:redrob;xp8:gniddap;tfel:ngila-txet\"=elyts \"".split("").reverse().join("") + (_0xdc93b["selectedStructureType"] === _0x13a["typeName"] ? ")21.0,552,552,552(abgr".split("").reverse().join("") : "rgba(255,255,255,0.04)") + ">gnorts<>\"".split("").reverse().join("") + _0x13a["typeName"] + "</strong> " + _0xa9e2a + _0xecadd + "<div>" + _0x0d5eg(_0x13a["labels"] && _0x13a["labels"][264836 ^ 264836] || _0x13a["image"]) + ">nottub/<>vid/<".split("").reverse().join("");
    } _0x816c += "</div>"; _0x69bd["innerHTML"] = _0x816c; _0xd658be["innerHTML"] = ">\"retnec:smeti-ngila;parw:parw-xelf;xp8:pag;xelf:yalpsid\"=elyts vid<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + _0xg8f7b() + " edom-tide-atad \"xobkcehc\"=epyt tupni<>\"retniop:rosruc;retnec:smeti-ngila;xp6:pag;xelf:yalpsid\"=elyts lebal<".split("").reverse().join("") + (_0xdc93b["placementEditMode"] ? "dekcehc".split("").reverse().join("") : "") + " elggot-thgilhgih-atad \"xobkcehc\"=epyt tupni<>\"retniop:rosruc;retnec:smeti-ngila;xp6:pag;xelf:yalpsid\"=elyts lebal<>lebal/<edoM tidE >".split("").reverse().join("") + (_0xdc93b["highlightStructures"] ? "checked" : "") + "> Highlight In-Game</label></div><canvas data-structure-canvas width=\"900\" height=\"620\" style=\"width:100%;max-width:100%;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02);cursor:" + (_0xdc93b["placementEditMode"] ? "barg".split("").reverse().join("") : "tluafed".split("").reverse().join("")) + "\"></canvas><div style=\"display:flex;gap:8px;flex-wrap:wrap\"><button data-realtime-place>Place Chest at Player Position</button><button data-apply-runtime-now>Apply Config to Runtime Now</button></div><div style=\"color:#bcae94\">Drag chest type chips to place. In Edit Mode, drag markers to move, drag corner handles to resize collision boxes. Green = selected, yellow = others, red boxes = collision.</div></div>"; var _0xc0186d = (378026 ^ 378028) + (969849 ^ 969849); var _0x59bc8d = _0x5e_0x03a(); _0xc0186d = (826255 ^ 826248) + (306308 ^ 306305); if (!_0x59bc8d) {
        _0xf977f["textContent"] = "No structure selected.";
        return;
    } var _0xcff = _0x7eed[_0x59bc8d["typeName"]] || { "placements": [] }; var _0x064acg = (696704 ^ 696711) + (690100 ^ 690101); var _0xd72ead = _0xcff["placements"] || []; _0x064acg = (637634 ^ 637642) + (172001 ^ 172007); var _0x70_0x0bd = ">\"xp8:pag;dirg:yalpsid\"=elyts vid<>vid/<>gnorts/<stnemecalP>gnorts<>vid<".split("").reverse().join(""); for (var p = 653712 ^ 653712; p < _0xd72ead["length"]; p++) {
        var _0x3dg2b = _0x87g[_0xd72ead[p]["chestTypeId"]] ? _0x87g[_0xd72ead[p]["chestTypeId"]]["closed"] : "";
        _0x70_0x0bd += "<button class=\"mdz-item-card\" data-placement-index=\"" + p + "\" style=\"text-align:left;background:" + (_0xdc93b["selectedPlacementIndex"] === p ? "rgba(255,255,255,0.12)" : ")40.0,552,552,552(abgr".split("").reverse().join("")) + "\"><img class=\"mdz-thumb\" src=\"" + _0x0d5eg(_0x3dg2b) + "\" alt=\"\"><div><div style=\"font-weight:700\">" + _0x0d5eg(_0xd72ead[p]["chestTypeId"]) + "</div><div style=\"color:#bcae94\">Offset " + _0xd72ead[p]["offsetX"] + ", " + _0xd72ead[p]["offsetY"] + "</div></div><span>Edit</span></button>";
    } _0x70_0x0bd += ">nottub/<epyT tsehC detceleS ddA>tnemecalp-dda-atad nottub<".split("").reverse().join(""); if (_0xd72ead[_0xdc93b["selectedPlacementIndex"]]) {
        let _0x422e;
        var _0x2126c = _0xd72ead[_0xdc93b["selectedPlacementIndex"]];
        _0x422e = "lmbjgl";
        var _0x9dc = _0x2126c["lootTable"] && _0x56fd[_0x2126c["lootTable"]] ? _0x56fd[_0x2126c["lootTable"]] : [];
        var _0xacd2a = (137886 ^ 137882) + (739491 ^ 739492);
        var _0x9515bd = _0xbd2(_0x2126c["collisionObject"]);
        _0xacd2a = "feflmj";
        _0x70_0x0bd += "<div style=\"display:grid;gap:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,0.08)\">" + "# tnemecalP>gnorts<".split("").reverse().join("") + (_0xdc93b["selectedPlacementIndex"] + (572865 ^ 572864)) + " Config</strong>" + "\"=eulav \"rebmun\"=epyt \"Xtesffo\"=dleif-tnemecalp-atad tupni<X tesffO>lebal<".split("").reverse().join("") + _0x2126c["offsetX"] + "\"></label>" + "<label>Offset Y<input data-placement-field=\"offsetY\" type=\"number\" value=\"" + _0x2126c["offsetY"] + "\"></label>" + "<label>Chest Type<select data-placement-field=\"chestTypeId\">" + _0x2fa95b(_0x2126c["chestTypeId"]) + ">lebal/<>tceles/<".split("").reverse().join("") + "<label>Loot Table Override<input data-placement-field=\"lootTable\" value=\"" + _0x0d5eg(_0x2126c["lootTable"] || "") + ">lebal/<>\"tluafed epyt rof ytpme evaeL\"=redlohecalp \"".split("").reverse().join("") + "(>\"49eacb#:roloc\"=elyts naps< ecnahC nwapS tsehC>lebal<".split("").reverse().join("") + Math["round"]((_0x2126c["randomLootChance"] != null ? _0x2126c["randomLootChance"] : 0.5) * (194956 ^ 195048)) + "\"=eulav \"50.0\"=pets \"1\"=xam \"0\"=nim \"egnar\"=epyt \"ecnahCtooLmodnar\"=dleif-tnemecalp-atad tupni<>naps/<)raeppa ot ecnahc %".split("").reverse().join("") + (_0x2126c["randomLootChance"] != null ? _0x2126c["randomLootChance"] : 0.5) + "\" style=\"width:100%;padding:0\"></label>" + "<label>Locked<select data-placement-field=\"locked\"><option value=\"\">inherit</option><option value=\"1\"" + (_0x2126c["locked"] === !![] ? " selected" : "") + "\"0\"=eulav noitpo<>noitpo/<eurt>".split("").reverse().join("") + (_0x2126c["locked"] === false ? "detceles ".split("").reverse().join("") : "") + ">lebal/<>tceles/<>noitpo/<eslaf>".split("").reverse().join("") + "<label>Unlock Item ID<input data-placement-field=\"unlockItemId\" type=\"number\" value=\"" + (_0x2126c["unlockItemId"] == null ? "" : _0x2126c["unlockItemId"]) + "\"></label>" + "<button data-pick-placement-unlock>Pick Unlock Item</button>" + "<div style=\"display:grid;gap:6px\"><strong>Placement Collision</strong>" + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:6px\">" + "\"1\"=eulav noitpo<>noitpo/<tirehni>\"\"=eulav noitpo<>\"delbane\"=loc-tnemecalp-atad tceles<delbanE>lebal<".split("").reverse().join("") + (_0x2126c["collisionObject"] && _0x2126c["collisionObject"]["enabled"] === !![] ? " selected" : "") + "\"0\"=eulav noitpo<>noitpo/<eurt>".split("").reverse().join("") + (_0x2126c["collisionObject"] && _0x2126c["collisionObject"]["enabled"] === false ? "detceles ".split("").reverse().join("") : "") + ">false</option></select></label>" + "\"=eulav \"1\"=nim \"rebmun\"=epyt \"htdiw\"=loc-tnemecalp-atad tupni<htdiW>lebal<".split("").reverse().join("") + _0x9515bd["width"] + "\"></label>" + ">\"xp6:pag;rf1 rf1:snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<>vid/<".split("").reverse().join("") + "<label>Height<input data-placement-col=\"height\" type=\"number\" min=\"1\" value=\"" + _0x9515bd["height"] + "\"></label>" + "\"=eulav \"rebmun\"=epyt \"Xtesffo\"=loc-tnemecalp-atad tupni<X tesffO>lebal<".split("").reverse().join("") + _0x9515bd["offsetX"] + "\"></label>" + ">\"xp6:pag;rf1 rf1:snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<>vid/<".split("").reverse().join("") + "<label>Offset Y<input data-placement-col=\"offsetY\" type=\"number\" value=\"" + _0x9515bd["offsetY"] + "\"></label>" + "<div></div></div></div>" + ">gnorts/<crA noitcaretnI>gnorts<>\"xp6:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + "<div style=\"display:grid;grid-template-columns:1fr 1fr;gap:6px\">" + "\"0\"=eulav noitpo<>\"delbane\"=dleif-cra-atad tceles<delbanE>lebal<".split("").reverse().join("") + (!(_0x2126c["interactArc"] && _0x2126c["interactArc"]["enabled"]) ? " selected" : "") + ">Off</option><option value=\"1\"" + (_0x2126c["interactArc"] && _0x2126c["interactArc"]["enabled"] ? " selected" : "") + ">lebal/<>tceles/<>noitpo/<nO>".split("").reverse().join("") + "<label>Span (°)<input data-arc-field=\"spanDeg\" type=\"number\" min=\"1\" max=\"360\" value=\"" + (_0x2126c["interactArc"] ? _0x2126c["interactArc"]["spanDeg"] : 287557 ^ 287579) + "\"></label>" + ">vid/<".split("").reverse().join("") + ">\"xp6:pag;rf1 rf1:snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + "<label>Center Angle (°) <span style=\"color:#bcae94\">0=Right 90=Down 180=Left 270=Up</span><input data-arc-field=\"centerAngleDeg\" type=\"range\" min=\"0\" max=\"359\" step=\"1\" value=\"" + (_0x2126c["interactArc"] ? _0x2126c["interactArc"]["centerAngleDeg"] : 994911 ^ 994821) + ">lebal/<>\"0:gniddap;%001:htdiw\"=elyts \"".split("").reverse().join("") + "<label>Dist (px)<input data-arc-field=\"dist\" type=\"number\" min=\"1\" value=\"" + (_0x2126c["interactArc"] && _0x2126c["interactArc"]["dist"] != null ? _0x2126c["interactArc"]["dist"] : "") + "\" placeholder=\"default\"></label>" + "</div>" + ">savnac/<>\")3.0,0,0,0(abgr:dnuorgkcab;%05:suidar-redrob;retniop:rosruc;otua 0:nigram;kcolb:yalpsid\"=elyts \"021\"=thgieh \"021\"=htdiw weiverp-cra-atad savnac<".split("").reverse().join("") + "</div>";
        if (_0x2126c["lootTable"] && _0x56fd[_0x2126c["lootTable"]]) {
            _0x70_0x0bd += "<div style=\"display:grid;gap:6px\"><strong>Placement Loot Entries</strong>";
            for (var _0x55c04f = 839618 ^ 839618; _0x55c04f < _0x9dc["length"]; _0x55c04f++) {
                _0x70_0x0bd += "\"=di-meti-atad \"23\"=thgieh \"23\"=htdiw \"noci-meti-zdm\"=ssalc savnac<>\"drac-meti-zdm\"=ssalc vid<".split("").reverse().join("") + _0x9dc[_0x55c04f]["id"] + "\"></canvas><div><div style=\"font-weight:700\">" + _0x0d5eg(_0xf51d(_0x9dc[_0x55c04f]["id"])) + " <span style=\"color:#bcae94\">ID " + _0x9dc[_0x55c04f]["id"] + "\"=ytirar-tool-lp-atad tupni<ytiraR>lebal<>\"xp4:pot-nigram;xp6:pag;rf1 rf1:snmuloc-etalpmet-dirg;dirg:yalpsid\"=elyts vid<>vid/<>naps/<".split("").reverse().join("") + _0x55c04f + "\"=eulav \"".split("").reverse().join("") + _0x0d5eg(_0x9dc[_0x55c04f]["rarity"] || "muidem".split("").reverse().join("")) + "\"></label><label>Steps<input data-pl-loot-steps=\"" + _0x55c04f + "\"=eulav \"".split("").reverse().join("") + _0x0d5eg((_0x9dc[_0x55c04f]["stackSteps"] || [])["join"](",")) + "\"></label></div></div><button data-pl-remove-loot=\"" + _0x55c04f + "\" style=\"font-size:10px\">X</button></div>";
            }
            _0x70_0x0bd += "<button data-pl-add-loot>Add Loot to Placement</button></div>";
        }
        else {
            _0x70_0x0bd += ">vid/<.gnitide tool tnemecalp-rep elbane ot evoba eman elbat tool a teS>\"49eacb#:roloc\"=elyts vid<".split("").reverse().join("");
        }
        _0x70_0x0bd += ">nottub/<tnemecalP evomeR>\"74d64e#:roloc\"=elyts tnemecalp-evomer-atad nottub<>nottub/<tnemecalP evaS>tnemecalp-evas-atad nottub<".split("").reverse().join("") + "</div>";
    } _0x70_0x0bd += ">vid/<".split("").reverse().join(""); _0xf977f["innerHTML"] = _0x70_0x0bd; _0x6348a(); _0x8412a(); }
    function _0xg8f7b() { var _0x642dda = (699797 ^ 699796) + (440086 ^ 440080); var _0x157 = ""; _0x642dda = "lcoade"; for (var _0x6fa2fc in _0x87g) {
        _0x157 += "<button draggable=\"true\" data-drag-chest-type=\"" + _0x6fa2fc + "\"=crs \"bmuht-zdm\"=ssalc gmi<>\"xp01 xp6:gniddap\"=elyts \"drac-meti-zdm\"=ssalc \"".split("").reverse().join("") + _0x0d5eg(_0x87g[_0x6fa2fc]["closed"]) + ">\"007:thgiew-tnof\"=elyts vid<>\"tfel:ngila-txet\"=elyts vid<>\"\"=tla \"".split("").reverse().join("") + _0x0d5eg(_0x87g[_0x6fa2fc]["name"]) + "</div><div style=\"color:#bcae94\">" + _0x0d5eg(_0x6fa2fc) + "</div></div><span>Drag</span></button>";
    } return _0x157; }
    function _0x2fa95b(selectedChestTypeId) { var _0xec0f6e = ""; for (var _0x5g98c in _0x87g) {
        _0xec0f6e += "<option value=\"" + _0x0d5eg(_0x5g98c) + "\"" + (_0x5g98c === selectedChestTypeId ? " selected" : "") + ">" + _0x0d5eg(_0x87g[_0x5g98c]["name"]) + "</option>";
    } return _0xec0f6e; }
    function _0x5e_0x03a() { var _0x1g6f = (759171 ^ 759172) + (985628 ^ 985624); var _0xc4708d = _0xdc93b["structureData"] ? _0xdc93b["structureData"]["structures"] : []; _0x1g6f = (568034 ^ 568038) + (826595 ^ 826599); for (var i = 862658 ^ 862658; i < _0xc4708d["length"]; i++) {
        if (_0xc4708d[i]["typeName"] === _0xdc93b["selectedStructureType"])
            return _0xc4708d[i];
    } return null; }
    function _0x6348a(_0xed_0x6ag, _0xd7ead, _0xabc4ab) { var _0xe79c = _0xdc93b["ui"]["left"]; _0xed_0x6ag = (176436 ^ 176433) + (586467 ^ 586465); var _0xbbcd3g = (864397 ^ 864393) + (247448 ^ 247451); var center = _0xdc93b["ui"]["center"]; _0xbbcd3g = 821395 ^ 821399; var _0x78593b = _0xdc93b["ui"]["right"]; var _0xea384d = _0xe79c["querySelector"]("[data-structure-search]"); _0xd7ead = (353526 ^ 353525) + (385170 ^ 385168); if (_0xea384d)
        _0xea384d["addEventListener"]("input", function (_0xed54gd) { var _0xc3f = this["selectionStart"]; _0xed54gd = (766509 ^ 766506) + (754610 ^ 754618); _0xdc93b["structureSearch"] = this["value"]; _0x1f051d(); var _0xf22aa = _0xdc93b["ui"]["left"]["querySelector"]("]hcraes-erutcurts-atad[".split("").reverse().join("")); if (_0xf22aa) {
            _0xf22aa["focus"]();
            _0xf22aa["setSelectionRange"](_0xc3f, _0xc3f);
        } }); var _0x1fdd = (585008 ^ 585010) + (811645 ^ 811636); var _0xe9a9cf = _0xe79c["querySelectorAll"]("[data-cat-filter]"); _0x1fdd = (709822 ^ 709819) + (853495 ^ 853489); for (var _0x90071b = 590032 ^ 590032; _0x90071b < _0xe9a9cf["length"]; _0x90071b++) {
        _0xe9a9cf[_0x90071b]["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0x987eg = this["getAttribute"]("retlif-tac-atad".split("").reverse().join("")); if (_0x987eg === "all") {
            _0xdc93b["structureSearch"] = "";
        }
        else if (_0x987eg === "configured") {
            _0xdc93b["structureSearch"] = "";
            _0xdc93b["structureSearch"] = "derugifnoc:".split("").reverse().join("");
        }
        else {
            _0xdc93b["structureSearch"] = _0x987eg;
        } _0x1f051d(); });
    } var _0x20d18e = _0xe79c["querySelectorAll"]("[data-structure-type]"); for (var i = 421032 ^ 421032; i < _0x20d18e["length"]; i++) {
        _0x20d18e[i]["addEventListener"]("click", function () { _0xdc93b["selectedStructureType"] = this["getAttribute"]("data-structure-type"); _0xdc93b["selectedPlacementIndex"] = -(705774 ^ 705775); _0x1f051d(); });
    } var _0xccec0c = (909849 ^ 909852) + (514749 ^ 514740); var _0x26aba = center["querySelectorAll"]("]epyt-tsehc-gard-atad[".split("").reverse().join("")); _0xccec0c = (752370 ^ 752373) + (395948 ^ 395948); for (var j = 139680 ^ 139680; j < _0x26aba["length"]; j++) {
        _0x26aba[j]["addEventListener"]("dragstart", function (event) { event["dataTransfer"]["setData"]("text/plain", this["getAttribute"]("data-drag-chest-type")); });
    } var _0xc19d = center["querySelector"]("[data-structure-canvas]"); _0xc19d["addEventListener"]("dragover", function (event) { event["preventDefault"](); }); _0xc19d["addEventListener"]("drop", function (event) { event["preventDefault"](); var _0xcb4fb = event["dataTransfer"]["getData"]("text/plain") || _0xdc93b["selectedChestTypeId"]; _0xa76dg(_0xcb4fb, event, _0xc19d); }); _0x5424d(_0xc19d); var _0xfa9cad = center["querySelector"]("[data-edit-mode]"); if (_0xfa9cad)
        _0xfa9cad["addEventListener"]("change", function () { _0xdc93b["placementEditMode"] = this["checked"]; _0xc19d["style"]["cursor"] = this["checked"] ? "barg".split("").reverse().join("") : "tluafed".split("").reverse().join(""); }); var _0xc56fad = center["querySelector"]("[data-highlight-toggle]"); if (_0xc56fad)
        _0xc56fad["addEventListener"]("egnahc".split("").reverse().join(""), function () { _0xdc93b["highlightStructures"] = this["checked"]; var _0x7d_0xgca = (445092 ^ 445089) + (470919 ^ 470914); var _0xf01e = _0x6ec34e(); _0x7d_0xgca = (622793 ^ 622785) + (905916 ^ 905913); if (_0xf01e)
            _0xf01e[K["redraw"]] = !![]; }); var _0x9569ef = center["querySelector"]("[data-realtime-place]"); if (_0x9569ef)
        _0x9569ef["addEventListener"]("click", function (_0x2g77c) { var _0xac174f = _0x6ec34e(); if (!_0xac174f) {
            _0xdc93b["statusText"] = ".elbaliava ton emitnuR".split("").reverse().join("");
            _0x1f051d();
            return;
        } var _0x223bfb = _0x5e9e6g("t181")[117928 ^ 117928]; if (!_0x223bfb) {
            _0xdc93b["statusText"] = "Player not found.";
            _0x1f051d();
            return;
        } var _0x5bb65a = _0xdc93b["selectedStructureType"]; _0x2g77c = 436603 ^ 436605; if (!_0x5bb65a) {
            _0xdc93b["statusText"] = ".detceles epyt erutcurts oN".split("").reverse().join("");
            _0x1f051d();
            return;
        } var _0xc96fc = _0x5e9e6g(_0x5bb65a); var _0xf5d1b = null, _0xde3 = 999999; for (var _0xa5c5bf = 529195 ^ 529195; _0xa5c5bf < _0xc96fc["length"]; _0xa5c5bf++) {
            var d = Math["hypot"](_0x223bfb["x"] - _0xc96fc[_0xa5c5bf]["x"], _0x223bfb["y"] - _0xc96fc[_0xa5c5bf]["y"]);
            if (d < _0xde3) {
                _0xde3 = d;
                _0xf5d1b = _0xc96fc[_0xa5c5bf];
            }
        } if (!_0xf5d1b) {
            _0xdc93b["statusText"] = " oN".split("").reverse().join("") + _0x5bb65a + " instances found in game.";
            _0x1f051d();
            return;
        } var _0x9afce = (632749 ^ 632744) + (126422 ^ 126431); var _0xdaa = Math["round"](_0x223bfb["x"] - _0xf5d1b["x"]); _0x9afce = 175156 ^ 175157; var _0xfc_0x97c = (126129 ^ 126132) + (339548 ^ 339541); var _0xb79b = Math["round"](_0x223bfb["y"] - _0xf5d1b["y"]); _0xfc_0x97c = (119033 ^ 119038) + (549214 ^ 549212); if (!_0x7eed[_0x5bb65a])
            _0x7eed[_0x5bb65a] = { "placements": [] }; _0x7eed[_0x5bb65a]["placements"]["push"](_0x85252f({
            "chestTypeId": _0xdc93b["selectedChestTypeId"],
                    "offsetX": _0xdaa,
                    "offsetY": _0xb79b
        }, _0xdc93b["selectedChestTypeId"])); _0xb8bf0a(_0x5425bb()); _0xdc93b["selectedPlacementIndex"] = _0x7eed[_0x5bb65a]["placements"]["length"] - (706690 ^ 706691); _0xdc93b["statusText"] = "Placed chest at player offset (" + _0xdaa + " ,".split("").reverse().join("") + _0xb79b + " no )".split("").reverse().join("") + _0x5bb65a + ". Config applied."; _0x1f051d(); }); var _0x494ffd = (986342 ^ 986342) + (476506 ^ 476506); var _0x47ba = center["querySelector"]("]won-emitnur-ylppa-atad[".split("").reverse().join("")); _0x494ffd = 543681 ^ 543680; if (_0x47ba)
        _0x47ba["addEventListener"]("click", function () { var _0x17857c = _0x5425bb(); _0xb8bf0a(_0x17857c); _0x79gea(_0x17857c); _0xdc93b["statusText"] = "Config applied to runtime and saved. Chests will update on next frame."; _0x1f051d(); }); var _0xdbbgf = _0x78593b["querySelectorAll"]("[data-placement-index]"); for (var p = 882237 ^ 882237; p < _0xdbbgf["length"]; p++) {
        _0xdbbgf[p]["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xdc93b["selectedPlacementIndex"] = Number(this["getAttribute"]("xedni-tnemecalp-atad".split("").reverse().join(""))); _0x1f051d(); });
    } var _0x2589a = (961005 ^ 960997) + (527774 ^ 527767); var _0x2e5ad = _0x78593b["querySelector"]("[data-add-placement]"); _0x2589a = (358957 ^ 358957) + (240043 ^ 240046); if (_0x2e5ad)
        _0x2e5ad["addEventListener"]("click", function (_0x34b85d) { var _0xfdgc = _0xdc93b["selectedStructureType"]; _0x34b85d = 344215 ^ 344209; if (!_0x7eed[_0xfdgc])
            _0x7eed[_0xfdgc] = { "placements": [] }; _0x7eed[_0xfdgc]["placements"]["push"](_0x85252f({
            "chestTypeId": _0xdc93b["selectedChestTypeId"],
                    "offsetX": 0,
                    "offsetY": 0
        }, _0xdc93b["selectedChestTypeId"])); _0xdc93b["selectedPlacementIndex"] = _0x7eed[_0xfdgc]["placements"]["length"] - (879930 ^ 879931); _0x1f051d(); }); var _0xef461c = (991490 ^ 991492) + (482861 ^ 482853); var _0xce3 = _0x78593b["querySelector"]("[data-save-placement]"); _0xef461c = (551113 ^ 551119) + (304462 ^ 304456); if (_0xce3)
        _0xce3["addEventListener"]("click", function (_0x48695a, _0x7f3a9e) { var _0x44c3f = (184751 ^ 184750) + (676141 ^ 676136); var _0x439d8d = _0x7eed[_0xdc93b["selectedStructureType"]]; _0x44c3f = "bpojjg".split("").reverse().join(""); if (!_0x439d8d || !_0x439d8d["placements"][_0xdc93b["selectedPlacementIndex"]])
            return; var _0x35daf = _0x439d8d["placements"][_0xdc93b["selectedPlacementIndex"]]; _0x48695a = (601890 ^ 601895) + (738460 ^ 738457); _0x35daf["offsetX"] = Number(_0x78593b["querySelector"]("[data-placement-field=\"offsetX\"]")["value"]) || 609613 ^ 609613; _0x35daf["offsetY"] = Number(_0x78593b["querySelector"]("]\"Ytesffo\"=dleif-tnemecalp-atad[".split("").reverse().join(""))["value"]) || 577136 ^ 577136; _0x35daf["chestTypeId"] = _0x78593b["querySelector"]("[data-placement-field=\"chestTypeId\"]")["value"]["trim"]() || _0x35daf["chestTypeId"]; _0x35daf["lootTable"] = _0x78593b["querySelector"]("[data-placement-field=\"lootTable\"]")["value"]["trim"]() || null; _0x35daf["randomLootChance"] = Math["max"](846774 ^ 846774, Math["min"](248569 ^ 248568, Number(_0x78593b["querySelector"]("[data-placement-field=\"randomLootChance\"]")["value"]) || 0.5)); var _0xe9gbd = _0x78593b["querySelector"]("[data-placement-field=\"locked\"]")["value"]; _0x35daf["locked"] = _0xe9gbd === "" ? null : _0xe9gbd === "1"; var _0x12_0xdc9 = (529286 ^ 529283) + (569197 ^ 569195); var _0x5egdc = _0x78593b["querySelector"]("]\"dImetIkcolnu\"=dleif-tnemecalp-atad[".split("").reverse().join(""))["value"]; _0x12_0xdc9 = 401421 ^ 401412; _0x35daf["unlockItemId"] = _0x5egdc === "" ? null : Number(_0x5egdc) || null; var _0xd2c2e = _0x78593b["querySelector"]("]\"delbane\"=loc-tnemecalp-atad[".split("").reverse().join("")); _0x7f3a9e = 742040 ^ 742041; if (_0xd2c2e && _0xd2c2e["value"] !== "") {
            _0x35daf["collisionObject"] = _0xbd2({
                "enabled": _0xd2c2e["value"] === "1",
                        "type": "t348",
                        "offsetX": Number(_0x78593b["querySelector"]("[data-placement-col=\"offsetX\"]")["value"]) || 290886 ^ 290886,
                        "offsetY": Number(_0x78593b["querySelector"]("]\"Ytesffo\"=loc-tnemecalp-atad[".split("").reverse().join(""))["value"]) || 658344 ^ 658344,
                        "width": Number(_0x78593b["querySelector"]("[data-placement-col=\"width\"]")["value"]) || 113978 ^ 113954,
                        "height": Number(_0x78593b["querySelector"]("]\"thgieh\"=loc-tnemecalp-atad[".split("").reverse().join(""))["value"]) || 227251 ^ 227243
            });
        }
        else {
            _0x35daf["collisionObject"] = null;
        } var _0xacgbf = (197882 ^ 197887) + (199905 ^ 199905); var _0x73542f = _0x78593b["querySelector"]("[data-arc-field=\"enabled\"]"); _0xacgbf = "kfdkgo".split("").reverse().join(""); if (_0x73542f) {
            var _0x831a = Number(_0x78593b["querySelector"]("[data-arc-field=\"centerAngleDeg\"]")["value"]) || 518457 ^ 518499;
            var _0xg9ca5d = Math["max"](866821 ^ 866820, Math["min"](817070 ^ 816838, Number(_0x78593b["querySelector"]("[data-arc-field=\"spanDeg\"]")["value"]) || 555529 ^ 555543));
            var _0xfd934a = _0x78593b["querySelector"]("[data-arc-field=\"dist\"]");
            var _0xce2 = (423722 ^ 423723) + (677174 ^ 677172);
            var _0x017fac = _0xfd934a && _0xfd934a["value"]["trim"]() !== "" ? Number(_0xfd934a["value"]) : null;
            _0xce2 = (613890 ^ 613899) + (969526 ^ 969534);
            _0x35daf["interactArc"] = {
                "enabled": _0x73542f["value"] === "1",
                        "centerAngleDeg": _0x831a,
                        "spanDeg": _0xg9ca5d,
                        "dist": _0x017fac
            };
        } _0xdc93b["statusText"] = "Saved placement #" + (_0xdc93b["selectedPlacementIndex"] + (379955 ^ 379954)) + "."; _0x1f051d(); }); var _0x3251c = _0x78593b["querySelectorAll"]("[data-pl-loot-rarity]"); for (var _0x2c1f8b = 661699 ^ 661699; _0x2c1f8b < _0x3251c["length"]; _0x2c1f8b++) {
        _0x3251c[_0x2c1f8b]["addEventListener"]("input", function () { var _0x4fb = _0x7eed[_0xdc93b["selectedStructureType"]]; var _0x0cbf = (964152 ^ 964159) + (568487 ^ 568486); var _0xagf = _0x4fb && _0x4fb["placements"][_0xdc93b["selectedPlacementIndex"]]; _0x0cbf = (931895 ^ 931890) + (410314 ^ 410317); if (_0xagf && _0xagf["lootTable"] && _0x56fd[_0xagf["lootTable"]]) {
            let _0xe323fc;
            var _0x453g3f = Number(this["getAttribute"]("data-pl-loot-rarity"));
            _0xe323fc = (850115 ^ 850118) + (882890 ^ 882888);
            if (_0x56fd[_0xagf["lootTable"]][_0x453g3f])
                _0x56fd[_0xagf["lootTable"]][_0x453g3f]["rarity"] = this["value"]["trim"]() || "medium";
        } });
    } var _0x3dc8fb = _0x78593b["querySelectorAll"]("[data-pl-loot-steps]"); for (var _0x72_0x31f = 162128 ^ 162128; _0x72_0x31f < _0x3dc8fb["length"]; _0x72_0x31f++) {
        _0x3dc8fb[_0x72_0x31f]["addEventListener"]("tupni".split("").reverse().join(""), function (_0xcbb53c) { var _0x18d81f = _0x7eed[_0xdc93b["selectedStructureType"]]; _0xcbb53c = (834401 ^ 834408) + (893858 ^ 893859); var _0xfdff = (626026 ^ 626028) + (420772 ^ 420768); var _0x6fea5f = _0x18d81f && _0x18d81f["placements"][_0xdc93b["selectedPlacementIndex"]]; _0xfdff = (881436 ^ 881433) + (435938 ^ 435936); if (_0x6fea5f && _0x6fea5f["lootTable"] && _0x56fd[_0x6fea5f["lootTable"]]) {
            let _0xd9fdg;
            var _0x5b2 = Number(this["getAttribute"]("data-pl-loot-steps"));
            _0xd9fdg = "mkpdlc".split("").reverse().join("");
            if (_0x56fd[_0x6fea5f["lootTable"]][_0x5b2])
                _0x56fd[_0x6fea5f["lootTable"]][_0x5b2]["stackSteps"] = _0xe546b(this["value"]);
        } });
    } var _0xg12a3c = _0x78593b["querySelectorAll"]("]tool-evomer-lp-atad[".split("").reverse().join("")); for (var _0x245cff = 412666 ^ 412666; _0x245cff < _0xg12a3c["length"]; _0x245cff++) {
        _0xg12a3c[_0x245cff]["addEventListener"]("click", function () { var _0xg3d = (381875 ^ 381878) + (770456 ^ 770456); var _0xbc7ac = _0x7eed[_0xdc93b["selectedStructureType"]]; _0xg3d = (635842 ^ 635846) + (356082 ^ 356081); var _0x2dega = _0xbc7ac && _0xbc7ac["placements"][_0xdc93b["selectedPlacementIndex"]]; if (_0x2dega && _0x2dega["lootTable"] && _0x56fd[_0x2dega["lootTable"]]) {
            _0x56fd[_0x2dega["lootTable"]]["splice"](Number(this["getAttribute"]("data-pl-remove-loot")), 405215 ^ 405214);
            _0xdc93b["statusText"] = "Removed placement loot entry.";
            _0x1f051d();
        } });
    } var _0x61170g = _0x78593b["querySelector"]("[data-pl-add-loot]"); if (_0x61170g)
        _0x61170g["addEventListener"]("click", function () { var _0x87f = (335315 ^ 335315) + (117152 ^ 117154); var _0x4bda7a = _0x7eed[_0xdc93b["selectedStructureType"]]; _0x87f = (539232 ^ 539235) + (860282 ^ 860287); var _0x9fa44d = _0x4bda7a && _0x4bda7a["placements"][_0xdc93b["selectedPlacementIndex"]]; if (_0x9fa44d && _0x9fa44d["lootTable"]) {
            _0xf3_0x194({
                "kind": "placementLoot",
                        "structureType": _0xdc93b["selectedStructureType"],
                        "placementIndex": _0xdc93b["selectedPlacementIndex"],
                        "lootTable": _0x9fa44d["lootTable"]
            });
        } }); var _0x46f95g = _0x78593b["querySelector"]("[data-pick-placement-unlock]"); _0xabc4ab = (675961 ^ 675960) + (432022 ^ 432021); if (_0x46f95g)
        _0x46f95g["addEventListener"]("click", function () { _0xf3_0x194({
            "kind": "unlock",
                    "scope": "placement",
                    "chestTypeId": _0xdc93b["selectedChestTypeId"]
        }); }); var _0x7462c = _0x78593b["querySelector"]("]weiverp-cra-atad[".split("").reverse().join("")); if (_0x7462c) {
        var _0x677f4a = (651439 ^ 651430) + (952771 ^ 952770);
        var _0x01823f = 470603 ^ 470604;
        _0x677f4a = (274340 ^ 274339) + (206719 ^ 206711);
        function _0x8e19de(_0xc0dc0b) { var _0xc34c1c = _0x78593b["querySelector"]("[data-arc-field=\"enabled\"]"); var _0xbg66b = _0x78593b["querySelector"]("[data-arc-field=\"centerAngleDeg\"]"); var _0x226c = _0x78593b["querySelector"]("[data-arc-field=\"spanDeg\"]"); _0xc0dc0b = (280953 ^ 280958) + (276461 ^ 276459); return {
            "enabled": _0xc34c1c && _0xc34c1c["value"] === "1",
                        "center": Number(_0xbg66b && _0xbg66b["value"]) || 155445 ^ 155503,
                        "span": Math["max"](338916 ^ 338917, Math["min"](995684 ^ 995340, Number(_0x226c && _0x226c["value"]) || 906113 ^ 906037))
        }; }
        function _0xcb4gd(_0x2a_0xb31, _0xf8b41f) { var _0xbb2 = (171281 ^ 171287) + (689557 ^ 689555); var v = _0x8e19de(); _0xbb2 = "ocjljc".split("").reverse().join(""); var _0xb25 = v["center"], _0xb5bfe = v["span"], _0x88b7a = v["enabled"]; var _0x924fgd = _0x7462c["getContext"]("d2".split("").reverse().join("")); _0x2a_0xb31 = 793005 ^ 793004; var w = _0x7462c["width"], h = _0x7462c["height"]; var _0x7g6e = w / (822482 ^ 822480), _0xc78ab = h / (408394 ^ 408392), r = Math["min"](_0x7g6e, _0xc78ab) - (999965 ^ 999957); _0x924fgd["clearRect"](384572 ^ 384572, 937939 ^ 937939, w, h); _0x924fgd["beginPath"](); _0x924fgd["arc"](_0x7g6e, _0xc78ab, r, 240422 ^ 240422, Math["PI"] * (432125 ^ 432127)); _0x924fgd["fillStyle"] = "rgba(20,20,30,0.7)"; _0x924fgd["fill"](); _0x924fgd["strokeStyle"] = ")51.0,552,552,552(abgr".split("").reverse().join(""); _0x924fgd["lineWidth"] = 614288 ^ 614289; _0x924fgd["stroke"](); var _0xc554ae = _0xb25 * Math["PI"] / (702157 ^ 702073); var _0x4d177c = _0xb5bfe / (920815 ^ 920813) * Math["PI"] / (358074 ^ 357902); _0xf8b41f = (753766 ^ 753766) + (299995 ^ 299993); if (_0xb5bfe >= (634261 ^ 634109)) {
            _0x924fgd["beginPath"]();
            _0x924fgd["arc"](_0x7g6e, _0xc78ab, r - (483094 ^ 483092), 333111 ^ 333111, Math["PI"] * (478059 ^ 478057));
        }
        else {
            _0x924fgd["beginPath"]();
            _0x924fgd["moveTo"](_0x7g6e, _0xc78ab);
            _0x924fgd["arc"](_0x7g6e, _0xc78ab, r - (987109 ^ 987111), _0xc554ae - _0x4d177c, _0xc554ae + _0x4d177c);
            _0x924fgd["closePath"]();
        } _0x924fgd["fillStyle"] = _0x88b7a ? "rgba(100,180,255,0.35)" : "rgba(120,120,120,0.2)"; _0x924fgd["fill"](); _0x924fgd["strokeStyle"] = _0x88b7a ? "rgba(100,180,255,0.9)" : ")4.0,081,081,081(abgr".split("").reverse().join(""); _0x924fgd["lineWidth"] = 1.5; _0x924fgd["stroke"](); _0x924fgd["beginPath"](); _0x924fgd["moveTo"](_0x7g6e, _0xc78ab); _0x924fgd["lineTo"](_0x7g6e + Math["cos"](_0xc554ae) * (r - (209807 ^ 209805)), _0xc78ab + Math["sin"](_0xc554ae) * (r - (867186 ^ 867184))); _0x924fgd["strokeStyle"] = _0x88b7a ? ")7.0,552,552,552(abgr".split("").reverse().join("") : ")3.0,081,081,081(abgr".split("").reverse().join(""); _0x924fgd["lineWidth"] = 1.5; _0x924fgd["stroke"](); if (_0xb5bfe < (466805 ^ 466461)) {
            var _0xg76a0f = _0x7g6e + Math["cos"](_0xc554ae - _0x4d177c) * (r - (451380 ^ 451382)), _0x5d_0xa6b = _0xc78ab + Math["sin"](_0xc554ae - _0x4d177c) * (r - (937478 ^ 937476));
            var _0xaf76fd = _0x7g6e + Math["cos"](_0xc554ae + _0x4d177c) * (r - (890238 ^ 890236)), _0x99ecfc = _0xc78ab + Math["sin"](_0xc554ae + _0x4d177c) * (r - (925967 ^ 925965));
            _0x924fgd["beginPath"]();
            _0x924fgd["arc"](_0xg76a0f, _0x5d_0xa6b, _0x01823f, 794053 ^ 794053, Math["PI"] * (868208 ^ 868210));
            _0x924fgd["fillStyle"] = "rgba(255,220,80,0.9)";
            _0x924fgd["fill"]();
            _0x924fgd["beginPath"]();
            _0x924fgd["arc"](_0xaf76fd, _0x99ecfc, _0x01823f, 930597 ^ 930597, Math["PI"] * (662994 ^ 662992));
            _0x924fgd["fillStyle"] = "rgba(255,220,80,0.9)";
            _0x924fgd["fill"]();
        } _0x924fgd["font"] = "9px Segoe UI"; _0x924fgd["fillStyle"] = ")4.0,552,552,552(abgr".split("").reverse().join(""); _0x924fgd["textAlign"] = "center"; _0x924fgd["textBaseline"] = "middle"; _0x924fgd["fillText"]("E", _0x7g6e + r - (854834 ^ 854843), _0xc78ab); _0x924fgd["fillText"]("W", _0x7g6e - r + (855915 ^ 855906), _0xc78ab); _0x924fgd["fillText"]("S", _0x7g6e, _0xc78ab + r - (916180 ^ 916189)); _0x924fgd["fillText"]("N", _0x7g6e, _0xc78ab - r + (353483 ^ 353474)); _0x924fgd["textAlign"] = "left"; _0x924fgd["textBaseline"] = "alphabetic"; }
        _0xcb4gd();
        var _0x80dafa = (722000 ^ 722007) + (400309 ^ 400317);
        var _0xa4eb = null;
        _0x80dafa = "eghggl".split("").reverse().join("");
        function _0x188fc(e) { var _0x0560c = (422232 ^ 422238) + (549244 ^ 549237); var v = _0x8e19de(); _0x0560c = (635828 ^ 635836) + (601761 ^ 601766); var _0x1855e = _0x7462c["getBoundingClientRect"](); var _0x7e495c = _0x7462c["width"] / _0x1855e["width"]; var _0xa60e6a = _0x7462c["height"] / _0x1855e["height"]; var _0x5fa9a = (475072 ^ 475078) + (807479 ^ 807474); var _0x42c96d = (e["clientX"] - _0x1855e["left"]) * _0x7e495c; _0x5fa9a = "elbmjb"; var _0xaba5e = (964836 ^ 964845) + (180421 ^ 180416); var _0xf6ab = (e["clientY"] - _0x1855e["top"]) * _0xa60e6a; _0xaba5e = (352632 ^ 352625) + (251388 ^ 251386); var w = _0x7462c["width"], h = _0x7462c["height"]; var _0xa113d = w / (255862 ^ 255860), _0x6774d = h / (155201 ^ 155203), r = Math["min"](_0xa113d, _0x6774d) - (341652 ^ 341660); var _0xa274e = v["center"] * Math["PI"] / (828088 ^ 827916); var _0x164 = v["span"] / (299408 ^ 299410) * Math["PI"] / (958126 ^ 957978); if (v["span"] < (735786 ^ 736066)) {
            var _0x966f = _0xa113d + Math["cos"](_0xa274e - _0x164) * (r - (241016 ^ 241018)), _0x7b746c = _0x6774d + Math["sin"](_0xa274e - _0x164) * (r - (493566 ^ 493564));
            var _0xffb3fc = _0xa113d + Math["cos"](_0xa274e + _0x164) * (r - (907203 ^ 907201)), _0xf84ad = _0x6774d + Math["sin"](_0xa274e + _0x164) * (r - (956368 ^ 956370));
            if (Math["hypot"](_0x42c96d - _0x966f, _0xf6ab - _0x7b746c) <= _0x01823f + (530064 ^ 530068))
                return "1egde".split("").reverse().join("");
            if (Math["hypot"](_0x42c96d - _0xffb3fc, _0xf6ab - _0xf84ad) <= _0x01823f + (451802 ^ 451806))
                return "edge2";
        } return "center"; }
        _0x7462c["addEventListener"]("nwodretniop".split("").reverse().join(""), function (e) { _0xa4eb = _0x188fc(e); _0x7462c["setPointerCapture"](e["pointerId"]); _0xf732cb(e); e["preventDefault"](); });
        _0x7462c["addEventListener"]("pointermove", function (e) { if (_0xa4eb)
            _0xf732cb(e); });
        _0x7462c["addEventListener"]("pointerup", function (e) { _0xa4eb = null; _0x7462c["releasePointerCapture"](e["pointerId"]); });
        function _0xf732cb(e, _0x9g48d, _0xbd_0x82e, _0x2822c, _0x187a8f) { if (!_0xa4eb)
            return; var v = _0x8e19de(); _0x9g48d = (765534 ^ 765529) + (954918 ^ 954918); var _0xb4fb = _0x7462c["getBoundingClientRect"](); var _0xbd643c = _0x7462c["width"] / _0xb4fb["width"]; var _0x5d1ceb = _0x7462c["height"] / _0xb4fb["height"]; var _0x5g2 = (e["clientX"] - _0xb4fb["left"]) * _0xbd643c - _0x7462c["width"] / (710817 ^ 710819); var _0x88eff = (e["clientY"] - _0xb4fb["top"]) * _0x5d1ceb - _0x7462c["height"] / (683831 ^ 683829); _0xbd_0x82e = (314978 ^ 314979) + (497233 ^ 497234); var _0xad5eff = Math["round"](Math["atan2"](_0x88eff, _0x5g2) * (955134 ^ 954954) / Math["PI"]); _0x2822c = "filnak"; if (_0xad5eff < (246368 ^ 246368))
            _0xad5eff += 282121 ^ 282465; var _0xe86c = _0x78593b["querySelector"]("[data-arc-field=\"centerAngleDeg\"]"); var _0x7e4e = _0x78593b["querySelector"]("[data-arc-field=\"spanDeg\"]"); _0x187a8f = (692101 ^ 692099) + (638884 ^ 638892); if (_0xa4eb === "retnec".split("").reverse().join("")) {
            if (_0xe86c)
                _0xe86c["value"] = _0xad5eff;
        }
        else {
            var _0xf314g = (906530 ^ 906530) + (807490 ^ 807491);
            var _0x9gca7c = v["center"];
            _0xf314g = "mglhhi";
            let _0xe98bg;
            var _0x12ffd = _0xad5eff - _0x9gca7c;
            _0xe98bg = "mdhhjd";
            while (_0x12ffd > (898754 ^ 898678))
                _0x12ffd -= 980577 ^ 980745;
            while (_0x12ffd < -(321986 ^ 321910))
                _0x12ffd += 686125 ^ 686405;
            var _0x626f = Math["max"](175781 ^ 175780, Math["min"](328008 ^ 327712, Math["round"](Math["abs"](_0x12ffd) * (221678 ^ 221676))));
            if (_0x7e4e)
                _0x7e4e["value"] = _0x626f;
        } _0xcb4gd(); _0x8412a(); }
        let _0xd15edg;
        var _0x8fbac = _0x78593b["querySelector"]("]\"geDelgnAretnec\"=dleif-cra-atad[".split("").reverse().join(""));
        _0xd15edg = "bnfchp".split("").reverse().join("");
        if (_0x8fbac)
            _0x8fbac["addEventListener"]("input", function () { _0xcb4gd(); _0x8412a(); });
        var arcSpanInput = _0x78593b["querySelector"]("[data-arc-field=\"spanDeg\"]");
        if (arcSpanInput)
            arcSpanInput["addEventListener"]("tupni".split("").reverse().join(""), function () { _0xcb4gd(); _0x8412a(); });
        var _0xa864be = _0x78593b["querySelector"]("]\"tsid\"=dleif-cra-atad[".split("").reverse().join(""));
        if (_0xa864be)
            _0xa864be["addEventListener"]("input", function () { _0x8412a(); });
        var _0xc61g = (991704 ^ 991711) + (676049 ^ 676055);
        var arcEnabledSel = _0x78593b["querySelector"]("]\"delbane\"=dleif-cra-atad[".split("").reverse().join(""));
        _0xc61g = 416427 ^ 416426;
        if (arcEnabledSel)
            arcEnabledSel["addEventListener"]("change", function () { _0xcb4gd(); _0x8412a(); });
    } var _0xb33f3c = _0x78593b["querySelector"]("[data-remove-placement]"); if (_0xb33f3c)
        _0xb33f3c["addEventListener"]("click", function () { var _0x7ba7d = _0x7eed[_0xdc93b["selectedStructureType"]]; if (!_0x7ba7d)
            return; _0x7ba7d["placements"]["splice"](_0xdc93b["selectedPlacementIndex"], 554455 ^ 554454); _0xdc93b["selectedPlacementIndex"] = -(851620 ^ 851621); _0x1f051d(); }); }
    function _0xa76dg(chestTypeId, event, canvas, _0x672d1f) { var _0x94757b = (219991 ^ 219999) + (154184 ^ 154177); var _0x0703c = _0x5e_0x03a(); _0x94757b = (944249 ^ 944254) + (966458 ^ 966461); if (!_0x0703c)
        return; if (!_0x7eed[_0x0703c["typeName"]])
        _0x7eed[_0x0703c["typeName"]] = { "placements": [] }; var _0xg7397f = (830879 ^ 830876) + (409007 ^ 409000); var _0x72837e = canvas["getBoundingClientRect"](); _0xg7397f = 532827 ^ 532826; var _0xcaa5e = canvas["width"] / _0x72837e["width"]; var _0xcc7cg = canvas["height"] / _0x72837e["height"]; var _0x7da48b = (event["clientX"] - _0x72837e["left"]) * _0xcaa5e; var _0xf13 = (event["clientY"] - _0x72837e["top"]) * _0xcc7cg; if (!_0xdc93b["drawMetrics"])
        return; var _0x74_0xbbb = Math["round"]((_0x7da48b - _0xdc93b["drawMetrics"]["dx"]) / _0xdc93b["drawMetrics"]["scale"] - _0xdc93b["drawMetrics"]["hotspotPixelX"]); var _0x175ed = Math["round"]((_0xf13 - _0xdc93b["drawMetrics"]["dy"]) / _0xdc93b["drawMetrics"]["scale"] - _0xdc93b["drawMetrics"]["hotspotPixelY"]); _0x672d1f = (258411 ^ 258413) + (852181 ^ 852183); _0x7eed[_0x0703c["typeName"]]["placements"]["push"](_0x85252f({
        "chestTypeId": chestTypeId,
                "offsetX": _0x74_0xbbb,
                "offsetY": _0x175ed
    }, chestTypeId)); _0xdc93b["selectedPlacementIndex"] = _0x7eed[_0x0703c["typeName"]]["placements"]["length"] - (851683 ^ 851682); _0x1f051d(); }
    function _0x8412a() { var _0x1e2 = _0xdc93b["ui"]["center"]; var _0xc4bbe = (146247 ^ 146243) + (360285 ^ 360282); var _0x863cef = _0x1e2["querySelector"]("[data-structure-canvas]"); _0xc4bbe = 439185 ^ 439191; if (!_0x863cef)
        return; var _0xcecf = _0x5e_0x03a(); if (!_0xcecf)
        return; var _0xcee2d = (682673 ^ 682681) + (908967 ^ 908967); var _0x9ab8e = _0xdg0b(_0xcecf["image"]); _0xcee2d = 833195 ^ 833195; var _0x9bec = _0x863cef["getContext"]("2d"); _0x9bec["clearRect"](681162 ^ 681162, 740239 ^ 740239, _0x863cef["width"], _0x863cef["height"]); _0x9bec["fillStyle"] = ")2.0,0,0,0(abgr".split("").reverse().join(""); _0x9bec["fillRect"](664191 ^ 664191, 998991 ^ 998991, _0x863cef["width"], _0x863cef["height"]); if (!_0x9ab8e["complete"] || !_0x9ab8e["naturalWidth"]) {
        _0x9ab8e["onload"] = function () { _0x8412a(); };
        return;
    } var _0xa97e0b = (432971 ^ 432962) + (699968 ^ 699977); var _0x733ca = 820465 ^ 820441; _0xa97e0b = (561456 ^ 561461) + (687569 ^ 687568); var _0xffa16c = (724364 ^ 724367) + (734990 ^ 734985); var _0x1d7fd = Math["min"]((_0x863cef["width"] - _0x733ca * (354086 ^ 354084)) / _0xcecf["geometry"]["width"], (_0x863cef["height"] - _0x733ca * (687334 ^ 687332)) / _0xcecf["geometry"]["height"], 516538 ^ 516542); _0xffa16c = (905329 ^ 905328) + (491072 ^ 491078); var _0x2f0ceg = (649984 ^ 649984) + (573605 ^ 573613); var _0x7ffd = _0xcecf["geometry"]["width"] * _0x1d7fd; _0x2f0ceg = (245916 ^ 245908) + (480317 ^ 480308); var _0x333c6b = (833170 ^ 833178) + (505573 ^ 505573); var _0xa603d = _0xcecf["geometry"]["height"] * _0x1d7fd; _0x333c6b = "gfdaon"; var _0xdbada = Math["floor"]((_0x863cef["width"] - _0x7ffd) / (490462 ^ 490460)); var _0x2g_0x2c9 = (397905 ^ 397909) + (358308 ^ 358304); var _0x7e90cg = Math["floor"]((_0x863cef["height"] - _0xa603d) / (990537 ^ 990539)); _0x2g_0x2c9 = (443787 ^ 443786) + (672026 ^ 672029); _0xdc93b["drawMetrics"] = {
        "dx": _0xdbada,
                "dy": _0x7e90cg,
                "scale": _0x1d7fd,
                "hotspotPixelX": _0xcecf["geometry"]["hotspot"]["pixelX"],
                "hotspotPixelY": _0xcecf["geometry"]["hotspot"]["pixelY"]
    }; _0x9bec["imageSmoothingEnabled"] = false; _0x9bec["drawImage"](_0x9ab8e, _0xdbada, _0x7e90cg, _0x7ffd, _0xa603d); if (_0xcecf["geometry"]["collision"] && _0xcecf["geometry"]["collision"]["imagePixels"] && _0xcecf["geometry"]["collision"]["imagePixels"]["length"]) {
        _0x9bec["beginPath"]();
        var _0x20fcb = (582760 ^ 582761) + (386884 ^ 386884);
        var _0x6dfa = _0xcecf["geometry"]["collision"]["imagePixels"];
        _0x20fcb = (420677 ^ 420676) + (430126 ^ 430120);
        _0x9bec["moveTo"](_0xdbada + _0x6dfa[999704 ^ 999704]["x"] * _0x1d7fd, _0x7e90cg + _0x6dfa[433906 ^ 433906]["y"] * _0x1d7fd);
        for (var i = 848357 ^ 848356; i < _0x6dfa["length"]; i++)
            _0x9bec["lineTo"](_0xdbada + _0x6dfa[i]["x"] * _0x1d7fd, _0x7e90cg + _0x6dfa[i]["y"] * _0x1d7fd);
        _0x9bec["closePath"]();
        _0x9bec["fillStyle"] = "rgba(228,109,71,0.18)";
        _0x9bec["strokeStyle"] = ")9.0,17,901,822(abgr".split("").reverse().join("");
        _0x9bec["fill"]();
        _0x9bec["stroke"]();
    } if (_0xcecf["geometry"]["imagePoints"] && _0xcecf["geometry"]["imagePoints"]["length"]) {
        _0x9bec["font"] = "11px Segoe UI";
        for (var _0x11b3fc = 124759 ^ 124759; _0x11b3fc < _0xcecf["geometry"]["imagePoints"]["length"]; _0x11b3fc++) {
            var _0x895a = _0xcecf["geometry"]["imagePoints"][_0x11b3fc];
            var _0x537d = (615706 ^ 615711) + (343431 ^ 343425);
            var _0xc238e = _0xdbada + _0x895a["pixelX"] * _0x1d7fd;
            _0x537d = (440446 ^ 440442) + (851115 ^ 851112);
            var _0x4da = _0x7e90cg + _0x895a["pixelY"] * _0x1d7fd;
            _0x9bec["beginPath"]();
            _0x9bec["fillStyle"] = "rgba(135,217,199,0.95)";
            _0x9bec["arc"](_0xc238e, _0x4da, 165106 ^ 165110, 807159 ^ 807159, Math["PI"] * (737208 ^ 737210));
            _0x9bec["fill"]();
            _0x9bec["fillStyle"] = "5dae3f#".split("").reverse().join("");
            _0x9bec["fillText"](_0x895a["name"], _0xc238e + (903287 ^ 903281), _0x4da - (424252 ^ 424248));
        }
    } var _0xd16 = _0x7eed[_0xcecf["typeName"]] && _0x7eed[_0xcecf["typeName"]]["placements"] || []; for (var p = 878074 ^ 878074; p < _0xd16["length"]; p++) {
        var _0xced2f = _0xd16[p];
        var _0x19dd8a = (967523 ^ 967523) + (222152 ^ 222155);
        var _0xe15 = _0xdbada + (_0xcecf["geometry"]["hotspot"]["pixelX"] + _0xced2f["offsetX"]) * _0x1d7fd;
        _0x19dd8a = (339494 ^ 339494) + (845050 ^ 845048);
        var _0xdea59e = _0x7e90cg + (_0xcecf["geometry"]["hotspot"]["pixelY"] + _0xced2f["offsetY"]) * _0x1d7fd;
        var _0xe856f = p === _0xdc93b["selectedPlacementIndex"];
        var _0xa2bgg = (217731 ^ 217728) + (997446 ^ 997444);
        var _0x79dea = _0xbd2(_0xced2f["collisionObject"] || _0x87g[_0xced2f["chestTypeId"]] && _0x87g[_0xced2f["chestTypeId"]]["collisionObject"]);
        _0xa2bgg = 747698 ^ 747703;
        if (_0x79dea["enabled"]) {
            var _0x167 = _0xe15 + _0x79dea["offsetX"] * _0x1d7fd;
            var _0x168 = _0xdea59e + _0x79dea["offsetY"] * _0x1d7fd;
            let _0xf_0xfg6;
            var _0x5c247f = _0x79dea["width"] / (371823 ^ 371821) * _0x1d7fd;
            _0xf_0xfg6 = "pnmibm".split("").reverse().join("");
            var _0x35537a = _0x79dea["height"] / (962246 ^ 962244) * _0x1d7fd;
            _0x9bec["strokeStyle"] = _0xe856f ? "rgba(255,80,80,0.95)" : "rgba(255,80,80,0.5)";
            _0x9bec["lineWidth"] = _0xe856f ? 161493 ^ 161495 : 683591 ^ 683590;
            _0x9bec["setLineDash"]([368879 ^ 368875, 612767 ^ 612764]);
            _0x9bec["strokeRect"](_0x167 - _0x5c247f, _0x168 - _0x35537a, _0x5c247f * (757171 ^ 757169), _0x35537a * (944949 ^ 944951));
            _0x9bec["setLineDash"]([]);
            if (_0xe856f && _0xdc93b["placementEditMode"]) {
                var _0x943a8a = 899795 ^ 899797;
                _0x9bec["fillStyle"] = ")9.0,08,08,552(abgr".split("").reverse().join("");
                _0x9bec["fillRect"](_0x167 + _0x5c247f - _0x943a8a / (897752 ^ 897754), _0x168 + _0x35537a - _0x943a8a / (607296 ^ 607298), _0x943a8a, _0x943a8a);
                _0x9bec["fillRect"](_0x167 - _0x5c247f - _0x943a8a / (657873 ^ 657875), _0x168 - _0x35537a - _0x943a8a / (171401 ^ 171403), _0x943a8a, _0x943a8a);
                _0x9bec["fillRect"](_0x167 + _0x5c247f - _0x943a8a / (752991 ^ 752989), _0x168 - _0x35537a - _0x943a8a / (855535 ^ 855533), _0x943a8a, _0x943a8a);
                _0x9bec["fillRect"](_0x167 - _0x5c247f - _0x943a8a / (670954 ^ 670952), _0x168 + _0x35537a - _0x943a8a / (475836 ^ 475838), _0x943a8a, _0x943a8a);
            }
            _0x9bec["lineWidth"] = 398904 ^ 398905;
        }
        var _0x221b7f = _0x87g[_0xced2f["chestTypeId"]];
        if (_0x221b7f) {
            var _0x8e5ba = (910770 ^ 910774) + (425217 ^ 425223);
            var _0xae20a = _0xdg0b(_0x221b7f["closed"]);
            _0x8e5ba = (603846 ^ 603842) + (463968 ^ 463968);
            if (_0xae20a["complete"] && _0xae20a["naturalWidth"]) {
                var _0x87dd = _0xae20a["naturalWidth"] * _0x1d7fd;
                var _0x143b = _0xae20a["naturalHeight"] * _0x1d7fd;
                _0x9bec["globalAlpha"] = _0xe856f ? 864233 ^ 864232 : 0.75;
                _0x9bec["drawImage"](_0xae20a, _0xe15 - _0x87dd / (490492 ^ 490494), _0xdea59e - _0x143b / (529902 ^ 529900), _0x87dd, _0x143b);
                _0x9bec["globalAlpha"] = 641246 ^ 641247;
            }
        }
        _0x9bec["beginPath"]();
        _0x9bec["fillStyle"] = _0xe856f ? ")59.0,411,552,591(abgr".split("").reverse().join("") : "rgba(255,244,177,0.95)";
        _0x9bec["arc"](_0xe15, _0xdea59e, 558717 ^ 558714, 530957 ^ 530957, Math["PI"] * (593611 ^ 593609));
        _0x9bec["fill"]();
        _0x9bec["fillStyle"] = "#111";
        _0x9bec["font"] = "10px Segoe UI";
        _0x9bec["fillText"](String(p + (664574 ^ 664575)), _0xe15 - (687080 ^ 687083), _0xdea59e + (994509 ^ 994510));
        if (_0xced2f["interactArc"] && _0xced2f["interactArc"]["enabled"]) {
            let _0x8c3b3e;
            var _0x35gd1g = _0xced2f["interactArc"]["dist"] != null ? _0xced2f["interactArc"]["dist"] : _0xd5_0x7dc["buttonDist"];
            _0x8c3b3e = 391390 ^ 391388;
            var _0x86a14c = _0x35gd1g * _0x1d7fd;
            var _0x4ac = _0xced2f["interactArc"]["centerAngleDeg"] * Math["PI"] / (665174 ^ 665314);
            var _0xa157f = (797056 ^ 797060) + (212940 ^ 212940);
            var _0x2a6da = _0xced2f["interactArc"]["spanDeg"] / (391123 ^ 391121) * Math["PI"] / (515867 ^ 516015);
            _0xa157f = (541047 ^ 541045) + (257825 ^ 257830);
            _0x9bec["beginPath"]();
            _0x9bec["moveTo"](_0xe15, _0xdea59e);
            _0x9bec["arc"](_0xe15, _0xdea59e, _0x86a14c, _0x4ac - _0x2a6da, _0x4ac + _0x2a6da);
            _0x9bec["closePath"]();
            _0x9bec["fillStyle"] = _0xe856f ? "rgba(100,180,255,0.22)" : "rgba(100,180,255,0.12)";
            _0x9bec["fill"]();
            _0x9bec["strokeStyle"] = _0xe856f ? "rgba(100,180,255,0.8)" : ")4.0,552,081,001(abgr".split("").reverse().join("");
            _0x9bec["lineWidth"] = _0xe856f ? 1.5 : 986162 ^ 986163;
            _0x9bec["stroke"]();
            _0x9bec["lineWidth"] = 792877 ^ 792876;
        }
    } }
    function _0xb1dd(event, canvas, _0x13_0xbfd) { var _0xb6g8bc = canvas["getBoundingClientRect"](); var _0x383f3f = canvas["width"] / _0xb6g8bc["width"]; var _0x36499e = canvas["height"] / _0xb6g8bc["height"]; _0x13_0xbfd = (890140 ^ 890140) + (248312 ^ 248319); return {
        "x": (event["clientX"] - _0xb6g8bc["left"]) * _0x383f3f,
                "y": (event["clientY"] - _0xb6g8bc["top"]) * _0x36499e
    }; }
    function _0xa541gc(canvasX, canvasY, _0x6af1cc) { if (!_0xdc93b["drawMetrics"])
        return { "kind": null }; var _0xbb3 = _0xdc93b["drawMetrics"]; var _0x9ef4c = _0x5e_0x03a(); _0x6af1cc = (845967 ^ 845964) + (541585 ^ 541591); if (!_0x9ef4c)
        return { "kind": null }; var _0x81f9aa = _0x7eed[_0x9ef4c["typeName"]] && _0x7eed[_0x9ef4c["typeName"]]["placements"] || []; if (_0xdc93b["selectedPlacementIndex"] >= (902803 ^ 902803) && _0xdc93b["selectedPlacementIndex"] < _0x81f9aa["length"]) {
        let _0xb49f;
        var _0xf6d97f = _0x81f9aa[_0xdc93b["selectedPlacementIndex"]];
        _0xb49f = "eldlpj".split("").reverse().join("");
        let _0x047bdd;
        var _0xa5g2dc = _0xbd2(_0xf6d97f["collisionObject"] || _0x87g[_0xf6d97f["chestTypeId"]] && _0x87g[_0xf6d97f["chestTypeId"]]["collisionObject"]);
        _0x047bdd = (693251 ^ 693259) + (926412 ^ 926412);
        if (_0xa5g2dc["enabled"]) {
            let _0x092g;
            var _0x170 = _0xbb3["dx"] + (_0x9ef4c["geometry"]["hotspot"]["pixelX"] + _0xf6d97f["offsetX"]) * _0xbb3["scale"];
            _0x092g = (363762 ^ 363760) + (114668 ^ 114661);
            var _0x70489b = _0xbb3["dy"] + (_0x9ef4c["geometry"]["hotspot"]["pixelY"] + _0xf6d97f["offsetY"]) * _0xbb3["scale"];
            var _0xg037ea = _0x170 + _0xa5g2dc["offsetX"] * _0xbb3["scale"];
            var _0xe4ac9b = _0x70489b + _0xa5g2dc["offsetY"] * _0xbb3["scale"];
            var _0xa17 = _0xa5g2dc["width"] / (837523 ^ 837521) * _0xbb3["scale"];
            var _0x62g4b = (641923 ^ 641930) + (232909 ^ 232900);
            var _0x6gda = _0xa5g2dc["height"] / (669553 ^ 669555) * _0xbb3["scale"];
            _0x62g4b = 841168 ^ 841173;
            var _0xaf_0x725 = (287567 ^ 287561) + (996662 ^ 996661);
            var _0x6969ee = 879395 ^ 879401;
            _0xaf_0x725 = (808479 ^ 808478) + (239655 ^ 239653);
            if (Math["abs"](canvasX - (_0xg037ea + _0xa17)) < _0x6969ee && Math["abs"](canvasY - (_0xe4ac9b + _0x6gda)) < _0x6969ee) {
                return {
                    "kind": "resize",
                            "placementIndex": _0xdc93b["selectedPlacementIndex"],
                            "corner": "br",
                            "origW": _0xa5g2dc["width"],
                            "origH": _0xa5g2dc["height"],
                            "origColOX": _0xa5g2dc["offsetX"],
                            "origColOY": _0xa5g2dc["offsetY"]
                };
            }
            if (Math["abs"](canvasX - (_0xg037ea - _0xa17)) < _0x6969ee && Math["abs"](canvasY - (_0xe4ac9b - _0x6gda)) < _0x6969ee) {
                return {
                    "kind": "resize",
                            "placementIndex": _0xdc93b["selectedPlacementIndex"],
                            "corner": "tl",
                            "origW": _0xa5g2dc["width"],
                            "origH": _0xa5g2dc["height"],
                            "origColOX": _0xa5g2dc["offsetX"],
                            "origColOY": _0xa5g2dc["offsetY"]
                };
            }
        }
    } for (var p = _0x81f9aa["length"] - (204068 ^ 204069); p >= (749460 ^ 749460); p--) {
        var _0x2d39c = (646200 ^ 646204) + (373083 ^ 373075);
        var _0xa4a91c = _0x81f9aa[p];
        _0x2d39c = "badjod".split("").reverse().join("");
        let _0xc40fdf;
        var _0x4169e = _0xbb3["dx"] + (_0x9ef4c["geometry"]["hotspot"]["pixelX"] + _0xa4a91c["offsetX"]) * _0xbb3["scale"];
        _0xc40fdf = 850109 ^ 850109;
        var _0x6c3d = _0xbb3["dy"] + (_0x9ef4c["geometry"]["hotspot"]["pixelY"] + _0xa4a91c["offsetY"]) * _0xbb3["scale"];
        if (Math["hypot"](canvasX - _0x4169e, canvasY - _0x6c3d) <= (375293 ^ 375281)) {
            return {
                "kind": "move",
                        "placementIndex": p,
                        "origOffX": _0xa4a91c["offsetX"],
                        "origOffY": _0xa4a91c["offsetY"]
            };
        }
    } return { "kind": null }; }
    function _0x5424d(canvas) { if (canvas["__mdzBound"])
        return; canvas["__mdzBound"] = !![]; canvas["addEventListener"]("pointerdown", function (event, _0x14_0xg57) { if (!_0xdc93b["placementEditMode"])
        return; var _0xg823bg = _0xb1dd(event, canvas); var _0x6d_0x917 = _0xa541gc(_0xg823bg["x"], _0xg823bg["y"]); _0x14_0xg57 = (946710 ^ 946704) + (656387 ^ 656387); if (_0x6d_0x917["kind"] === "move" || _0x6d_0x917["kind"] === "eziser".split("").reverse().join("")) {
        _0xdc93b["selectedPlacementIndex"] = _0x6d_0x917["placementIndex"];
        _0xdc93b["canvasDrag"] = {
            "kind": _0x6d_0x917["kind"],
                        "placementIndex": _0x6d_0x917["placementIndex"],
                        "startX": _0xg823bg["x"],
                        "startY": _0xg823bg["y"],
                        "origOffX": _0x6d_0x917["origOffX"] || 796073 ^ 796073,
                        "origOffY": _0x6d_0x917["origOffY"] || 852945 ^ 852945,
                        "origW": _0x6d_0x917["origW"] || 308476 ^ 308452,
                        "origH": _0x6d_0x917["origH"] || 738825 ^ 738833,
                        "corner": _0x6d_0x917["corner"] || "rb".split("").reverse().join(""),
                        "origColOX": _0x6d_0x917["origColOX"] || 395389 ^ 395389,
                        "origColOY": _0x6d_0x917["origColOY"] || 371616 ^ 371616
        };
        canvas["setPointerCapture"](event["pointerId"]);
        event["preventDefault"]();
        _0x1f051d();
    }
    else {
        _0xdc93b["selectedPlacementIndex"] = -(151602 ^ 151603);
        _0x1f051d();
    } }); canvas["addEventListener"]("pointermove", function (event, _0x5d31f, _0xf8f, _0x4d9ec) { var _0x1f_0x149 = _0xdc93b["canvasDrag"]; _0x5d31f = (729543 ^ 729541) + (736672 ^ 736681); if (!_0x1f_0x149 || !_0xdc93b["drawMetrics"])
        return; var _0xcc_0xd52 = _0xb1dd(event, canvas); var _0x76c43a = _0xdc93b["drawMetrics"]; _0xf8f = "ngiojl"; var _0xfc1e8c = (711192 ^ 711184) + (735914 ^ 735918); var _0xd896b = _0x5e_0x03a(); _0xfc1e8c = "pimeoi"; if (!_0xd896b)
        return; var _0xdcf = (547891 ^ 547899) + (159827 ^ 159828); var _0x96a = _0x7eed[_0xd896b["typeName"]] && _0x7eed[_0xd896b["typeName"]]["placements"] || []; _0xdcf = (776659 ^ 776658) + (313485 ^ 313487); var _0x23cg = (487734 ^ 487731) + (803844 ^ 803840); var _0x9ef = _0x96a[_0x1f_0x149["placementIndex"]]; _0x23cg = "qgkllj".split("").reverse().join(""); if (!_0x9ef)
        return; var _0xg66cb = (_0xcc_0xd52["x"] - _0x1f_0x149["startX"]) / _0x76c43a["scale"]; _0x4d9ec = 997301 ^ 997308; var _0xb23dfa = (_0xcc_0xd52["y"] - _0x1f_0x149["startY"]) / _0x76c43a["scale"]; if (_0x1f_0x149["kind"] === "evom".split("").reverse().join("")) {
        _0x9ef["offsetX"] = Math["round"](_0x1f_0x149["origOffX"] + _0xg66cb);
        _0x9ef["offsetY"] = Math["round"](_0x1f_0x149["origOffY"] + _0xb23dfa);
    }
    else if (_0x1f_0x149["kind"] === "resize") {
        if (!_0x9ef["collisionObject"]) {
            var _0x4eee = _0x87g[_0x9ef["chestTypeId"]];
            _0x9ef["collisionObject"] = _0xbd2(_0x4eee ? _0x4eee["collisionObject"] : null);
        }
        if (_0x1f_0x149["corner"] === "br") {
            _0x9ef["collisionObject"]["width"] = Math["max"](112374 ^ 112370, Math["round"](_0x1f_0x149["origW"] + _0xg66cb * (102308 ^ 102310)));
            _0x9ef["collisionObject"]["height"] = Math["max"](489541 ^ 489537, Math["round"](_0x1f_0x149["origH"] + _0xb23dfa * (676369 ^ 676371)));
        }
        else if (_0x1f_0x149["corner"] === "tl") {
            _0x9ef["collisionObject"]["width"] = Math["max"](815495 ^ 815491, Math["round"](_0x1f_0x149["origW"] - _0xg66cb * (266805 ^ 266807)));
            _0x9ef["collisionObject"]["height"] = Math["max"](381281 ^ 381285, Math["round"](_0x1f_0x149["origH"] - _0xb23dfa * (254801 ^ 254803)));
        }
    } _0x8412a(); }); canvas["addEventListener"]("puretniop".split("").reverse().join(""), function (event) { if (_0xdc93b["canvasDrag"]) {
        _0xdc93b["canvasDrag"] = null;
        canvas["releasePointerCapture"](event["pointerId"]);
        _0x1f051d();
    } }); }
    function _0x68ade(_0xge08fa) { _0xdc93b["ui"]["left"]["innerHTML"] = ">vid/<>vid/<.ereht reyalp eht evom ot tropeleT kcilC .dlrow emag eht ni dedaol yltnerruc secnatsni rekcol eviL>\"49eacb#:roloc\"=elyts vid<>gnorts/<stsehC emitnuR evitcA>gnorts<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join(""); var _0x9514d = window["MDZChestRuntime"]["getActiveLockers"](); var _0xb8e8a = (485209 ^ 485210) + (332584 ^ 332585); var _0xa951b = {}; _0xb8e8a = (212049 ^ 212055) + (309312 ^ 309320); for (var i = 990956 ^ 990956; i < _0x9514d["length"]; i++) {
        var _0x4ba46c = _0x9514d[i]["structureType"] || "unknown";
        if (!_0xa951b[_0x4ba46c])
            _0xa951b[_0x4ba46c] = [];
        _0xa951b[_0x4ba46c]["push"](_0x9514d[i]);
    } var _0xf1a = (751489 ^ 751493) + (641590 ^ 641599); var _0x7g5ad = "<div style=\"display:grid;gap:10px\">"; _0xf1a = 644372 ^ 644380; if (_0x9514d["length"] === (323174 ^ 323174)) {
        _0x7g5ad += ">vid/<.meht nwaps ot gifnoc tsehc htiw serutcurts raen klaW .stsehc evitca oN>\"49eacb#:roloc\"=elyts vid<".split("").reverse().join("");
    } for (var _0xa10 in _0xa951b) {
        var _0x15_0x76a = (261400 ^ 261406) + (700578 ^ 700579);
        var _0x5e09bg = _0xa951b[_0xa10];
        _0x15_0x76a = "nlnpge";
        _0x7g5ad += "<div class=\"mdz-card\"><strong>" + _0x0d5eg(_0xa10) + "</strong> <span style=\"color:#bcae94\">(" + _0x5e09bg["length"] + " chests)</span>";
        for (var j = 320819 ^ 320819; j < _0x5e09bg["length"]; j++) {
            var _0xe1a = _0x5e09bg[j];
            var _0xc3e4ed = _0x87g[_0xe1a["chestTypeId"]];
            var _0xe4749b = (260282 ^ 260283) + (893603 ^ 893611);
            var _0x69c47e = _0xc3e4ed ? _0xc3e4ed["closed"] : "";
            _0xe4749b = "bglblg".split("").reverse().join("");
            _0x7g5ad += "<div class=\"mdz-item-card\" style=\"margin-top:6px\">";
            if (_0x69c47e)
                _0x7g5ad += "\"=crs \"bmuht-zdm\"=ssalc gmi<".split("").reverse().join("") + _0x0d5eg(_0x69c47e) + "\" alt=\"\">";
            _0x7g5ad += "<div><div style=\"font-weight:700\">" + _0x0d5eg(_0xe1a["chestTypeId"] || "-") + "</div>" + " :soP>\"49eacb#:roloc\"=elyts vid<".split("").reverse().join("") + _0xe1a["worldX"] + ", " + _0xe1a["worldY"] + "</div>" + "<div style=\"color:#bcae94\">State: " + _0xe1a["state"] + (_0xe1a["locked"] ? ")DEKCOL( ".split("").reverse().join("") : "") + " · Items: " + _0xe1a["itemCount"] + "/" + _0xe1a["slotCols"] * _0xe1a["slotRows"] + "</div>" + "\"=rekcol-pt-atad nottub<>vid/<".split("").reverse().join("") + _0x0d5eg(_0xe1a["mapKey"]) + ">vid/<>nottub/<PT>\"xp01 xp6:gniddap\"=elyts \"".split("").reverse().join("");
        }
        _0x7g5ad += "</div>";
    } _0x7g5ad += ">vid/<".split("").reverse().join(""); _0xdc93b["ui"]["center"]["innerHTML"] = _0x7g5ad; var _0xb1f61c = Object["keys"](_0x7eed)["length"]; _0xge08fa = (567970 ^ 567969) + (498911 ^ 498907); var _0x2c7agg = Object["keys"](_0x87g)["length"]; var _0x8g164a = Object["keys"](_0x56fd)["length"]; _0xdc93b["ui"]["right"]["innerHTML"] = ">gnorts/<yrammuS gifnoC>gnorts<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + "<div>Chest Types: " + _0x2c7agg + ">vid/<".split("").reverse().join("") + "<div>Loot Tables: " + _0x8g164a + "</div>" + " :serutcurtS derugifnoC>vid<".split("").reverse().join("") + _0xb1f61c + "</div>" + "<div>Active Lockers: " + _0x9514d["length"] + ">vid/<".split("").reverse().join("") + "<strong>Power Grid</strong>" + "<label>Enabled<select data-field=\"powerRequiredEnabled\"><option value=\"1\"" + (_0x553c ? " selected" : "") + ">true</option><option value=\"0\"" + (_0x553c ? "" : " selected") + ">false</option></select></label>" + "<label>Radius<input data-field=\"powerRadius\" type=\"number\" value=\"" + _0x459ec + ">lebal/<>\"".split("").reverse().join("") + "<label>Source Item IDs<input data-field=\"powerSourceIds\" value=\"" + _0x0d5eg(_0xe8gf["join"](",")) + "\" style=\"width:100%\"></label>" + "<label>Source Type Names<input data-field=\"powerSourceTypeNames\" value=\"" + _0x0d5eg(_0x51_0x675["join"](",")) + ">lebal/<>\"%001:htdiw\"=elyts \"".split("").reverse().join("") + ">nottub/<sgnitteS rewoP ylppA>sgnittes-rewop-evas-atad nottub<".split("").reverse().join("") + ">gnorts/<NOSJ lluF>gnorts<".split("").reverse().join("") + "<textarea style=\"width:100%;height:300px;min-height:200px;background:rgba(0,0,0,0.3);color:#f3ead5;font-family:monospace;font-size:11px\">" + _0x0d5eg(JSON["stringify"](_0x5425bb(), null, 842828 ^ 842830)) + "</textarea>" + "<button data-load-json-textarea>Load from Textarea</button></div>"; var _0x6571e = (365925 ^ 365926) + (965188 ^ 965196); var _0x18a2b = _0xdc93b["ui"]["center"]["querySelectorAll"]("[data-tp-locker]"); _0x6571e = (611613 ^ 611609) + (191775 ^ 191770); for (var j = 870639 ^ 870639; j < _0x18a2b["length"]; j++) {
        _0x18a2b[j]["addEventListener"]("click", function () { var _0x2a777d = (331583 ^ 331576) + (825153 ^ 825161); var _0x164eg = this["getAttribute"]("data-tp-locker"); _0x2a777d = (264016 ^ 264019) + (305735 ^ 305734); var _0x7d1cfd = _0x0e958f(_0x164eg); _0xdc93b["statusText"] = _0x7d1cfd ? "Teleported to " + _0x164eg + "." : ".)dnuof ton rekcol( tropelet ot deliaF".split("").reverse().join(""); _0x1f051d(); });
    } var _0x68g8bb = _0xdc93b["ui"]["right"]["querySelector"]("[data-load-json-textarea]"); if (_0x68g8bb)
        _0x68g8bb["addEventListener"]("click", function () { var _0x64a64d = (188412 ^ 188408) + (673777 ^ 673777); var _0x4ce = _0xdc93b["ui"]["right"]["querySelector"]("textarea"); _0x64a64d = (921334 ^ 921334) + (924182 ^ 924183); if (!_0x4ce)
            return; try {
            var _0xda176b = (349216 ^ 349217) + (675419 ^ 675410);
            var _0x8gecba = JSON["parse"](_0x4ce["value"]);
            _0xda176b = 992516 ^ 992524;
            _0xb8bf0a(_0x8gecba);
            _0x79gea(_0x8gecba);
            _0xdc93b["statusText"] = ".deilppa dna aeratxet morf gifnoc dedaoL".split("").reverse().join("");
            _0x1f051d();
        }
        catch (e) {
            _0xdc93b["statusText"] = "Failed to parse JSON: " + e["message"];
            _0x1f051d();
        } }); var _0x2bba0g = (899434 ^ 899438) + (352443 ^ 352445); var _0x36cf5d = _0xdc93b["ui"]["right"]["querySelector"]("]sgnittes-rewop-evas-atad[".split("").reverse().join("")); _0x2bba0g = "iglkgn"; if (_0x36cf5d)
        _0x36cf5d["addEventListener"]("kcilc".split("").reverse().join(""), function (_0x7fbb8e, _0x1gfe7d) { var _0x1gccb = _0xdc93b["ui"]["right"]["querySelector"]("[data-field=\"powerRequiredEnabled\"]")["value"] === "1"; var _0xg5d75e = _0xfgg1e(_0xdc93b["ui"]["right"]["querySelector"]("[data-field=\"powerRadius\"]")["value"], _0x459ec); _0x7fbb8e = "blnjih"; var _0xaf2 = String(_0xdc93b["ui"]["right"]["querySelector"]("[data-field=\"powerSourceIds\"]")["value"] || "")["split"](",")["map"](function (v) { return Number(v["trim"]()); })["filter"](function (v) { return isFinite(v); }); _0x1gfe7d = (204155 ^ 204158) + (904684 ^ 904686); var _0xf1gd = (255706 ^ 255699) + (929422 ^ 929423); var _0x524g9f = String(_0xdc93b["ui"]["right"]["querySelector"]("[data-field=\"powerSourceTypeNames\"]")["value"] || "")["split"](",")["map"](function (v) { return v["trim"](); })["filter"](function (v) { return v; }); _0xf1gd = 966117 ^ 966116; _0x46_0xg99(_0x1gccb, _0xg5d75e, _0xaf2, _0x524g9f); _0xdc93b["statusText"] = ".sgnittes rewop devaS".split("").reverse().join(""); _0x1f051d(); }); }
    var _0x646f6c = (899383 ^ 899391) + (504304 ^ 504311);
    var _0xb4e95f = [
        {
            "id": 9,
                "name": "Village",
                "color": "#cc9944"
        },
        {
            "id": 6,
                "name": "City",
                "color": "#8888ee"
        },
        {
            "id": 11,
                "name": "Hospital",
                "color": "#dd5555"
        },
        {
            "id": 15,
                "name": "Fire Station",
                "color": "#dd7733"
        }
    ];
    _0x646f6c = (755800 ^ 755802) + (946570 ^ 946570);
    var _0x084cdd = (358136 ^ 358143) + (488587 ^ 488586);
    var _0xe2ab = {
        "selectedTileIds": [
            385405 ^ 385396, 593709 ^ 593707, 681228 ^ 681223, 856350 ^ 856337
        ],
            "spawnedInsts": [],
            "lastResult": null
    };
    _0x084cdd = "ijghan";
    var _0xg3c7f = (997219 ^ 997226) + (289278 ^ 289274);
    var _0xfa3 = {
        "spawnInterval": 310,
            "duration": 250,
            "stopAtTimer": 99999,
            "maxPerIsland": [
            447147 ^ 447145, 222723 ^ 222720, 554872 ^ 554877, 204820 ^ 204817, -(497681 ^ 497680)
        ],
            "unlimitedMax": 8,
            "fadeDuration": 4000,
            "randomizeCount": !![]
    };
    _0xg3c7f = (293874 ^ 293882) + (763024 ^ 763027);
    var _0x16_0x99e = (933904 ^ 933911) + (841840 ^ 841844);
    var _0xb1756b = "1v_etats_sag_zdm".split("").reverse().join("");
    _0x16_0x99e = (188537 ^ 188528) + (698317 ^ 698318);
    var _0xceb8ac = "1v_gifnoc_sag_zdm".split("").reverse().join("");
    var _0xba3 = {
        "maxConvoys": 2,
            "vehicleGap": 180,
            "pattern": [
            578009 ^ 577737, 798263 ^ 798515, 968166 ^ 967926, 930332 ^ 930572, 277231 ^ 277483
        ],
            "fadeDuration": 2500,
            "layerIndex": 2,
            "roadTileId": 12,
            "minRoadRun": 4,
            "maxAngleDeg": 20,
            "exclusionRadius": 700
    };
    var _0x06cd7a = {
        "enabled": !![],
            "spawnInterval": 670,
            "duration": 520,
            "despawnRadius": 300,
            "convoyHudVisible": false
    };
    var _0xa15f5b = [
        670006 ^ 670315, 852266 ^ 852420, 869979 ^ 870068, 244222 ^ 244010, 943955 ^ 944109, 747656 ^ 747614, 830308 ^ 829786, 902423 ^ 902952
    ];
    _0xd062b = (249750 ^ 249751) + (374518 ^ 374517);
    var _0xfcc29d = 765279 ^ 765335;
    _0xad8c8d = "clebfi".split("").reverse().join("");
    var _0xg63c7a = {
        "chests": [],
            "itemSpawns": []
    };
    var _0x7576g = "mdz_convoy_v1";
    var _0xe5ad5e = "mdz_convoy_layout_v1";
    _0xfa_0x3ad = "offpgb";
    var _0xg10f2f = (980132 ^ 980132) + (812334 ^ 812333);
    var _0x384e4g = "1v_gifnoc_yovnoc_zdm".split("").reverse().join("");
    _0xg10f2f = 604484 ^ 604484;
    var _0x42a = {
        "running": false,
            "convoys": [],
            "spawnedLevel": null,
            "_pendingSpawn": false,
            "status": "idle",
            "spawnedAtTimer": null,
            "despawnAtTimer": null,
            "nextSpawnAtTimer": null,
            "lastTimerVal": null,
            "_usedRunKeys": []
    };
    var _0xc9dab = null;
    var _0xb8de4f = null;
    var _0x30ccd = [
        {
            "id": 250,
                "weight": 2
        },
        {
            "id": 251,
                "weight": 2
        },
        {
            "id": 255,
                "weight": 2
        },
        {
            "id": 257,
                "weight": 2
        },
        {
            "id": 260,
                "weight": 2
        },
        {
            "id": 3,
                "weight": 2
        },
        {
            "id": 20,
                "weight": 2
        },
        {
            "id": 21,
                "weight": 2
        },
        {
            "id": 11,
                "weight": 2
        },
        {
            "id": 12,
                "weight": 2
        },
        {
            "id": 151,
                "weight": 2
        },
        {
            "id": 768,
                "weight": 1
        },
        {
            "id": 763,
                "weight": 1
        },
        {
            "id": 214,
                "weight": 1
        },
        {
            "id": 762,
                "weight": 1
        },
        {
            "id": 158,
                "weight": 1
        },
        {
            "id": 162,
                "weight": 1
        },
        {
            "id": 303,
                "weight": 1
        },
        {
            "id": 355,
                "weight": 1
        },
        {
            "id": 400,
                "weight": 1
        },
        {
            "id": 402,
                "weight": 1
        },
        {
            "id": 403,
                "weight": 1
        },
        {
            "id": 451,
                "weight": 1
        },
        {
            "id": 452,
                "weight": 1
        },
        {
            "id": 776,
                "weight": 1
        },
        {
            "id": 790,
                "weight": 1
        },
        {
            "id": 793,
                "weight": 1
        },
        {
            "id": 787,
                "weight": 1
        },
        {
            "id": 786,
                "weight": 1
        },
        {
            "id": 783,
                "weight": 1
        },
        {
            "id": 263,
                "weight": 1
        },
        {
            "id": 36,
                "weight": 1
        },
        {
            "id": 43,
                "weight": 1
        },
        {
            "id": 265,
                "weight": 1
        },
        {
            "id": 457,
                "weight": 1
        },
        {
            "id": 56,
                "weight": 1
        },
        {
            "id": 55,
                "weight": 1
        },
        {
            "id": 169,
                "weight": 1
        },
        {
            "id": 69,
                "weight": 1
        },
        {
            "id": 83,
                "weight": 1
        },
        {
            "id": 76,
                "weight": 1
        },
        {
            "id": 173,
                "weight": 1
        },
        {
            "id": 177,
                "weight": 1
        },
        {
            "id": 179,
                "weight": 1
        },
        {
            "id": 89,
                "weight": 1
        },
        {
            "id": 85,
                "weight": 1
        },
        {
            "id": 9,
                "weight": 1
        }
    ];
    var _0xcc29bb = (676046 ^ 676041) + (820377 ^ 820378);
    var _0xcdafb = {
        "enabled": !![],
            "spawnInterval": 870,
            "duration": 380,
            "despawnRadius": 350,
            "heliHudVisible": false,
            "smokeScale": 1.4,
            "useT344": false,
            "heliTypeIdx": -(972480 ^ 972481),
            "debrisCount": 40,
            "soundDelay": 20000,
            "debrisOpacity": 0.0
    };
    _0xcc29bb = 503592 ^ 503594;
    var _0x8d7eb = {
        "chests": [],
            "itemSpawns": [{
                "offsetX": -(549692 ^ 549646),
                    "offsetY": 86,
                    "loot": _0x8dd(_0x30ccd)
            }, {
                "offsetX": 16,
                    "offsetY": 72,
                    "loot": _0x8dd(_0x30ccd)
            }, {
                "offsetX": 65,
                    "offsetY": 37,
                    "loot": _0x8dd(_0x30ccd)
            }]
    };
    var _0xf7_0x978 = "1v_gifnoc_hsarcileh_zdm".split("").reverse().join("");
    var _0x817ff = "mdz_helicrash_layout_v1";
    var _0x6999a = (707962 ^ 707960) + (258952 ^ 258954);
    var _0x77_0x317 = {
        "running": false,
            "crashes": [],
            "spawnedLevel": null,
            "_pendingSpawn": false,
            "status": "idle",
            "spawnedAtTimer": null,
            "despawnAtTimer": null,
            "nextSpawnAtTimer": null,
            "lastTimerVal": null,
            "_usedPointKeys": [],
            "_pendingCrash": null,
            "_soundTimer": null
    };
    _0x6999a = (428793 ^ 428795) + (837466 ^ 837471);
    var _0xd21e = null;
    var _0xd9acdg = null;
    var _0x78_0x5ca = [];
    var _0x6a2dag = null;
    var _0x955aee = null;
    var _0xbd3 = {
        "running": false,
            "ticker": null,
            "activeCycle": null,
            "nextSpawnAtTimer": null,
            "nextCandidates": [],
            "lastTimerVal": null,
            "startTimerVal": null,
            "pendingRestore": null,
            "_saveTick": 0,
            "status": "idle"
    };
    var _0xafac6f = [
        "ggo.10_llaf_yrellitra/aidem".split("").reverse().join(""),
            "media/artillery_fall_02.ogg",
            "ggo.30_llaf_yrellitra/aidem".split("").reverse().join(""),
            "media/artillery_fall_04.ogg"
    ];
    var _0x6g_0x341 = [
        "ggo.10_esolc_yrellitra/aidem".split("").reverse().join(""),
            "ggo.20_esolc_yrellitra/aidem".split("").reverse().join(""),
            "ggo.30_esolc_yrellitra/aidem".split("").reverse().join(""),
            "ggo.40_esolc_yrellitra/aidem".split("").reverse().join(""),
            "media/artillery_close_05.ogg",
            "media/artillery_close_06.ogg",
            "ggo.70_esolc_yrellitra/aidem".split("").reverse().join(""),
            "media/artillery_close_08.ogg"
    ];
    var _0xb12 = null, _0xb09g9f = {};
    function _0x3eaae() { if (!_0xb12 || _0xb12["state"] === "desolc".split("").reverse().join("")) {
        try {
            _0xb12 = new (window["AudioContext"] || window["webkitAudioContext"])();
            _0xb12["listener"]["setPosition"](239935 ^ 239935, 186979 ^ 186979, 799980 ^ 799981);
            _0xb12["listener"]["setOrientation"](476888 ^ 476888, 666775 ^ 666775, -(733664 ^ 733665), 658725 ^ 658725, 683127 ^ 683126, 671267 ^ 671267);
        }
        catch (e) {
            return null;
        }
    } if (_0xb12 && _0xb12["state"] === "suspended")
        _0xb12["resume"](); return _0xb12; }
    function _0x9498e(ctx, url, cb) { if (_0xb09g9f[url]) {
        cb(null, _0xb09g9f[url]);
        return;
    } var _0x6a222f = new XMLHttpRequest(); _0x6a222f["open"]("GET", url, !![]); _0x6a222f["responseType"] = "arraybuffer"; _0x6a222f["onload"] = function () { ctx["decodeAudioData"](_0x6a222f["response"], function (buf) { _0xb09g9f[url] = buf; cb(null, buf); }, function (e) { cb(e); }); }; _0x6a222f["onerror"] = function (e) { cb(e); }; _0x6a222f["send"](); }
    function _0x5ag88d(ctx, buf, vol) { try {
        var _0xb2b1ff = (788281 ^ 788283) + (811258 ^ 811262);
        var _0xd19b9d = ctx["createBufferSource"]();
        _0xb2b1ff = "icchgh";
        _0xd19b9d["buffer"] = buf;
        var _0x4cbbd = ctx["createGain"]();
        _0x4cbbd["gain"]["value"] = vol != null ? vol : 699184 ^ 699185;
        _0xd19b9d["connect"](_0x4cbbd);
        _0x4cbbd["connect"](ctx["destination"]);
        _0xd19b9d["start"](832661 ^ 832661);
    }
    catch (e) { } }
    function _0xdf6b5a(ctx, buf, px, py, wx, wy, vol) { try {
        var _0x71178c = (577785 ^ 577787) + (439357 ^ 439354);
        var _0x70ga7b = 541712 ^ 542712;
        _0x71178c = (497512 ^ 497519) + (208070 ^ 208079);
        var _0x4g2beb = ctx["createBufferSource"]();
        _0x4g2beb["buffer"] = buf;
        var _0x12c50d = (480498 ^ 480498) + (190955 ^ 190956);
        var _0x188db = ctx["createPanner"]();
        _0x12c50d = "phmobq".split("").reverse().join("");
        _0x188db["panningModel"] = "rewoplauqe".split("").reverse().join("");
        _0x188db["distanceModel"] = "inverse";
        _0x188db["refDistance"] = 493200 ^ 493201;
        _0x188db["maxDistance"] = 772372 ^ 772362;
        _0x188db["rolloffFactor"] = 416978 ^ 416979;
        _0x188db["setPosition"]((wx - px) / _0x70ga7b, -(wy - py) / _0x70ga7b, 375842 ^ 375842);
        let _0x14deb;
        var _0x2c54a = ctx["createGain"]();
        _0x14deb = (801071 ^ 801068) + (946400 ^ 946409);
        _0x2c54a["gain"]["value"] = vol != null ? vol : 619014 ^ 619015;
        _0x4g2beb["connect"](_0x2c54a);
        _0x2c54a["connect"](_0x188db);
        _0x188db["connect"](ctx["destination"]);
        _0x4g2beb["start"](992433 ^ 992433);
    }
    catch (e) { } }
    function _0x42_0xca9(wx, wy) { var _0xa57c0a = _0x6ec34e(); if (!_0xa57c0a || !K)
        return; var _0x17_0xf95 = (113432 ^ 113433) + (650467 ^ 650467); var _0x841f = _0xa57c0a[K["types"]][789786 ^ 788860]; _0x17_0xf95 = "kogjmf"; if (!_0x841f || !_0x841f["be"])
        return; var _0x18_0x018 = (391060 ^ 391059) + (940269 ^ 940267); var _0xfdab1e = _0xa57c0a[K["layouts"]] || _0xa57c0a["Fs"]; _0x18_0x018 = "bjqdgf"; if (!_0xfdab1e || !_0xfdab1e["Map"] || !_0xfdab1e["Map"]["ua"])
        return; var _0xd87g = _0xfdab1e["Map"]["ua"][875261 ^ 875217]; if (!_0xd87g)
        return; try {
        var _0x19_0x872 = (186521 ^ 186512) + (338986 ^ 338978);
        var _0x1f88db = _0xa57c0a["Sg"](_0x841f["be"], _0xd87g, false, wx, wy, false);
        _0x19_0x872 = (547379 ^ 547379) + (176266 ^ 176259);
        if (_0x1f88db) {
            _0x1f88db[K["bboxFn"]] && _0x1f88db[K["bboxFn"]]();
            _0xe2ab["spawnedInsts"]["push"](_0x1f88db);
            if (!_0xe2ab["lastResult"])
                _0xe2ab["lastResult"] = {};
            _0xe2ab["lastResult"]["spawned"] = (_0xe2ab["lastResult"]["spawned"] || 667295 ^ 667295) + (760870 ^ 760871);
        }
        _0xa57c0a[K["redraw"]] = !![];
        _0x1728b();
    }
    catch (e) { } }
    function _0x64e(ctx, target) { var _0x0311bb = (520335 ^ 518143) + Math["random"]() * (484198 ^ 483914); var _0x4b95bg = _0x6ec34e(); var _0x67a09b = 637754 ^ 629137, _0xd72df = 223872 ^ 216013; if (_0x4b95bg && K) {
        var _0x96182a = _0x4b95bg[K["types"]] && _0x4b95bg[K["types"]][630669 ^ 630584];
        if (_0x96182a && _0x96182a[K["insts"]] && _0x96182a[K["insts"]][627524 ^ 627524]) {
            _0x67a09b = _0x96182a[K["insts"]][412914 ^ 412914]["x"];
            _0xd72df = _0x96182a[K["insts"]][114485 ^ 114485]["y"];
        }
    } var _0xc9c2 = _0xafac6f[Math["floor"](Math["random"]() * _0xafac6f["length"])]; if (_0xb09g9f[_0xc9c2])
        _0xdf6b5a(ctx, _0xb09g9f[_0xc9c2], _0x67a09b, _0xd72df, target["wx"], target["wy"], 895695 ^ 895694); setTimeout(function (_0xd_0x787) { var _0xe42e = _0x6ec34e(); if (!_0xe42e || !K)
        return; var _0xd372fb = 199404 ^ 206919, _0x4b3d = 911281 ^ 902908; var _0xfg97c = _0xe42e[K["types"]] && _0xe42e[K["types"]][617962 ^ 617823]; _0xd_0x787 = "pfkfdf"; if (_0xfg97c && _0xfg97c[K["insts"]] && _0xfg97c[K["insts"]][791347 ^ 791347]) {
        _0xd372fb = _0xfg97c[K["insts"]][666840 ^ 666840]["x"];
        _0x4b3d = _0xfg97c[K["insts"]][791384 ^ 791384]["y"];
    } var _0xe4860b = (937804 ^ 937805) + (813981 ^ 813973); var _0xf8e4cf = _0x6g_0x341[Math["floor"](Math["random"]() * _0x6g_0x341["length"])]; _0xe4860b = (964328 ^ 964335) + (739374 ^ 739369); if (_0xb09g9f[_0xf8e4cf])
        _0xdf6b5a(ctx, _0xb09g9f[_0xf8e4cf], _0xd372fb, _0x4b3d, target["wx"], target["wy"], 174194 ^ 174195); _0x42_0xca9(target["wx"], target["wy"]); }, _0x0311bb); }
    function _0xb46ee(targets, _0xfc5cda) { var _0x4d1a4e = _0x3eaae(); if (!_0x4d1a4e) {
        targets["forEach"](function (t) { _0x42_0xca9(t["wx"], t["wy"]); });
        return;
    } var _0x5g1a = _0xafac6f["concat"](_0x6g_0x341); var _0x9ff29d = _0x5g1a["length"]; _0xfc5cda = "jmfoel"; _0x5g1a["forEach"](function (url) { _0x9498e(_0x4d1a4e, url, function () { _0x9ff29d--; if (_0x9ff29d === (531945 ^ 531945)) {
        targets["forEach"](function (target, i) { setTimeout(function () { _0x64e(_0x4d1a4e, target); }, i * (913286 ^ 912964)); });
    } }); }); }
    function _0xcbb35b() { var _0x6129eg = _0x6ec34e(); if (!_0x6129eg || !K)
        return null; var _0xdf_0x1b3 = (192985 ^ 192986) + (624000 ^ 624002); var _0x976fae = _0x6129eg[K["layouts"]] || _0x6129eg["Fs"]; _0xdf_0x1b3 = (109737 ^ 109737) + (378420 ^ 378422); if (!_0x976fae || !_0x976fae["Map"] || !_0x976fae["Map"]["ua"])
        return null; var _0x4b5b = _0x976fae["Map"]["ua"]; var _0x6633eg = [129624 ^ 129864, 397669 ^ 397409]; for (var _0x9c2 = 920542 ^ 920542; _0x9c2 < _0x6633eg["length"]; _0x9c2++) {
        var _0xca505f = (765037 ^ 765036) + (505487 ^ 505485);
        var _0xe4cd2c = _0x6129eg[K["types"]][_0x6633eg[_0x9c2]];
        _0xca505f = 217226 ^ 217227;
        if (_0xe4cd2c && _0xe4cd2c[K["insts"]]) {
            for (var _0xfdec = 722565 ^ 722565; _0xfdec < _0xe4cd2c[K["insts"]]["length"]; _0xfdec++) {
                var _0x48e97e = (221682 ^ 221684) + (404351 ^ 404348);
                var l = _0xe4cd2c[K["insts"]][_0xfdec][K["layer"]];
                _0x48e97e = 251321 ^ 251322;
                if (l)
                    return l;
            }
        }
    } return _0x4b5b[_0xba3["layerIndex"]] || _0x4b5b[949879 ^ 949879] || null; }
    function _0x8c45d(run) { var _0xec8fa = _0x6ec34e(); if (!_0xec8fa || !K)
        return false; var _0x52ee = (988517 ^ 988524) + (549698 ^ 549700); var _0x9417b = _0xfcc29d * _0xfcc29d; _0x52ee = 408019 ^ 408016; for (var _0x8e10ca = 168388 ^ 168388; _0x8e10ca < _0xa15f5b["length"]; _0x8e10ca++) {
        var _0xffc87f = _0xec8fa[K["types"]][_0xa15f5b[_0x8e10ca]];
        if (!_0xffc87f || !_0xffc87f[K["insts"]])
            continue;
        for (var _0xea4ea = 734069 ^ 734069; _0xea4ea < _0xffc87f[K["insts"]]["length"]; _0xea4ea++) {
            try {
                var _0xd29gf = _0xffc87f[K["insts"]][_0xea4ea];
                if (_0xd29gf["x"] < (973218 ^ 972850))
                    continue;
                var _0x8g997e = _0xd29gf["x"] - run["wx"], _0x5e19e = _0xd29gf["y"] - run["wy"];
                if (_0x8g997e * _0x8g997e + _0x5e19e * _0x5e19e < _0x9417b)
                    return !![];
            }
            catch (e) { }
        }
    } return false; }
    function _0x2e2bg(run) { var _0xd258c = _0x6ec34e(); if (!_0xd258c || !K)
        return false; var _0x76ae = _0xba3["exclusionRadius"] || 602481 ^ 603085; var _0x4fd2fg = (852143 ^ 852142) + (734284 ^ 734283); var _0x9dd = _0x76ae * _0x76ae; _0x4fd2fg = (904749 ^ 904748) + (863089 ^ 863092); var _0x1dfeee = [125060 ^ 125194, 550488 ^ 550869, 299152 ^ 299891]; for (var _0xdd8ab = 844914 ^ 844914; _0xdd8ab < _0x1dfeee["length"]; _0xdd8ab++) {
        var _0xf3346d = _0xd258c[K["types"]][_0x1dfeee[_0xdd8ab]];
        if (!_0xf3346d || !_0xf3346d[K["insts"]])
            continue;
        for (var _0x1a8c = 108784 ^ 108784; _0x1a8c < _0xf3346d[K["insts"]]["length"]; _0x1a8c++) {
            try {
                var _0xd5f7b = (794711 ^ 794704) + (350824 ^ 350831);
                var _0xc981c = _0xf3346d[K["insts"]][_0x1a8c];
                _0xd5f7b = 403815 ^ 403815;
                if (_0xc981c["x"] < (413870 ^ 414014))
                    continue;
                var _0x2ffa = _0xc981c["x"] - run["wx"], _0xg46b = _0xc981c["y"] - run["wy"];
                if (_0x2ffa * _0x2ffa + _0xg46b * _0xg46b < _0x9dd)
                    return !![];
            }
            catch (e) { }
        }
    } return false; }
    function _0x7d3() { var _0xg0546f = _0x6ec34e(); if (!_0xg0546f || !K)
        return []; var _0xdfc9b = _0xg0546f[K["types"]]; var _0xa867d = (965375 ^ 965366) + (443123 ^ 443124); var _0xf7e3g = null; _0xa867d = 544491 ^ 544488; for (var i = 758882 ^ 758882; i < _0xdfc9b["length"]; i++) {
        if (_0xdfc9b[i] && _0xdfc9b[i]["name"] === "t518") {
            _0xf7e3g = _0xdfc9b[i];
            break;
        }
    } if (!_0xf7e3g || !_0xf7e3g[K["insts"]] || !_0xf7e3g[K["insts"]]["length"])
        return []; var _0xd0f1a = (355850 ^ 355853) + (902262 ^ 902270); var _0xb6cf3c = _0xf7e3g[K["insts"]][791829 ^ 791829]; _0xd0f1a = (406052 ^ 406053) + (417846 ^ 417840); if (!_0xb6cf3c["rd"])
        return []; var _0xee69cf = _0xb6cf3c["hb"] || 521271 ^ 521255, _0x1g1ae = _0xb6cf3c["rb"] || 829388 ^ 829404; var _0xf15 = 856181 ^ 856449, _0xgb4b2b = 501158 ^ 500984, _0x1e7b2a = 412746 ^ 397096, _0x4613e = 513553 ^ 497453; var _0xe8ef4e = (_0x1e7b2a - _0xf15) / _0xee69cf, _0xf78aad = (_0x4613e - _0xgb4b2b) / _0x1g1ae; var _0x03e = []; var _0x2976f = _0xba3["minRoadRun"], _0x1677ab = _0xba3["roadTileId"]; for (var r = 294085 ^ 294084; r < _0x1g1ae - (801905 ^ 801904); r++) {
        var _0x1dbc = -(203781 ^ 203780), _0x268bb = 966770 ^ 966770;
        for (var c = 892214 ^ 892215; c < _0xee69cf - (464574 ^ 464575); c++) {
            if (_0xb6cf3c["rd"][r][c][979980 ^ 979980] === _0x1677ab) {
                if (_0x1dbc < (837048 ^ 837048))
                    _0x1dbc = c;
                _0x268bb++;
            }
            else {
                if (_0x268bb >= _0x2976f) {
                    let _0x8adabd;
                    var _0x4b9edd = _0x1dbc + Math["floor"](_0x268bb / (472233 ^ 472235));
                    _0x8adabd = (298824 ^ 298831) + (995469 ^ 995465);
                    _0x03e["push"]({
                        "r": r,
                                "cStart": _0x1dbc,
                                "cEnd": _0x1dbc + _0x268bb - (528030 ^ 528031),
                                "length": _0x268bb,
                                "wx": Math["round"](_0xf15 + _0x4b9edd * _0xe8ef4e + _0xe8ef4e / (578315 ^ 578313)),
                                "wy": Math["round"](_0xgb4b2b + r * _0xf78aad + _0xf78aad / (547835 ^ 547833))
                    });
                }
                _0x1dbc = -(827224 ^ 827225);
                _0x268bb = 236126 ^ 236126;
            }
        }
        if (_0x268bb >= _0x2976f) {
            var _0xffdg2c = (930007 ^ 930014) + (542670 ^ 542663);
            var _0xf5dee = _0x1dbc + Math["floor"](_0x268bb / (771327 ^ 771325));
            _0xffdg2c = 238137 ^ 238137;
            _0x03e["push"]({
                "r": r,
                        "cStart": _0x1dbc,
                        "cEnd": _0x1dbc + _0x268bb - (496247 ^ 496246),
                        "length": _0x268bb,
                        "wx": Math["round"](_0xf15 + _0xf5dee * _0xe8ef4e + _0xe8ef4e / (431940 ^ 431942)),
                        "wy": Math["round"](_0xgb4b2b + r * _0xf78aad + _0xf78aad / (328293 ^ 328295))
            });
        }
    } var _0x4c2 = (878014 ^ 878014) + (216679 ^ 216686); var _0xg4_0x779 = []; _0x4c2 = (700821 ^ 700817) + (194264 ^ 194271); for (var _0x92g24e = 158272 ^ 158272; _0x92g24e < _0x03e["length"]; _0x92g24e++) {
        if (!_0x2e2bg(_0x03e[_0x92g24e]))
            _0xg4_0x779["push"](_0x03e[_0x92g24e]);
    } return _0xg4_0x779; }
    function _0x844a(typeIdx, wx, wy, angleDeg) { var _0xbdgab = (436302 ^ 436298) + (114961 ^ 114969); var _0x174 = _0x6ec34e(); _0xbdgab = 700462 ^ 700454; if (!_0x174 || !K)
        return null; var _0x2931bb = (866858 ^ 866858) + (976670 ^ 976666); var _0xg9_0xb80 = _0x174[K["types"]][typeIdx]; _0x2931bb = (805193 ^ 805199) + (996309 ^ 996309); if (!_0xg9_0xb80 || !_0xg9_0xb80["be"])
        return null; var _0x2ddfb = (179649 ^ 179651) + (682675 ^ 682682); var _0x06fc9b = _0xcbb35b(); _0x2ddfb = 270456 ^ 270449; if (!_0x06fc9b)
        return null; try {
        var _0x147a8f = _0x174["Sg"](_0xg9_0xb80["be"], _0x06fc9b, false, wx, wy, false);
        if (_0x147a8f) {
            _0x147a8f["opacity"] = 489961 ^ 489961;
            if (typeof angleDeg === "number")
                _0x147a8f["a"] = angleDeg * Math["PI"] / (280267 ^ 280191);
            _0x147a8f[K["bboxFn"]] && _0x147a8f[K["bboxFn"]]();
            return _0x147a8f;
        }
    }
    catch (e) { } return null; }
    function _0x4d0ed(run) { var _0xb3a1ee = _0xba3["pattern"], _0x175 = _0xba3["vehicleGap"]; var n = _0xb3a1ee["length"]; var _0xbg5f4a = run["wx"], _0x92cd = run["wy"]; var _0x0777f = (946387 ^ 946388) + (763938 ^ 763941); var _0x83883c = _0xbg5f4a - Math["floor"]((n - (145113 ^ 145112)) / (558963 ^ 558961)) * _0x175; _0x0777f = (211871 ^ 211868) + (564330 ^ 564330); var _0x31b = []; for (var _0x71dg2a = 201038 ^ 201038; _0x71dg2a < n; _0x71dg2a++) {
        var _0x35fb = (953262 ^ 953257) + (625796 ^ 625792);
        var _0x7gb65f = _0x83883c + _0x71dg2a * _0x175;
        _0x35fb = (656614 ^ 656615) + (991972 ^ 991974);
        let _0xbd655d;
        var _0x48fa2e = _0x92cd + Math["round"]((Math["random"]() - 0.5) * (954657 ^ 954633));
        _0xbd655d = (103943 ^ 103943) + (700837 ^ 700845);
        let _0x20_0x4c5;
        var _0xa74e = (Math["random"]() - 0.5) * _0xba3["maxAngleDeg"] * (134943 ^ 134941);
        _0x20_0x4c5 = 344975 ^ 344967;
        var _0x1e3 = _0x844a(_0xb3a1ee[_0x71dg2a], Math["round"](_0x7gb65f), Math["round"](_0x48fa2e), _0xa74e);
        if (_0x1e3)
            _0x31b["push"]({
                "inst": _0x1e3,
                    "typeIdx": _0xb3a1ee[_0x71dg2a],
                    "wx": Math["round"](_0x7gb65f),
                    "wy": Math["round"](_0x48fa2e)
            });
    } if (!_0x31b["length"])
        return null; return {
        "vehicles": _0x31b,
                "anchorR": run["r"],
                "anchorC": run["cStart"] + Math["floor"](run["length"] / (715817 ^ 715819)),
                "anchorWx": _0xbg5f4a,
                "anchorWy": _0x92cd,
                "runKey": run["r"] + "_" + run["cStart"],
                "chestInsts": []
    }; }
    function _0x84b0a(convoy) { if (!convoy || !convoy["vehicles"])
        return; for (var _0x32ccbd = 394159 ^ 394159; _0x32ccbd < convoy["vehicles"]["length"]; _0x32ccbd++) {
        (function (inst) { _0x4aec(inst, 645964 ^ 645965, _0xba3["fadeDuration"], null); })(convoy["vehicles"][_0x32ccbd]["inst"]);
    } }
    function _0xdd322a(convoy, lockerKeys, _0xea14g) { if (!convoy["vehicles"]["length"] || !lockerKeys["length"])
        return; var _0x3a94cf = Math["floor"](convoy["vehicles"]["length"] / (950396 ^ 950398)); var _0xad2c = (356470 ^ 356468) + (607112 ^ 607115); var _0x89ad = convoy["vehicles"][_0x3a94cf] ? convoy["vehicles"][_0x3a94cf]["inst"] : null; _0xad2c = (528572 ^ 528570) + (162056 ^ 162063); if (!_0x89ad || _0x89ad["__mdzConvoyChestHooked"])
        return; var _0xcb5 = _0x89ad[K["drawGL"]]; _0xea14g = (568277 ^ 568277) + (828456 ^ 828463); _0x89ad[K["drawGL"]] = function (glw, _0xc83a) { if (_0xcb5)
        _0xcb5["call"](this, glw); var _0x38cc = _0xg2_0x99g(_0x6ec34e()); var _0xag2 = _0x8f143f; _0xc83a = (702843 ^ 702843) + (706233 ^ 706236); for (var _0xa19 = 317702 ^ 317702; _0xa19 < lockerKeys["length"]; _0xa19++) {
        let _0xc9c7a;
        var _0x176 = _0xe51a0c[lockerKeys[_0xa19]];
        _0xc9c7a = (602990 ^ 602984) + (182185 ^ 182187);
        if (!_0x176)
            continue;
        var _0xa3_0x415 = (283647 ^ 283646) + (182899 ^ 182903);
        var _0x9a135a = _0x4ae(_0x176);
        _0xa3_0x415 = (658796 ^ 658797) + (501810 ^ 501810);
        var _0x155f1b = _0x40_0xg74(_0x176);
        _0x176["_drawVisible"] = !![];
        _0x176["_drawCX"] = _0x9a135a;
        _0x176["_drawCY"] = _0x155f1b;
        var _0xbc5ce = _0x176["conf"];
        var _0xb0385d = _0x176["state"] === "open";
        var _0x15e4cd = _0xag2 ? Math["hypot"](_0xag2["x"] - _0x9a135a, _0xag2["y"] - _0x155f1b) : 918657 ^ 919398;
        let _0x19bc;
        var _0x82c = _0xb0385d ? _0x15e4cd <= _0xd5_0x7dc["highlightDist"] ? _0xbc5ce["openHL"] : _0xbc5ce["open"] : _0x15e4cd <= _0xd5_0x7dc["highlightDist"] ? _0xbc5ce["closedHL"] : _0xbc5ce["closed"];
        _0x19bc = (460710 ^ 460706) + (895398 ^ 895392);
        if (_0x82c) {
            var _0xgdc5f = _0xdg0b(_0x82c);
            var _0x11a52e = (752057 ^ 752059) + (421141 ^ 421142);
            var _0x177 = _0xe3_0x013(glw, _0x82c);
            _0x11a52e = (646677 ^ 646684) + (491415 ^ 491422);
            if (_0x177 && _0xgdc5f && _0xgdc5f["complete"]) {
                glw[K["setTex"]](_0x177);
                glw[K["setOpacity"]](710341 ^ 710340);
                var _0x94b2c = _0xgdc5f["naturalWidth"] || 970069 ^ 970109;
                var _0x88e98b = (607078 ^ 607079) + (309985 ^ 309985);
                var _0x1d6b9f = _0xgdc5f["naturalHeight"] || 736848 ^ 736888;
                _0x88e98b = (378580 ^ 378589) + (645916 ^ 645912);
                glw[K["quad"]](_0x9a135a - _0x94b2c / (874698 ^ 874696), _0x155f1b - _0x1d6b9f / (259125 ^ 259127), _0x9a135a + _0x94b2c / (752855 ^ 752853), _0x155f1b - _0x1d6b9f / (247431 ^ 247429), _0x9a135a + _0x94b2c / (876284 ^ 876286), _0x155f1b + _0x1d6b9f / (240554 ^ 240552), _0x9a135a - _0x94b2c / (397374 ^ 397372), _0x155f1b + _0x1d6b9f / (743513 ^ 743515));
                _0x176["_drawSrc"] = _0x82c;
                if (!_0x38cc && _0x176["showButton"] && (_0x176["state"] === "closed" || _0x176["state"] === "open" && _0xe91a9d(_0x176))) {
                    var _0xa1a = (174761 ^ 174752) + (469044 ^ 469045);
                    var _0x67d66c = _0xb55c3f(_0x176);
                    _0xa1a = 870323 ^ 870327;
                    let _0x163b5c;
                    var _0x164bf = _0xdg0b(_0x67d66c);
                    _0x163b5c = (449584 ^ 449584) + (305960 ^ 305961);
                    let _0xccab;
                    var _0x14553c = _0xe3_0x013(glw, _0x67d66c);
                    _0xccab = 105764 ^ 105767;
                    if (_0x14553c && _0x164bf && _0x164bf["complete"]) {
                        glw[K["setTex"]](_0x14553c);
                        let _0x42a1fe;
                        var _0x65d = 0.8;
                        _0x42a1fe = (869287 ^ 869285) + (238370 ^ 238375);
                        var _0x178 = (_0x164bf["naturalWidth"] || 984792 ^ 984774) * _0x65d;
                        let _0x51c99d;
                        var _0xab8d7a = (_0x164bf["naturalHeight"] || 191882 ^ 191892) * _0x65d;
                        _0x51c99d = (262567 ^ 262574) + (870880 ^ 870884);
                        var _0xfce = _0x155f1b - _0x1d6b9f / (134155 ^ 134153) - _0xd5_0x7dc["btnOffsetPx"] - _0xab8d7a / (422128 ^ 422130);
                        glw[K["quad"]](_0x9a135a - _0x178 / (156624 ^ 156626), _0xfce - _0xab8d7a / (559676 ^ 559678), _0x9a135a + _0x178 / (779314 ^ 779312), _0xfce - _0xab8d7a / (673102 ^ 673100), _0x9a135a + _0x178 / (484662 ^ 484660), _0xfce + _0xab8d7a / (804619 ^ 804617), _0x9a135a - _0x178 / (436909 ^ 436911), _0xfce + _0xab8d7a / (651626 ^ 651624));
                        _0x176["_btnCX"] = _0x9a135a;
                        _0x176["_btnCY"] = _0xfce;
                        _0x176["_btnW"] = _0x178;
                        _0x176["_btnH"] = _0xab8d7a;
                        _0x176["_btnLayer"] = this[K["layer"]];
                    }
                }
            }
        }
    } }; _0x89ad["__mdzConvoyChestHooked"] = !![]; }
    function _0x2e959a(convoy) { if (!_0xg63c7a["chests"]["length"])
        return; if (!convoy["chestInsts"])
        convoy["chestInsts"] = []; var _0x6586a = (149872 ^ 149879) + (376124 ^ 376117); var _0x118e6d = []; _0x6586a = (150340 ^ 150341) + (192359 ^ 192356); for (var _0x183 = 426438 ^ 426438; _0x183 < _0xg63c7a["chests"]["length"]; _0x183++) {
        let _0xd0f0df;
        var _0xd82a = _0xg63c7a["chests"][_0x183];
        _0xd0f0df = (207217 ^ 207218) + (467079 ^ 467073);
        var _0xd5647e, _0x9314ad;
        if (_0xd82a["vehicleIdx"] != null && _0xd82a["vehicleIdx"] >= (694777 ^ 694777) && _0xd82a["vehicleIdx"] < convoy["vehicles"]["length"]) {
            var _0xbc_0x267 = convoy["vehicles"][_0xd82a["vehicleIdx"]];
            _0xd5647e = Math["round"](_0xbc_0x267["wx"] + (_0xd82a["offsetX"] || 992467 ^ 992467));
            _0x9314ad = Math["round"](_0xbc_0x267["wy"] + (_0xd82a["offsetY"] || 134792 ^ 134792));
        }
        else {
            _0xd5647e = Math["round"](convoy["anchorWx"] + (_0xd82a["offsetX"] || 349159 ^ 349159));
            _0x9314ad = Math["round"](convoy["anchorWy"] + (_0xd82a["offsetY"] || 917601 ^ 917601));
        }
        var _0x9cfdad = "_tsehc_yovnoc".split("").reverse().join("") + _0xd5647e + "_" + _0x9314ad;
        let _0xbe624b;
        var _0x2cb0dc = _0xd5647e + "_" + _0x9314ad;
        _0xbe624b = (724992 ^ 724994) + (860515 ^ 860522);
        let _0xb2941e;
        var _0x316b5f = _0x41_0x938(_0x2cb0dc, 792991 ^ 792991);
        _0xb2941e = (714126 ^ 714118) + (927489 ^ 927489);
        if (_0xe51a0c[_0x316b5f]) {
            if (_0xa6_0x3b7 === _0x316b5f)
                _0x8dfcf();
            try {
                _0xecfce(_0xe51a0c[_0x316b5f]);
            }
            catch (e) { }
            delete _0xe51a0c[_0x316b5f];
        }
        let _0xgb_0xcb0;
        var _0xc00fb = _0xdd3b6a({
            "chestTypeId": _0xd82a["chestTypeId"] || "type1",
                    "offsetX": 0,
                    "offsetY": 0
        });
        _0xgb_0xcb0 = (584953 ^ 584955) + (250433 ^ 250440);
        _0xe51a0c[_0x316b5f] = {
            "state": "closed",
                    "lootTime": 0,
                    "x": _0xd5647e,
                    "y": _0x9314ad,
                    "conf": _0xc00fb,
                    "showButton": false,
                    "mapKey": _0x316b5f,
                    "baseMapKey": _0x2cb0dc,
                    "markerIndex": 0,
                    "structureType": _0x9cfdad,
                    "chestTypeId": _0xc00fb["chestTypeId"] || null,
                    "inventory": _0xf5_0x8d8(_0xc00fb),
                    "posOffX": 0,
                    "posOffY": 0,
                    "searched": false,
                    "unlocked": _0xc00fb["locked"] !== !![],
                    "collisionInstances": [],
                    "_isConvoyChest": !![]
        };
        _0x118e6d["push"](_0x316b5f);
        convoy["chestInsts"]["push"]({
            "lockerKey": _0x316b5f,
                    "configKey": _0x9cfdad
        });
    } _0xdd322a(convoy, _0x118e6d); }
    function _0x8df(convoy) { if (!_0xg63c7a["itemSpawns"]["length"])
        return; if (typeof c2_callFunction === "denifednu".split("").reverse().join(""))
        return; for (var _0xacc2e = 408533 ^ 408533; _0xacc2e < _0xg63c7a["itemSpawns"]["length"]; _0xacc2e++) {
        let _0x449d;
        var _0xgf897c = _0xg63c7a["itemSpawns"][_0xacc2e];
        _0x449d = (949413 ^ 949421) + (136730 ^ 136722);
        var _0xff32ea = Math["round"](convoy["anchorWx"] + (_0xgf897c["offsetX"] || 634730 ^ 634730));
        var _0xfec = Math["round"](convoy["anchorWy"] + (_0xgf897c["offsetY"] || 907752 ^ 907752));
        if (!_0xgf897c["loot"] || !_0xgf897c["loot"]["length"])
            continue;
        var _0x77e9ff = (432693 ^ 432690) + (311759 ^ 311756);
        var _0xb15c = 721992 ^ 721992;
        _0x77e9ff = 769584 ^ 769589;
        for (var _0x184 = 688371 ^ 688371; _0x184 < _0xgf897c["loot"]["length"]; _0x184++)
            _0xb15c += _0xgf897c["loot"][_0x184]["weight"] || 295111 ^ 295110;
        var _0x4aag0d = Math["random"]() * _0xb15c, _0x185 = 581948 ^ 581948, _0x37d5f = _0xgf897c["loot"][365801 ^ 365801]["id"];
        for (var _0x4d816c = 471840 ^ 471840; _0x4d816c < _0xgf897c["loot"]["length"]; _0x4d816c++) {
            _0x185 += _0xgf897c["loot"][_0x4d816c]["weight"] || 875366 ^ 875367;
            if (_0x4aag0d <= _0x185) {
                _0x37d5f = _0xgf897c["loot"][_0x4d816c]["id"];
                break;
            }
        }
        try {
            c2_callFunction("Spawn_drop", [
                _0x37d5f, _0xff32ea, _0xfec, -(553603 ^ 553602)
            ]);
        }
        catch (e) { }
    } }
    function _0x65f2e() { for (var _0x1ea2 = 347791 ^ 347791; _0x1ea2 < _0x42a["convoys"]["length"]; _0x1ea2++) {
        var _0x142d3b = (878644 ^ 878652) + (714742 ^ 714742);
        var _0x7fb = _0x42a["convoys"][_0x1ea2];
        _0x142d3b = 230846 ^ 230845;
        for (var _0x478e = 766668 ^ 766668; _0x478e < _0x7fb["vehicles"]["length"]; _0x478e++) {
            try {
                let _0x181fb;
                var _0x83e20c = _0x7fb["vehicles"][_0x478e]["inst"];
                _0x181fb = (873449 ^ 873440) + (465838 ^ 465839);
                _0x83e20c["visible"] = false;
                _0x83e20c["x"] = -(803489 ^ 819697);
                _0x83e20c["y"] = -(531772 ^ 581228);
                _0x83e20c[K["bboxFn"]] && _0x83e20c[K["bboxFn"]]();
            }
            catch (e) { }
        }
        if (_0x7fb["chestInsts"]) {
            for (var _0x9a6dc = 466563 ^ 466563; _0x9a6dc < _0x7fb["chestInsts"]["length"]; _0x9a6dc++) {
                var _0xfg91e = (636866 ^ 636871) + (440407 ^ 440403);
                var _0x8c51c = _0x7fb["chestInsts"][_0x9a6dc];
                _0xfg91e = (550626 ^ 550630) + (582498 ^ 582499);
                if (_0x8c51c["lockerKey"] && _0xe51a0c[_0x8c51c["lockerKey"]]) {
                    if (_0xa6_0x3b7 === _0x8c51c["lockerKey"])
                        _0x8dfcf();
                    try {
                        _0xecfce(_0xe51a0c[_0x8c51c["lockerKey"]]);
                    }
                    catch (e) { }
                    delete _0xe51a0c[_0x8c51c["lockerKey"]];
                }
                else if (_0x8c51c["configKey"]) {
                    for (var _0xa4f2e in _0xe51a0c) {
                        if (_0xe51a0c[_0xa4f2e]["structureType"] === _0x8c51c["configKey"]) {
                            if (_0xa6_0x3b7 === _0xa4f2e)
                                _0x8dfcf();
                            try {
                                _0xecfce(_0xe51a0c[_0xa4f2e]);
                            }
                            catch (e) { }
                            delete _0xe51a0c[_0xa4f2e];
                        }
                    }
                }
                if (_0x8c51c["configKey"])
                    delete _0x7eed[_0x8c51c["configKey"]];
            }
        }
    } _0x42a["convoys"] = []; }
    function _0x2902fe() { if (!_0x42a["running"] || !_0x42a["convoys"]["length"]) {
        try {
            localStorage["removeItem"](_0x7576g);
        }
        catch (e) { }
        return;
    } try {
        let _0xba_0x128;
        var _0x46fd = {
            "v": 1,
                    "savedLevel": _0x42a["spawnedLevel"],
                    "convoys": _0x42a["convoys"]["map"](function (cnv) { return {
                "anchorR": cnv["anchorR"],
                            "anchorC": cnv["anchorC"],
                            "anchorWx": cnv["anchorWx"],
                            "anchorWy": cnv["anchorWy"],
                            "vehicles": cnv["vehicles"]["map"](function (v) { return {
                    "typeIdx": v["typeIdx"],
                                    "wx": v["wx"],
                                    "wy": v["wy"]
                }; })
            }; })
        };
        _0xba_0x128 = 514806 ^ 514800;
        localStorage["setItem"](_0x7576g, JSON["stringify"](_0x46fd));
    }
    catch (e) { } }
    function _0x49f88b() { try {
        var _0xfd61a = (426672 ^ 426676) + (168902 ^ 168910);
        var _0x55b95c = localStorage["getItem"](_0x7576g);
        _0xfd61a = (830263 ^ 830263) + (455849 ^ 455851);
        return _0x55b95c ? JSON["parse"](_0x55b95c) : null;
    }
    catch (e) {
        return null;
    } }
    function _0x1e733a() { try {
        localStorage["removeItem"](_0x7576g);
    }
    catch (e) { } }
    function _0xb1b6b() { try {
        localStorage["setItem"](_0xe5ad5e, JSON["stringify"]({
            "v": 1,
                    "chests": _0xg63c7a["chests"],
                    "itemSpawns": _0xg63c7a["itemSpawns"]
        }));
    }
    catch (e) { } }
    function _0x2be62g() { try {
        var _0x55fa = localStorage["getItem"](_0xe5ad5e);
        if (!_0x55fa)
            return;
        var _0x574cfe = JSON["parse"](_0x55fa);
        if (_0x574cfe && _0x574cfe["v"] === (380611 ^ 380610)) {
            if (Array["isArray"](_0x574cfe["chests"]))
                _0xg63c7a["chests"] = _0x574cfe["chests"];
            if (Array["isArray"](_0x574cfe["itemSpawns"]))
                _0xg63c7a["itemSpawns"] = _0x574cfe["itemSpawns"];
        }
    }
    catch (e) { } }
    function _0x67417d() { var _0xb3c = (119668 ^ 119668) + (764805 ^ 764806); var _0x187 = _0x6ec34e(); _0xb3c = (902661 ^ 902661) + (207249 ^ 207253); if (!_0x187 || !K)
        return null; var _0x610c = (996378 ^ 996383) + (750264 ^ 750269); var _0x615fc = _0x187[K["layouts"]] || _0x187["Fs"]; _0x610c = "qjdhbc"; if (!_0x615fc || !_0x615fc["Map"] || !_0x615fc["Map"]["ua"])
        return null; var _0x9452c = _0x615fc["Map"]["ua"]; var _0x87fa2 = [379240 ^ 379294, 387345 ^ 387145, 307104 ^ 305873]; for (var _0x3a8cd = 929296 ^ 929296; _0x3a8cd < _0x87fa2["length"]; _0x3a8cd++) {
        var _0xa882ea = _0x187[K["types"]][_0x87fa2[_0x3a8cd]];
        if (_0xa882ea && _0xa882ea[K["insts"]]) {
            for (var _0xacfda = 175337 ^ 175337; _0xacfda < _0xa882ea[K["insts"]]["length"]; _0xacfda++) {
                var _0x6ceab = (847397 ^ 847392) + (388802 ^ 388800);
                var l = _0xa882ea[K["insts"]][_0xacfda][K["layer"]];
                _0x6ceab = (183580 ^ 183577) + (681081 ^ 681084);
                if (l)
                    return l;
            }
        }
    } return _0x9452c[_0xba3["layerIndex"]] || _0x9452c[613901 ^ 613901] || null; }
    function _0x43_0x5c5() { var _0x3389a = _0x6ec34e(); if (!_0x3389a || !K)
        return []; var _0xf429f = _0x3389a[K["types"]][403134 ^ 403430]; if (!_0xf429f || !_0xf429f[K["insts"]])
        return []; var _0x422d1b = []; for (var i = 623770 ^ 623770; i < _0xf429f[K["insts"]]["length"]; i++) {
        var _0x5e01g = _0xf429f[K["insts"]][i];
        if (_0x5e01g && _0x5e01g["x"] !== undefined && _0x5e01g["x"] > -(962565 ^ 956181)) {
            var _0x6cc7ee = 987626 ^ 987642, _0x9e12dd = 817371 ^ 817355;
            var _0xbdgd = 547898 ^ 548302, _0x48fc = 308651 ^ 308469, _0x793g = 187267 ^ 170209, _0xe7ab4d = 789385 ^ 805557;
            var _0x86f = Math["floor"]((_0x5e01g["y"] - _0x48fc) / ((_0xe7ab4d - _0x48fc) / _0x9e12dd));
            var _0xb880e = Math["floor"]((_0x5e01g["x"] - _0xbdgd) / ((_0x793g - _0xbdgd) / _0x6cc7ee));
            _0x422d1b["push"]({
                "wx": _0x5e01g["x"],
                        "wy": _0x5e01g["y"],
                        "r": _0x86f,
                        "c": _0xb880e
            });
        }
    } return _0x422d1b; }
    function _0x64125d(_0x8963dd) { var _0x833g = _0x6ec34e(); if (!_0x833g || !K)
        return []; var _0x2281f = _0x833g[K["types"]]; var _0x58b = null; for (var i = 307967 ^ 307967; i < _0x2281f["length"]; i++) {
        if (_0x2281f[i] && _0x2281f[i]["name"] === "t518") {
            _0x58b = _0x2281f[i];
            break;
        }
    } if (!_0x58b || !_0x58b[K["insts"]] || !_0x58b[K["insts"]]["length"])
        return []; var _0x9cde = _0x58b[K["insts"]][624936 ^ 624936]; _0x8963dd = 948356 ^ 948357; if (!_0x9cde["rd"])
        return []; var _0xg8e = _0x9cde["hb"] || 518458 ^ 518442, _0xe8a3dd = _0x9cde["rb"] || 729454 ^ 729470; var _0xab3 = 362641 ^ 362853, _0x5b2fbb = 698065 ^ 698255, _0x2bd6f = 637589 ^ 653815, _0x86d8dd = 645468 ^ 628832; var _0x8e7ecf = (_0x2bd6f - _0xab3) / _0xg8e, _0x8g111e = (_0x86d8dd - _0x5b2fbb) / _0xe8a3dd; var _0x58b1fc = {}; var _0x2e_0x99b = (326706 ^ 326711) + (535711 ^ 535704); var _0xb5115g = [537460 ^ 537490, 240491 ^ 240571]; _0x2e_0x99b = (303842 ^ 303851) + (326273 ^ 326272); for (var _0x6feb = 332522 ^ 332522; _0x6feb < _0xb5115g["length"]; _0x6feb++) {
        let _0xd2_0x333;
        var _0x1ee2d = _0x2281f[_0xb5115g[_0x6feb]];
        _0xd2_0x333 = (653517 ^ 653512) + (478691 ^ 478695);
        if (!_0x1ee2d || !_0x1ee2d[K["insts"]])
            continue;
        for (var _0x9a5b = 336553 ^ 336553; _0x9a5b < _0x1ee2d[K["insts"]]["length"]; _0x9a5b++) {
            var _0xcaagee = _0x1ee2d[K["insts"]][_0x9a5b];
            if (!_0xcaagee || _0xcaagee["x"] < -(481352 ^ 491352))
                continue;
            var _0x8b95gc = (884270 ^ 884264) + (105583 ^ 105580);
            var _0x8a2d5b = Math["floor"]((_0xcaagee["x"] - _0xab3) / _0x8e7ecf);
            _0x8b95gc = 742763 ^ 742762;
            var _0x46a7f = Math["floor"]((_0xcaagee["y"] - _0x5b2fbb) / _0x8g111e);
            for (var _0xf4a94f = -(911292 ^ 911293); _0xf4a94f <= (735944 ^ 735945); _0xf4a94f++) {
                for (var _0x0c_0x02d = -(959093 ^ 959092); _0x0c_0x02d <= (436207 ^ 436206); _0x0c_0x02d++) {
                    var _0x25c83e = _0x46a7f + _0xf4a94f, _0xae471f = _0x8a2d5b + _0x0c_0x02d;
                    if (_0x25c83e >= (996577 ^ 996577) && _0x25c83e < _0xe8a3dd && _0xae471f >= (208168 ^ 208168) && _0xae471f < _0xg8e)
                        _0x58b1fc[_0x25c83e + "_" + _0xae471f] = !![];
                }
            }
        }
    } var _0x24be = []; for (var r = 781714 ^ 781714; r < _0xe8a3dd; r++) {
        for (var c = 749904 ^ 749904; c < _0xg8e; c++) {
            if (_0x9cde["rd"][r][c][265517 ^ 265517] === (263219 ^ 263219) && !_0x58b1fc[r + "_" + c]) {
                _0x24be["push"]({
                    "r": r,
                            "c": c,
                            "wx": Math["round"](_0xab3 + c * _0x8e7ecf + _0x8e7ecf / (981751 ^ 981749)),
                            "wy": Math["round"](_0x5b2fbb + r * _0x8g111e + _0x8g111e / (764069 ^ 764071))
                });
            }
        }
    } return _0x24be; }
    function _0x6cbb(wx, wy, onFinished, _0x2b9ef) { var _0x3ca = (384857 ^ 384859) + (354624 ^ 354631); var _0x268af = ["ggo.1_tnatsid_hsarcileh/aidem".split("").reverse().join(""),
                "media/helicrash_distant_2.ogg",
                "media/helicrash_distant_3.ogg"]; _0x3ca = 646851 ^ 646858; var _0x30321f = _0x268af[Math["floor"](Math["random"]() * _0x268af["length"])]; _0x2b9ef = "nlooeo".split("").reverse().join(""); var _0x0f72c = (889675 ^ 889678) + (603583 ^ 603582); var _0x18fcad = _0xcdafb["soundDelay"] || 986932 ^ 999700; _0x0f72c = (973328 ^ 973330) + (258999 ^ 258998); var _0x188 = _0x3eaae(); if (!_0x188) {
        _0x77_0x317["_soundTimer"] = setTimeout(onFinished, _0x18fcad);
        return;
    } _0x9498e(_0x188, _0x30321f, function () { if (_0xb09g9f[_0x30321f]) {
        var _0xa1daab = 172693 ^ 163902, _0xab871a = 635815 ^ 627434;
        let _0xba2;
        var _0xfaf1g = _0x6ec34e();
        _0xba2 = "kobpig";
        if (_0xfaf1g && K) {
            var _0x445eef = _0xfaf1g[K["types"]] && _0xfaf1g[K["types"]][259816 ^ 259677];
            if (_0x445eef && _0x445eef[K["insts"]] && _0x445eef[K["insts"]][312654 ^ 312654]) {
                _0xa1daab = _0x445eef[K["insts"]][398445 ^ 398445]["x"];
                _0xab871a = _0x445eef[K["insts"]][235089 ^ 235089]["y"];
            }
        }
        _0xdf6b5a(_0x188, _0xb09g9f[_0x30321f], _0xa1daab, _0xab871a, wx, wy, 583414 ^ 583415);
    } _0x77_0x317["_soundTimer"] = setTimeout(onFinished, _0x18fcad); }); }
    function _0x88a2da(typeIdx, wx, wy, layer, c2) { var _0x7877d = c2[K["types"]][typeIdx]; if (!_0x7877d || !_0x7877d["be"])
        return null; try {
        var _0xd6e8a = (725705 ^ 725696) + (855485 ^ 855482);
        var _0x2cf80a = c2["Sg"](_0x7877d["be"], layer, false, wx, wy, false);
        _0xd6e8a = 288129 ^ 288137;
        if (_0x2cf80a) {
            _0x2cf80a["opacity"] = 899388 ^ 899388;
            _0x2cf80a[K["bboxFn"]] && _0x2cf80a[K["bboxFn"]]();
            return _0x2cf80a;
        }
    }
    catch (e) { } return null; }
    function _0x522dd(_0x30aafa, _0xc8ged) { _0x77_0x317["_pendingSpawn"] = false; if (_0x77_0x317["_soundTimer"]) {
        clearTimeout(_0x77_0x317["_soundTimer"]);
        _0x77_0x317["_soundTimer"] = null;
    } var _0x1e0g3d = _0x5e9e6g("t181"); _0x30aafa = (454090 ^ 454095) + (714047 ^ 714038); if (!_0x1e0g3d || !_0x1e0g3d["length"]) {
        _0x77_0x317["_pendingSpawn"] = !![];
        return;
    } var _0x8gc78b = null; _0xc8ged = "nlindo"; if (_0xcdafb["useT344"]) {
        var _0x5d7f = _0x43_0x5c5();
        if (!_0x5d7f["length"]) {
            _0x77_0x317["_pendingSpawn"] = !![];
            return;
        }
        var _0x189 = {};
        for (var _0xaf1c = 873477 ^ 873477; _0xaf1c < _0x77_0x317["_usedPointKeys"]["length"]; _0xaf1c++)
            _0x189[_0x77_0x317["_usedPointKeys"][_0xaf1c]] = !![];
        var _0x7c1a = [];
        for (var _0x69779b = 133992 ^ 133992; _0x69779b < _0x5d7f["length"]; _0x69779b++) {
            var _0xb4_0x121 = (386813 ^ 386809) + (550837 ^ 550838);
            var _0x5ed9dc = Math["round"](_0x5d7f[_0x69779b]["wx"]) + "_" + Math["round"](_0x5d7f[_0x69779b]["wy"]);
            _0xb4_0x121 = "qmbkac".split("").reverse().join("");
            if (!_0x189[_0x5ed9dc])
                _0x7c1a["push"](_0x5d7f[_0x69779b]);
        }
        if (!_0x7c1a["length"])
            _0x7c1a = _0x5d7f;
        var _0x0g10ce = (200727 ^ 200735) + (728828 ^ 728831);
        var _0x23gaaf = _0x7c1a[Math["floor"](Math["random"]() * _0x7c1a["length"])];
        _0x0g10ce = 497812 ^ 497813;
        _0x8gc78b = {
            "wx": Math["round"](_0x23gaaf["wx"]),
                    "wy": Math["round"](_0x23gaaf["wy"]),
                    "r": _0x23gaaf["r"] || -(898358 ^ 898359),
                    "c": _0x23gaaf["c"] || -(960171 ^ 960170)
        };
    }
    else {
        var _0x32d1fb = (601947 ^ 601950) + (858186 ^ 858187);
        var _0x0e8f = _0x64125d();
        _0x32d1fb = (284649 ^ 284651) + (784542 ^ 784535);
        if (!_0x0e8f["length"]) {
            _0x77_0x317["_pendingSpawn"] = !![];
            return;
        }
        var _0x200b = {};
        for (var _0xb1b9ff = 327286 ^ 327286; _0xb1b9ff < _0x77_0x317["_usedPointKeys"]["length"]; _0xb1b9ff++)
            _0x200b[_0x77_0x317["_usedPointKeys"][_0xb1b9ff]] = !![];
        var _0xg5b = (193132 ^ 193125) + (288087 ^ 288084);
        var _0xddf32f = [];
        _0xg5b = "fknoqp";
        for (var _0x06g1fe = 614739 ^ 614739; _0x06g1fe < _0x0e8f["length"]; _0x06g1fe++) {
            if (!_0x200b[_0x0e8f[_0x06g1fe]["r"] + "_" + _0x0e8f[_0x06g1fe]["c"]])
                _0xddf32f["push"](_0x0e8f[_0x06g1fe]);
        }
        if (!_0xddf32f["length"])
            _0xddf32f = _0x0e8f;
        _0x8gc78b = _0xddf32f[Math["floor"](Math["random"]() * _0xddf32f["length"])];
    } var _0xf0f = _0x8gc78b["r"] >= (336284 ^ 336284) ? _0x8gc78b["r"] + "_" + _0x8gc78b["c"] : _0x8gc78b["wx"] + "_" + _0x8gc78b["wy"]; _0x77_0x317["_pendingCrash"] = {
        "wx": _0x8gc78b["wx"],
                "wy": _0x8gc78b["wy"],
                "pointKey": _0xf0f,
                "r": _0x8gc78b["r"],
                "c": _0x8gc78b["c"]
    }; _0x77_0x317["status"] = "gnimocni".split("").reverse().join(""); _0x3e567e(); _0xd1f8e(); _0x6cbb(_0x8gc78b["wx"], _0x8gc78b["wy"], function () { if (!_0x77_0x317["running"] || !_0x77_0x317["_pendingCrash"])
        return; var _0xe1b98f = (585773 ^ 585774) + (397777 ^ 397783); var _0x5103a = _0x77_0x317["_pendingCrash"]; _0xe1b98f = "fjenia"; _0x77_0x317["_pendingCrash"] = null; _0x77_0x317["_soundTimer"] = null; _0xf868cc(_0x5103a); }); }
    function _0xf868cc(pending) { var _0x451ga = pending["wx"], _0x2749c = pending["wy"], _0xa6e5c = pending["pointKey"]; var _0xde5 = _0x6ec34e(), _0xef2ada = _0x67417d(); var _0x98dde = {
        "instHeli": null,
                "instSmoke": null,
                "debrisInsts": [],
                "anchorWx": _0x451ga,
                "anchorWy": _0x2749c,
                "anchorR": pending["r"],
                "anchorC": pending["c"],
                "chestInsts": []
    }; if (_0xde5 && _0xef2ada) {
        var _0x7ge2dd = (902225 ^ 902232) + (991100 ^ 991103);
        var _0x3dbe1a = _0xcdafb["heliTypeIdx"];
        _0x7ge2dd = (637109 ^ 637104) + (140093 ^ 140094);
        if (!_0x3dbe1a || _0x3dbe1a < (776195 ^ 776195))
            _0x3dbe1a = Math["random"]() < 0.5 ? 892971 ^ 894298 : 115013 ^ 115123;
        _0x98dde["instHeli"] = _0x88a2da(_0x3dbe1a, _0x451ga, _0x2749c, _0xef2ada, _0xde5);
        if (_0x98dde["instHeli"])
            _0x4aec(_0x98dde["instHeli"], 145796 ^ 145797, _0xba3["fadeDuration"], null);
        var _0xdb4f9a = _0xde5[K["types"]][750090 ^ 749867];
        if (_0xdb4f9a && _0xdb4f9a["be"]) {
            try {
                var _0xcba5ef = (249928 ^ 249921) + (313882 ^ 313880);
                var _0x1db1f = _0xde5["Sg"](_0xdb4f9a["be"], _0xef2ada, false, _0x451ga, _0x2749c, false);
                _0xcba5ef = "kfacgb";
                if (_0x1db1f) {
                    var _0xd5b2 = _0xcdafb["smokeScale"] || 1.4;
                    if (_0x1db1f["width"])
                        _0x1db1f["width"] *= _0xd5b2;
                    if (_0x1db1f["height"])
                        _0x1db1f["height"] *= _0xd5b2;
                    _0x1db1f[K["bboxFn"]] && _0x1db1f[K["bboxFn"]]();
                    _0x98dde["instSmoke"] = _0x1db1f;
                }
            }
            catch (e) { }
        }
        var _0xff707d = _0xcdafb["debrisCount"] || 616907 ^ 616931;
        var _0xdfe42c = (651463 ^ 651470) + (942198 ^ 942197);
        var _0xc1g = _0xde5[K["types"]][115193 ^ 115254];
        _0xdfe42c = 818849 ^ 818852;
        if (_0xc1g && _0xc1g["be"]) {
            if (_0x78_0x5ca["length"] > (661793 ^ 661793)) {
                for (var _0x3747d = 129606 ^ 129606; _0x3747d < _0x78_0x5ca["length"]; _0x3747d++) {
                    try {
                        var _0x654cce = (253008 ^ 253012) + (483482 ^ 483486);
                        var _0x932d = _0x78_0x5ca[_0x3747d];
                        _0x654cce = 652881 ^ 652884;
                        var _0x89e9db = (443950 ^ 443942) + (126657 ^ 126664);
                        var _0x83_0xbec = Math["round"](_0x451ga + (_0x932d["dx"] || 710945 ^ 710945));
                        _0x89e9db = (295218 ^ 295217) + (879611 ^ 879608);
                        var _0x4df2 = Math["round"](_0x2749c + (_0x932d["dy"] || 803761 ^ 803761));
                        var _0x7afd = _0xde5["Sg"](_0xc1g["be"], _0xef2ada, false, _0x83_0xbec, _0x4df2, false);
                        if (_0x7afd) {
                            _0x7afd["opacity"] = _0xcdafb["debrisOpacity"];
                            _0x7afd[K["bboxFn"]] && _0x7afd[K["bboxFn"]]();
                            _0x98dde["debrisInsts"]["push"](_0x7afd);
                        }
                    }
                    catch (e) { }
                }
            }
            else {
                for (var _0x9d927b = 709349 ^ 709349; _0x9d927b < _0xff707d; _0x9d927b++) {
                    try {
                        var _0x7e9ga = (560917 ^ 560919) + (608069 ^ 608064);
                        var _0x251g4g = Math["random"]() * Math["PI"] * (751957 ^ 751959);
                        _0x7e9ga = "glklka".split("").reverse().join("");
                        var _0x81gf = (177497 ^ 177479) + Math["random"]() * (570927 ^ 571111);
                        var _0xfa5 = Math["round"](_0x451ga + Math["cos"](_0x251g4g) * _0x81gf);
                        let _0x722c5f;
                        var _0xbe5ca = Math["round"](_0x2749c + Math["sin"](_0x251g4g) * _0x81gf);
                        _0x722c5f = (216096 ^ 216097) + (550470 ^ 550464);
                        var _0x74a8cd = _0xde5["Sg"](_0xc1g["be"], _0xef2ada, false, _0xfa5, _0xbe5ca, false);
                        if (_0x74a8cd) {
                            _0x74a8cd["opacity"] = _0xcdafb["debrisOpacity"];
                            _0x74a8cd[K["bboxFn"]] && _0x74a8cd[K["bboxFn"]]();
                            _0x98dde["debrisInsts"]["push"](_0x74a8cd);
                        }
                    }
                    catch (e) { }
                }
            }
        }
    } _0x77_0x317["crashes"]["push"](_0x98dde); _0x73e(_0x98dde); _0x3d9gd(_0x98dde); _0x77_0x317["_usedPointKeys"]["push"](_0xa6e5c); if (_0x77_0x317["_usedPointKeys"]["length"] > (321137 ^ 321143))
        _0x77_0x317["_usedPointKeys"]["shift"](); if (_0xcdafb["enabled"]) {
        var _0x1e279b = (711234 ^ 711235) + (688657 ^ 688657);
        var _0x2c71ed = _0x8f_0x7af();
        _0x1e279b = (689725 ^ 689721) + (711697 ^ 711701);
        _0x77_0x317["status"] = "active";
        _0x77_0x317["spawnedAtTimer"] = _0x2c71ed;
        _0x77_0x317["despawnAtTimer"] = _0x2c71ed !== null ? _0x2c71ed + _0xcdafb["duration"] : null;
        _0x77_0x317["nextSpawnAtTimer"] = null;
    } _0xd1f8e(); _0x3e567e(); }
    function _0xf4_0x8ae() { if (_0x77_0x317["_soundTimer"]) {
        clearTimeout(_0x77_0x317["_soundTimer"]);
        _0x77_0x317["_soundTimer"] = null;
    } _0x77_0x317["_pendingCrash"] = null; for (var _0xc277cf = 583569 ^ 583569; _0xc277cf < _0x77_0x317["crashes"]["length"]; _0xc277cf++) {
        var _0x5399cf = _0x77_0x317["crashes"][_0xc277cf];
        var _0xdfg = (438332 ^ 438329) + (466647 ^ 466641);
        var _0x4cgb = [
            _0x5399cf["instHeli"], _0x5399cf["instSmoke"], _0x5399cf["inst1393"], _0x5399cf["inst246"]
        ];
        _0xdfg = (276289 ^ 276288) + (821843 ^ 821844);
        for (var _0x2be9f = 802421 ^ 802421; _0x2be9f < _0x4cgb["length"]; _0x2be9f++) {
            if (_0x4cgb[_0x2be9f]) {
                try {
                    _0x4cgb[_0x2be9f]["visible"] = false;
                    _0x4cgb[_0x2be9f]["x"] = -(78192 ^ 127520);
                    _0x4cgb[_0x2be9f]["y"] = -(600373 ^ 649829);
                    _0x4cgb[_0x2be9f][K["bboxFn"]] && _0x4cgb[_0x2be9f][K["bboxFn"]]();
                }
                catch (e) { }
            }
        }
        if (_0x5399cf["debrisInsts"]) {
            for (var _0xb2276c = 890889 ^ 890889; _0xb2276c < _0x5399cf["debrisInsts"]["length"]; _0xb2276c++) {
                let _0xeacgc;
                var _0x264fd = _0x5399cf["debrisInsts"][_0xb2276c];
                _0xeacgc = "cfiine";
                if (_0x264fd) {
                    try {
                        _0x264fd["visible"] = false;
                        _0x264fd["x"] = -(369453 ^ 352381);
                        _0x264fd["y"] = -(594825 ^ 643289);
                        _0x264fd[K["bboxFn"]] && _0x264fd[K["bboxFn"]]();
                    }
                    catch (e) { }
                }
            }
        }
        if (_0x5399cf["chestInsts"]) {
            for (var _0xcg2 = 840509 ^ 840509; _0xcg2 < _0x5399cf["chestInsts"]["length"]; _0xcg2++) {
                let _0xe8969a;
                var _0x7a36c = _0x5399cf["chestInsts"][_0xcg2];
                _0xe8969a = 744480 ^ 744485;
                if (_0x7a36c["lockerKey"] && _0xe51a0c[_0x7a36c["lockerKey"]]) {
                    if (_0xa6_0x3b7 === _0x7a36c["lockerKey"])
                        _0x8dfcf();
                    try {
                        _0xecfce(_0xe51a0c[_0x7a36c["lockerKey"]]);
                    }
                    catch (e) { }
                    delete _0xe51a0c[_0x7a36c["lockerKey"]];
                }
                if (_0x7a36c["configKey"])
                    delete _0x7eed[_0x7a36c["configKey"]];
            }
        }
    } _0x77_0x317["crashes"] = []; }
    function _0x1c4c8b(_0xc9bccf) { if (!_0x77_0x317["running"] || !_0xcdafb["enabled"])
        return; var _0xbafca = _0x8f_0x7af(); _0xc9bccf = (911023 ^ 911018) + (670539 ^ 670536); if (_0xbafca === null)
        return; _0x77_0x317["lastTimerVal"] = _0xbafca; if (_0x77_0x317["status"] === "incoming") {
        _0x3e567e();
        return;
    } if (_0x77_0x317["status"] === "active") {
        if (_0x77_0x317["despawnAtTimer"] === null)
            _0x77_0x317["despawnAtTimer"] = _0xbafca + _0xcdafb["duration"];
        if (_0xbafca >= _0x77_0x317["despawnAtTimer"])
            _0x77_0x317["status"] = "despawning";
    }
    else if (_0x77_0x317["status"] === "gninwapsed".split("").reverse().join("")) {
        var _0x64216c = _0x8f143f;
        var _0x6g2 = !![];
        if (_0x64216c) {
            for (var _0xcbb = 558809 ^ 558809; _0xcbb < _0x77_0x317["crashes"]["length"]; _0xcbb++) {
                var _0x6c59f = _0x77_0x317["crashes"][_0xcbb];
                var _0xbggf = _0x64216c["x"] - _0x6c59f["anchorWx"], _0xbc02a = _0x64216c["y"] - _0x6c59f["anchorWy"];
                if (Math["sqrt"](_0xbggf * _0xbggf + _0xbc02a * _0xbc02a) < _0xcdafb["despawnRadius"]) {
                    _0x6g2 = false;
                    break;
                }
            }
        }
        if (_0x6g2) {
            _0xf4_0x8ae();
            _0x77_0x317["status"] = "waiting";
            _0x77_0x317["nextSpawnAtTimer"] = _0xbafca + _0xcdafb["spawnInterval"];
        }
    }
    else if (_0x77_0x317["status"] === "waiting") {
        if (_0x77_0x317["nextSpawnAtTimer"] !== null && _0xbafca >= _0x77_0x317["nextSpawnAtTimer"]) {
            _0x77_0x317["nextSpawnAtTimer"] = null;
            _0x77_0x317["status"] = "eldi".split("").reverse().join("");
            _0x522dd();
        }
    } _0x3e567e(); }
    function _0x44_0x4e3() { if (_0x77_0x317["running"])
        return; _0x77_0x317["running"] = !![]; _0x77_0x317["status"] = "idle"; _0x77_0x317["spawnedAtTimer"] = null; _0x77_0x317["despawnAtTimer"] = null; _0x77_0x317["nextSpawnAtTimer"] = null; _0x77_0x317["lastTimerVal"] = null; _0xc0558g(); _0x522dd(); }
    function _0x66f3f() { _0x77_0x317["running"] = false; _0x77_0x317["_pendingSpawn"] = false; _0x77_0x317["status"] = "eldi".split("").reverse().join(""); _0x77_0x317["spawnedAtTimer"] = null; _0x77_0x317["despawnAtTimer"] = null; _0x77_0x317["nextSpawnAtTimer"] = null; if (_0x77_0x317["_soundTimer"]) {
        clearTimeout(_0x77_0x317["_soundTimer"]);
        _0x77_0x317["_soundTimer"] = null;
    } _0x77_0x317["_pendingCrash"] = null; _0xf4_0x8ae(); _0x77_0x317["spawnedLevel"] = null; _0xd1f8e(); }
    function _0xf7b77b() { try {
        localStorage["setItem"](_0x817ff, JSON["stringify"]({
            "v": 1,
                    "chests": _0x8d7eb["chests"],
                    "itemSpawns": _0x8d7eb["itemSpawns"],
                    "debris": _0x78_0x5ca
        }));
    }
    catch (e) { } }
    function _0xc0558g() { try {
        var _0x9gd2f = localStorage["getItem"](_0x817ff);
        if (!_0x9gd2f)
            return;
        var _0x779adb = (184716 ^ 184708) + (549085 ^ 549082);
        var _0x3eg = JSON["parse"](_0x9gd2f);
        _0x779adb = "hmcecc";
        if (_0x3eg && _0x3eg["v"] === (658171 ^ 658170)) {
            if (Array["isArray"](_0x3eg["chests"]))
                _0x8d7eb["chests"] = _0x3eg["chests"];
            if (Array["isArray"](_0x3eg["itemSpawns"]))
                _0x8d7eb["itemSpawns"] = _0x3eg["itemSpawns"];
            if (Array["isArray"](_0x3eg["debris"]))
                _0x78_0x5ca = _0x3eg["debris"];
        }
    }
    catch (e) { } }
    function _0xg3gbdf(crash, lockerKeys) { var _0x1291d = crash["instHeli"] || crash["inst1393"] || crash["inst246"]; if (!_0x1291d || _0x1291d["__mdzHeliChestHooked"])
        return; var _0x782e = (537957 ^ 537952) + (125705 ^ 125705); var _0xg1fd = _0x1291d[K["drawGL"]]; _0x782e = (836496 ^ 836497) + (414787 ^ 414788); _0x1291d[K["drawGL"]] = function (glw) { if (_0xg1fd)
        _0xg1fd["call"](this, glw); var _0xe7d5b = (158766 ^ 158765) + (354576 ^ 354580); var _0xb632e = _0xg2_0x99g(_0x6ec34e()); _0xe7d5b = (980052 ^ 980054) + (540784 ^ 540793); var _0x5344fd = (875837 ^ 875833) + (150790 ^ 150790); var _0x77b6ea = _0x8f143f; _0x5344fd = "ccpkom"; for (var _0xd27d = 134499 ^ 134499; _0xd27d < lockerKeys["length"]; _0xd27d++) {
        var _0x1725ca = _0xe51a0c[lockerKeys[_0xd27d]];
        if (!_0x1725ca)
            continue;
        var _0xe29b = _0x4ae(_0x1725ca);
        var _0x4e11g = _0x40_0xg74(_0x1725ca);
        _0x1725ca["_drawVisible"] = !![];
        _0x1725ca["_drawCX"] = _0xe29b;
        _0x1725ca["_drawCY"] = _0x4e11g;
        let _0xa4f;
        var _0xe9b4b = _0x1725ca["conf"];
        _0xa4f = 585452 ^ 585455;
        var _0x2694cg = (833265 ^ 833265) + (600974 ^ 600972);
        var _0xead2 = _0x1725ca["state"] === "nepo".split("").reverse().join("");
        _0x2694cg = (221883 ^ 221886) + (523315 ^ 523317);
        var _0xd0b = _0x77b6ea ? Math["hypot"](_0x77b6ea["x"] - _0xe29b, _0x77b6ea["y"] - _0x4e11g) : 404513 ^ 405446;
        var _0x192 = _0xead2 ? _0xd0b <= _0xd5_0x7dc["highlightDist"] ? _0xe9b4b["openHL"] : _0xe9b4b["open"] : _0xd0b <= _0xd5_0x7dc["highlightDist"] ? _0xe9b4b["closedHL"] : _0xe9b4b["closed"];
        if (_0x192) {
            var _0x5gc43b = _0xdg0b(_0x192), _0x193 = _0xe3_0x013(glw, _0x192);
            if (_0x193 && _0x5gc43b && _0x5gc43b["complete"]) {
                glw[K["setTex"]](_0x193);
                glw[K["setOpacity"]](856712 ^ 856713);
                var _0x7ce4ef = _0x5gc43b["naturalWidth"] || 821869 ^ 821829, _0x3ff = _0x5gc43b["naturalHeight"] || 127211 ^ 127171;
                glw[K["quad"]](_0xe29b - _0x7ce4ef / (792582 ^ 792580), _0x4e11g - _0x3ff / (614779 ^ 614777), _0xe29b + _0x7ce4ef / (103306 ^ 103304), _0x4e11g - _0x3ff / (261149 ^ 261151), _0xe29b + _0x7ce4ef / (182970 ^ 182968), _0x4e11g + _0x3ff / (605327 ^ 605325), _0xe29b - _0x7ce4ef / (206087 ^ 206085), _0x4e11g + _0x3ff / (428858 ^ 428856));
                if (_0xa6_0x3b7 === lockerKeys[_0xd27d] || _0x1725ca["state"] === "open") {
                    _0x4cChestRadius(glw, _0xe29b, _0x4e11g, _0xd5_0x7dc["interactionRadius"], _0xa6_0x3b7 === lockerKeys[_0xd27d]);
                }
                _0x1725ca["_drawSrc"] = _0x192;
                if (!_0xb632e && _0x1725ca["showButton"] && (_0x1725ca["state"] === "closed" || _0x1725ca["state"] === "nepo".split("").reverse().join("") && _0xe91a9d(_0x1725ca))) {
                    let _0xg043db;
                    var _0x052c = _0xb55c3f(_0x1725ca);
                    _0xg043db = "heoljd";
                    var _0x229d2b = _0xdg0b(_0x052c), _0xd9e = _0xe3_0x013(glw, _0x052c);
                    if (_0xd9e && _0x229d2b && _0x229d2b["complete"]) {
                        glw[K["setTex"]](_0xd9e);
                        var _0x7a37ef = 0.8, _0x738e = (_0x229d2b["naturalWidth"] || 945444 ^ 945466) * _0x7a37ef, _0x483f2a = (_0x229d2b["naturalHeight"] || 299083 ^ 299093) * _0x7a37ef;
                        var _0xf9f2d = _0x4e11g - _0x3ff / (196252 ^ 196254) - _0xd5_0x7dc["btnOffsetPx"] - _0x483f2a / (699473 ^ 699475);
                        glw[K["quad"]](_0xe29b - _0x738e / (788356 ^ 788358), _0xf9f2d - _0x483f2a / (424235 ^ 424233), _0xe29b + _0x738e / (948438 ^ 948436), _0xf9f2d - _0x483f2a / (392280 ^ 392282), _0xe29b + _0x738e / (425564 ^ 425566), _0xf9f2d + _0x483f2a / (620219 ^ 620217), _0xe29b - _0x738e / (146177 ^ 146179), _0xf9f2d + _0x483f2a / (389981 ^ 389983));
                        _0x1725ca["_btnCX"] = _0xe29b;
                        _0x1725ca["_btnCY"] = _0xf9f2d;
                        _0x1725ca["_btnW"] = _0x738e;
                        _0x1725ca["_btnH"] = _0x483f2a;
                        _0x1725ca["_btnLayer"] = this[K["layer"]];
                    }
                }
            }
        }
    } }; _0x1291d["__mdzHeliChestHooked"] = !![]; }
    function _0x73e(crash) { if (!_0x8d7eb["chests"]["length"])
        return; if (!crash["chestInsts"])
        crash["chestInsts"] = []; var _0xf2ed = (673438 ^ 673435) + (959772 ^ 959768); var _0xdb2 = []; _0xf2ed = (526915 ^ 526912) + (844593 ^ 844600); for (var _0x87c6dc = 534593 ^ 534593; _0x87c6dc < _0x8d7eb["chests"]["length"]; _0x87c6dc++) {
        var _0x50b = (705778 ^ 705782) + (143281 ^ 143287);
        var _0xda2d1f = _0x8d7eb["chests"][_0x87c6dc];
        _0x50b = 119908 ^ 119911;
        var _0xacf = typeof _0xda2d1f["spawnChance"] === "number" ? _0xda2d1f["spawnChance"] : 425510 ^ 425511;
        if (Math["random"]() > _0xacf)
            continue;
        var _0xc0cc = Math["round"](crash["anchorWx"] + (_0xda2d1f["offsetX"] || 203521 ^ 203521));
        var _0x96d = Math["round"](crash["anchorWy"] + (_0xda2d1f["offsetY"] || 797162 ^ 797162));
        var _0x6e75a = (434212 ^ 434214) + (231832 ^ 231834);
        var _0xafg1df = "heli_chest_" + _0xc0cc + "_" + _0x96d;
        _0x6e75a = 947491 ^ 947490;
        var _0xc963b = _0xc0cc + "_" + _0x96d;
        var _0x48f = _0x41_0x938(_0xc963b, 619341 ^ 619341);
        if (_0xe51a0c[_0x48f]) {
            if (_0xa6_0x3b7 === _0x48f)
                _0x8dfcf();
            try {
                _0xecfce(_0xe51a0c[_0x48f]);
            }
            catch (e) { }
            delete _0xe51a0c[_0x48f];
        }
        var _0xd23e3f = (426581 ^ 426588) + (600207 ^ 600206);
        var _0x64da = _0xdd3b6a({
            "chestTypeId": _0xda2d1f["chestTypeId"] || "1epyt".split("").reverse().join(""),
                    "offsetX": 0,
                    "offsetY": 0
        });
        _0xd23e3f = 358675 ^ 358677;
        _0xe51a0c[_0x48f] = {
            "state": "closed",
                    "lootTime": 0,
                    "x": _0xc0cc,
                    "y": _0x96d,
                    "conf": _0x64da,
                    "showButton": false,
                    "mapKey": _0x48f,
                    "baseMapKey": _0xc963b,
                    "markerIndex": 0,
                    "structureType": _0xafg1df,
                    "chestTypeId": _0x64da["chestTypeId"] || null,
                    "inventory": _0xf5_0x8d8(_0x64da),
                    "posOffX": 0,
                    "posOffY": 0,
                    "searched": false,
                    "unlocked": _0x64da["locked"] !== !![],
                    "collisionInstances": [],
                    "_isHeliCrashChest": !![]
        };
        _0xdb2["push"](_0x48f);
        crash["chestInsts"]["push"]({
            "lockerKey": _0x48f,
                    "configKey": _0xafg1df
        });
    } _0xg3gbdf(crash, _0xdb2); }
    function _0x3d9gd(crash) { if (!_0x8d7eb["itemSpawns"]["length"])
        return; if (typeof c2_callFunction === "undefined")
        return; for (var _0x0ee5fa = 223107 ^ 223107; _0x0ee5fa < _0x8d7eb["itemSpawns"]["length"]; _0x0ee5fa++) {
        var _0x45968f = (824866 ^ 824875) + (634881 ^ 634884);
        var _0x41923e = _0x8d7eb["itemSpawns"][_0x0ee5fa];
        _0x45968f = (440057 ^ 440059) + (347526 ^ 347520);
        var _0xa7ab = (649106 ^ 649104) + (610782 ^ 610779);
        var _0xf8ea3c = Math["round"](crash["anchorWx"] + (_0x41923e["offsetX"] || 360389 ^ 360389));
        _0xa7ab = (155038 ^ 155030) + (811827 ^ 811829);
        var _0x51c = Math["round"](crash["anchorWy"] + (_0x41923e["offsetY"] || 380676 ^ 380676));
        if (!_0x41923e["loot"] || !_0x41923e["loot"]["length"])
            continue;
        var _0x196 = 254794 ^ 254794;
        for (var _0x045dfd = 174240 ^ 174240; _0x045dfd < _0x41923e["loot"]["length"]; _0x045dfd++)
            _0x196 += _0x41923e["loot"][_0x045dfd]["weight"] || 445086 ^ 445087;
        var _0x2bcfcd = Math["random"]() * _0x196, _0xbgbff = 960500 ^ 960500, _0x52187f = _0x41923e["loot"][885565 ^ 885565]["id"];
        for (var _0xb1c7dd = 162012 ^ 162012; _0xb1c7dd < _0x41923e["loot"]["length"]; _0xb1c7dd++) {
            _0xbgbff += _0x41923e["loot"][_0xb1c7dd]["weight"] || 752156 ^ 752157;
            if (_0x2bcfcd <= _0xbgbff) {
                _0x52187f = _0x41923e["loot"][_0xb1c7dd]["id"];
                break;
            }
        }
        try {
            c2_callFunction("Spawn_drop", [
                _0x52187f, _0xf8ea3c, _0x51c, -(607559 ^ 607558)
            ]);
        }
        catch (e) { }
    } }
    function _0x5866da() { var _0xe27a = "<div style=\"border-top:1px solid rgba(255,255,255,0.12);margin-top:8px;padding-top:6px;font-size:11px\">"; _0xe27a += "<strong style=\"font-size:12px\">&#128641; Helicrash Event</strong><br>"; if (!_0x77_0x317["running"]) {
        _0xe27a += ">naps/<deppotS>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("");
    }
    else if (_0x77_0x317["_pendingSpawn"]) {
        _0xe27a += "<span style=\"color:#fc0\">Pending — waiting for map data...</span>";
    }
    else if (_0x77_0x317["status"] === "incoming") {
        _0xe27a += "<span style=\"color:#fa5\">&#127756; INCOMING — distant sound playing...</span>";
        if (_0x77_0x317["_pendingCrash"]) {
            _0xe27a += "<br><span style=\"color:#bcae94\">Landing at (" + _0x77_0x317["_pendingCrash"]["wx"] + ", " + _0x77_0x317["_pendingCrash"]["wy"] + ")</span>";
        }
    }
    else if (_0xcdafb["enabled"]) {
        var _0xf9307b = (296875 ^ 296878) + (432977 ^ 432976);
        var t = _0x77_0x317["lastTimerVal"];
        _0xf9307b = (650062 ^ 650062) + (721567 ^ 721559);
        if (_0x77_0x317["status"] === "active") {
            var _0x978fe = _0x77_0x317["despawnAtTimer"] !== null && t !== null ? Math["max"](208013 ^ 208013, _0x77_0x317["despawnAtTimer"] - t) : "?";
            _0xe27a += "<span style=\"color:#5cf\">ACTIVE — " + _0x77_0x317["crashes"]["length"] + " crash(es)</span><br>";
            _0xe27a += " :ni snwapseD>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("") + _0x978fe + " ticks</span><br>";
        }
        else if (_0x77_0x317["status"] === "gninwapsed".split("").reverse().join("")) {
            _0xe27a += "<span style=\"color:#fa5\">DESPAWNING — waiting for player to leave</span><br>";
            _0xe27a += "<span style=\"color:#bcae94\">Radius: " + _0xcdafb["despawnRadius"] + " units</span><br>";
        }
        else if (_0x77_0x317["status"] === "waiting") {
            var _0x486c5a = _0x77_0x317["nextSpawnAtTimer"] !== null && t !== null ? Math["max"](330282 ^ 330282, _0x77_0x317["nextSpawnAtTimer"] - t) : "?";
            _0xe27a += "<span style=\"color:#fc0\">WAITING — next in " + _0x486c5a + ">rb<>naps/<skcit ".split("").reverse().join("");
        }
        else {
            _0xe27a += "<span style=\"color:#5cf\">Timer idle</span><br>";
        }
        for (var _0xg7e49b = 753201 ^ 753201; _0xg7e49b < _0x77_0x317["crashes"]["length"]; _0xg7e49b++) {
            let _0x163a;
            var _0x8a14a = _0x77_0x317["crashes"][_0xg7e49b];
            _0x163a = (356974 ^ 356973) + (823168 ^ 823176);
            _0xe27a += "#;psbn&;psbn&>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("") + (_0xg7e49b + (497666 ^ 497667)) + ": (" + _0x8a14a["anchorWx"] + "," + _0x8a14a["anchorWy"] + "), " + (_0x8a14a["chestInsts"] ? _0x8a14a["chestInsts"]["length"] : 636217 ^ 636217) + " ,)s(tsehc ".split("").reverse().join("") + (_0x8a14a["debrisInsts"] ? _0x8a14a["debrisInsts"]["length"] : 176402 ^ 176402) + ">rb<>naps/<sirbed ".split("").reverse().join("");
        }
    } _0xe27a += "</div>"; return _0xe27a; }
    function _0x82fe() { var _0xeaga = 0.4; var _0x2935f = (239636 ^ 239633) + (859470 ^ 859466); var _0xd349a = 118069 ^ 117973; _0x2935f = (162546 ^ 162550) + (698561 ^ 698562); var _0x11fa = (864996 ^ 865004) + (233169 ^ 233175); var _0x2ba7f = 223576 ^ 223632; _0x11fa = (562967 ^ 562967) + (125153 ^ 125157); var _0xabe5a = _0xd349a / (670295 ^ 670293), _0x1341e = _0x2ba7f / (418930 ^ 418928); var _0x73c2c = "<div style=\"font-size:11px;margin-bottom:6px;color:#bcae94\">Drag <span style=\"color:#ffd700;font-weight:700\">C</span> (chests) and <span style=\"color:#40ff80;font-weight:700\">I</span> (item spawns) relative to crash center <span style=\"color:#5cf\">&#8853;</span>. Loot drops on spawn.</div>"; _0x73c2c += "<div style=\"display:flex;gap:6px;margin-bottom:6px;flex-wrap:wrap\">"; _0x73c2c += "<button data-heli-layout-add=\"chest\" style=\"padding:4px 8px;font-size:11px;background:rgba(200,160,40,0.2);border:1px solid #a87020\">+ Add Chest</button>"; _0x73c2c += "<button data-heli-layout-add=\"itemSpawn\" style=\"padding:4px 8px;font-size:11px;background:rgba(40,160,80,0.2);border:1px solid #206040\">+ Add Item Spawn</button>"; if (_0xd21e !== null) {
        _0x73c2c += "<button data-heli-layout-duplicate style=\"padding:4px 8px;font-size:11px;background:rgba(60,120,200,0.2);border:1px solid #2060a0\">&#9645; Duplicate</button>";
        _0x73c2c += ">nottub/<eteleD ;semit&>\"03030a# dilos xp1:redrob;)2.0,06,06,002(abgr:dnuorgkcab;xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts eteled-tuoyal-ileh-atad nottub<".split("").reverse().join("");
    } _0x73c2c += ">nottub/<tuoyaL evaS ;091821#&>\"xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts evas-tuoyal-ileh-atad nottub<".split("").reverse().join(""); _0x73c2c += "<button data-heli-layout-reset style=\"padding:4px 8px;font-size:11px;background:rgba(100,60,20,0.2);border:1px solid #805020\">&#8635; Default</button>"; _0x73c2c += "</div>"; _0x73c2c += "<div data-heli-layout-canvas style=\"position:relative;width:" + _0xd349a + ":thgieh;xp".split("").reverse().join("") + _0x2ba7f + "px;background:#0d1117;border:1px solid #334;overflow:hidden;user-select:none\">"; _0x73c2c += "<div style=\"position:absolute;left:" + _0xabe5a + "px;top:0;width:1px;height:" + _0x2ba7f + "px;background:rgba(90,200,255,0.12);pointer-events:none\"></div>"; _0x73c2c += "<div style=\"position:absolute;left:0;top:" + _0x1341e + ":htdiw;xp".split("").reverse().join("") + _0xd349a + ">vid/<>\"enon:stneve-retniop;)21.0,552,002,09(abgr:dnuorgkcab;xp1:thgieh;xp".split("").reverse().join(""); _0x73c2c += ":tfel;etulosba:noitisop\"=elyts vid<".split("").reverse().join("") + (_0xabe5a - (621198 ^ 621195)) + "px;top:" + (_0x1341e - (823782 ^ 823779)) + "px;width:10px;height:10px;border-radius:5px;background:#5cf;pointer-events:none\" title=\"Crash anchor\"></div>"; _0x73c2c += ":tfel;etulosba:noitisop\"=elyts vid<".split("").reverse().join("") + (_0xabe5a - (404561 ^ 404594)) + "px;top:" + (_0x1341e - (321754 ^ 321747)) + "px;width:70px;height:18px;background:rgba(80,50,20,0.4);border:1px dashed rgba(200,150,50,0.5);color:#a07030;font-size:9px;text-align:center;line-height:18px;pointer-events:none;border-radius:2px\">HELICRASH</div>"; for (var _0x08d3f = 535509 ^ 535509; _0x08d3f < _0x8d7eb["chests"]["length"]; _0x08d3f++) {
        var _0x96be4g = (526353 ^ 526360) + (790831 ^ 790824);
        var _0xa4bc = _0x8d7eb["chests"][_0x08d3f];
        _0x96be4g = "nhenmb";
        var _0xfe24ac = Math["round"](_0xabe5a + (_0xa4bc["offsetX"] || 336976 ^ 336976) * _0xeaga - (593158 ^ 593164));
        var _0xb3936f = Math["round"](_0x1341e + (_0xa4bc["offsetY"] || 543567 ^ 543567) * _0xeaga - (666959 ^ 666949));
        var _0x85_0xb74 = _0xd21e && _0xd21e["type"] === "chest" && _0xd21e["idx"] === _0x08d3f;
        _0x73c2c += "<div data-heli-layout-item data-layout-item-type=\"chest\" data-layout-item-idx=\"" + _0x08d3f + " \"".split("").reverse().join("") + "style=\"position:absolute;left:" + _0xfe24ac + "px;top:" + _0xb3936f + "px;width:20px;height:20px;background:#c8a040;" + "border:2px solid " + (_0x85_0xb74 ? "fff#".split("").reverse().join("") : "007dff#".split("").reverse().join("")) + ";cursor:move;z-index:3;border-radius:2px;" + "text-align:center;line-height:16px;font-size:10px;color:#000;touch-action:none\" " + "title=\"Chest " + (_0x08d3f + (375209 ^ 375208)) + "( ".split("").reverse().join("") + (_0xa4bc["offsetX"] || 599507 ^ 599507) + "," + (_0xa4bc["offsetY"] || 769078 ^ 769078) + ")\">C</div>";
    } for (var _0xg5b2 = 905073 ^ 905073; _0xg5b2 < _0x8d7eb["itemSpawns"]["length"]; _0xg5b2++) {
        var _0x86_0xf1g = _0x8d7eb["itemSpawns"][_0xg5b2];
        var _0x87258c = (395905 ^ 395906) + (796042 ^ 796041);
        var _0x29agd = Math["round"](_0xabe5a + (_0x86_0xf1g["offsetX"] || 880854 ^ 880854) * _0xeaga - (807453 ^ 807447));
        _0x87258c = 837207 ^ 837203;
        var _0x2b311c = Math["round"](_0x1341e + (_0x86_0xf1g["offsetY"] || 105927 ^ 105927) * _0xeaga - (627930 ^ 627920));
        var _0x22344d = (258677 ^ 258677) + (414607 ^ 414601);
        var _0xb3f2a = _0xd21e && _0xd21e["type"] === "nwapSmeti".split("").reverse().join("") && _0xd21e["idx"] === _0xg5b2;
        _0x22344d = (954933 ^ 954929) + (379440 ^ 379441);
        _0x73c2c += "\"=xdi-meti-tuoyal-atad \"nwapSmeti\"=epyt-meti-tuoyal-atad meti-tuoyal-ileh-atad vid<".split("").reverse().join("") + _0xg5b2 + "\" " + "style=\"position:absolute;left:" + _0x29agd + "px;top:" + _0x2b311c + ";040802#:dnuorgkcab;xp02:thgieh;xp02:htdiw;xp".split("").reverse().join("") + "border:2px solid " + (_0xb3f2a ? "fff#".split("").reverse().join("") : "#40ff80") + ";cursor:move;z-index:3;border-radius:50%;" + "text-align:center;line-height:16px;font-size:10px;color:#fff;touch-action:none\" " + " nwapS metI\"=eltit".split("").reverse().join("") + (_0xg5b2 + (471458 ^ 471459)) + "( ".split("").reverse().join("") + (_0x86_0xf1g["offsetX"] || 586398 ^ 586398) + "," + (_0x86_0xf1g["offsetY"] || 878955 ^ 878955) + ")\">I</div>";
    } _0x73c2c += "</div>"; if (_0xd21e !== null) {
        let _0x711ebe;
        var _0x87_0x91f = _0xd21e;
        _0x711ebe = 363892 ^ 363895;
        var _0x5bf = _0x87_0x91f["type"] === "chest" ? _0x8d7eb["chests"] : _0x8d7eb["itemSpawns"];
        var _0x6cd9f = _0x5bf[_0x87_0x91f["idx"]];
        if (_0x6cd9f) {
            _0x73c2c += "<div style=\"margin-top:8px;padding:6px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:4px;font-size:11px\">";
            _0x73c2c += "<strong>" + (_0x87_0x91f["type"] === "chest" ? "&#128230; Chest " : " nwapS metI ;502821#&".split("").reverse().join("")) + (_0x87_0x91f["idx"] + (561750 ^ 561751)) + ">rb<>gnorts/<".split("").reverse().join("");
            _0x73c2c += "\"=eulav \"Xtesffo\"=porp-tuoyal-ileh-atad \"rebmun\"=epyt tupni<;psbn&:X tesffO".split("").reverse().join("") + (_0x6cd9f["offsetX"] || 331039 ^ 331039) + ";psbn&;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp05:htdiw\"=elyts \"".split("").reverse().join("");
            _0x73c2c += "Y:&nbsp;<input type=\"number\" data-heli-layout-prop=\"offsetY\" value=\"" + (_0x6cd9f["offsetY"] || 313039 ^ 313039) + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"><br><br>";
            if (_0x87_0x91f["type"] === "chest") {
                _0x73c2c += ">\"xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab\"=elyts \"dIepyTtsehc\"=porp-tuoyal-ileh-atad tceles<;psbn&:epyT tsehC".split("").reverse().join("");
                for (var _0x98374a in _0x87g) {
                    _0x73c2c += "\"=eulav noitpo<".split("").reverse().join("") + _0x0d5eg(_0x98374a) + "\"" + ((_0x6cd9f["chestTypeId"] || "1epyt".split("").reverse().join("")) === _0x98374a ? " selected" : "") + ">" + _0x0d5eg(_0x87g[_0x98374a]["name"] || _0x98374a) + ">noitpo/<".split("").reverse().join("");
                }
                _0x73c2c += "</select><br>";
                var _0xd45c0e = typeof _0x6cd9f["spawnChance"] === "number" ? _0x6cd9f["spawnChance"] : 574110 ^ 574111;
                _0x73c2c += "Spawn Chance:&nbsp;<input type=\"number\" data-heli-layout-prop=\"spawnChance\" value=\"" + _0xd45c0e + "\" min=\"0\" max=\"1\" step=\"0.05\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;(0=never &bull; 1=always)&nbsp;<span style=\"color:" + (_0xd45c0e >= (738986 ^ 738987) ? "#5cf" : _0xd45c0e <= (697594 ^ 697594) ? "55f#".split("").reverse().join("") : "0cf#".split("").reverse().join("")) + ">\"007:thgiew-tnof;".split("").reverse().join("") + Math["round"](_0xd45c0e * (658834 ^ 658934)) + "%</span><br>";
            }
            else {
                var _0x33df = (734335 ^ 734327) + (322173 ^ 322168);
                var _0x2d2 = _0x6cd9f["loot"] || [];
                _0x33df = (799556 ^ 799565) + (201200 ^ 201207);
                _0x73c2c += "<strong>Loot Table</strong> (" + _0x2d2["length"] + " entries):<br>";
                _0x73c2c += "<div style=\"max-height:80px;overflow-y:auto;margin:3px 0\">";
                for (var _0x8d84f = 106916 ^ 106916; _0x8d84f < _0x2d2["length"]; _0x8d84f++) {
                    _0x73c2c += "<span style=\"color:#5cf\">ID&nbsp;" + _0x2d2[_0x8d84f]["id"] + "</span>&nbsp;<span title=\"Spawn weight: higher = picked more often. Not quantity — always spawns 1 item.\" style=\"color:#aaa;cursor:help\">wt:</span><input type=\"number\" min=\"1\" data-heli-loot-weight data-heli-loot-idx=\"" + _0x8d84f + "\" value=\"" + (_0x2d2[_0x8d84f]["weight"] || 394956 ^ 394957) + ";psbn&>\".meti 1 snwaps syawla — ytitnauq toN .netfo erom dekcip = rehgih :thgiew nwapS\"=eltit \"xp2 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp43:htdiw\"=elyts \"".split("").reverse().join("");
                    _0x73c2c += "\"=xdi-tool-ileh-atad evomer-tool-ileh-atad nottub<".split("").reverse().join("") + _0x8d84f + ">rb<>nottub/<;semit&>\")2.0,06,06,002(abgr:dnuorgkcab;xp4 0:gniddap;xp01:ezis-tnof\"=elyts \"".split("").reverse().join("");
                }
                _0x73c2c += "</div>";
                _0x73c2c += ">\"xp2:mottob-nigram;parw:parw-xelf;retnec:smeti-ngila;xp4:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("");
                _0x73c2c += "<input type=\"number\" data-heli-loot-add-id style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\" placeholder=\"ID\">";
                _0x73c2c += "<button data-heli-loot-add style=\"font-size:11px;padding:2px 6px\">Add ID</button>";
                _0x73c2c += "</div>";
            }
            _0x73c2c += "<br><button data-heli-layout-prop-apply style=\"font-size:11px;padding:2px 8px\">Apply</button>";
            _0x73c2c += "</div>";
        }
    } return _0x73c2c; }
    function _0xbe1ced(_0xfe9c, _0x17b83g) { var _0x199 = 0.8; var _0x21_0xa86 = (157320 ^ 157321) + (863379 ^ 863376); var _0xcc3 = 321928 ^ 321640; _0x21_0xa86 = 435364 ^ 435361; var _0x7db = 976295 ^ 976079; var _0x51266a = _0xcc3 / (916946 ^ 916944), _0x642b = _0x7db / (269473 ^ 269475); var _0x88_0xd2c = _0x78_0x5ca["length"] > (588181 ^ 588181); _0xfe9c = (908035 ^ 908039) + (523195 ^ 523194); var _0xd4bf = "<div style=\"font-size:11px;margin-bottom:6px;color:#bcae94\">"; _0x17b83g = "pbhfod".split("").reverse().join(""); _0xd4bf += " .>naps/<;3588#&>\"fc5#:roloc\"=elyts naps< retnec hsarc ot evitaler )sirbed 579t( >naps/<;2369#&>\"007:thgiew-tnof;326a5f#:roloc\"=elyts naps< garD".split("").reverse().join(""); _0xd4bf += (_0x88_0xd2c ? "<strong style=\"color:#5cf\">" + _0x78_0x5ca["length"] + " piece(s) — custom layout active</strong>" : "<span style=\"color:#fc0\">No layout — random scatter used</span>") + ">vid/<".split("").reverse().join(""); _0xd4bf += ">\"parw:parw-xelf;xp6:mottob-nigram;xp5:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join(""); _0xd4bf += "<button data-debris-add style=\"padding:4px 8px;font-size:11px;background:rgba(200,140,40,0.2);border:1px solid #a87020\">+ Add</button>"; if (_0x6a2dag !== null) {
        _0xd4bf += ">nottub/<puD ;5469#&>\"0a0602# dilos xp1:redrob;)2.0,002,021,06(abgr:dnuorgkcab;xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts pud-sirbed-atad nottub<".split("").reverse().join("");
        _0xd4bf += "<button data-debris-del style=\"padding:4px 8px;font-size:11px;background:rgba(200,60,60,0.2);border:1px solid #a03030\">&times; Del</button>";
    } _0xd4bf += "<button data-debris-scatter style=\"padding:4px 8px;font-size:11px;background:rgba(60,100,20,0.2);border:1px solid #507020\">&#8635; Gen Scatter</button>"; _0xd4bf += "<button data-debris-clear style=\"padding:4px 8px;font-size:11px;background:rgba(100,40,20,0.2);border:1px solid #703020\">✕ Clear All</button>"; _0xd4bf += ">nottub/<evaS ;091821#&>\"xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts evas-sirbed-atad nottub<".split("").reverse().join(""); _0xd4bf += "</div>"; _0xd4bf += "<div data-debris-canvas style=\"position:relative;width:" + _0xcc3 + "px;height:" + _0x7db + "px;background:#0d1117;border:1px solid #334;overflow:hidden;user-select:none\">"; _0xd4bf += ":tfel;etulosba:noitisop\"=elyts vid<".split("").reverse().join("") + _0x51266a + "px;top:0;width:1px;height:" + _0x7db + ">vid/<>\"enon:stneve-retniop;)21.0,552,002,09(abgr:dnuorgkcab;xp".split("").reverse().join(""); _0xd4bf += "<div style=\"position:absolute;left:0;top:" + _0x642b + "px;width:" + _0xcc3 + ">vid/<>\"enon:stneve-retniop;)21.0,552,002,09(abgr:dnuorgkcab;xp1:thgieh;xp".split("").reverse().join(""); var _0x91260e = Math["round"]((694710 ^ 694696) * _0x199), _0xbdb26a = Math["round"]((256324 ^ 256418) * _0x199); _0xd4bf += ":tfel;etulosba:noitisop\"=elyts vid<".split("").reverse().join("") + (_0x51266a - _0x91260e) + "px;top:" + (_0x642b - _0x91260e) + ":htdiw;xp".split("").reverse().join("") + _0x91260e * (989572 ^ 989574) + ":thgieh;xp".split("").reverse().join("") + _0x91260e * (513096 ^ 513098) + "px;border:1px dashed rgba(100,150,255,0.3);border-radius:50%;pointer-events:none\" title=\"Min scatter radius (30)\"></div>"; _0xd4bf += "<div style=\"position:absolute;left:" + (_0x51266a - _0xbdb26a) + ":pot;xp".split("").reverse().join("") + (_0x642b - _0xbdb26a) + ":htdiw;xp".split("").reverse().join("") + _0xbdb26a * (565378 ^ 565376) + "px;height:" + _0xbdb26a * (179291 ^ 179289) + "px;border:1px dashed rgba(255,100,100,0.3);border-radius:50%;pointer-events:none\" title=\"Max scatter radius (230)\"></div>"; _0xd4bf += "<div style=\"position:absolute;left:" + (_0x51266a - (538700 ^ 538697)) + "px;top:" + (_0x642b - (123970 ^ 123975)) + "px;width:10px;height:10px;border-radius:5px;background:#5cf;pointer-events:none\" title=\"Crash center\"></div>"; for (var _0xd30c = 288126 ^ 288126; _0xd30c < _0x78_0x5ca["length"]; _0xd30c++) {
        let _0xa824a;
        var _0x4c8bg = _0x78_0x5ca[_0xd30c];
        _0xa824a = "bofqkk";
        var _0x4a2 = Math["round"](_0x51266a + (_0x4c8bg["dx"] || 354874 ^ 354874) * _0x199 - (519584 ^ 519588));
        var _0xf9a57a = Math["round"](_0x642b + (_0x4c8bg["dy"] || 774614 ^ 774614) * _0x199 - (132035 ^ 132039));
        var _0xdda58b = _0x6a2dag === _0xd30c;
        _0xd4bf += "<div data-debris-item data-debris-idx=\"" + _0xd30c + "\" " + "style=\"position:absolute;left:" + _0x4a2 + ":pot;xp".split("").reverse().join("") + _0xf9a57a + ";326a5f#:dnuorgkcab;xp8:thgieh;xp8:htdiw;xp".split("").reverse().join("") + "border:1px solid " + (_0xdda58b ? "#fff" : "02070a#".split("").reverse().join("")) + " \"enon:noitca-hcuot;3:xedni-z;evom:rosruc;".split("").reverse().join("") + "title=\"Debris " + (_0xd30c + (802950 ^ 802951)) + " (" + (_0x4c8bg["dx"] || 106817 ^ 106817) + "," + (_0x4c8bg["dy"] || 359958 ^ 359958) + ")\"></div>";
    } _0xd4bf += ">vid/<".split("").reverse().join(""); if (_0x6a2dag !== null && _0x78_0x5ca[_0x6a2dag]) {
        var _0x200 = _0x78_0x5ca[_0x6a2dag];
        _0xd4bf += "<div style=\"margin-top:8px;padding:6px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:4px;font-size:11px\">";
        _0xd4bf += " sirbeD ;502821#&>gnorts<".split("").reverse().join("") + (_0x6a2dag + (809250 ^ 809251)) + ">rb<>gnorts/<".split("").reverse().join("");
        _0xd4bf += "dx:&nbsp;<input type=\"number\" data-debris-prop=\"dx\" value=\"" + (_0x200["dx"] || 742154 ^ 742154) + "\" style=\"width:55px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;&nbsp;";
        _0xd4bf += "dy:&nbsp;<input type=\"number\" data-debris-prop=\"dy\" value=\"" + (_0x200["dy"] || 653634 ^ 653634) + "\" style=\"width:55px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"><br><br>";
        _0xd4bf += "<button data-debris-prop-apply style=\"font-size:11px;padding:2px 8px\">Apply</button>";
        _0xd4bf += ">vid/<".split("").reverse().join("");
    } return _0xd4bf; }
    function _0x8ccc(saved) { for (var _0xba14a = 675339 ^ 675339; _0xba14a < saved["convoys"]["length"]; _0xba14a++) {
        var _0x8284cb = saved["convoys"][_0xba14a], _0x496cgd = [];
        for (var _0x3eca1b = 636480 ^ 636480; _0x3eca1b < _0x8284cb["vehicles"]["length"]; _0x3eca1b++) {
            var _0x22_0x1aa = (801302 ^ 801297) + (923489 ^ 923488);
            var _0x99daf = _0x8284cb["vehicles"][_0x3eca1b];
            _0x22_0x1aa = (522130 ^ 522132) + (142245 ^ 142247);
            var _0x2g1a = (108014 ^ 108011) + (268716 ^ 268718);
            var _0x201 = _0x844a(_0x99daf["typeIdx"], _0x99daf["wx"], _0x99daf["wy"], 761514 ^ 761514);
            _0x2g1a = (801251 ^ 801251) + (429535 ^ 429526);
            if (_0x201) {
                _0x201["opacity"] = 361533 ^ 361532;
                _0x496cgd["push"]({
                    "inst": _0x201,
                            "typeIdx": _0x99daf["typeIdx"],
                            "wx": _0x99daf["wx"],
                            "wy": _0x99daf["wy"]
                });
            }
        }
        if (_0x496cgd["length"]) {
            _0x42a["convoys"]["push"]({
                "vehicles": _0x496cgd,
                        "anchorR": _0x8284cb["anchorR"],
                        "anchorC": _0x8284cb["anchorC"],
                        "anchorWx": _0x8284cb["anchorWx"],
                        "anchorWy": _0x8284cb["anchorWy"]
            });
        }
    } }
    function _0xc7fb0c(_0x32g, _0xd6c7b) { var _0x776ada = _0x3cba(); _0x42a["spawnedLevel"] = _0x776ada; if (!_0x06cd7a["enabled"]) {
        var _0x59c92f = (144689 ^ 144688) + (598236 ^ 598238);
        var _0x1171b = _0x49f88b();
        _0x59c92f = (979563 ^ 979560) + (578060 ^ 578056);
        if (_0x1171b && _0x1171b["v"] === (752177 ^ 752176) && _0x1171b["savedLevel"] === _0x776ada) {
            _0x8ccc(_0x1171b);
            _0x42a["_pendingSpawn"] = false;
            _0xd1f8e();
            return;
        }
    } _0x1e733a(); var _0xa581gd = _0x7d3(); if (!_0xa581gd["length"]) {
        _0x42a["_pendingSpawn"] = !![];
        return;
    } var _0x76275f = {}; for (var _0xd19 = 812819 ^ 812819; _0xd19 < _0x42a["_usedRunKeys"]["length"]; _0xd19++)
        _0x76275f[_0x42a["_usedRunKeys"][_0xd19]] = !![]; var _0x8g6c9d = []; _0x32g = (350333 ^ 350328) + (885120 ^ 885124); for (var _0x3be4fb = 756564 ^ 756564; _0x3be4fb < _0xa581gd["length"]; _0x3be4fb++) {
        if (!_0x76275f[_0xa581gd[_0x3be4fb]["r"] + "_" + _0xa581gd[_0x3be4fb]["cStart"]])
            _0x8g6c9d["push"](_0xa581gd[_0x3be4fb]);
    } if (!_0x8g6c9d["length"])
        _0x8g6c9d = _0xa581gd; var _0xdc0e = []; for (var _0x0e2 = 226736 ^ 226736; _0x0e2 < _0x8g6c9d["length"]; _0x0e2++) {
        if (!_0x8c45d(_0x8g6c9d[_0x0e2]))
            _0xdc0e["push"](_0x8g6c9d[_0x0e2]);
    } if (!_0xdc0e["length"])
        _0xdc0e = _0x8g6c9d; _0x8g6c9d = _0xdc0e; for (var s = _0x8g6c9d["length"] - (332173 ^ 332172); s > (984676 ^ 984676); s--) {
        var _0xec3 = Math["floor"](Math["random"]() * (s + (575865 ^ 575864)));
        var _0xc7cedf = _0x8g6c9d[s];
        _0x8g6c9d[s] = _0x8g6c9d[_0xec3];
        _0x8g6c9d[_0xec3] = _0xc7cedf;
    } var _0x92b = Math["min"](_0xba3["maxConvoys"], _0x8g6c9d["length"]); _0xd6c7b = (732921 ^ 732912) + (709849 ^ 709853); for (var i = 204024 ^ 204024; i < _0x92b; i++) {
        let _0x43efd;
        var _0xc10 = _0x4d0ed(_0x8g6c9d[i]);
        _0x43efd = (120247 ^ 120246) + (380124 ^ 380116);
        if (_0xc10) {
            _0x42a["convoys"]["push"](_0xc10);
            _0x84b0a(_0xc10);
            _0x2e959a(_0xc10);
            _0x8df(_0xc10);
            if (_0xc10["runKey"]) {
                _0x42a["_usedRunKeys"]["push"](_0xc10["runKey"]);
                if (_0x42a["_usedRunKeys"]["length"] > (242557 ^ 242553))
                    _0x42a["_usedRunKeys"]["shift"]();
            }
        }
    } _0x42a["_pendingSpawn"] = false; if (_0x06cd7a["enabled"]) {
        var _0x43b20b = (818981 ^ 818988) + (316649 ^ 316649);
        var _0x8c3 = _0x8f_0x7af();
        _0x43b20b = (189456 ^ 189460) + (633168 ^ 633173);
        _0x42a["status"] = "active";
        _0x42a["spawnedAtTimer"] = _0x8c3;
        _0x42a["despawnAtTimer"] = _0x8c3 !== null ? _0x8c3 + _0x06cd7a["duration"] : null;
        _0x42a["nextSpawnAtTimer"] = null;
    }
    else {
        _0x2902fe();
    } _0xd1f8e(); }
    function _0x02999g() { if (_0x42a["running"])
        return; _0x42a["running"] = !![]; _0x42a["status"] = "idle"; _0x42a["spawnedAtTimer"] = null; _0x42a["despawnAtTimer"] = null; _0x42a["nextSpawnAtTimer"] = null; _0x42a["lastTimerVal"] = null; _0x2be62g(); _0xc7fb0c(); }
    function _0xcac18a() { _0x42a["running"] = false; _0x42a["_pendingSpawn"] = false; _0x42a["status"] = "idle"; _0x42a["spawnedAtTimer"] = null; _0x42a["despawnAtTimer"] = null; _0x42a["nextSpawnAtTimer"] = null; _0x65f2e(); _0x1e733a(); _0x42a["spawnedLevel"] = null; _0xd1f8e(); }
    function _0xbaf5a() { if (!_0x42a["running"] || !_0x06cd7a["enabled"])
        return; var _0x202 = _0x8f_0x7af(); if (_0x202 === null)
        return; _0x42a["lastTimerVal"] = _0x202; if (_0x42a["status"] === "active") {
        if (_0x42a["despawnAtTimer"] === null) {
            _0x42a["despawnAtTimer"] = _0x202 + _0x06cd7a["duration"];
        }
        if (_0x202 >= _0x42a["despawnAtTimer"]) {
            _0x42a["status"] = "despawning";
            _0xd1f8e();
        }
    }
    else if (_0x42a["status"] === "despawning") {
        var _0xcce4b = (192646 ^ 192643) + (194651 ^ 194642);
        var _0xc9291b = _0x8f143f;
        _0xcce4b = (700408 ^ 700401) + (139473 ^ 139473);
        var _0xd9_0x964 = false;
        if (_0xc9291b) {
            var _0xdd23bb = _0x06cd7a["despawnRadius"] * _0x06cd7a["despawnRadius"];
            for (var _0x27ag = 232370 ^ 232370; _0x27ag < _0x42a["convoys"]["length"]; _0x27ag++) {
                var _0x3763ef = _0x42a["convoys"][_0x27ag];
                var _0xcfcgd = _0xc9291b["x"] - _0x3763ef["anchorWx"], _0xcfee = _0xc9291b["y"] - _0x3763ef["anchorWy"];
                if (_0xcfcgd * _0xcfcgd + _0xcfee * _0xcfee < _0xdd23bb) {
                    _0xd9_0x964 = !![];
                    break;
                }
            }
        }
        if (!_0xd9_0x964) {
            _0x65f2e();
            _0x42a["status"] = "waiting";
            _0x42a["nextSpawnAtTimer"] = _0x202 + _0x06cd7a["spawnInterval"];
            _0xd1f8e();
        }
    }
    else if (_0x42a["status"] === "waiting") {
        if (_0x42a["nextSpawnAtTimer"] !== null && _0x202 >= _0x42a["nextSpawnAtTimer"]) {
            _0x42a["nextSpawnAtTimer"] = null;
            _0x42a["status"] = "eldi".split("").reverse().join("");
            _0xc7fb0c();
        }
    } _0xcda06f(); }
    function _0xaa69ad(_0x20e) { var _0xeeef = ">\"xp11:ezis-tnof;xp6:pot-gniddap;xp8:pot-nigram;)21.0,552,552,552(abgr dilos xp1:pot-redrob\"=elyts vid<".split("").reverse().join(""); _0x20e = 384782 ^ 384781; _0xeeef += "<strong style=\"font-size:12px\">Convoy Wreckage</strong><br>"; if (!_0x42a["running"]) {
        _0xeeef += ">naps/<deppotS>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("");
    }
    else if (_0x42a["_pendingSpawn"]) {
        _0xeeef += "<span style=\"color:#fc0\">Pending — waiting for map data...</span>";
    }
    else if (_0x06cd7a["enabled"]) {
        var t = _0x42a["lastTimerVal"];
        if (_0x42a["status"] === "active") {
            var _0x9279ef = _0x42a["despawnAtTimer"] !== null && t !== null ? Math["max"](342963 ^ 342963, _0x42a["despawnAtTimer"] - t) : "?";
            _0xeeef += "<span style=\"color:#5cf\">ACTIVE &mdash; " + _0x42a["convoys"]["length"] + " convoy(s)</span><br>";
            _0xeeef += " :ni snwapseD>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("") + _0x9279ef + ">rb<>naps/<skcit ".split("").reverse().join("");
        }
        else if (_0x42a["status"] === "despawning") {
            _0xeeef += "<span style=\"color:#fa5\">DESPAWNING &mdash; waiting for player to leave area</span><br>";
            _0xeeef += "<span style=\"color:#bcae94\">Radius: " + _0x06cd7a["despawnRadius"] + " units from anchor</span><br>";
        }
        else if (_0x42a["status"] === "waiting") {
            var _0x9cdgdf = _0x42a["nextSpawnAtTimer"] !== null && t !== null ? Math["max"](854758 ^ 854758, _0x42a["nextSpawnAtTimer"] - t) : "?";
            _0xeeef += " ni nwaps txen ;hsadm& GNITIAW>\"0cf#:roloc\"=elyts naps<".split("").reverse().join("") + _0x9cdgdf + " ticks</span><br>";
        }
        else {
            _0xeeef += "<span style=\"color:#5cf\">Timer idle</span><br>";
        }
        for (var _0x038d = 665577 ^ 665577; _0x038d < _0x42a["convoys"]["length"]; _0x038d++) {
            var _0xdfb21d = _0x42a["convoys"][_0x038d];
            _0xeeef += "<span style=\"color:#bcae94\">&nbsp;&nbsp;#" + (_0x038d + (788910 ^ 788911)) + ": " + _0xdfb21d["vehicles"]["length"] + " veh, " + (_0xdfb21d["chestInsts"] ? _0xdfb21d["chestInsts"]["length"] : 332346 ^ 332346) + " chests</span><br>";
        }
    }
    else {
        var _0x1g9e = (475796 ^ 475798) + (932769 ^ 932774);
        var _0xf75dc = _0x42a["convoys"]["length"];
        _0x1g9e = 517003 ^ 517004;
        _0xeeef += ">\"fc5#:roloc\"=elyts naps<".split("").reverse().join("") + _0xf75dc + "yovnoc ".split("").reverse().join("") + (_0xf75dc !== (280802 ^ 280803) ? "s" : "") + " active</span><br>";
        for (var _0x33f76a = 144021 ^ 144021; _0x33f76a < _0x42a["convoys"]["length"]; _0x33f76a++) {
            var _0x71g2fd = _0x42a["convoys"][_0x33f76a];
            _0xeeef += "#;psbn&;psbn&>\"49eacb#:roloc\"=elyts naps<".split("").reverse().join("") + (_0x33f76a + (127877 ^ 127876)) + ": " + _0x71g2fd["vehicles"]["length"] + " veh, " + (_0x71g2fd["chestInsts"] ? _0x71g2fd["chestInsts"]["length"] : 504288 ^ 504288) + " chests, row " + _0x71g2fd["anchorR"] + " loc ".split("").reverse().join("") + _0x71g2fd["anchorC"] + "</span><br>";
        }
    } _0xeeef += "</div>"; return _0xeeef; }
    function _0xa4_0xe4g(_0xcffc) { var _0x23_0x69b = (955067 ^ 955064) + (933292 ^ 933294); var _0xe4af = 0.4; _0x23_0x69b = 231573 ^ 231569; var _0xef9e = 382508 ^ 382056; var _0xdgf4b = 708643 ^ 708843; var _0x517e = _0xef9e / (312326 ^ 312324), _0xba37af = _0xdgf4b / (267541 ^ 267543); var _0x2b2 = _0xba3["vehicleGap"]; var _0x91a = _0xba3["pattern"]; var _0xfcaea = (678975 ^ 678968) + (743216 ^ 743220); var n = _0x91a["length"]; _0xfcaea = (543413 ^ 543415) + (699374 ^ 699367); var _0x345eae = "<div style=\"font-size:11px;margin-bottom:6px;color:#bcae94\">Drag <span style=\"color:#ffd700;font-weight:700\">C</span> (chests) and <span style=\"color:#40ff80;font-weight:700\">I</span> (item spawns) to reposition. <span style=\"color:#5cf\">&#8853;</span> = convoy anchor origin.</div>"; _0xcffc = "hfdomg"; _0x345eae += ">\"parw:parw-xelf;xp6:mottob-nigram;xp6:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join(""); _0x345eae += ">nottub/<tsehC ddA +>\"02078a# dilos xp1:redrob;)2.0,04,061,002(abgr:dnuorgkcab;xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts \"tsehc\"=dda-tuoyal-yovnoc-atad nottub<".split("").reverse().join(""); _0x345eae += "<button data-convoy-layout-add=\"itemSpawn\" style=\"padding:4px 8px;font-size:11px;background:rgba(40,160,80,0.2);border:1px solid #206040\">+ Add Item Spawn</button>"; if (_0xc9dab !== null) {
        _0x345eae += ">nottub/<etacilpuD ;5469#&>\"0a0602# dilos xp1:redrob;)2.0,002,021,06(abgr:dnuorgkcab;xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts etacilpud-tuoyal-yovnoc-atad nottub<".split("").reverse().join("");
        _0x345eae += ">nottub/<eteleD ;semit&>\"03030a# dilos xp1:redrob;)2.0,06,06,002(abgr:dnuorgkcab;xp11:ezis-tnof;xp8 xp4:gniddap\"=elyts eteled-tuoyal-yovnoc-atad nottub<".split("").reverse().join("");
    } _0x345eae += "<button data-convoy-layout-save style=\"padding:4px 8px;font-size:11px\">&#128190; Save Layout</button>"; _0x345eae += "</div>"; _0x345eae += ":htdiw;evitaler:noitisop\"=elyts savnac-tuoyal-yovnoc-atad vid<".split("").reverse().join("") + _0xef9e + ":thgieh;xp".split("").reverse().join("") + _0xdgf4b + "px;background:#0d1117;border:1px solid #334;overflow:hidden;user-select:none\">"; _0x345eae += "<div style=\"position:absolute;left:" + _0x517e + "px;top:0;width:1px;height:" + _0xdgf4b + ">vid/<>\"enon:stneve-retniop;)21.0,552,002,09(abgr:dnuorgkcab;xp".split("").reverse().join(""); _0x345eae += "<div style=\"position:absolute;left:0;top:" + _0xba37af + "px;width:" + _0xef9e + ">vid/<>\"enon:stneve-retniop;)21.0,552,002,09(abgr:dnuorgkcab;xp1:thgieh;xp".split("").reverse().join(""); _0x345eae += "<div style=\"position:absolute;left:" + (_0x517e - (746815 ^ 746810)) + ":pot;xp".split("").reverse().join("") + (_0xba37af - (552857 ^ 552860)) + "px;width:10px;height:10px;border-radius:5px;background:#5cf;pointer-events:none\" title=\"Convoy anchor\"></div>"; for (var _0xbe63e = 808695 ^ 808695; _0xbe63e < n; _0xbe63e++) {
        var _0x89c = (_0xbe63e - (n - (732765 ^ 732764)) / (645785 ^ 645787)) * _0x2b2;
        var _0xb5_0x525 = (724569 ^ 724574) + (872055 ^ 872048);
        var _0x352bb = Math["round"](_0x517e + _0x89c * _0xe4af - (785123 ^ 785147));
        _0xb5_0x525 = 298517 ^ 298517;
        var _0xcg5g = (826772 ^ 826769) + (864125 ^ 864123);
        var _0x1d_0xb90 = Math["round"](_0xba37af - (342606 ^ 342596));
        _0xcg5g = (564230 ^ 564228) + (700998 ^ 700993);
        var _0xdda = _0x91a[_0xbe63e] === (755731 ^ 755971) ? "665544#".split("").reverse().join("") : "#334d55";
        let _0xb1dc9c;
        var _0xf2692d = _0x91a[_0xbe63e] === (273671 ^ 273431) ? "Truck" : "ATV";
        _0xb1dc9c = (819931 ^ 819931) + (590213 ^ 590220);
        _0x345eae += "<div style=\"position:absolute;left:" + _0x352bb + ":pot;xp".split("").reverse().join("") + _0x1d_0xb90 + "px;width:48px;height:20px;background:" + _0xdda + ";border:1px solid #667;color:#aaa;font-size:8px;text-align:center;line-height:20px;pointer-events:none;border-radius:2px\">" + _0xf2692d + "</div>";
    } for (var _0x497c = 340768 ^ 340768; _0x497c < _0xg63c7a["chests"]["length"]; _0x497c++) {
        var _0x1a665c = (395326 ^ 395318) + (379487 ^ 379479);
        var _0x56ccfb = _0xg63c7a["chests"][_0x497c];
        _0x1a665c = 551193 ^ 551185;
        var _0x73gc, _0xc537ba;
        if (_0x56ccfb["vehicleIdx"] != null && _0x56ccfb["vehicleIdx"] >= (415164 ^ 415164) && _0x56ccfb["vehicleIdx"] < n) {
            _0x73gc = Math["round"](_0x517e + ((_0x56ccfb["vehicleIdx"] - (n - (189112 ^ 189113)) / (550481 ^ 550483)) * _0x2b2 + (_0x56ccfb["offsetX"] || 407676 ^ 407676)) * _0xe4af - (642180 ^ 642190));
            _0xc537ba = Math["round"](_0xba37af + (_0x56ccfb["offsetY"] || 113364 ^ 113364) * _0xe4af - (303531 ^ 303521));
        }
        else {
            _0x73gc = Math["round"](_0x517e + (_0x56ccfb["offsetX"] || 636117 ^ 636117) * _0xe4af - (746566 ^ 746572));
            _0xc537ba = Math["round"](_0xba37af + (_0x56ccfb["offsetY"] || 122188 ^ 122188) * _0xe4af - (303190 ^ 303196));
        }
        var _0x29ea = (620200 ^ 620203) + (909927 ^ 909924);
        var _0xf9_0x144 = _0xc9dab && _0xc9dab["type"] === "chest" && _0xc9dab["idx"] === _0x497c;
        _0x29ea = (125263 ^ 125263) + (989212 ^ 989204);
        var _0x8db21b = _0x56ccfb["vehicleIdx"] != null && _0x56ccfb["vehicleIdx"] >= (694045 ^ 694045) ? "&#128279;" : "";
        _0x345eae += "<div data-convoy-layout-item data-layout-item-type=\"chest\" data-layout-item-idx=\"" + _0x497c + " \"".split("").reverse().join("") + ":tfel;etulosba:noitisop\"=elyts".split("").reverse().join("") + _0x73gc + "px;top:" + _0xc537ba + "px;width:20px;height:20px;background:#c8a040;" + "border:2px solid " + (_0xf9_0x144 ? "#fff" : "#ffd700") + ";xp2:suidar-redrob;3:xedni-z;evom:rosruc;".split("").reverse().join("") + "text-align:center;line-height:16px;font-size:10px;color:#000;touch-action:none\" " + " tsehC\"=eltit".split("").reverse().join("") + (_0x497c + (224442 ^ 224443)) + " :".split("").reverse().join("") + _0x0d5eg(_0x56ccfb["chestTypeId"] || "type1") + (_0x56ccfb["vehicleIdx"] != null && _0x56ccfb["vehicleIdx"] >= (615487 ^ 615487) ? " [V" + (_0x56ccfb["vehicleIdx"] + (197994 ^ 197995)) + "]" : "") + " (" + (_0x56ccfb["offsetX"] || 955159 ^ 955159) + "," + (_0x56ccfb["offsetY"] || 338469 ^ 338469) + ">\")".split("").reverse().join("") + _0x8db21b + ">vid/<C".split("").reverse().join("");
    } for (var _0xfb6gb = 157447 ^ 157447; _0xfb6gb < _0xg63c7a["itemSpawns"]["length"]; _0xfb6gb++) {
        let _0x24_0xd2d;
        var _0x8c2bf = _0xg63c7a["itemSpawns"][_0xfb6gb];
        _0x24_0xd2d = (566161 ^ 566161) + (140168 ^ 140160);
        var _0xc7b = (365056 ^ 365059) + (201736 ^ 201740);
        var _0x21c0ba = Math["round"](_0x517e + (_0x8c2bf["offsetX"] || 254743 ^ 254743) * _0xe4af - (141897 ^ 141891));
        _0xc7b = (447976 ^ 447979) + (350029 ^ 350028);
        var _0x76585b = Math["round"](_0xba37af + (_0x8c2bf["offsetY"] || 428109 ^ 428109) * _0xe4af - (464171 ^ 464161));
        let _0xfgd;
        var _0x12c5b = _0xc9dab && _0xc9dab["type"] === "nwapSmeti".split("").reverse().join("") && _0xc9dab["idx"] === _0xfb6gb;
        _0xfgd = (997621 ^ 997616) + (151810 ^ 151808);
        _0x345eae += "\"=xdi-meti-tuoyal-atad \"nwapSmeti\"=epyt-meti-tuoyal-atad meti-tuoyal-yovnoc-atad vid<".split("").reverse().join("") + _0xfb6gb + " \"".split("").reverse().join("") + ":tfel;etulosba:noitisop\"=elyts".split("").reverse().join("") + _0x21c0ba + "px;top:" + _0x76585b + "px;width:20px;height:20px;background:#208040;" + "border:2px solid " + (_0x12c5b ? "fff#".split("").reverse().join("") : "#40ff80") + ";cursor:move;z-index:3;border-radius:50%;" + "text-align:center;line-height:16px;font-size:10px;color:#fff;touch-action:none\" " + "title=\"Item Spawn " + (_0xfb6gb + (730989 ^ 730988)) + " :".split("").reverse().join("") + (_0x8c2bf["loot"] ? _0x8c2bf["loot"]["length"] : 682071 ^ 682071) + " items (" + (_0x8c2bf["offsetX"] || 697806 ^ 697806) + "," + (_0x8c2bf["offsetY"] || 699775 ^ 699775) + ">vid/<I>\")".split("").reverse().join("");
    } _0x345eae += "</div>"; if (_0xc9dab !== null) {
        let _0x25_0xc11;
        var _0x4dd5a = _0xc9dab;
        _0x25_0xc11 = (882953 ^ 882959) + (150105 ^ 150104);
        let _0x7d2;
        var _0x6g51f = _0x4dd5a["type"] === "tsehc".split("").reverse().join("") ? _0xg63c7a["chests"] : _0xg63c7a["itemSpawns"];
        _0x7d2 = (497098 ^ 497100) + (345230 ^ 345231);
        var _0x9bf = (981403 ^ 981402) + (779359 ^ 779353);
        var _0xd4e = _0x6g51f[_0x4dd5a["idx"]];
        _0x9bf = "hkkahg";
        if (_0xd4e) {
            _0x345eae += "<div style=\"margin-top:8px;padding:6px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:4px;font-size:11px\">";
            _0x345eae += ">gnorts<".split("").reverse().join("") + (_0x4dd5a["type"] === "tsehc".split("").reverse().join("") ? "&#128230; Chest " : "&#128205; Item Spawn ") + (_0x4dd5a["idx"] + (202502 ^ 202503)) + "</strong><br>";
            _0x345eae += "Offset X:&nbsp;<input type=\"number\" data-layout-prop=\"offsetX\" value=\"" + (_0xd4e["offsetX"] || 416128 ^ 416128) + ";psbn&;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp05:htdiw\"=elyts \"".split("").reverse().join("");
            _0x345eae += "\"=eulav \"Ytesffo\"=porp-tuoyal-atad \"rebmun\"=epyt tupni<;psbn&:Y".split("").reverse().join("") + (_0xd4e["offsetY"] || 615825 ^ 615825) + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"><br><br>";
            if (_0x4dd5a["type"] === "tsehc".split("").reverse().join("")) {
                _0x345eae += "Chest Type:&nbsp;<select data-layout-prop=\"chestTypeId\" style=\"background:#222;border:1px solid #555;color:#fff;padding:1px\">";
                for (var _0xfda6bb in _0x87g) {
                    _0x345eae += "<option value=\"" + _0x0d5eg(_0xfda6bb) + "\"" + ((_0xd4e["chestTypeId"] || "type1") === _0xfda6bb ? "detceles ".split("").reverse().join("") : "") + ">" + _0x0d5eg(_0x87g[_0xfda6bb]["name"] || _0xfda6bb) + "</option>";
                }
                _0x345eae += "</select><br>";
                _0x345eae += "Link to vehicle:&nbsp;<select data-layout-prop=\"vehicleIdx\" style=\"background:#222;border:1px solid #555;color:#fff;padding:1px\">";
                _0x345eae += "<option value=\"-1\"" + (_0xd4e["vehicleIdx"] == null || _0xd4e["vehicleIdx"] < (421962 ^ 421962) ? " selected" : "") + ">None (free offset)</option>";
                for (var _0x4374af = 810391 ^ 810391; _0x4374af < n; _0x4374af++) {
                    _0x345eae += "<option value=\"" + _0x4374af + "\"" + (_0xd4e["vehicleIdx"] === _0x4374af ? "detceles ".split("").reverse().join("") : "") + ">Vehicle " + (_0x4374af + (259902 ^ 259903)) + " (" + (_0x91a[_0x4374af] === (714871 ^ 715111) ? "Truck" : "ATV") + ">noitpo/<)".split("").reverse().join("");
                }
                _0x345eae += "</select><br>";
            }
            else {
                var _0xfad87d = (409076 ^ 409077) + (999154 ^ 999155);
                var _0x7a_0xf49 = _0xd4e["loot"] || [];
                _0xfad87d = (987286 ^ 987280) + (636293 ^ 636290);
                _0x345eae += "<strong>Loot Table</strong>:<br>";
                _0x345eae += ">\"0 xp3:nigram;otua:y-wolfrevo;xp08:thgieh-xam\"=elyts vid<".split("").reverse().join("");
                for (var _0xe1f = 312867 ^ 312867; _0xe1f < _0x7a_0xf49["length"]; _0xe1f++) {
                    _0x345eae += "<span style=\"color:#5cf\">ID&nbsp;" + _0x7a_0xf49[_0xe1f]["id"] + "</span>&nbsp;<span title=\"Spawn weight: higher = picked more often. Not quantity — always spawns 1 item.\" style=\"color:#aaa;cursor:help\">wt:</span><input type=\"number\" min=\"1\" data-loot-weight data-loot-idx=\"" + _0xe1f + "\" value=\"" + (_0x7a_0xf49[_0xe1f]["weight"] || 136427 ^ 136426) + "\" style=\"width:34px;background:#222;border:1px solid #555;color:#fff;padding:1px 2px\" title=\"Spawn weight: higher = picked more often. Not quantity — always spawns 1 item.\">&nbsp;";
                    _0x345eae += "<button data-loot-remove data-loot-idx=\"" + _0xe1f + "\" style=\"font-size:10px;padding:0 4px;background:rgba(200,60,60,0.2)\">&times;</button><br>";
                }
                _0x345eae += "</div>";
                _0x345eae += "<div style=\"display:flex;gap:4px;align-items:center;flex-wrap:wrap;margin-bottom:2px\">";
                _0x345eae += "<input type=\"number\" data-loot-add-id style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\" placeholder=\"ID\">";
                _0x345eae += ">nottub/<DI ddA>\"xp6 xp2:gniddap;xp11:ezis-tnof\"=elyts dda-tool-atad nottub<".split("").reverse().join("");
                _0x345eae += "<button data-loot-open-picker style=\"font-size:11px;padding:2px 8px;background:rgba(90,180,255,0.15);border-color:#5ab4ff\">&#127922; Item Picker</button>";
                _0x345eae += "</div>";
                _0x345eae += " :dda kciuQ>\"888#:roloc;xp01:ezis-tnof;xp4:pot-nigram\"=elyts vid<".split("").reverse().join("");
                var _0x1d581f = [
                    839172 ^ 839183, 199974 ^ 199978, 623233 ^ 623247, 264737 ^ 264750, 101869 ^ 101800, 266529 ^ 266602, 837261 ^ 837342, 983104 ^ 983065, 926655 ^ 926678, 828707 ^ 828745, 765944 ^ 765847, 328153 ^ 328105, 558415 ^ 558158, 213328 ^ 213043
                ];
                for (var _0xg28da = 474331 ^ 474331; _0xg28da < _0x1d581f["length"]; _0xg28da++) {
                    let _0xc44de;
                    var _0x3729e = false;
                    _0xc44de = (803190 ^ 803190) + (339653 ^ 339653);
                    for (var _0x76669b = 164109 ^ 164109; _0x76669b < _0x7a_0xf49["length"]; _0x76669b++) {
                        if (_0x7a_0xf49[_0x76669b]["id"] === _0x1d581f[_0xg28da]) {
                            _0x3729e = !![];
                            break;
                        }
                    }
                    _0x345eae += "<span data-quick-add-id=\"" + _0x1d581f[_0xg28da] + ":roloc;retniop:rosruc\"=elyts \"".split("").reverse().join("") + (_0x3729e ? "5f5#".split("").reverse().join("") : "#888") + " DI ddA\"=eltit \"xp4:thgir-nigram;".split("").reverse().join("") + _0x1d581f[_0xg28da] + ">\"".split("").reverse().join("") + _0x1d581f[_0xg28da] + ">naps/<".split("").reverse().join("");
                }
                _0x345eae += "</div>";
            }
            _0x345eae += "<br><button data-layout-prop-apply style=\"font-size:11px;padding:2px 8px\">Apply</button>";
            _0x345eae += "</div>";
        }
    } return _0x345eae; }
    function _0x1728b(_0x2ebcd, _0xbc5db, _0xd4_0x483, _0x352cac, _0xf3759d, _0xaaaa0b, _0x65e01a) { var _0x1baad = (877079 ^ 877078) + (891496 ^ 891501); var _0xebd = _0xdc93b["ui"]["left"]; _0x1baad = (462981 ^ 462977) + (641078 ^ 641072); var _0x1495ac = _0xdc93b["ui"]["center"]; var _0x49996d = _0xdc93b["ui"]["right"]; var _0xf5fd = "<div style=\"display:grid;gap:10px\">" + "<strong>Event Object Spawner</strong>" + "<div style=\"color:#bcae94\">Spawns t1126 (duqu event overlay, 2000x2000) at the center of selected town tile types on the current map.</div>" + "<strong style=\"margin-top:4px\">Target Tile Types</strong>"; _0x2ebcd = (786661 ^ 786663) + (828093 ^ 828085); for (var i = 801823 ^ 801823; i < _0xb4e95f["length"]; i++) {
        var _0x3b963b = _0xb4e95f[i];
        var _0xc54e = _0xe2ab["selectedTileIds"]["indexOf"](_0x3b963b["id"]) >= (192744 ^ 192744);
        _0xf5fd += "<label style=\"display:flex;align-items:center;gap:8px\"><input type=\"checkbox\" data-event-tile=\"" + _0x3b963b["id"] + "\"" + (_0xc54e ? " checked" : "") + ">" + "<span style=\"display:inline-block;width:10px;height:10px;background:" + _0x3b963b["color"] + ">naps/<>\"xp2:suidar-redrob;".split("").reverse().join("") + _0x0d5eg(_0x3b963b["name"]) + " (ID " + _0x3b963b["id"] + ")</label>";
    } _0xf5fd += "<button data-event-action=\"spawn\" style=\"padding:8px;margin-top:4px\">Spawn at Towns</button>" + "<button data-event-action=\"clear\" style=\"padding:6px;background:rgba(200,60,60,0.15)\">Hide Spawned (" + _0xe2ab["spawnedInsts"]["length"] + ">nottub/<)".split("").reverse().join("") + "<button data-event-action=\"flare-test\" style=\"padding:6px;margin-top:4px;background:rgba(255,165,0,0.15)\">Test Flare Shot</button>"; _0xf5fd += ">\"xp4:pag;dirg:yalpsid;xp8:pot-gniddap;xp01:pot-nigram;)21.0,552,552,552(abgr dilos xp1:pot-redrob\"=elyts vid<".split("").reverse().join("") + "<strong>Dynamic Toxic Gas</strong>" + ">vid/<.nwodtnuoc eno serahs hctab hcaE .LLA_remiT no desab sehctab 6211t snwaps-otuA>\"xp11:ezis-tnof;49eacb#:roloc\"=elyts vid<".split("").reverse().join("") + ">\"xp2:pot-nigram;xp11:ezis-tnof\"=elyts vid<".split("").reverse().join("") + "Spawn interval: <input type=\"number\" data-gas-cfg=\"spawnInterval\" value=\"" + _0xfa3["spawnInterval"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"> ticks after despawn<br>" + "\"=eulav \"noitarud\"=gfc-sag-atad \"rebmun\"=epyt tupni< :noitaruD".split("").reverse().join("") + _0xfa3["duration"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"> ticks per batch<br>" + "\"=eulav \"remiTtApots\"=gfc-sag-atad \"rebmun\"=epyt tupni< :LLA_remiT ta potS".split("").reverse().join("") + _0xfa3["stopAtTimer"] + ">rb<>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp55:htdiw\"=elyts \"".split("").reverse().join("") + "Fade duration: <input type=\"number\" data-gas-cfg=\"fadeDuration\" value=\"" + _0xfa3["fadeDuration"] + "\" style=\"width:55px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\"> ms<br>" + "Max/island — L0:<input type=\"number\" data-gas-cfg=\"max0\" value=\"" + _0xfa3["maxPerIsland"][690223 ^ 690223] + " >\"xp2 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp62:htdiw\"=elyts \"".split("").reverse().join("") + "L1:<input type=\"number\" data-gas-cfg=\"max1\" value=\"" + _0xfa3["maxPerIsland"][437090 ^ 437091] + "\" style=\"width:26px;background:#222;border:1px solid #555;color:#fff;padding:1px 2px\"> " + "L2:<input type=\"number\" data-gas-cfg=\"max2\" value=\"" + _0xfa3["maxPerIsland"][542831 ^ 542829] + "\" style=\"width:26px;background:#222;border:1px solid #555;color:#fff;padding:1px 2px\"> " + "\"=eulav \"3xam\"=gfc-sag-atad \"rebmun\"=epyt tupni<:3L".split("").reverse().join("") + _0xfa3["maxPerIsland"][532254 ^ 532253] + "\" style=\"width:26px;background:#222;border:1px solid #555;color:#fff;padding:1px 2px\"> " + "\"=eulav \"4xam\"=gfc-sag-atad \"rebmun\"=epyt tupni<:+4L".split("").reverse().join("") + _0xfa3["maxPerIsland"][788529 ^ 788533] + "\" style=\"width:30px;background:#222;border:1px solid #555;color:#fff;padding:1px 2px\"> (-1=All)<br>" + "<label style=\"user-select:none;cursor:pointer\"><input type=\"checkbox\" data-gas-chk=\"randomizeCount\"" + (_0xfa3["randomizeCount"] ? " checked" : "") + ">lebal/<)xam dnalsi ot 1( tnuoc ekirts ezimodnaR >".split("").reverse().join("") + ">vid/<".split("").reverse().join("") + ">\"xp2:pot-nigram;xp6:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + "<button data-gas-action=\"apply-cfg\" style=\"padding:4px 8px;font-size:11px\">Apply Config</button>" + "<button data-gas-action=\"toggle\" style=\"padding:6px 10px;background:" + (_0xbd3["running"] ? ")52.0,06,06,002(abgr".split("").reverse().join("") : ")52.0,06,061,06(abgr".split("").reverse().join("")) + ">\"".split("").reverse().join("") + (_0xbd3["running"] ? "saG potS ;2369#&".split("").reverse().join("") : "saG tratS ;4569#&".split("").reverse().join("")) + "</button>" + "<button data-gas-action=\"toggle-hud\" style=\"padding:6px 10px;background:rgba(60,80,120,0.25)\" title=\"Show/hide gas HUD overlay\">&#9635; HUD</button>" + "</div>" + ">vid/<".split("").reverse().join(""); _0xf5fd += ">\"xp4:pag;dirg:yalpsid;xp8:pot-gniddap;xp01:pot-nigram;)21.0,552,552,552(abgr dilos xp1:pot-redrob\"=elyts vid<".split("").reverse().join("") + ">gnorts/<egakcerW yovnoC yratiliM ;366821#&>gnorts<".split("").reverse().join("") + "<div style=\"color:#bcae94;font-size:11px\">Spawns military vehicle wreckage on road tiles. Respawns on a timer at a new location each time.</div>" + ">\"xp2:pot-nigram;xp11:ezis-tnof\"=elyts vid<".split("").reverse().join("") + "Max convoys:&nbsp;<input type=\"number\" data-convoy-cfg=\"maxConvoys\" value=\"" + _0xba3["maxConvoys"] + "\" style=\"width:36px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;&nbsp;" + "Gap:&nbsp;<input type=\"number\" data-convoy-cfg=\"vehicleGap\" value=\"" + _0xba3["vehicleGap"] + "\" style=\"width:46px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;units<br>" + "\"=eulav \"dIeliTdaor\"=gfc-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:DI elit daoR".split("").reverse().join("") + _0xba3["roadTileId"] + "\" style=\"width:36px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;&nbsp;" + "\"=eulav \"nuRdaoRnim\"=gfc-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:nur niM".split("").reverse().join("") + _0xba3["minRoadRun"] + ">rb<selit;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp23:htdiw\"=elyts \"".split("").reverse().join("") + "\"=eulav \"xednIreyal\"=gfc-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:xdi reyaL".split("").reverse().join("") + _0xba3["layerIndex"] + "\" style=\"width:32px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;&nbsp;" + "\"=eulav \"noitaruDedaf\"=gfc-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:edaF".split("").reverse().join("") + _0xba3["fadeDuration"] + ";psbn&;psbn&sm;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp64:htdiw\"=elyts \"".split("").reverse().join("") + "Angle:&nbsp;&plusmn;<input type=\"number\" data-convoy-cfg=\"maxAngleDeg\" value=\"" + _0xba3["maxAngleDeg"] + "\" style=\"width:36px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;deg<br>" + "\"=eulav \"suidaRnoisulcxe\"=gfc-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:suidar .lcxE".split("").reverse().join("") + _0xba3["exclusionRadius"] + "\" style=\"width:46px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;units<br>" + "</div>" + "<div style=\"font-size:11px;margin-top:2px;padding:4px;background:rgba(255,255,255,0.04);border-radius:3px\">" + "<strong>Respawn Timer</strong><br>" + "<label style=\"user-select:none;cursor:pointer\"><input type=\"checkbox\" data-convoy-chk=\"timerEnabled\"" + (_0x06cd7a["enabled"] ? " checked" : "") + ">rb<>lebal/<nwapser desab-remit elbanE >".split("").reverse().join("") + "Spawn interval:&nbsp;<input type=\"number\" data-convoy-timer=\"spawnInterval\" value=\"" + _0x06cd7a["spawnInterval"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;ticks<br>" + "\"=eulav \"noitarud\"=remit-yovnoc-atad \"rebmun\"=epyt tupni<;psbn&:noitaruD".split("").reverse().join("") + _0x06cd7a["duration"] + ">rb<skcit;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp05:htdiw\"=elyts \"".split("").reverse().join("") + "Despawn radius:&nbsp;<input type=\"number\" data-convoy-timer=\"despawnRadius\" value=\"" + _0x06cd7a["despawnRadius"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;units<br>" + "</div>" + "<div style=\"display:flex;gap:6px;margin-top:2px;flex-wrap:wrap\">" + "<button data-convoy-action=\"apply-cfg\" style=\"padding:4px 8px;font-size:11px\">Apply Config</button>" + ":dnuorgkcab;xp01 xp6:gniddap\"=elyts \"elggot\"=noitca-yovnoc-atad nottub<".split("").reverse().join("") + (_0x42a["running"] ? "rgba(200,60,60,0.25)" : "rgba(60,160,60,0.25)") + ">\"".split("").reverse().join("") + (_0x42a["running"] ? "&#9632; Stop Convoy" : "yovnoC tratS ;4569#&".split("").reverse().join("")) + "</button>" + "<button data-convoy-action=\"respawn\" style=\"padding:6px 10px;background:rgba(255,165,0,0.15)\" title=\"Clear and re-roll convoy positions\">&#8635; Respawn</button>" + ":dnuorgkcab;xp01 xp6:gniddap\"=elyts \"duh-elggot\"=noitca-yovnoc-atad nottub<".split("").reverse().join("") + (_0x06cd7a["convoyHudVisible"] ? ")53.0,552,081,09(abgr".split("").reverse().join("") : ")52.0,021,08,06(abgr".split("").reverse().join("")) + "\" title=\"Show/hide convoy HUD overlay\">&#9635; HUD</button>" + "<button data-convoy-action=\"toggle-layout\" style=\"padding:6px 10px;background:" + (_0xdc93b["convoyLayoutMode"] ? "rgba(90,180,255,0.25)" : ")52.0,001,06,06(abgr".split("").reverse().join("")) + "\" title=\"Toggle convoy layout editor\">&#128295; " + (_0xdc93b["convoyLayoutMode"] ? "Map View" : "Edit Layout") + ">nottub/<".split("").reverse().join("") + "</div>" + "<div style=\"font-size:11px;color:#bcae94\">Status:&nbsp;" + (_0x42a["running"] ? _0x42a["_pendingSpawn"] ? ">naps/<...gnidneP>\"0cf#:roloc\"=elyts naps<".split("").reverse().join("") : ">\"fc5#:roloc\"=elyts naps<".split("").reverse().join("") + (_0x06cd7a["enabled"] ? _0x42a["status"]["toUpperCase"]() : _0x42a["convoys"]["length"] + " convoy(s)") + "</span>" : "deppotS".split("").reverse().join("")) + "</div>" + " :tuoyaL>\"49eacb#:roloc;xp11:ezis-tnof\"=elyts vid<".split("").reverse().join("") + _0xg63c7a["chests"]["length"] + " chest(s), " + _0xg63c7a["itemSpawns"]["length"] + ">vid/<)s(nwaps meti ".split("").reverse().join("") + "</div>"; _0xf5fd += "<div style=\"border-top:1px solid rgba(255,255,255,0.12);margin-top:10px;padding-top:8px;display:grid;gap:4px\">" + "<strong>&#128641; Dynamic Helicrash</strong>" + "<div style=\"color:#bcae94;font-size:11px\">Spawns a helicopter wreck + 40 debris on a forest tile. Plays a distant sound 20s before spawning.</div>" + "<div style=\"font-size:11px;margin-top:2px\">" + "\"=eulav \"lavretnInwaps\"=remit-ileh-atad \"rebmun\"=epyt tupni<;psbn&:lavretni nwapS".split("").reverse().join("") + _0xcdafb["spawnInterval"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;ticks<br>" + "Duration:&nbsp;<input type=\"number\" data-heli-timer=\"duration\" value=\"" + _0xcdafb["duration"] + "\" style=\"width:50px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;ticks<br>" + "\"=eulav \"suidaRnwapsed\"=remit-ileh-atad \"rebmun\"=epyt tupni<;psbn&:suidar nwapseD".split("").reverse().join("") + _0xcdafb["despawnRadius"] + ">rb<stinu;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp05:htdiw\"=elyts \"".split("").reverse().join("") + "\"=eulav \"elacSekoms\"=remit-ileh-atad \"rebmun\"=epyt tupni<;psbn&:elacs ekomS".split("").reverse().join("") + _0xcdafb["smokeScale"] + ";psbn&;psbn&x;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp64:htdiw\"=elyts \"1.0\"=pets \"".split("").reverse().join("") + "Debris:&nbsp;<input type=\"number\" data-heli-timer=\"debrisCount\" value=\"" + _0xcdafb["debrisCount"] + "\" style=\"width:36px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;(t975)<br>" + "\"=eulav \"yticapOsirbed\"=remit-ileh-atad \"rebmun\"=epyt tupni<;psbn&:yticapo sirbeD".split("").reverse().join("") + _0xcdafb["debrisOpacity"] + "\" min=\"0\" max=\"1\" step=\"0.05\" style=\"width:46px;background:#222;border:1px solid #555;color:#fff;padding:1px 3px\">&nbsp;(0=hidden, 1=visible)<br>" + "\"=eulav \"yaleDdnuos\"=remit-ileh-atad \"rebmun\"=epyt tupni<;psbn&:yaled dnuoS".split("").reverse().join("") + _0xcdafb["soundDelay"] + ">rb<sm;psbn&>\"xp3 xp1:gniddap;fff#:roloc;555# dilos xp1:redrob;222#:dnuorgkcab;xp55:htdiw\"=elyts \"".split("").reverse().join("") + "Heli type:&nbsp;<select data-heli-timer=\"heliTypeIdx\" style=\"background:#222;border:1px solid #555;color:#fff;padding:1px\">" + "<option value=\"-1\"" + (_0xcdafb["heliTypeIdx"] < (753185 ^ 753185) ? "detceles ".split("").reverse().join("") : "") + ">Random (t1393 or t246)</option>" + "<option value=\"1393\"" + (_0xcdafb["heliTypeIdx"] === (401131 ^ 400282) ? " selected" : "") + ">noitpo/<)ileH dehsarC( 3931t>".split("").reverse().join("") + "\"642\"=eulav noitpo<".split("").reverse().join("") + (_0xcdafb["heliTypeIdx"] === (831402 ^ 831324) ? "detceles ".split("").reverse().join("") : "") + ">t246 (Small Heli)</option>" + ">rb<>tceles/<".split("").reverse().join("") + "\"delbanEremit\"=khc-ileh-atad \"xobkcehc\"=epyt tupni<>\"retniop:rosruc;enon:tceles-resu\"=elyts lebal<".split("").reverse().join("") + (_0xcdafb["enabled"] ? " checked" : "") + "> Enable timer-based respawn</label><br>" + "<label style=\"user-select:none;cursor:pointer\"><input type=\"checkbox\" data-heli-chk=\"useT344\"" + (_0xcdafb["useT344"] ? " checked" : "") + ">lebal/<selit tserof fo daetsni srekram 443t esU >".split("").reverse().join("") + "</div>" + ">\"parw:parw-xelf;xp2:pot-nigram;xp6:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("") + "<button data-heli-action=\"apply-cfg\" style=\"padding:4px 8px;font-size:11px\">Apply Config</button>" + "<button data-heli-action=\"toggle\" style=\"padding:6px 10px;background:" + (_0x77_0x317["running"] ? "rgba(200,60,60,0.25)" : "rgba(60,160,60,0.25)") + ">\"".split("").reverse().join("") + (_0x77_0x317["running"] ? "&#9632; Stop Heli" : "ileH tratS ;4569#&".split("").reverse().join("")) + "</button>" + ">nottub/<nwapseR ;5368#&>\"noitacol wen ta nwaps-er dna raelC\"=eltit \")51.0,0,561,552(abgr:dnuorgkcab;xp01 xp6:gniddap\"=elyts \"nwapser\"=noitca-ileh-atad nottub<".split("").reverse().join("") + ":dnuorgkcab;xp01 xp6:gniddap\"=elyts \"duh-elggot\"=noitca-ileh-atad nottub<".split("").reverse().join("") + (_0xcdafb["heliHudVisible"] ? ")53.0,552,081,09(abgr".split("").reverse().join("") : "rgba(60,80,120,0.25)") + "\" title=\"Show/hide helicrash HUD\">&#9635; HUD</button>" + ":dnuorgkcab;xp01 xp6:gniddap\"=elyts \"tuoyal-elggot\"=noitca-ileh-atad nottub<".split("").reverse().join("") + (_0xdc93b["heliLayoutMode"] ? "rgba(90,180,255,0.25)" : "rgba(60,60,100,0.25)") + " ;592821#&>\"rotide tuoyal hsarcileh elggoT\"=eltit \"".split("").reverse().join("") + (_0xdc93b["heliLayoutMode"] ? "Map View" : "tuoyaL tidE".split("").reverse().join("")) + ">nottub/<".split("").reverse().join("") + "<button data-heli-action=\"toggle-debris\" style=\"padding:6px 10px;background:" + (_0xdc93b["heliDebrisMode"] ? "rgba(245,166,35,0.35)" : ")52.0,02,06,06(abgr".split("").reverse().join("")) + " ;402821#&>\"rotide tuoyal sirbed 579t elggoT\"=eltit \"".split("").reverse().join("") + (_0xdc93b["heliDebrisMode"] ? "Map View" : "Edit Debris") + ">nottub/<".split("").reverse().join("") + ">vid/<".split("").reverse().join("") + ";psbn&:sutatS>\"49eacb#:roloc;xp11:ezis-tnof\"=elyts vid<".split("").reverse().join("") + (_0x77_0x317["running"] ? _0x77_0x317["_pendingSpawn"] ? "<span style=\"color:#fc0\">Pending...</span>" : "<span style=\"color:#5cf\">" + _0x77_0x317["status"]["toUpperCase"]() + ">naps/<".split("").reverse().join("") : "deppotS".split("").reverse().join("")) + "</div>" + "<div style=\"font-size:11px;color:#bcae94\">Layout: " + _0x8d7eb["chests"]["length"] + " chest(s), " + _0x8d7eb["itemSpawns"]["length"] + " item spawn(s), " + (_0x78_0x5ca["length"] > (636713 ^ 636713) ? _0x78_0x5ca["length"] + " debris piece(s)" : "random debris") + "</div>" + ">vid/<".split("").reverse().join(""); _0xf5fd += "</div>"; _0xebd["innerHTML"] = _0xf5fd; var _0xb7f = (701551 ^ 701544) + (549340 ^ 549339); var _0xcae6e = _0x6ec34e(); _0xb7f = "idqldh".split("").reverse().join(""); var _0xd3_0x57f = (817415 ^ 817415) + (976014 ^ 976015); var _0x88b6cf = ""; _0xd3_0x57f = (462312 ^ 462312) + (128507 ^ 128505); if (_0xdc93b["heliLayoutMode"]) {
        _0x88b6cf = "<div style=\"display:grid;gap:6px\">" + "<strong>&#128641; Helicrash Layout Editor</strong>" + _0x82fe() + "</div>";
    }
    else if (_0xdc93b["heliDebrisMode"]) {
        _0x88b6cf = ">\"xp6:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("") + "<strong>&#128641; Helicrash Debris Layout (t975)</strong>" + _0xbe1ced() + "</div>";
    }
    else if (_0xdc93b["convoyLayoutMode"]) {
        _0x88b6cf = "<div style=\"display:grid;gap:6px\">" + ">gnorts/<rotidE tuoyaL yovnoC>gnorts<".split("").reverse().join("") + _0xa4_0xe4g() + ">vid/<".split("").reverse().join("");
    }
    else {
        _0x88b6cf = ">gnorts/<weiverP dirG paM>gnorts<>\"xp6:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join("");
        if (!_0xcae6e || !K) {
            _0x88b6cf += "<div style=\"color:#f55\">Runtime not available.</div>";
        }
        else {
            var _0x26_0xe96 = (399255 ^ 399254) + (679173 ^ 679175);
            var _0x89gef = null;
            _0x26_0xe96 = (498552 ^ 498553) + (826555 ^ 826559);
            var _0xbbf = (883059 ^ 883067) + (338711 ^ 338706);
            var _0x565e5d = _0xcae6e[K["types"]];
            _0xbbf = "bknppl".split("").reverse().join("");
            for (var j = 949137 ^ 949137; j < _0x565e5d["length"]; j++) {
                if (_0x565e5d[j]["name"] === "t518") {
                    _0x89gef = _0x565e5d[j];
                    break;
                }
            }
            if (!_0x89gef || !_0x89gef[K["insts"]]["length"] || !_0x89gef[K["insts"]][365491 ^ 365491]["rd"]) {
                _0x88b6cf += "<div style=\"color:#bcae94\">Map data not loaded. Open the Map layout first.</div>";
            }
            else {
                var _0x981b6a = (358925 ^ 358925) + (885070 ^ 885066);
                var _0x5ee15a = _0x89gef[K["insts"]][861988 ^ 861988];
                _0x981b6a = 315261 ^ 315256;
                var _0x59ba8c = _0x5ee15a["hb"] || 639675 ^ 639659, _0x5dc6fg = _0x5ee15a["rb"] || 592051 ^ 592035;
                var _0x44f = (736255 ^ 736252) + (547768 ^ 547771);
                var _0xb6ee = {};
                _0x44f = (363965 ^ 363964) + (639553 ^ 639553);
                for (var _0x17e59b = 671393 ^ 671393; _0x17e59b < _0xb4e95f["length"]; _0x17e59b++)
                    _0xb6ee[_0xb4e95f[_0x17e59b]["id"]] = _0xb4e95f[_0x17e59b]["color"];
                var _0x311b8a = (196711 ^ 196706) + (532925 ^ 532921);
                var _0xcf25ef = {};
                _0x311b8a = 105153 ^ 105153;
                for (var _0x705be = 669707 ^ 669707; _0x705be < _0xe2ab["selectedTileIds"]["length"]; _0x705be++)
                    _0xcf25ef[_0xe2ab["selectedTileIds"][_0x705be]] = !![];
                var _0xdb487d = {}, _0xa2c21c = {};
                if (_0xbd3["activeCycle"] && _0xbd3["activeCycle"]["insts"]) {
                    for (var _0x9e398e = 368972 ^ 368972; _0x9e398e < _0xbd3["activeCycle"]["insts"]["length"]; _0x9e398e++) {
                        var _0xc4a22e = _0xbd3["activeCycle"]["insts"][_0x9e398e];
                        _0xdb487d[_0xc4a22e["r"] + "_" + _0xc4a22e["c"]] = !![];
                    }
                }
                for (var _0xe7a = 456605 ^ 456605; _0xe7a < _0xbd3["nextCandidates"]["length"]; _0xe7a++) {
                    var _0x0ae54f = _0xbd3["nextCandidates"][_0xe7a];
                    _0xa2c21c[_0x0ae54f["r"] + "_" + _0x0ae54f["c"]] = !![];
                }
                var _0xbbgd = {};
                for (var _0x1b_0x176 = 721462 ^ 721462; _0x1b_0x176 < _0x42a["convoys"]["length"]; _0x1b_0x176++) {
                    var _0x53bd = _0x42a["convoys"][_0x1b_0x176];
                    _0xbbgd[_0x53bd["anchorR"] + "_" + _0x53bd["anchorC"]] = !![];
                }
                var _0xf93b = {}, _0x89_0x5bf = {};
                for (var _0xdc988f = 760646 ^ 760646; _0xdc988f < _0x77_0x317["crashes"]["length"]; _0xdc988f++) {
                    var _0xf5d = _0x77_0x317["crashes"][_0xdc988f];
                    if (_0xf5d["anchorR"] >= (985466 ^ 985466) && _0xf5d["anchorC"] >= (916559 ^ 916559))
                        _0xf93b[_0xf5d["anchorR"] + "_" + _0xf5d["anchorC"]] = !![];
                }
                if (_0x77_0x317["_pendingCrash"] && _0x77_0x317["_pendingCrash"]["r"] >= (216838 ^ 216838)) {
                    _0x89_0x5bf[_0x77_0x317["_pendingCrash"]["r"] + "_" + _0x77_0x317["_pendingCrash"]["c"]] = !![];
                }
                _0x88b6cf += "<div data-event-grid=\"1\" style=\"display:grid;grid-template-columns:repeat(" + _0x59ba8c + ",18px);gap:2px\">";
                for (var _0xffd = 173039 ^ 173039; _0xffd < _0x5dc6fg; _0xffd++) {
                    for (var _0x87aafg = 570581 ^ 570581; _0x87aafg < _0x59ba8c; _0x87aafg++) {
                        var _0x85d7e = _0x5ee15a["rd"][_0xffd][_0x87aafg][853671 ^ 853671];
                        var _0xa628g = (325197 ^ 325195) + (542753 ^ 542753);
                        var _0x15ac9g = _0xcf25ef[_0x85d7e];
                        _0xa628g = (266539 ^ 266538) + (558434 ^ 558442);
                        let _0x657g;
                        var _0xd02gfa = _0xffd + "_" + _0x87aafg;
                        _0x657g = (686171 ^ 686173) + (169017 ^ 169022);
                        let _0x18a;
                        var _0x91_0xf7e = _0xdb487d[_0xd02gfa];
                        _0x18a = (682679 ^ 682674) + (204680 ^ 204684);
                        var _0x1169b = (199450 ^ 199454) + (391734 ^ 391743);
                        var _0x63fead = _0xa2c21c[_0xd02gfa];
                        _0x1169b = 562271 ^ 562270;
                        var _0xae735f = _0xbbgd[_0xd02gfa];
                        let _0x9g07bg;
                        var _0x4cf = _0xf93b[_0xd02gfa];
                        _0x9g07bg = (530443 ^ 530443) + (876549 ^ 876544);
                        var _0x8g274f = _0x89_0x5bf[_0xd02gfa];
                        var _0xd98c4a, _0xaa2de;
                        if (_0x91_0xf7e) {
                            _0xd98c4a = "rgba(0,220,80,0.35)";
                            _0xaa2de = ")9.0,09,552,0(abgr dilos xp2".split("").reverse().join("");
                        }
                        else if (_0x63fead) {
                            _0xd98c4a = ")22.0,0,091,552(abgr".split("").reverse().join("");
                            _0xaa2de = "1px dashed rgba(255,210,0,0.7)";
                        }
                        else if (_0x4cf) {
                            _0xd98c4a = "rgba(220,80,30,0.4)";
                            _0xaa2de = "2px solid rgba(255,120,40,0.95)";
                        }
                        else if (_0x8g274f) {
                            _0xd98c4a = "rgba(255,165,0,0.25)";
                            _0xaa2de = "2px dashed rgba(255,165,0,0.8)";
                        }
                        else if (_0xae735f) {
                            _0xd98c4a = "rgba(120,80,200,0.35)";
                            _0xaa2de = "2px solid rgba(150,110,230,0.9)";
                        }
                        else if (_0x15ac9g) {
                            _0xd98c4a = _0xb6ee[_0x85d7e] || "888#".split("").reverse().join("");
                            _0xaa2de = ")4.0,552,552,552(abgr dilos xp1".split("").reverse().join("");
                        }
                        else {
                            _0xd98c4a = ")40.0,552,552,552(abgr".split("").reverse().join("");
                            _0xaa2de = "1px solid rgba(255,255,255,0.06)";
                        }
                        var _0xc55edd = _0x91_0xf7e ? "ACTIVE GAS\nRow " + _0xffd + " loC ,".split("").reverse().join("") + _0x87aafg : _0x63fead ? " woR\nNWAPS TXEN".split("").reverse().join("") + _0xffd + " loC ,".split("").reverse().join("") + _0x87aafg : _0x4cf ? "HELICRASH\nRow " + _0xffd + " loC ,".split("").reverse().join("") + _0x87aafg : _0x8g274f ? " woR\nGNIMOCNI ILEH".split("").reverse().join("") + _0xffd + ", Col " + _0x87aafg : _0xae735f ? "CONVOY ANCHOR\nRow " + _0xffd + " loC ,".split("").reverse().join("") + _0x87aafg : " woR\nereh tneve nwapS".split("").reverse().join("") + _0xffd + ", Col " + _0x87aafg + " epyt( ".split("").reverse().join("") + _0x85d7e + ")";
                        _0x88b6cf += "<div data-gr=\"" + _0xffd + "\" data-gc=\"" + _0x87aafg + "\" title=\"" + _0xc55edd + "\" style=\"width:18px;height:18px;background:" + _0xd98c4a + ";border:" + _0xaa2de + ";border-radius:2px;cursor:pointer\"></div>";
                    }
                }
                _0x88b6cf += "</div>";
                var _0xe1fcb = ">\"xp01:ezis-tnof;xp4:pot-nigram;parw:parw-xelf;xp8:pag;xelf:yalpsid\"=elyts vid<".split("").reverse().join("");
                for (var li = 340669 ^ 340669; li < _0xb4e95f["length"]; li++) {
                    _0xe1fcb += "<span><span style=\"display:inline-block;width:10px;height:10px;background:" + _0xb4e95f[li]["color"] + ";border-radius:2px\"></span> " + _0x0d5eg(_0xb4e95f[li]["name"]) + ">naps/<".split("").reverse().join("");
                }
                _0xe1fcb += "<span><span style=\"display:inline-block;width:10px;height:10px;background:rgba(0,220,80,0.35);border:2px solid rgba(0,255,90,0.9);border-radius:2px\"></span> Gas active</span>";
                _0xe1fcb += "<span><span style=\"display:inline-block;width:10px;height:10px;background:rgba(255,190,0,0.22);border:1px dashed rgba(255,210,0,0.7);border-radius:2px\"></span> Next spawn</span>";
                _0xe1fcb += "<span><span style=\"display:inline-block;width:10px;height:10px;background:rgba(120,80,200,0.35);border:2px solid rgba(150,110,230,0.9);border-radius:2px\"></span> Convoy</span>";
                _0xe1fcb += ">naps/<hsarcileH >naps/<>\"xp2:suidar-redrob;)59.0,04,021,552(abgr dilos xp2:redrob;)4.0,03,08,022(abgr:dnuorgkcab;xp01:thgieh;xp01:htdiw;kcolb-enilni:yalpsid\"=elyts naps<>naps<".split("").reverse().join("");
                _0xe1fcb += ">naps/<gnimocni ileH >naps/<>\"xp2:suidar-redrob;)8.0,0,561,552(abgr dehsad xp2:redrob;)52.0,0,561,552(abgr:dnuorgkcab;xp01:thgieh;xp01:htdiw;kcolb-enilni:yalpsid\"=elyts naps<>naps<".split("").reverse().join("");
                _0xe1fcb += "</div>";
                _0x88b6cf += _0xe1fcb;
            }
        }
        _0x88b6cf += ">vid/<".split("").reverse().join("");
    } _0x1495ac["innerHTML"] = _0x88b6cf; var _0x92_0x8g6 = ">gnorts/<tluseR>gnorts<>\"xp8:pag;dirg:yalpsid\"=elyts vid<".split("").reverse().join(""); _0xbc5db = (490699 ^ 490702) + (536176 ^ 536176); if (_0xe2ab["lastResult"]) {
        if (_0xe2ab["lastResult"]["error"]) {
            _0x92_0x8g6 += "<div style=\"color:#f55\">" + _0x0d5eg(_0xe2ab["lastResult"]["error"]) + ">vid/<".split("").reverse().join("");
        }
        else if (_0xe2ab["lastResult"]["cleared"] != null) {
            _0x92_0x8g6 += "<div style=\"color:#5cf\">Hidden " + _0xe2ab["lastResult"]["cleared"] + ">vid/<.secnatsni ".split("").reverse().join("");
        }
        else if (_0xe2ab["lastResult"]["pending"] != null) {
            _0x92_0x8g6 += " gnikirtS>\"5af#:roloc\"=elyts vid<".split("").reverse().join("") + _0xe2ab["lastResult"]["pending"] + " location(s)...</div>";
            if (_0xe2ab["lastResult"]["spawned"]) {
                _0x92_0x8g6 += ">\"5f5#:roloc\"=elyts vid<".split("").reverse().join("") + _0xe2ab["lastResult"]["spawned"] + " spawned so far.</div>";
            }
        }
        else {
            _0x92_0x8g6 += " denwapS>\"5f5#:roloc\"=elyts vid<".split("").reverse().join("") + _0xe2ab["lastResult"]["spawned"] + " instances.</div>";
        }
    }
    else {
        _0x92_0x8g6 += "<div style=\"color:#bcae94\">No spawn yet.</div>";
    } _0x92_0x8g6 += " :denwaps dekcarT>rb<)44( niaR :reyaL>rb<stinu dlrow 0002x0002 :eziS>rb<gnp.0teehs-uqud :etirpS>rb<6211t :epyT>\"xp6:pot-nigram;xp11:ezis-tnof;49eacb#:roloc\"=elyts vid<".split("").reverse().join("") + _0xe2ab["spawnedInsts"]["length"] + ">vid/<".split("").reverse().join(""); if (_0xe2ab["flareResult"]) {
        if (_0xe2ab["flareResult"]["error"]) {
            _0x92_0x8g6 += "<div style=\"color:#f55;font-size:11px;margin-top:4px\">Flare: " + _0x0d5eg(_0xe2ab["flareResult"]["error"]) + ">vid/<".split("").reverse().join("");
        }
        else {
            _0x92_0x8g6 += "<div style=\"color:#fc0;font-size:11px;margin-top:4px\">Flare shot at (" + _0xe2ab["flareResult"]["x"] + " ,".split("").reverse().join("") + _0xe2ab["flareResult"]["y"] + ">vid/<.)".split("").reverse().join("");
        }
    } _0x92_0x8g6 += "<div data-gas-countdown=\"1\">" + _0x4edf() + ">vid/<".split("").reverse().join(""); _0x92_0x8g6 += "<div data-convoy-countdown=\"1\">" + _0xaa69ad() + "</div>"; _0x92_0x8g6 += "<div data-heli-countdown=\"1\">" + _0x5866da() + "</div>"; _0x92_0x8g6 += ">vid/<".split("").reverse().join(""); _0x49996d["innerHTML"] = _0x92_0x8g6; var _0x1562fb = (786576 ^ 786581) + (602826 ^ 602829); var _0x1ff97f = _0xebd["querySelectorAll"]("]elit-tneve-atad[".split("").reverse().join("")); _0x1562fb = (894979 ^ 894979) + (582195 ^ 582198); for (var _0xe642de = 785789 ^ 785789; _0xe642de < _0x1ff97f["length"]; _0xe642de++) {
        _0x1ff97f[_0xe642de]["addEventListener"]("change", function (_0x98a) { var _0xeg4gc = parseInt(this["getAttribute"]("data-event-tile")); _0x98a = 572237 ^ 572238; var _0xc5d0f = _0xe2ab["selectedTileIds"]["indexOf"](_0xeg4gc); if (this["checked"] && _0xc5d0f < (922432 ^ 922432))
            _0xe2ab["selectedTileIds"]["push"](_0xeg4gc);
        else if (!this["checked"] && _0xc5d0f >= (673180 ^ 673180))
            _0xe2ab["selectedTileIds"]["splice"](_0xc5d0f, 577018 ^ 577019); _0x1728b(); });
    } var _0x9c4cdd = (287812 ^ 287815) + (619734 ^ 619731); var _0xae6c = _0xebd["querySelector"]("]\"nwaps\"=noitca-tneve-atad[".split("").reverse().join("")); _0x9c4cdd = 950497 ^ 950496; if (_0xae6c)
        _0xae6c["addEventListener"]("click", function () { _0xe2ab["lastResult"] = _0x58682d(_0xe2ab["selectedTileIds"]); _0x1728b(); }); var _0xb13 = _0xebd["querySelector"]("[data-event-action=\"clear\"]"); _0xd4_0x483 = (811060 ^ 811061) + (366749 ^ 366741); if (_0xb13)
        _0xb13["addEventListener"]("click", function () { _0x1213e(function () { _0xe2ab["spawnedInsts"] = []; _0x1728b(); }); }); var _0x63113e = (501784 ^ 501787) + (135710 ^ 135705); var _0x93_0x3ca = _0x1495ac["querySelector"]("]\"1\"=dirg-tneve-atad[".split("").reverse().join("")); _0x63113e = (769675 ^ 769679) + (625395 ^ 625396); if (_0x93_0x3ca) {
        _0x93_0x3ca["addEventListener"]("kcilc".split("").reverse().join(""), function (e) { var _0x35acba = e["target"]; while (_0x35acba && _0x35acba !== _0x93_0x3ca && !_0x35acba["hasAttribute"]("data-gr"))
            _0x35acba = _0x35acba["parentElement"]; if (!_0x35acba || !_0x35acba["hasAttribute"]("data-gr"))
            return; _0xe2ab["lastResult"] = _0xd8e(parseInt(_0x35acba["getAttribute"]("rg-atad".split("").reverse().join(""))), parseInt(_0x35acba["getAttribute"]("data-gc"))); _0x1728b(); });
    } var _0x2a4 = _0xebd["querySelector"]("]\"tset-eralf\"=noitca-tneve-atad[".split("").reverse().join("")); _0x352cac = 400488 ^ 400491; if (_0x2a4)
        _0x2a4["addEventListener"]("click", function () { _0xe2ab["flareResult"] = _0x37963a(); _0x1728b(); }); var _0xd66ae = _0xebd["querySelector"]("[data-gas-action=\"toggle\"]"); _0xf3759d = (348233 ^ 348233) + (969901 ^ 969899); if (_0xd66ae)
        _0xd66ae["addEventListener"]("click", function () { if (_0xbd3["running"])
            _0x34c3e(!![]);
        else
            _0xceba(); }); var _0x06c20e = _0xebd["querySelector"]("[data-gas-action=\"toggle-hud\"]"); _0xaaaa0b = "plbkkd"; if (_0x06c20e)
        _0x06c20e["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0x0964e = (371402 ^ 371404) + (291027 ^ 291027); var _0xg73c = document["getElementById"]("duHsaGzdm".split("").reverse().join("")); _0x0964e = 322503 ^ 322496; if (_0xg73c)
            _0xg73c["style"]["display"] = _0xg73c["style"]["display"] === "enon".split("").reverse().join("") ? "block" : "none"; }); var _0x968e2g = _0xebd["querySelector"]("]\"gfc-ylppa\"=noitca-sag-atad[".split("").reverse().join("")); if (_0x968e2g)
        _0x968e2g["addEventListener"]("click", function () { var _0x6ce = (233717 ^ 233718) + (151474 ^ 151473); var _0xbd3c1c = {
            "spawnInterval": function (v) { _0xfa3["spawnInterval"] = Math["max"](175800 ^ 175801, v); },
                    "duration": function (v) { _0xfa3["duration"] = Math["max"](904992 ^ 904993, v); },
                    "stopAtTimer": function (v) { _0xfa3["stopAtTimer"] = v; },
                    "fadeDuration": function (v) { _0xfa3["fadeDuration"] = Math["max"](479403 ^ 479439, v); },
                    "max0": function (v) { _0xfa3["maxPerIsland"][808113 ^ 808113] = v < (652167 ^ 652167) ? -(848582 ^ 848583) : Math["max"](440354 ^ 440355, v); },
                    "max1": function (v) { _0xfa3["maxPerIsland"][924915 ^ 924914] = v < (181654 ^ 181654) ? -(480055 ^ 480054) : Math["max"](435282 ^ 435283, v); },
                    "max2": function (v) { _0xfa3["maxPerIsland"][354900 ^ 354902] = v < (110679 ^ 110679) ? -(261444 ^ 261445) : Math["max"](634933 ^ 634932, v); },
                    "max3": function (v) { _0xfa3["maxPerIsland"][242332 ^ 242335] = v < (816650 ^ 816650) ? -(747811 ^ 747810) : Math["max"](233086 ^ 233087, v); },
                    "max4": function (v) { _0xfa3["maxPerIsland"][581898 ^ 581902] = v < (515785 ^ 515785) ? -(569573 ^ 569572) : Math["max"](731841 ^ 731840, v); }
        }; _0x6ce = (258901 ^ 258900) + (113364 ^ 113373); var _0xb6a = _0xebd["querySelectorAll"]("[data-gas-cfg]"); for (var _0x353ae = 938380 ^ 938380; _0x353ae < _0xb6a["length"]; _0x353ae++) {
            var _0x1d36f = (978080 ^ 978083) + (977045 ^ 977044);
            var _0xaa2e = _0xb6a[_0x353ae]["getAttribute"]("data-gas-cfg");
            _0x1d36f = (731417 ^ 731423) + (799911 ^ 799908);
            var _0xd7dg = (127834 ^ 127827) + (878232 ^ 878237);
            var _0xa3a = parseFloat(_0xb6a[_0x353ae]["value"]);
            _0xd7dg = "hkgfbj".split("").reverse().join("");
            if (!isNaN(_0xa3a) && _0xbd3c1c[_0xaa2e])
                _0xbd3c1c[_0xaa2e](_0xa3a);
        } var _0xf85f = _0xebd["querySelectorAll"]("]khc-sag-atad[".split("").reverse().join("")); for (var _0x31571d = 351651 ^ 351651; _0x31571d < _0xf85f["length"]; _0x31571d++) {
            if (_0xf85f[_0x31571d]["getAttribute"]("data-gas-chk") === "tnuoCezimodnar".split("").reverse().join(""))
                _0xfa3["randomizeCount"] = _0xf85f[_0x31571d]["checked"];
        } _0x9gf(); _0x1728b(); }); var _0x4dce5f = _0xebd["querySelector"]("[data-convoy-action=\"toggle\"]"); if (_0x4dce5f)
        _0x4dce5f["addEventListener"]("click", function () { if (_0x42a["running"])
            _0xcac18a();
        else
            _0x02999g(); }); var _0xb2837f = _0xebd["querySelector"]("[data-convoy-action=\"respawn\"]"); if (_0xb2837f)
        _0xb2837f["addEventListener"]("click", function () { _0x1e733a(); _0x65f2e(); _0x42a["_pendingSpawn"] = false; _0x42a["status"] = "idle"; if (_0x42a["running"])
            _0xc7fb0c(); _0x1728b(); }); var _0x574fa = _0xebd["querySelector"]("[data-convoy-action=\"toggle-hud\"]"); if (_0x574fa)
        _0x574fa["addEventListener"]("click", function () { _0x06cd7a["convoyHudVisible"] = !_0x06cd7a["convoyHudVisible"]; _0x1d5a(); _0xcda06f(); _0x1728b(); }); var _0x99dcf = _0xebd["querySelector"]("]\"tuoyal-elggot\"=noitca-yovnoc-atad[".split("").reverse().join("")); _0x65e01a = (104025 ^ 104025) + (792999 ^ 792992); if (_0x99dcf)
        _0x99dcf["addEventListener"]("click", function () { _0xdc93b["convoyLayoutMode"] = !_0xdc93b["convoyLayoutMode"]; _0xc9dab = null; _0xb8de4f = null; _0x1728b(); }); var _0xd741bb = (727892 ^ 727890) + (624707 ^ 624707); var _0xa962c = _0xebd["querySelector"]("]\"gfc-ylppa\"=noitca-yovnoc-atad[".split("").reverse().join("")); _0xd741bb = "ellnfp".split("").reverse().join(""); if (_0xa962c)
        _0xa962c["addEventListener"]("click", function (_0x7d481e, _0xg3abf) { var _0xe8241f = (756411 ^ 756412) + (451265 ^ 451273); var _0x379de = {
            "maxConvoys": function (v) { _0xba3["maxConvoys"] = Math["max"](945780 ^ 945781, v); },
                    "vehicleGap": function (v) { _0xba3["vehicleGap"] = Math["max"](892412 ^ 892366, v); },
                    "roadTileId": function (v) { _0xba3["roadTileId"] = Math["floor"](v); },
                    "minRoadRun": function (v) { _0xba3["minRoadRun"] = Math["max"](775714 ^ 775715, v); },
                    "layerIndex": function (v) { _0xba3["layerIndex"] = Math["max"](663436 ^ 663436, Math["floor"](v)); },
                    "fadeDuration": function (v) { _0xba3["fadeDuration"] = Math["max"](692376 ^ 692476, v); },
                    "maxAngleDeg": function (v) { _0xba3["maxAngleDeg"] = Math["max"](968464 ^ 968464, v); },
                    "exclusionRadius": function (v) { _0xba3["exclusionRadius"] = Math["max"](570785 ^ 570785, v); }
        }; _0xe8241f = (775678 ^ 775674) + (716687 ^ 716681); var _0x75f36e = _0xebd["querySelectorAll"]("[data-convoy-cfg]"); _0x7d481e = (558937 ^ 558937) + (726639 ^ 726631); for (var _0x46d = 799385 ^ 799385; _0x46d < _0x75f36e["length"]; _0x46d++) {
            var _0xb21bf = (815145 ^ 815150) + (616797 ^ 616789);
            var _0xc5cfe = _0x75f36e[_0x46d]["getAttribute"]("gfc-yovnoc-atad".split("").reverse().join(""));
            _0xb21bf = (417901 ^ 417899) + (979215 ^ 979207);
            var _0x781ebb = parseFloat(_0x75f36e[_0x46d]["value"]);
            if (!isNaN(_0x781ebb) && _0x379de[_0xc5cfe])
                _0x379de[_0xc5cfe](_0x781ebb);
        } var _0xe7979a = _0xebd["querySelectorAll"]("[data-convoy-timer]"); _0xg3abf = (706186 ^ 706187) + (744681 ^ 744680); for (var _0x25be = 382243 ^ 382243; _0x25be < _0xe7979a["length"]; _0x25be++) {
            var _0x05d09e = _0xe7979a[_0x25be]["getAttribute"]("remit-yovnoc-atad".split("").reverse().join(""));
            var _0x395e4d = parseFloat(_0xe7979a[_0x25be]["value"]);
            if (!isNaN(_0x395e4d)) {
                if (_0x05d09e === "spawnInterval")
                    _0x06cd7a["spawnInterval"] = Math["max"](510675 ^ 510674, _0x395e4d);
                if (_0x05d09e === "noitarud".split("").reverse().join(""))
                    _0x06cd7a["duration"] = Math["max"](915704 ^ 915705, _0x395e4d);
                if (_0x05d09e === "suidaRnwapsed".split("").reverse().join(""))
                    _0x06cd7a["despawnRadius"] = Math["max"](285156 ^ 285142, _0x395e4d);
            }
        } var _0x3becf = _0xebd["querySelector"]("[data-convoy-chk=\"timerEnabled\"]"); if (_0x3becf)
            _0x06cd7a["enabled"] = _0x3becf["checked"]; _0x1d5a(); _0x1728b(); }); if (_0xdc93b["convoyLayoutMode"]) {
        var _0xagc = _0x1495ac["querySelector"]("[data-convoy-layout-canvas]");
        var _0xa11 = _0x1495ac["querySelector"]("[data-convoy-layout-add=\"chest\"]");
        if (_0xa11)
            _0xa11["addEventListener"]("click", function () { _0xg63c7a["chests"]["push"]({
                "offsetX": 0,
                        "offsetY": 0,
                        "chestTypeId": "type1"
            }); _0xc9dab = {
                "type": "chest",
                        "idx": _0xg63c7a["chests"]["length"] - (416431 ^ 416430)
            }; _0x1728b(); });
        var _0x9cf1fc = _0x1495ac["querySelector"]("[data-convoy-layout-add=\"itemSpawn\"]");
        if (_0x9cf1fc)
            _0x9cf1fc["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xg63c7a["itemSpawns"]["push"]({
                "offsetX": 0,
                        "offsetY": 0,
                        "loot": []
            }); _0xc9dab = {
                "type": "itemSpawn",
                        "idx": _0xg63c7a["itemSpawns"]["length"] - (225618 ^ 225619)
            }; _0x1728b(); });
        let _0x66112g;
        var _0x1bd53a = _0x1495ac["querySelector"]("]etacilpud-tuoyal-yovnoc-atad[".split("").reverse().join(""));
        _0x66112g = (567722 ^ 567724) + (957205 ^ 957213);
        if (_0x1bd53a)
            _0x1bd53a["addEventListener"]("click", function (_0x511gad) { if (!_0xc9dab)
                return; var _0x9agfa = _0xc9dab["type"] === "tsehc".split("").reverse().join("") ? _0xg63c7a["chests"] : _0xg63c7a["itemSpawns"]; var _0x0g889d = _0x9agfa[_0xc9dab["idx"]]; if (!_0x0g889d)
                return; var _0x1fa94b = _0x8dd(_0x0g889d); _0x511gad = (207790 ^ 207784) + (673551 ^ 673544); _0x1fa94b["offsetX"] = (_0x1fa94b["offsetX"] || 340962 ^ 340962) + (261799 ^ 261811); _0x1fa94b["offsetY"] = (_0x1fa94b["offsetY"] || 163155 ^ 163155) + (275781 ^ 275793); _0x9agfa["push"](_0x1fa94b); _0xc9dab = {
                "type": _0xc9dab["type"],
                        "idx": _0x9agfa["length"] - (470991 ^ 470990)
            }; _0x1728b(); });
        var _0xa37c = (333396 ^ 333405) + (156930 ^ 156928);
        var _0x95_0x25b = _0x1495ac["querySelector"]("]eteled-tuoyal-yovnoc-atad[".split("").reverse().join(""));
        _0xa37c = "bhkqjb";
        if (_0x95_0x25b)
            _0x95_0x25b["addEventListener"]("kcilc".split("").reverse().join(""), function () { if (!_0xc9dab)
                return; if (_0xc9dab["type"] === "chest") {
                _0xg63c7a["chests"]["splice"](_0xc9dab["idx"], 999391 ^ 999390);
            }
            else {
                _0xg63c7a["itemSpawns"]["splice"](_0xc9dab["idx"], 891172 ^ 891173);
            } _0xc9dab = null; _0x1728b(); });
        var _0x74f = _0x1495ac["querySelector"]("[data-convoy-layout-save]");
        if (_0x74f)
            _0x74f["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xb1b6b(); _0x1728b(); });
        var _0x9846c = _0x1495ac["querySelector"]("[data-layout-prop-apply]");
        if (_0x9846c)
            _0x9846c["addEventListener"]("click", function () { if (!_0xc9dab)
                return; var _0x215 = _0xc9dab["type"] === "tsehc".split("").reverse().join("") ? _0xg63c7a["chests"] : _0xg63c7a["itemSpawns"]; var _0xf6fb2b = (940322 ^ 940322) + (675946 ^ 675944); var _0x32cb = _0x215[_0xc9dab["idx"]]; _0xf6fb2b = (940287 ^ 940286) + (661698 ^ 661699); if (!_0x32cb)
                return; var _0x23ad = _0x1495ac["querySelectorAll"]("[data-layout-prop]"); for (var _0x5db28e = 984666 ^ 984666; _0x5db28e < _0x23ad["length"]; _0x5db28e++) {
                var _0x67dae = _0x23ad[_0x5db28e]["getAttribute"]("data-layout-prop");
                var _0x67e = _0x23ad[_0x5db28e]["value"];
                if (_0x67dae === "Xtesffo".split("").reverse().join("") || _0x67dae === "offsetY")
                    _0x32cb[_0x67dae] = Math["round"](parseFloat(_0x67e) || 150655 ^ 150655);
                else if (_0x67dae === "chestTypeId")
                    _0x32cb[_0x67dae] = _0x67e;
                else if (_0x67dae === "spriteTypeIdx")
                    _0x32cb[_0x67dae] = parseInt(_0x67e) || 737182 ^ 736456;
                else if (_0x67dae === "xdIelcihev".split("").reverse().join(""))
                    _0x32cb[_0x67dae] = parseInt(_0x67e) < (235229 ^ 235229) ? null : parseInt(_0x67e);
            } _0x1728b(); });
        var _0xe10 = _0x1495ac["querySelectorAll"]("[data-loot-weight]");
        for (var _0xa21ca = 188026 ^ 188026; _0xa21ca < _0xe10["length"]; _0xa21ca++) {
            _0xe10[_0xa21ca]["addEventListener"]("egnahc".split("").reverse().join(""), function (el) { return function () { if (!_0xc9dab || _0xc9dab["type"] !== "itemSpawn")
                return; var _0x2f2 = parseInt(el["getAttribute"]("data-loot-idx")); var _0xg_0xe92 = (369067 ^ 369069) + (102713 ^ 102717); var _0xeca72e = _0xg63c7a["itemSpawns"][_0xc9dab["idx"]]; _0xg_0xe92 = (355303 ^ 355311) + (101084 ^ 101077); if (_0xeca72e && _0xeca72e["loot"] && _0xeca72e["loot"][_0x2f2])
                _0xeca72e["loot"][_0x2f2]["weight"] = Math["max"](358380 ^ 358381, parseInt(el["value"]) || 889927 ^ 889926); _0x1728b(); }; }(_0xe10[_0xa21ca]));
        }
        let _0xdea53e;
        var _0x351gbb = _0x1495ac["querySelectorAll"]("]evomer-tool-atad[".split("").reverse().join(""));
        _0xdea53e = 860668 ^ 860669;
        for (var _0x34362f = 516345 ^ 516345; _0x34362f < _0x351gbb["length"]; _0x34362f++) {
            _0x351gbb[_0x34362f]["addEventListener"]("click", function (el) { return function () { if (!_0xc9dab || _0xc9dab["type"] !== "itemSpawn")
                return; var _0xa673df = (994733 ^ 994731) + (546164 ^ 546167); var _0x8f3 = parseInt(el["getAttribute"]("data-loot-idx")); _0xa673df = 788568 ^ 788574; var _0x216 = _0xg63c7a["itemSpawns"][_0xc9dab["idx"]]; if (_0x216 && _0x216["loot"])
                _0x216["loot"]["splice"](_0x8f3, 347593 ^ 347592); _0x1728b(); }; }(_0x351gbb[_0x34362f]));
        }
        var _0xd189ba = _0x1495ac["querySelector"]("[data-loot-add]");
        if (_0xd189ba)
            _0xd189ba["addEventListener"]("click", function () { if (!_0xc9dab || _0xc9dab["type"] !== "itemSpawn")
                return; var _0x1a86gc = _0x1495ac["querySelector"]("]di-dda-tool-atad[".split("").reverse().join("")); var _0xd20 = parseInt(_0x1a86gc ? _0x1a86gc["value"] : "") || 647451 ^ 647451; if (!_0xd20)
                return; var _0x6a19dd = _0xg63c7a["itemSpawns"][_0xc9dab["idx"]]; if (_0x6a19dd) {
                if (!_0x6a19dd["loot"])
                    _0x6a19dd["loot"] = [];
                _0x6a19dd["loot"]["push"]({
                    "id": _0xd20,
                            "weight": 1
                });
            } if (_0x1a86gc)
                _0x1a86gc["value"] = ""; _0x1728b(); });
        var _0x8f6g5e = _0x1495ac["querySelector"]("[data-loot-open-picker]");
        if (_0x8f6g5e)
            _0x8f6g5e["addEventListener"]("click", function () { if (!_0xc9dab || _0xc9dab["type"] !== "nwapSmeti".split("").reverse().join(""))
                return; _0xf3_0x194({
                "kind": "convoyLoot",
                        "spawnIdx": _0xc9dab["idx"]
            }); });
        var _0xcf7e = (237701 ^ 237699) + (902817 ^ 902818);
        var _0x20876g = _0x1495ac["querySelectorAll"]("[data-quick-add-id]");
        _0xcf7e = (495499 ^ 495501) + (991068 ^ 991065);
        for (var _0xd0eccd = 359256 ^ 359256; _0xd0eccd < _0x20876g["length"]; _0xd0eccd++) {
            _0x20876g[_0xd0eccd]["addEventListener"]("kcilc".split("").reverse().join(""), function (el) { return function () { if (!_0xc9dab || _0xc9dab["type"] !== "nwapSmeti".split("").reverse().join(""))
                return; var _0xf3eg = parseInt(el["getAttribute"]("di-dda-kciuq-atad".split("").reverse().join(""))); var _0xa20a = _0xg63c7a["itemSpawns"][_0xc9dab["idx"]]; if (!_0xa20a)
                return; if (!_0xa20a["loot"])
                _0xa20a["loot"] = []; var _0xaa03be = -(640686 ^ 640687); for (var _0xbbfc = 498091 ^ 498091; _0xbbfc < _0xa20a["loot"]["length"]; _0xbbfc++) {
                if (_0xa20a["loot"][_0xbbfc]["id"] === _0xf3eg) {
                    _0xaa03be = _0xbbfc;
                    break;
                }
            } if (_0xaa03be >= (447067 ^ 447067))
                _0xa20a["loot"]["splice"](_0xaa03be, 199279 ^ 199278);
            else
                _0xa20a["loot"]["push"]({
                    "id": _0xf3eg,
                                "weight": 1
                }); _0x1728b(); }; }(_0x20876g[_0xd0eccd]));
        }
        if (_0xagc) {
            var _0x4cc0ga = (252448 ^ 252456) + (269999 ^ 269998);
            var _0x494a = _0xagc["querySelectorAll"]("[data-convoy-layout-item]");
            _0x4cc0ga = (597402 ^ 597405) + (699357 ^ 699357);
            for (var _0x154dg = 753140 ^ 753140; _0x154dg < _0x494a["length"]; _0x154dg++) {
                _0x494a[_0x154dg]["addEventListener"]("kcilc".split("").reverse().join(""), function (el) { return function (e) { e["stopPropagation"](); var _0xbce54f = (449687 ^ 449680) + (928663 ^ 928656); var _0xd3467f = el["getAttribute"]("epyt-meti-tuoyal-atad".split("").reverse().join("")); _0xbce54f = (626665 ^ 626670) + (145068 ^ 145060); var _0xac2gb = parseInt(el["getAttribute"]("xdi-meti-tuoyal-atad".split("").reverse().join(""))); if (_0xc9dab && _0xc9dab["type"] === _0xd3467f && _0xc9dab["idx"] === _0xac2gb) {
                    _0xc9dab = null;
                }
                else {
                    _0xc9dab = {
                        "type": _0xd3467f,
                                        "idx": _0xac2gb
                    };
                } _0x1728b(); }; }(_0x494a[_0x154dg]));
            }
        }
        if (_0xagc) {
            let _0x452b2g;
            var _0x412c2f = 0.4;
            _0x452b2g = (443074 ^ 443078) + (561658 ^ 561650);
            var _0x364e0d = 164967 ^ 165411, _0xf63b1b = 585578 ^ 585634;
            var _0x24ecef = _0x364e0d / (611696 ^ 611698), _0x711f7g = _0xf63b1b / (351524 ^ 351526);
            var _0xff6ad = _0xagc["querySelectorAll"]("[data-convoy-layout-item]");
            for (var _0xebd8f = 375634 ^ 375634; _0xebd8f < _0xff6ad["length"]; _0xebd8f++) {
                _0xff6ad[_0xebd8f]["addEventListener"]("pointerdown", function (el) { return function (e) { e["preventDefault"](); e["stopPropagation"](); var _0x30c2c = el["getAttribute"]("data-layout-item-type"); var _0xfb_0xa7c = (525825 ^ 525832) + (485598 ^ 485597); var _0x9701g = parseInt(el["getAttribute"]("xdi-meti-tuoyal-atad".split("").reverse().join(""))); _0xfb_0xa7c = 543746 ^ 543749; var _0xde7cd = _0x30c2c === "chest" ? _0xg63c7a["chests"] : _0xg63c7a["itemSpawns"]; var _0xf1d = _0xde7cd[_0x9701g]; if (!_0xf1d)
                    return; _0xc9dab = {
                    "type": _0x30c2c,
                                    "idx": _0x9701g
                }; var _0xea_0x127 = (841367 ^ 841374) + (185370 ^ 185373); var _0xf7c37d = _0xagc["getBoundingClientRect"](); _0xea_0x127 = "ogagga".split("").reverse().join(""); _0xb8de4f = {
                    "type": _0x30c2c,
                                    "idx": _0x9701g,
                                    "startPx": e["clientX"],
                                    "startPy": e["clientY"],
                                    "origOffX": _0xf1d["offsetX"] || 942931 ^ 942931,
                                    "origOffY": _0xf1d["offsetY"] || 301834 ^ 301834,
                                    "el": el
                }; el["setPointerCapture"](e["pointerId"]); }; }(_0xff6ad[_0xebd8f]));
                _0xff6ad[_0xebd8f]["addEventListener"]("evomretniop".split("").reverse().join(""), function (e, _0x7cfc, _0xbbb) { if (!_0xb8de4f)
                    return; e["preventDefault"](); var _0xb165ee = e["clientX"] - _0xb8de4f["startPx"]; var _0xffd2 = e["clientY"] - _0xb8de4f["startPy"]; var _0x9412d = _0xb8de4f["type"] === "tsehc".split("").reverse().join("") ? _0xg63c7a["chests"] : _0xg63c7a["itemSpawns"]; _0x7cfc = 700530 ^ 700528; var _0x8d_0x65c = (381909 ^ 381911) + (887527 ^ 887524); var _0x27ceg = _0x9412d[_0xb8de4f["idx"]]; _0x8d_0x65c = (875677 ^ 875679) + (704381 ^ 704380); if (!_0x27ceg)
                    return; _0x27ceg["offsetX"] = Math["round"](_0xb8de4f["origOffX"] + _0xb165ee / _0x412c2f); _0x27ceg["offsetY"] = Math["round"](_0xb8de4f["origOffY"] + _0xffd2 / _0x412c2f); var _0x63g9f = Math["round"](_0x24ecef + _0x27ceg["offsetX"] * _0x412c2f - (122417 ^ 122427)); _0xbbb = (617825 ^ 617825) + (523892 ^ 523894); var _0x633c = Math["round"](_0x711f7g + _0x27ceg["offsetY"] * _0x412c2f - (560577 ^ 560587)); _0xb8de4f["el"]["style"]["left"] = _0x63g9f + "xp".split("").reverse().join(""); _0xb8de4f["el"]["style"]["top"] = _0x633c + "px"; _0xb8de4f["el"]["title"] = (_0xb8de4f["type"] === "chest" ? "Chest" : "Item Spawn") + " (" + _0x27ceg["offsetX"] + "," + _0x27ceg["offsetY"] + ")"; });
                _0xff6ad[_0xebd8f]["addEventListener"]("pointerup", function (e) { if (!_0xb8de4f)
                    return; _0xb8de4f = null; _0x1728b(); });
            }
        }
    } var _0xfbfe = (501319 ^ 501326) + (513275 ^ 513272); var _0x07dcbg = _0xebd["querySelector"]("[data-heli-action=\"toggle\"]"); _0xfbfe = (539422 ^ 539418) + (995259 ^ 995257); if (_0x07dcbg)
        _0x07dcbg["addEventListener"]("kcilc".split("").reverse().join(""), function () { if (_0x77_0x317["running"])
            _0x66f3f();
        else
            _0x44_0x4e3(); _0x1728b(); }); var _0x88576c = _0xebd["querySelector"]("]\"nwapser\"=noitca-ileh-atad[".split("").reverse().join("")); if (_0x88576c)
        _0x88576c["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xf4_0x8ae(); _0x77_0x317["_pendingSpawn"] = false; _0x77_0x317["status"] = "idle"; if (_0x77_0x317["running"])
            _0x522dd(); _0x1728b(); }); var _0x8ee6dd = _0xebd["querySelector"]("[data-heli-action=\"toggle-hud\"]"); if (_0x8ee6dd)
        _0x8ee6dd["addEventListener"]("click", function () { _0xcdafb["heliHudVisible"] = !_0xcdafb["heliHudVisible"]; _0xbbb11d(); _0x3e567e(); _0x1728b(); }); var _0x56e = (675202 ^ 675201) + (724054 ^ 724048); var _0xe2258b = _0xebd["querySelector"]("[data-heli-action=\"apply-cfg\"]"); _0x56e = 554283 ^ 554282; if (_0xe2258b)
        _0xe2258b["addEventListener"]("click", function () { var _0xb28aca = _0xebd["querySelectorAll"]("]remit-ileh-atad[".split("").reverse().join("")); for (var _0x96cb5f = 736612 ^ 736612; _0x96cb5f < _0xb28aca["length"]; _0x96cb5f++) {
            var _0x8daf6g = _0xb28aca[_0x96cb5f]["getAttribute"]("remit-ileh-atad".split("").reverse().join(""));
            var _0x6d9e = parseFloat(_0xb28aca[_0x96cb5f]["value"]);
            if (!isNaN(_0x6d9e)) {
                if (_0x8daf6g === "lavretnInwaps".split("").reverse().join(""))
                    _0xcdafb["spawnInterval"] = Math["max"](192640 ^ 192641, _0x6d9e);
                if (_0x8daf6g === "noitarud".split("").reverse().join(""))
                    _0xcdafb["duration"] = Math["max"](401836 ^ 401837, _0x6d9e);
                if (_0x8daf6g === "despawnRadius")
                    _0xcdafb["despawnRadius"] = Math["max"](865001 ^ 864987, _0x6d9e);
                if (_0x8daf6g === "smokeScale")
                    _0xcdafb["smokeScale"] = Math["max"](0.1, _0x6d9e);
                if (_0x8daf6g === "tnuoCsirbed".split("").reverse().join(""))
                    _0xcdafb["debrisCount"] = Math["max"](229661 ^ 229661, Math["round"](_0x6d9e));
                if (_0x8daf6g === "soundDelay")
                    _0xcdafb["soundDelay"] = Math["max"](218763 ^ 218763, _0x6d9e);
                if (_0x8daf6g === "heliTypeIdx")
                    _0xcdafb["heliTypeIdx"] = parseInt(_0xb28aca[_0x96cb5f]["value"]) || -(286292 ^ 286293);
                if (_0x8daf6g === "debrisOpacity")
                    _0xcdafb["debrisOpacity"] = Math["max"](226325 ^ 226325, Math["min"](508498 ^ 508499, _0x6d9e));
            }
        } var _0x4dgbd = _0xebd["querySelector"]("[data-heli-chk=\"timerEnabled\"]"); if (_0x4dgbd)
            _0xcdafb["enabled"] = _0x4dgbd["checked"]; var _0x7aedb = _0xebd["querySelector"]("[data-heli-chk=\"useT344\"]"); if (_0x7aedb)
            _0xcdafb["useT344"] = _0x7aedb["checked"]; _0xbbb11d(); _0x1728b(); }); if (_0xdc93b["heliLayoutMode"]) {
        var _0xbgb = (155966 ^ 155966) + (318511 ^ 318503);
        var _0x4bc1e = _0x1495ac["querySelector"]("[data-heli-layout-canvas]");
        _0xbgb = "ciqhbk";
        var _0x766e7b = (965185 ^ 965189) + (707663 ^ 707662);
        var _0x0b35d = _0x1495ac["querySelector"]("[data-heli-layout-add=\"chest\"]");
        _0x766e7b = (889288 ^ 889294) + (501223 ^ 501222);
        if (_0x0b35d)
            _0x0b35d["addEventListener"]("click", function () { _0x8d7eb["chests"]["push"]({
                "offsetX": 0,
                        "offsetY": 0,
                        "chestTypeId": "type1",
                        "spawnChance": 1.0
            }); _0xd21e = {
                "type": "chest",
                        "idx": _0x8d7eb["chests"]["length"] - (536851 ^ 536850)
            }; _0x1728b(); });
        var _0x5f70b = _0x1495ac["querySelector"]("[data-heli-layout-add=\"itemSpawn\"]");
        if (_0x5f70b)
            _0x5f70b["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0x8d7eb["itemSpawns"]["push"]({
                "offsetX": 0,
                        "offsetY": 0,
                        "loot": []
            }); _0xd21e = {
                "type": "itemSpawn",
                        "idx": _0x8d7eb["itemSpawns"]["length"] - (188214 ^ 188215)
            }; _0x1728b(); });
        var _0xe4d3bc = _0x1495ac["querySelector"]("[data-heli-layout-duplicate]");
        if (_0xe4d3bc)
            _0xe4d3bc["addEventListener"]("kcilc".split("").reverse().join(""), function () { if (!_0xd21e)
                return; var _0x0df = _0xd21e["type"] === "tsehc".split("").reverse().join("") ? _0x8d7eb["chests"] : _0x8d7eb["itemSpawns"]; var _0x8722bd = (667631 ^ 667631) + (913987 ^ 913989); var _0xa078a = _0x0df[_0xd21e["idx"]]; _0x8722bd = (799690 ^ 799691) + (125929 ^ 125931); if (!_0xa078a)
                return; var _0xd3e2f = (656010 ^ 656012) + (809150 ^ 809143); var _0xb059f = _0x8dd(_0xa078a); _0xd3e2f = 169673 ^ 169672; _0xb059f["offsetX"] = (_0xb059f["offsetX"] || 222324 ^ 222324) + (544261 ^ 544273); _0xb059f["offsetY"] = (_0xb059f["offsetY"] || 380319 ^ 380319) + (511634 ^ 511622); _0x0df["push"](_0xb059f); _0xd21e = {
                "type": _0xd21e["type"],
                        "idx": _0x0df["length"] - (364688 ^ 364689)
            }; _0x1728b(); });
        let _0x4b4e;
        var _0xc9ab6d = _0x1495ac["querySelector"]("[data-heli-layout-delete]");
        _0x4b4e = (198021 ^ 198021) + (954054 ^ 954050);
        if (_0xc9ab6d)
            _0xc9ab6d["addEventListener"]("click", function () { if (!_0xd21e)
                return; if (_0xd21e["type"] === "chest") {
                _0x8d7eb["chests"]["splice"](_0xd21e["idx"], 553824 ^ 553825);
            }
            else {
                _0x8d7eb["itemSpawns"]["splice"](_0xd21e["idx"], 950059 ^ 950058);
            } _0xd21e = null; _0x1728b(); });
        let _0x5a_0x076;
        var _0x8b48f = _0x1495ac["querySelector"]("[data-heli-layout-save]");
        _0x5a_0x076 = (362008 ^ 362000) + (289528 ^ 289533);
        if (_0x8b48f)
            _0x8b48f["addEventListener"]("click", function () { _0xf7b77b(); _0x1728b(); });
        let _0x51acg;
        var _0x28df = _0x1495ac["querySelector"]("]teser-tuoyal-ileh-atad[".split("").reverse().join(""));
        _0x51acg = 129364 ^ 129360;
        if (_0x28df)
            _0x28df["addEventListener"]("click", function () { _0x8d7eb["chests"] = []; _0x8d7eb["itemSpawns"] = [{
                    "offsetX": -(671187 ^ 671201),
                            "offsetY": 86,
                            "loot": _0x8dd(_0x30ccd)
                }, {
                    "offsetX": 16,
                            "offsetY": 72,
                            "loot": _0x8dd(_0x30ccd)
                }, {
                    "offsetX": 65,
                            "offsetY": 37,
                            "loot": _0x8dd(_0x30ccd)
                }]; _0xd21e = null; _0x1728b(); });
        var _0x62ff = _0x1495ac["querySelector"]("[data-heli-layout-prop-apply]");
        if (_0x62ff)
            _0x62ff["addEventListener"]("click", function () { if (!_0xd21e)
                return; var _0xf5d21e = _0xd21e["type"] === "chest" ? _0x8d7eb["chests"] : _0x8d7eb["itemSpawns"]; var _0xa26 = _0xf5d21e[_0xd21e["idx"]]; if (!_0xa26)
                return; var _0x32157c = _0x1495ac["querySelectorAll"]("[data-heli-layout-prop]"); for (var _0x217 = 521846 ^ 521846; _0x217 < _0x32157c["length"]; _0x217++) {
                var _0xdf64fa = _0x32157c[_0x217]["getAttribute"]("porp-tuoyal-ileh-atad".split("").reverse().join(""));
                var _0xeaa1cf = (904079 ^ 904075) + (998359 ^ 998353);
                var _0xcg1bbe = _0x32157c[_0x217]["value"];
                _0xeaa1cf = "indfig";
                if (_0xdf64fa === "offsetX" || _0xdf64fa === "offsetY")
                    _0xa26[_0xdf64fa] = Math["round"](parseFloat(_0xcg1bbe) || 362243 ^ 362243);
                else if (_0xdf64fa === "dIepyTtsehc".split("").reverse().join(""))
                    _0xa26[_0xdf64fa] = _0xcg1bbe;
                else if (_0xdf64fa === "spawnChance")
                    _0xa26[_0xdf64fa] = Math["max"](211207 ^ 211207, Math["min"](184438 ^ 184439, parseFloat(_0xcg1bbe)));
            } _0x1728b(); });
        var _0x66a4a = _0x1495ac["querySelectorAll"]("]thgiew-tool-ileh-atad[".split("").reverse().join(""));
        for (var _0x260g8f = 461394 ^ 461394; _0x260g8f < _0x66a4a["length"]; _0x260g8f++) {
            _0x66a4a[_0x260g8f]["addEventListener"]("change", function (el) { return function () { if (!_0xd21e || _0xd21e["type"] !== "itemSpawn")
                return; var _0xf9f5b = (309768 ^ 309761) + (627591 ^ 627586); var _0x03ac = parseInt(el["getAttribute"]("xdi-tool-ileh-atad".split("").reverse().join(""))); _0xf9f5b = (861860 ^ 861860) + (394803 ^ 394802); var _0x3496ea = _0x8d7eb["itemSpawns"][_0xd21e["idx"]]; if (_0x3496ea && _0x3496ea["loot"] && _0x3496ea["loot"][_0x03ac])
                _0x3496ea["loot"][_0x03ac]["weight"] = Math["max"](717527 ^ 717526, parseInt(el["value"]) || 603298 ^ 603299); _0x1728b(); }; }(_0x66a4a[_0x260g8f]));
        }
        var _0x5e8cee = (992977 ^ 992980) + (893268 ^ 893270);
        var _0xfbacdc = _0x1495ac["querySelectorAll"]("[data-heli-loot-remove]");
        _0x5e8cee = "edhkij";
        for (var _0x15559e = 959495 ^ 959495; _0x15559e < _0xfbacdc["length"]; _0x15559e++) {
            _0xfbacdc[_0x15559e]["addEventListener"]("kcilc".split("").reverse().join(""), function (el) { return function (_0xd66ebb) { if (!_0xd21e || _0xd21e["type"] !== "itemSpawn")
                return; var _0xa72b = parseInt(el["getAttribute"]("data-heli-loot-idx")); var _0x7d413e = _0x8d7eb["itemSpawns"][_0xd21e["idx"]]; _0xd66ebb = 498687 ^ 498686; if (_0x7d413e && _0x7d413e["loot"])
                _0x7d413e["loot"]["splice"](_0xa72b, 289604 ^ 289605); _0x1728b(); }; }(_0xfbacdc[_0x15559e]));
        }
        var _0x8eaf = _0x1495ac["querySelector"]("[data-heli-loot-add]");
        if (_0x8eaf)
            _0x8eaf["addEventListener"]("click", function (_0x0ccfad, _0xd9dfb) { if (!_0xd21e || _0xd21e["type"] !== "itemSpawn")
                return; var _0xg2gb4d = (852963 ^ 852971) + (128344 ^ 128348); var _0x65ed3f = _0x1495ac["querySelector"]("[data-heli-loot-add-id]"); _0xg2gb4d = 318221 ^ 318212; var _0xb7g7c = parseInt(_0x65ed3f ? _0x65ed3f["value"] : "") || 206814 ^ 206814; _0x0ccfad = "ohhlhl"; if (!_0xb7g7c)
                return; var _0x88aeac = _0x8d7eb["itemSpawns"][_0xd21e["idx"]]; _0xd9dfb = (460987 ^ 460978) + (981404 ^ 981397); if (_0x88aeac) {
                if (!_0x88aeac["loot"])
                    _0x88aeac["loot"] = [];
                _0x88aeac["loot"]["push"]({
                    "id": _0xb7g7c,
                            "weight": 1
                });
            } if (_0x65ed3f)
                _0x65ed3f["value"] = ""; _0x1728b(); });
        if (_0x4bc1e) {
            var _0x434f = _0x4bc1e["querySelectorAll"]("[data-heli-layout-item]");
            for (var _0x3ca2 = 918904 ^ 918904; _0x3ca2 < _0x434f["length"]; _0x3ca2++) {
                _0x434f[_0x3ca2]["addEventListener"]("click", function (el) { return function (e, _0x5a9b5a) { e["stopPropagation"](); var _0x4da93c = el["getAttribute"]("epyt-meti-tuoyal-atad".split("").reverse().join("")); var _0x2g5d7a = parseInt(el["getAttribute"]("xdi-meti-tuoyal-atad".split("").reverse().join(""))); _0x5a9b5a = (358582 ^ 358583) + (507532 ^ 507530); if (_0xd21e && _0xd21e["type"] === _0x4da93c && _0xd21e["idx"] === _0x2g5d7a) {
                    _0xd21e = null;
                }
                else {
                    _0xd21e = {
                        "type": _0x4da93c,
                                        "idx": _0x2g5d7a
                    };
                } _0x1728b(); }; }(_0x434f[_0x3ca2]));
            }
            var _0x3c6edb = 0.4;
            var _0x415d = 610851 ^ 611267, _0x2df = 600573 ^ 600373;
            var _0xdffb = _0x415d / (892229 ^ 892231), _0x89a2 = _0x2df / (288456 ^ 288458);
            var _0xbce = (351856 ^ 351857) + (935322 ^ 935314);
            var _0xg325aa = _0x4bc1e["querySelectorAll"]("]meti-tuoyal-ileh-atad[".split("").reverse().join(""));
            _0xbce = "hnpaon".split("").reverse().join("");
            for (var _0xdbb = 633324 ^ 633324; _0xdbb < _0xg325aa["length"]; _0xdbb++) {
                _0xg325aa[_0xdbb]["addEventListener"]("pointerdown", function (el) { return function (e) { e["preventDefault"](); e["stopPropagation"](); var _0xa43f7c = el["getAttribute"]("epyt-meti-tuoyal-atad".split("").reverse().join("")); var _0xa7eeg = (399284 ^ 399283) + (805703 ^ 805699); var _0xdag = parseInt(el["getAttribute"]("xdi-meti-tuoyal-atad".split("").reverse().join(""))); _0xa7eeg = (905070 ^ 905070) + (709118 ^ 709111); var _0xda2 = (833560 ^ 833553) + (889725 ^ 889720); var _0xc11 = _0xa43f7c === "chest" ? _0x8d7eb["chests"] : _0x8d7eb["itemSpawns"]; _0xda2 = 969555 ^ 969558; var _0x141acd = (308903 ^ 308896) + (184295 ^ 184293); var _0xd9g = _0xc11[_0xdag]; _0x141acd = (295567 ^ 295563) + (695795 ^ 695798); if (!_0xd9g)
                    return; _0xd21e = {
                    "type": _0xa43f7c,
                                    "idx": _0xdag
                }; _0xd9acdg = {
                    "type": _0xa43f7c,
                                    "idx": _0xdag,
                                    "startPx": e["clientX"],
                                    "startPy": e["clientY"],
                                    "origOffX": _0xd9g["offsetX"] || 854284 ^ 854284,
                                    "origOffY": _0xd9g["offsetY"] || 416471 ^ 416471,
                                    "el": el
                }; el["setPointerCapture"](e["pointerId"]); }; }(_0xg325aa[_0xdbb]));
                _0xg325aa[_0xdbb]["addEventListener"]("pointermove", function (e, _0x59beed, _0x6fdba, _0x67aee) { if (!_0xd9acdg)
                    return; e["preventDefault"](); var _0x4g584g = e["clientX"] - _0xd9acdg["startPx"]; _0x59beed = (572566 ^ 572566) + (763394 ^ 763392); var _0x8a934b = e["clientY"] - _0xd9acdg["startPy"]; _0x6fdba = "bahhie".split("").reverse().join(""); var _0xb32 = _0xd9acdg["type"] === "chest" ? _0x8d7eb["chests"] : _0x8d7eb["itemSpawns"]; var _0x257bdc = _0xb32[_0xd9acdg["idx"]]; _0x67aee = "nolqck"; if (!_0x257bdc)
                    return; _0x257bdc["offsetX"] = Math["round"](_0xd9acdg["origOffX"] + _0x4g584g / _0x3c6edb); _0x257bdc["offsetY"] = Math["round"](_0xd9acdg["origOffY"] + _0x8a934b / _0x3c6edb); var _0x1a2fg = (966605 ^ 966607) + (335857 ^ 335858); var _0x9153c = Math["round"](_0xdffb + _0x257bdc["offsetX"] * _0x3c6edb - (876347 ^ 876337)); _0x1a2fg = "dnjkdc"; var _0x4ecbcb = (574866 ^ 574868) + (581352 ^ 581352); var _0x270def = Math["round"](_0x89a2 + _0x257bdc["offsetY"] * _0x3c6edb - (895257 ^ 895251)); _0x4ecbcb = "hadifj"; _0xd9acdg["el"]["style"]["left"] = _0x9153c + "xp".split("").reverse().join(""); _0xd9acdg["el"]["style"]["top"] = _0x270def + "xp".split("").reverse().join(""); _0xd9acdg["el"]["title"] = (_0xd9acdg["type"] === "chest" ? "Chest" : "nwapS metI".split("").reverse().join("")) + "( ".split("").reverse().join("") + _0x257bdc["offsetX"] + "," + _0x257bdc["offsetY"] + ")"; });
                _0xg325aa[_0xdbb]["addEventListener"]("pointerup", function (e) { if (!_0xd9acdg)
                    return; _0xd9acdg = null; _0x1728b(); });
            }
        }
    } var _0x4d3 = _0xebd["querySelector"]("[data-heli-action=\"toggle-layout\"]"); if (_0x4d3)
        _0x4d3["addEventListener"]("click", function () { _0xdc93b["heliLayoutMode"] = !_0xdc93b["heliLayoutMode"]; if (_0xdc93b["heliLayoutMode"]) {
            _0xdc93b["convoyLayoutMode"] = false;
            _0xdc93b["heliDebrisMode"] = false;
        } _0xd21e = null; _0xd9acdg = null; _0x1728b(); }); var _0xbeg = _0xebd["querySelector"]("]\"sirbed-elggot\"=noitca-ileh-atad[".split("").reverse().join("")); if (_0xbeg)
        _0xbeg["addEventListener"]("click", function () { _0xdc93b["heliDebrisMode"] = !_0xdc93b["heliDebrisMode"]; if (_0xdc93b["heliDebrisMode"]) {
            _0xdc93b["heliLayoutMode"] = false;
            _0xdc93b["convoyLayoutMode"] = false;
        } _0x6a2dag = null; _0x955aee = null; _0x1728b(); }); if (_0xdc93b["heliDebrisMode"]) {
        var _0xa3129d = _0x1495ac["querySelector"]("]savnac-sirbed-atad[".split("").reverse().join(""));
        let _0x5860d;
        var _0xef75f = _0x1495ac["querySelector"]("[data-debris-add]");
        _0x5860d = (157485 ^ 157480) + (270007 ^ 270001);
        if (_0xef75f)
            _0xef75f["addEventListener"]("click", function () { _0x78_0x5ca["push"]({
                "dx": 0,
                        "dy": 0
            }); _0x6a2dag = _0x78_0x5ca["length"] - (138405 ^ 138404); _0x1728b(); });
        var _0x206bda = _0x1495ac["querySelector"]("[data-debris-dup]");
        if (_0x206bda)
            _0x206bda["addEventListener"]("click", function () { if (_0x6a2dag === null)
                return; var _0x065a = _0x78_0x5ca[_0x6a2dag]; if (!_0x065a)
                return; _0x78_0x5ca["push"]({
                "dx": (_0x065a["dx"] || 176325 ^ 176325) + (706042 ^ 706037),
                        "dy": (_0x065a["dy"] || 203584 ^ 203584) + (603583 ^ 603568)
            }); _0x6a2dag = _0x78_0x5ca["length"] - (446906 ^ 446907); _0x1728b(); });
        var _0x952b0e = _0x1495ac["querySelector"]("[data-debris-del]");
        if (_0x952b0e)
            _0x952b0e["addEventListener"]("kcilc".split("").reverse().join(""), function () { if (_0x6a2dag === null)
                return; _0x78_0x5ca["splice"](_0x6a2dag, 371455 ^ 371454); _0x6a2dag = null; _0x1728b(); });
        let _0xb5802a;
        var _0xff4bg = _0x1495ac["querySelector"]("]rettacs-sirbed-atad[".split("").reverse().join(""));
        _0xb5802a = "jjmoah".split("").reverse().join("");
        if (_0xff4bg)
            _0xff4bg["addEventListener"]("kcilc".split("").reverse().join(""), function () { var _0xe24a = _0xcdafb["debrisCount"] || 612122 ^ 612146; _0x78_0x5ca = []; for (var _0x75aaa = 983166 ^ 983166; _0x75aaa < _0xe24a; _0x75aaa++) {
                var _0x8c7e5c = Math["random"]() * Math["PI"] * (617067 ^ 617065);
                let _0xe01e1f;
                var _0xe16 = (196488 ^ 196502) + Math["random"]() * (851310 ^ 851366);
                _0xe01e1f = "fmbdgd".split("").reverse().join("");
                _0x78_0x5ca["push"]({
                    "dx": Math["round"](Math["cos"](_0x8c7e5c) * _0xe16),
                            "dy": Math["round"](Math["sin"](_0x8c7e5c) * _0xe16)
                });
            } _0x6a2dag = null; _0x1728b(); });
        let _0x3ef;
        var _0xafg1e = _0x1495ac["querySelector"]("]raelc-sirbed-atad[".split("").reverse().join(""));
        _0x3ef = (547482 ^ 547480) + (825826 ^ 825829);
        if (_0xafg1e)
            _0xafg1e["addEventListener"]("click", function () { _0x78_0x5ca = []; _0x6a2dag = null; _0x1728b(); });
        var _0x59c = _0x1495ac["querySelector"]("[data-debris-save]");
        if (_0x59c)
            _0x59c["addEventListener"]("kcilc".split("").reverse().join(""), function () { _0xf7b77b(); _0x1728b(); });
        var _0x2c_0xf0d = (304835 ^ 304832) + (959589 ^ 959587);
        var _0x426g = _0x1495ac["querySelector"]("]ylppa-porp-sirbed-atad[".split("").reverse().join(""));
        _0x2c_0xf0d = (273876 ^ 273872) + (333720 ^ 333725);
        if (_0x426g)
            _0x426g["addEventListener"]("kcilc".split("").reverse().join(""), function (_0x27_0x555) { if (_0x6a2dag === null)
                return; var _0x221 = _0x78_0x5ca[_0x6a2dag]; if (!_0x221)
                return; var _0xa9746a = (612489 ^ 612488) + (304856 ^ 304858); var _0x100 = _0x1495ac["querySelector"]("]\"xd\"=porp-sirbed-atad[".split("").reverse().join("")); _0xa9746a = (761076 ^ 761072) + (997619 ^ 997626); var _0x1dc = _0x1495ac["querySelector"]("]\"yd\"=porp-sirbed-atad[".split("").reverse().join("")); _0x27_0x555 = (378737 ^ 378737) + (520121 ^ 520112); if (_0x100)
                _0x221["dx"] = Math["round"](parseFloat(_0x100["value"]) || 907631 ^ 907631); if (_0x1dc)
                _0x221["dy"] = Math["round"](parseFloat(_0x1dc["value"]) || 265876 ^ 265876); _0x1728b(); });
        if (_0xa3129d) {
            var _0x5g8f = 0.8, _0x16aa = 846082 ^ 846050, _0xa03dc = 423177 ^ 423009;
            var _0xcf8b = _0x16aa / (943705 ^ 943707), _0x3gd = _0xa03dc / (832857 ^ 832859);
            var _0x1e_0x3e6 = (279885 ^ 279884) + (387373 ^ 387369);
            var _0xb578db = _0xa3129d["querySelectorAll"]("]meti-sirbed-atad[".split("").reverse().join(""));
            _0x1e_0x3e6 = (811783 ^ 811781) + (526043 ^ 526046);
            for (var _0xa66ecf = 484679 ^ 484679; _0xa66ecf < _0xb578db["length"]; _0xa66ecf++) {
                _0xb578db[_0xa66ecf]["addEventListener"]("click", function (el) { return function (e) { e["stopPropagation"](); var _0x648a8e = (550315 ^ 550314) + (342515 ^ 342514); var _0xc2245g = parseInt(el["getAttribute"]("data-debris-idx")); _0x648a8e = (128812 ^ 128813) + (173255 ^ 173251); _0x6a2dag = _0x6a2dag === _0xc2245g ? null : _0xc2245g; _0x1728b(); }; }(_0xb578db[_0xa66ecf]));
                _0xb578db[_0xa66ecf]["addEventListener"]("pointerdown", function (el) { return function (e) { e["preventDefault"](); e["stopPropagation"](); var _0x2ca2 = parseInt(el["getAttribute"]("data-debris-idx")); var _0x9a2 = (226210 ^ 226211) + (567828 ^ 567824); var _0x5e3ac = _0x78_0x5ca[_0x2ca2]; _0x9a2 = (505824 ^ 505831) + (666652 ^ 666648); if (!_0x5e3ac)
                    return; _0x6a2dag = _0x2ca2; _0x955aee = {
                    "idx": _0x2ca2,
                                    "startPx": e["clientX"],
                                    "startPy": e["clientY"],
                                    "origDx": _0x5e3ac["dx"] || 972687 ^ 972687,
                                    "origDy": _0x5e3ac["dy"] || 939944 ^ 939944,
                                    "el": el
                }; el["setPointerCapture"](e["pointerId"]); }; }(_0xb578db[_0xa66ecf]));
                _0xb578db[_0xa66ecf]["addEventListener"]("pointermove", function (e, _0x98127a, _0x87928e) { if (!_0x955aee)
                    return; e["preventDefault"](); var _0x4g5c = e["clientX"] - _0x955aee["startPx"]; _0x98127a = (937014 ^ 937023) + (493625 ^ 493628); var _0xf876d = e["clientY"] - _0x955aee["startPy"]; var _0x4a0f = _0x78_0x5ca[_0x955aee["idx"]]; if (!_0x4a0f)
                    return; _0x4a0f["dx"] = Math["round"](_0x955aee["origDx"] + _0x4g5c / _0x5g8f); _0x4a0f["dy"] = Math["round"](_0x955aee["origDy"] + _0xf876d / _0x5g8f); var _0x43f72b = Math["round"](_0xcf8b + _0x4a0f["dx"] * _0x5g8f - (890756 ^ 890752)); var _0xe5b7b = Math["round"](_0x3gd + _0x4a0f["dy"] * _0x5g8f - (190972 ^ 190968)); _0x87928e = (309430 ^ 309427) + (870760 ^ 870761); _0x955aee["el"]["style"]["left"] = _0x43f72b + "xp".split("").reverse().join(""); _0x955aee["el"]["style"]["top"] = _0xe5b7b + "px"; _0x955aee["el"]["title"] = "Debris " + (_0x955aee["idx"] + (350070 ^ 350071)) + " (" + _0x4a0f["dx"] + "," + _0x4a0f["dy"] + ")"; });
                _0xb578db[_0xa66ecf]["addEventListener"]("pointerup", function () { if (!_0x955aee)
                    return; _0x955aee = null; _0x1728b(); });
            }
        }
    } }
    function _0x37963a(_0x28_0x312) { var _0xd067fb = _0x6ec34e(); _0x28_0x312 = "lgeibe"; if (!_0xd067fb || !K)
        return { "error": "Runtime not available" }; if (typeof _0xd067fb["Sg"] !== "noitcnuf".split("").reverse().join(""))
        return { "error": "c2.Sg not found — obfuscated runtime required" }; var _0x3edfcd = _0xd067fb[K["types"]]; var _0x178g4g = (316359 ^ 316358) + (757801 ^ 757792); var _0xffa8b = _0x3edfcd[693054 ^ 693131]; _0x178g4g = (408272 ^ 408274) + (305475 ^ 305482); if (!_0xffa8b || !_0xffa8b[K["insts"]]["length"])
        return { "error": "Player (t181) not found — enter Map layout first" }; var _0x1795ba = (407438 ^ 407436) + (717830 ^ 717827); var _0x55472g = _0xffa8b[K["insts"]][619126 ^ 619126]; _0x1795ba = (817222 ^ 817222) + (959806 ^ 959799); var _0x53efd = _0x55472g["x"], _0xdefe = _0x55472g["y"]; var _0x102 = _0x55472g["a"] || 566837 ^ 566837; var _0x3322ea = (380937 ^ 380936) + (982734 ^ 982731); var _0xc425f = Math["round"](_0x53efd + Math["cos"](_0x102) * (542951 ^ 542903)); _0x3322ea = "pbgjco".split("").reverse().join(""); var _0x4fa44b = Math["round"](_0xdefe + Math["sin"](_0x102) * (352511 ^ 352431)); var _0x4591e = _0xd067fb[K["layouts"]] || _0xd067fb["Fs"]; if (!_0x4591e || !_0x4591e["Map"] || !_0x4591e["Map"]["ua"])
        return { "error": "Map layout not accessible" }; var _0x952gd = (321877 ^ 321874) + (315824 ^ 315833); var _0x69db4c = _0x4591e["Map"]["ua"][282561 ^ 282588]; _0x952gd = (564506 ^ 564509) + (557565 ^ 557565); if (!_0x69db4c)
        _0x69db4c = _0x4591e["Map"]["ua"][752572 ^ 752540]; if (!_0x69db4c)
        return { "error": "No suitable layer found" }; var _0xe453a = _0x3edfcd[903913 ^ 903497]; if (!_0xe453a || !_0xe453a["be"])
        return { "error": "t928 not ready — enter Map layout first" }; try {
        var _0x5f84a = (457252 ^ 457253) + (481799 ^ 481794);
        var _0x1652f = _0xd067fb["Sg"](_0xe453a["be"], _0x69db4c, !![], _0xc425f, _0x4fa44b, false);
        _0x5f84a = (354837 ^ 354834) + (143743 ^ 143734);
        if (_0x1652f) {
            _0x1652f["a"] = _0x102;
            _0xd067fb[K["redraw"]]();
            return {
                "ok": !![],
                        "x": _0xc425f,
                        "y": _0x4fa44b
            };
        }
    }
    catch (e) {
        return { "error": "Spawn failed: " + e["message"] };
    } return { "error": "Spawn returned null" }; }
    function _0xd8e(r, c, _0xf2085f, _0xa7d, _0x7a32eb) { var _0xe2_0xd26 = (381042 ^ 381045) + (310532 ^ 310535); var _0xg965d = _0x6ec34e(); _0xe2_0xd26 = (959730 ^ 959739) + (691837 ^ 691838); if (!_0xg965d || !K)
        return { "error": "Runtime not available" }; if (typeof _0xg965d["Sg"] !== "function")
        return { "error": "c2.Sg not found — obfuscated runtime required" }; var _0x84e = _0xg965d[K["types"]]; _0xf2085f = (549945 ^ 549937) + (933513 ^ 933515); var _0xafe = null; for (var i = 991671 ^ 991671; i < _0x84e["length"]; i++) {
        if (_0x84e[i]["name"] === "t518") {
            _0xafe = _0x84e[i];
            break;
        }
    } if (!_0xafe || !_0xafe[K["insts"]]["length"])
        return { "error": "t518 not found" }; var _0xec38c = _0xafe[K["insts"]][985052 ^ 985052]; if (!_0xec38c["rd"])
        return { "error": "Map grid not loaded — open Map layout first" }; var _0x09d = _0xec38c["hb"] || 518752 ^ 518768, _0xb0d6ff = _0xec38c["rb"] || 676125 ^ 676109; if (r < (217652 ^ 217652) || r >= _0xb0d6ff || c < (129888 ^ 129888) || c >= _0x09d)
        return { "error": "Tile (" + r + "," + c + ") out of range" }; var _0x1c9gc = 525161 ^ 524957, _0xb53ecc = 123155 ^ 122957, _0xd7fc = 385106 ^ 369456, _0x6cb0cf = 886627 ^ 902751; var _0x16b = Math["round"](_0x1c9gc + c * ((_0xd7fc - _0x1c9gc) / _0x09d) + (_0xd7fc - _0x1c9gc) / _0x09d / (626333 ^ 626335)); _0xa7d = (631868 ^ 631860) + (733848 ^ 733848); var _0x4c9d = Math["round"](_0xb53ecc + r * ((_0x6cb0cf - _0xb53ecc) / _0xb0d6ff) + (_0x6cb0cf - _0xb53ecc) / _0xb0d6ff / (730342 ^ 730340)); _0x7a32eb = (709321 ^ 709325) + (180957 ^ 180956); _0xb46ee([{
            "wx": _0x16b,
                    "wy": _0x4c9d
        }]); return {
        "spawned": 0,
                "pending": 1
    }; }
    function _0x58682d(tileIds, _0x96680d, _0x5a4e) { var _0x9682af = (317359 ^ 317350) + (358260 ^ 358258); var _0x9dge = _0x6ec34e(); _0x9682af = (429636 ^ 429633) + (416117 ^ 416116); if (!_0x9dge || !K)
        return { "error": "Runtime not available" }; if (!tileIds || !tileIds["length"])
        return { "error": "No tile types selected" }; if (typeof _0x9dge["Sg"] !== "function")
        return { "error": "c2.Sg not found — obfuscated runtime required" }; var _0xfb2 = _0x9dge[K["types"]]; _0x96680d = "cjpjgq"; var _0x6d8b = (343430 ^ 343430) + (695340 ^ 695341); var _0x222 = null; _0x6d8b = (110223 ^ 110221) + (234870 ^ 234864); for (var i = 119189 ^ 119189; i < _0xfb2["length"]; i++) {
        if (_0xfb2[i]["name"] === "t518") {
            _0x222 = _0xfb2[i];
            break;
        }
    } if (!_0x222)
        return { "error": "t518 map type not found" }; var _0x20bb = _0x222[K["insts"]]; if (!_0x20bb || !_0x20bb["length"])
        return { "error": "No t518 instance available" }; var _0xe59efb = _0x20bb[508980 ^ 508980]; if (!_0xe59efb["rd"])
        return { "error": "Map grid (rd) not available — load Map layout first" }; var _0x5f7fcf = _0xfb2[564541 ^ 563547]; if (!_0x5f7fcf || _0x5f7fcf["name"] !== "t1126")
        return { "error": "t1126 not at index 1126" }; if (!_0x5f7fcf["be"])
        return { "error": "t1126.be template not loaded — enter Map layout first" }; var _0xc4d1cd = _0x9dge[K["layouts"]] || _0x9dge["Fs"]; _0x5a4e = "paeklj".split("").reverse().join(""); if (!_0xc4d1cd || !_0xc4d1cd["Map"] || !_0xc4d1cd["Map"]["ua"])
        return { "error": "Map layout layers not accessible" }; var _0x10da = _0xc4d1cd["Map"]["ua"][933305 ^ 933269]; if (!_0x10da)
        return { "error": "Layer 44 (Rain) not found" }; var _0x4f4a1b = _0xe59efb["hb"] || 444198 ^ 444214, _0x5ac = _0xe59efb["rb"] || 734075 ^ 734059; var _0x843g = 894169 ^ 894253, _0xc38g3d = 660183 ^ 660361, _0xef5fe = 701472 ^ 718658, _0xcc6aa = 136761 ^ 153349; var _0x1ba8d = {}; for (var j = 299794 ^ 299794; j < tileIds["length"]; j++)
        _0x1ba8d[tileIds[j]] = !![]; var _0x086c = (410723 ^ 410724) + (850932 ^ 850932); var _0x6371a = []; _0x086c = 671856 ^ 671856; for (var r = 718821 ^ 718821; r < _0x5ac; r++) {
        for (var c = 265809 ^ 265809; c < _0x4f4a1b; c++) {
            if (!_0x1ba8d[_0xe59efb["rd"][r][c][984411 ^ 984411]])
                continue;
            let _0x1a3e6c;
            var _0xecd3b = Math["round"](_0x843g + c * ((_0xef5fe - _0x843g) / _0x4f4a1b) + (_0xef5fe - _0x843g) / _0x4f4a1b / (806680 ^ 806682));
            _0x1a3e6c = "pbqnlc";
            let _0xa671f;
            var _0x9d_0x4d9 = Math["round"](_0xc38g3d + r * ((_0xcc6aa - _0xc38g3d) / _0x5ac) + (_0xcc6aa - _0xc38g3d) / _0x5ac / (285002 ^ 285000));
            _0xa671f = 911448 ^ 911455;
            _0x6371a["push"]({
                "wx": _0xecd3b,
                        "wy": _0x9d_0x4d9
            });
        }
    } if (!_0x6371a["length"])
        return { "spawned": 0 }; _0xb46ee(_0x6371a); return {
        "spawned": 0,
                "pending": _0x6371a["length"]
    }; }
    function _0x7dd65a(_0x325bae) { var _0x26de = _0x6ec34e(); if (!_0x26de || !K)
        return { "error": "Runtime not available" }; var _0x451bef = 704577 ^ 704577; _0x325bae = "jigphm".split("").reverse().join(""); function _0x9afd5e(inst) { inst["visible"] = false; inst["x"] = -(816387 ^ 833107); inst["y"] = -(472226 ^ 522226); inst[K["bboxFn"]] && inst[K["bboxFn"]](); } for (var i = 429177 ^ 429177; i < _0xe2ab["spawnedInsts"]["length"]; i++) {
        try {
            _0x9afd5e(_0xe2ab["spawnedInsts"][i]);
            _0x451bef++;
        }
        catch (e) { }
    } _0xe2ab["spawnedInsts"] = []; var _0xcda69f = _0x26de[K["types"]] && _0x26de[K["types"]][454556 ^ 453626]; if (_0xcda69f && _0xcda69f[K["insts"]]) {
        var _0x57682f = _0xcda69f[K["insts"]];
        for (var j = 134507 ^ 134507; j < _0x57682f["length"]; j++) {
            try {
                var _0xd22 = _0x57682f[j];
                if (_0xd22["x"] < (444541 ^ 444909) || _0xd22["y"] < (420953 ^ 421237))
                    continue;
                _0x9afd5e(_0xd22);
                _0x451bef++;
            }
            catch (e) { }
        }
    } _0x26de[K["redraw"]] = !![]; return { "cleared": _0x451bef }; }
    function _0x3cba(_0xdfa) { var _0xcead = _0x6ec34e(); _0xdfa = (820913 ^ 820912) + (130600 ^ 130601); if (!_0xcead)
        return 270365 ^ 270365; var v = _0xg84a(_0xcead,
            "leveLtnerruC".split("").reverse().join("")); return v != null ? Math["max"](941732 ^ 941732, Math["floor"](Number(v))) : 560938 ^ 560938; }
    function _0x24aa(_0xb37a) { var _0x0d63ec = (704438 ^ 704432) + (489446 ^ 489445); var _0xbc2 = _0x3cba(); _0x0d63ec = (928532 ^ 928533) + (711646 ^ 711643); var _0xfg0ca = _0xfa3["maxPerIsland"]; _0xb37a = 127884 ^ 127882; var _0x8d1fd = (886163 ^ 886162) + (118502 ^ 118502); var _0xf31d1a = _0xbc2 < _0xfg0ca["length"] ? _0xfg0ca[_0xbc2] : _0xfg0ca[_0xfg0ca["length"] - (314559 ^ 314558)]; _0x8d1fd = 452647 ^ 452644; return _0xf31d1a < (623542 ^ 623542) ? _0xfa3["unlimitedMax"] : Math["max"](784157 ^ 784156, _0xf31d1a); }
    function _0x8f_0x7af() { var _0x1a279d = _0x6ec34e(); if (!_0x1a279d)
        return null; var v = _0xg84a(_0x1a279d,
            "LLA_remiT".split("").reverse().join("")); return v != null ? Number(v) : null; }
    function _0x267fc(count, _0x5af4c, _0xc9db, _0x0fa1b) { var _0xcc8e0f = _0x6ec34e(); _0x5af4c = 798527 ^ 798525; if (!_0xcc8e0f || !K)
        return []; var _0x3cbgad = _0xcc8e0f[K["types"]]; _0xc9db = (163944 ^ 163945) + (783916 ^ 783914); var _0xaaeb = null; for (var i = 376615 ^ 376615; i < _0x3cbgad["length"]; i++) {
        if (_0x3cbgad[i] && _0x3cbgad[i]["name"] === "815t".split("").reverse().join("")) {
            _0xaaeb = _0x3cbgad[i];
            break;
        }
    } if (!_0xaaeb || !_0xaaeb[K["insts"]] || !_0xaaeb[K["insts"]]["length"])
        return []; var _0x7g8b = _0xaaeb[K["insts"]][356106 ^ 356106]; _0x0fa1b = "kcjcme"; if (!_0x7g8b["rd"])
        return []; var _0x4d1fba = _0x7g8b["hb"] || 502609 ^ 502593, _0x1531a = _0x7g8b["rb"] || 219210 ^ 219226; var _0xd15bae = 892720 ^ 892612, _0xfe69ee = 767880 ^ 767702, _0x6475fc = 285712 ^ 270194, _0x1ce4cb = 847619 ^ 831039; var _0x223 = (_0x6475fc - _0xd15bae) / _0x4d1fba, _0x8ac = (_0x1ce4cb - _0xfe69ee) / _0x1531a; var _0xb490b = (307374 ^ 307369) + (428691 ^ 428693); var _0xea2 = {}; _0xb490b = 799009 ^ 799014; for (var _0x5d09be = 732916 ^ 732916; _0x5d09be < _0xe2ab["selectedTileIds"]["length"]; _0x5d09be++)
        _0xea2[_0xe2ab["selectedTileIds"][_0x5d09be]] = !![]; var _0x1329b = (861602 ^ 861607) + (215310 ^ 215307); var _0x224 = []; _0x1329b = 698263 ^ 698261; for (var r = 664277 ^ 664277; r < _0x1531a; r++) {
        for (var c = 357410 ^ 357410; c < _0x4d1fba; c++) {
            if (_0xea2[_0x7g8b["rd"][r][c][308972 ^ 308972]]) {
                _0x224["push"]({
                    "r": r,
                            "c": c,
                            "wx": Math["round"](_0xd15bae + c * _0x223 + _0x223 / (588863 ^ 588861)),
                            "wy": Math["round"](_0xfe69ee + r * _0x8ac + _0x8ac / (842109 ^ 842111))
                });
            }
        }
    } if (!_0x224["length"])
        return []; if (_0x224["length"] <= count) {
        for (var s = _0x224["length"] - (241340 ^ 241341); s > (964893 ^ 964893); s--) {
            let _0xf0d;
            var _0x428dfe = Math["floor"](Math["random"]() * (s + (314329 ^ 314328)));
            _0xf0d = (251977 ^ 251982) + (649735 ^ 649743);
            var _0xcdd3c = _0x224[s];
            _0x224[s] = _0x224[_0x428dfe];
            _0x224[_0x428dfe] = _0xcdd3c;
        }
        return _0x224;
    } var _0x8bf2ge = [], _0x4d1db = {}; while (_0x8bf2ge["length"] < count) {
        var _0x67bd8c = Math["floor"](Math["random"]() * _0x224["length"]);
        if (_0x4d1db[_0x67bd8c])
            continue;
        _0x4d1db[_0x67bd8c] = !![];
        _0x8bf2ge["push"](_0x224[_0x67bd8c]);
    } return _0x8bf2ge; }
    function _0x97907e() { if (!_0xbd3["running"] && _0xbd3["status"] === "eldi".split("").reverse().join("")) {
        try {
            localStorage["removeItem"](_0xb1756b);
        }
        catch (e) { }
        return;
    } try {
        var _0x007d = _0x8f_0x7af();
        var _0x7g5f7f = {
            "v": 1,
                    "savedTimerAll": _0x007d,
                    "savedLevel": _0x3cba(),
                    "startTimerVal": _0xbd3["startTimerVal"],
                    "status": _0xbd3["status"],
                    "nextSpawnAtTimer": _0xbd3["nextSpawnAtTimer"],
                    "nextCandidates": _0xbd3["nextCandidates"],
                    "activeCycle": _0xbd3["activeCycle"] ? {
                "positions": _0xbd3["activeCycle"]["insts"]["map"](function (it) { return {
                    "r": it["r"],
                                "c": it["c"],
                                "wx": it["wx"],
                                "wy": it["wy"]
                }; }),
                        "spawnedAtTimer": _0xbd3["activeCycle"]["spawnedAtTimer"],
                        "despawnAtTimer": _0xbd3["activeCycle"]["despawnAtTimer"]
            } : null
        };
        localStorage["setItem"](_0xb1756b, JSON["stringify"](_0x7g5f7f));
    }
    catch (e) { } }
    function _0xd5ee() { try {
        let _0xe7e;
        var _0xgd6c = localStorage["getItem"](_0xb1756b);
        _0xe7e = (156052 ^ 156048) + (942250 ^ 942242);
        return _0xgd6c ? JSON["parse"](_0xgd6c) : null;
    }
    catch (e) {
        return null;
    } }
    function _0xb7a2c() { try {
        localStorage["removeItem"](_0xb1756b);
    }
    catch (e) { } }
    function _0x9gf() { try {
        localStorage["setItem"](_0xceb8ac, JSON["stringify"](_0xfa3));
    }
    catch (e) { } }
    function _0x1d5a() { try {
        localStorage["setItem"](_0x384e4g, JSON["stringify"](_0x06cd7a));
    }
    catch (e) { } }
    function _0xcf0b0a() { try {
        var _0xe18 = localStorage["getItem"](_0x384e4g);
        if (!_0xe18)
            return;
        var _0x29_0x6f3 = (563806 ^ 563800) + (776667 ^ 776671);
        var _0x245b = JSON["parse"](_0xe18);
        _0x29_0x6f3 = (881255 ^ 881251) + (300223 ^ 300223);
        if (!_0x245b || typeof _0x245b !== "tcejbo".split("").reverse().join(""))
            return;
        if (typeof _0x245b["enabled"] === "boolean")
            _0x06cd7a["enabled"] = _0x245b["enabled"];
        if (typeof _0x245b["spawnInterval"] === "rebmun".split("").reverse().join("") && _0x245b["spawnInterval"] >= (721671 ^ 721670))
            _0x06cd7a["spawnInterval"] = _0x245b["spawnInterval"];
        if (typeof _0x245b["duration"] === "number" && _0x245b["duration"] >= (231495 ^ 231494))
            _0x06cd7a["duration"] = _0x245b["duration"];
        if (typeof _0x245b["despawnRadius"] === "rebmun".split("").reverse().join("") && _0x245b["despawnRadius"] >= (194272 ^ 194258))
            _0x06cd7a["despawnRadius"] = _0x245b["despawnRadius"];
        if (typeof _0x245b["convoyHudVisible"] === "naeloob".split("").reverse().join(""))
            _0x06cd7a["convoyHudVisible"] = _0x245b["convoyHudVisible"];
    }
    catch (e) { } }
    function _0xbbb11d() { try {
        localStorage["setItem"](_0xf7_0x978, JSON["stringify"](_0xcdafb));
    }
    catch (e) { } }
    function _0x5c4a1e() { try {
        let _0x3g_0x576;
        var _0x14d4ba = localStorage["getItem"](_0xf7_0x978);
        _0x3g_0x576 = "njkmeo".split("").reverse().join("");
        if (!_0x14d4ba)
            return;
        var _0x6g28bb = (988281 ^ 988283) + (475716 ^ 475719);
        var _0xde469e = JSON["parse"](_0x14d4ba);
        _0x6g28bb = (455976 ^ 455982) + (747568 ^ 747576);
        if (!_0xde469e || typeof _0xde469e !== "object")
            return;
        if (typeof _0xde469e["enabled"] === "boolean")
            _0xcdafb["enabled"] = _0xde469e["enabled"];
        if (typeof _0xde469e["spawnInterval"] === "rebmun".split("").reverse().join("") && _0xde469e["spawnInterval"] >= (538959 ^ 538958))
            _0xcdafb["spawnInterval"] = _0xde469e["spawnInterval"];
        if (typeof _0xde469e["duration"] === "rebmun".split("").reverse().join("") && _0xde469e["duration"] >= (116235 ^ 116234))
            _0xcdafb["duration"] = _0xde469e["duration"];
        if (typeof _0xde469e["despawnRadius"] === "rebmun".split("").reverse().join("") && _0xde469e["despawnRadius"] >= (901763 ^ 901809))
            _0xcdafb["despawnRadius"] = _0xde469e["despawnRadius"];
        if (typeof _0xde469e["heliHudVisible"] === "naeloob".split("").reverse().join(""))
            _0xcdafb["heliHudVisible"] = _0xde469e["heliHudVisible"];
        if (typeof _0xde469e["smokeScale"] === "rebmun".split("").reverse().join("") && _0xde469e["smokeScale"] > (613164 ^ 613164))
            _0xcdafb["smokeScale"] = _0xde469e["smokeScale"];
        if (typeof _0xde469e["useT344"] === "boolean")
            _0xcdafb["useT344"] = _0xde469e["useT344"];
        if (typeof _0xde469e["heliTypeIdx"] === "rebmun".split("").reverse().join(""))
            _0xcdafb["heliTypeIdx"] = _0xde469e["heliTypeIdx"];
        if (typeof _0xde469e["debrisCount"] === "number" && _0xde469e["debrisCount"] >= (252070 ^ 252070))
            _0xcdafb["debrisCount"] = _0xde469e["debrisCount"];
        if (typeof _0xde469e["soundDelay"] === "number" && _0xde469e["soundDelay"] >= (843652 ^ 843652))
            _0xcdafb["soundDelay"] = _0xde469e["soundDelay"];
        if (typeof _0xde469e["debrisOpacity"] === "number")
            _0xcdafb["debrisOpacity"] = Math["max"](227592 ^ 227592, Math["min"](378419 ^ 378418, _0xde469e["debrisOpacity"]));
    }
    catch (e) { } }
    function _0x2df29d() { try {
        let _0x03fee;
        var _0x29b0cc = localStorage["getItem"](_0xceb8ac);
        _0x03fee = 123777 ^ 123785;
        if (!_0x29b0cc)
            return;
        var _0xb9d4fd = (768038 ^ 768047) + (565331 ^ 565339);
        var _0x65438f = JSON["parse"](_0x29b0cc);
        _0xb9d4fd = (254683 ^ 254686) + (524761 ^ 524766);
        if (!_0x65438f || typeof _0x65438f !== "tcejbo".split("").reverse().join(""))
            return;
        if (typeof _0x65438f["spawnInterval"] === "rebmun".split("").reverse().join("") && _0x65438f["spawnInterval"] >= (281990 ^ 281991))
            _0xfa3["spawnInterval"] = _0x65438f["spawnInterval"];
        if (typeof _0x65438f["duration"] === "number" && _0x65438f["duration"] >= (637181 ^ 637180))
            _0xfa3["duration"] = _0x65438f["duration"];
        if (typeof _0x65438f["stopAtTimer"] === "rebmun".split("").reverse().join(""))
            _0xfa3["stopAtTimer"] = _0x65438f["stopAtTimer"];
        if (typeof _0x65438f["fadeDuration"] === "number" && _0x65438f["fadeDuration"] >= (346728 ^ 346636))
            _0xfa3["fadeDuration"] = _0x65438f["fadeDuration"];
        if (Array["isArray"](_0x65438f["maxPerIsland"]) && _0x65438f["maxPerIsland"]["length"] === (711600 ^ 711605))
            _0xfa3["maxPerIsland"] = _0x65438f["maxPerIsland"];
        if (typeof _0x65438f["unlimitedMax"] === "number" && _0x65438f["unlimitedMax"] >= (503792 ^ 503793))
            _0xfa3["unlimitedMax"] = _0x65438f["unlimitedMax"];
        if (typeof _0x65438f["randomizeCount"] === "boolean")
            _0xfa3["randomizeCount"] = _0x65438f["randomizeCount"];
    }
    catch (e) { } }
    function _0x11b41c(saved) { var _0xd12dc2 = _0x5e9e6g("181t".split("").reverse().join("")); if (!_0xd12dc2 || !_0xd12dc2["length"])
        return false; var _0xb6_0x33f = (665227 ^ 665226) + (499642 ^ 499645); var _0xc12 = _0x8f_0x7af(); _0xb6_0x33f = "jdilim"; if (_0xc12 == null)
        return false; if (_0x3cba() !== saved["savedLevel"])
        return !![]; if (saved["savedTimerAll"] != null && _0xc12 < saved["savedTimerAll"] - (185351 ^ 185397))
        return !![]; return false; }
    var _0x11ba = (323239 ^ 323234) + (214495 ^ 214487);
    var _0x7a3ba = 615881 ^ 615775;
    _0x11ba = 868427 ^ 868419;
    function _0x94c0fc(wx, wy, alreadyAdopted) { var _0xcg_0x296 = (296439 ^ 296439) + (963730 ^ 963730); var _0x69d4ag = _0x6ec34e(); _0xcg_0x296 = "leplqh"; if (!_0x69d4ag || !K)
        return null; var _0x2f_0x14a = (451253 ^ 451255) + (363417 ^ 363421); var _0x2ae73f = _0x69d4ag[K["types"]][372855 ^ 373777]; _0x2f_0x14a = "pkgnma"; if (_0x2ae73f && _0x2ae73f[K["insts"]]) {
        let _0x2c2;
        var _0x5e32dc = _0x2ae73f[K["insts"]];
        _0x2c2 = (316332 ^ 316328) + (408452 ^ 408451);
        var _0x226 = null, _0x5d0d4b = _0x7a3ba;
        for (var _0x8d7a = 294084 ^ 294084; _0x8d7a < _0x5e32dc["length"]; _0x8d7a++) {
            var _0xbcc = (779518 ^ 779512) + (652009 ^ 652010);
            var _0x5e3f = _0x5e32dc[_0x8d7a];
            _0xbcc = (789599 ^ 789596) + (712745 ^ 712748);
            if (_0x5e3f["x"] < (843374 ^ 843774) || _0x5e3f["y"] < (208796 ^ 208560))
                continue;
            if (alreadyAdopted && alreadyAdopted["indexOf"](_0x5e3f) >= (217871 ^ 217871))
                continue;
            var _0x10664b = (350102 ^ 350098) + (506939 ^ 506943);
            var _0xdf03ge = Math["hypot"](_0x5e3f["x"] - wx, _0x5e3f["y"] - wy);
            _0x10664b = (335545 ^ 335545) + (525953 ^ 525958);
            if (_0xdf03ge < _0x5d0d4b) {
                _0x5d0d4b = _0xdf03ge;
                _0x226 = _0x5e3f;
            }
        }
        if (_0x226) {
            _0x226["visible"] = !![];
            _0x226["opacity"] = 399663 ^ 399662;
            _0x226[K["bboxFn"]] && _0x226[K["bboxFn"]]();
            if (_0xe2ab["spawnedInsts"]["indexOf"](_0x226) < (516982 ^ 516982))
                _0xe2ab["spawnedInsts"]["push"](_0x226);
            return _0x226;
        }
    } return _0xe51cd(wx, wy); }
    function _0xe51cd(wx, wy, _0xc2_0x782) { var _0xba3ee = _0x6ec34e(); if (!_0xba3ee || !K)
        return null; var _0x1c9dea = _0xba3ee[K["types"]][889578 ^ 890508]; if (!_0x1c9dea || !_0x1c9dea["be"])
        return null; var _0x6d2 = _0xba3ee[K["layouts"]] || _0xba3ee["Fs"]; if (!_0x6d2 || !_0x6d2["Map"] || !_0x6d2["Map"]["ua"])
        return null; var _0xd461d = _0x6d2["Map"]["ua"][586206 ^ 586226]; _0xc2_0x782 = (498013 ^ 498005) + (838592 ^ 838601); if (!_0xd461d)
        return null; try {
        var _0x64ged = (999240 ^ 999241) + (997532 ^ 997525);
        var _0xd41d = _0xba3ee["Sg"](_0x1c9dea["be"], _0xd461d, false, wx, wy, false);
        _0x64ged = (616584 ^ 616591) + (548239 ^ 548232);
        if (_0xd41d) {
            _0xd41d[K["bboxFn"]] && _0xd41d[K["bboxFn"]]();
            _0xe2ab["spawnedInsts"]["push"](_0xd41d);
            return _0xd41d;
        }
    }
    catch (e) { } return null; }
    function _0x4aec(inst, targetOpacity, durationMs, onDone, _0xb20c7e) { var _0xb5cec = (914462 ^ 914456) + (339985 ^ 339990); var _0x927a = typeof inst["opacity"] === "number" ? inst["opacity"] : 938929 ^ 938928; _0xb5cec = (468768 ^ 468777) + (193700 ^ 193701); var _0x1efd3e = Math["max"](708600 ^ 708592, Math["round"](durationMs / (260972 ^ 260872))); var _0x4d2 = (500327 ^ 500327) + (804382 ^ 804379); var _0x84462f = durationMs / _0x1efd3e; _0x4d2 = (817040 ^ 817048) + (929523 ^ 929531); var _0x25321f = 914926 ^ 914926; _0xb20c7e = "eobefd".split("").reverse().join(""); var _0xc626g = (561164 ^ 561156) + (278982 ^ 278990); var _0xd158fc = setInterval(function () { _0x25321f++; inst["opacity"] = _0x927a + (targetOpacity - _0x927a) * (_0x25321f / _0x1efd3e); var _0xc13 = _0x6ec34e(); if (_0xc13)
        _0xc13[K["redraw"]] = !![]; if (_0x25321f >= _0x1efd3e) {
        clearInterval(_0xd158fc);
        inst["opacity"] = targetOpacity;
        if (onDone)
            onDone();
    } }, _0x84462f); _0xc626g = "bbhpeq".split("").reverse().join(""); return _0xd158fc; }
    function _0x1213e(onComplete, _0x7cb) { var _0xbc7daa = (985971 ^ 985968) + (387437 ^ 387433); var _0x6g3 = []; _0xbc7daa = 144775 ^ 144773; var _0x561ad = _0x6ec34e(); if (_0x561ad && K) {
        var _0x7de = _0x561ad[K["types"]] && _0x561ad[K["types"]][883267 ^ 884261];
        if (_0x7de && _0x7de[K["insts"]]) {
            var _0x8579ec = (406178 ^ 406176) + (503843 ^ 503840);
            var _0xfd1e = _0x7de[K["insts"]];
            _0x8579ec = (261744 ^ 261753) + (758217 ^ 758218);
            for (var _0xac8d = 442139 ^ 442139; _0xac8d < _0xfd1e["length"]; _0xac8d++) {
                if (_0xfd1e[_0xac8d]["x"] >= (199552 ^ 199184) && _0xfd1e[_0xac8d]["y"] >= (890232 ^ 889940))
                    _0x6g3["push"](_0xfd1e[_0xac8d]);
            }
        }
    } if (!_0x6g3["length"]) {
        if (onComplete)
            onComplete();
        return;
    } var _0xb99a = _0x6g3["length"], _0x447gc = 505832 ^ 505832; var _0x5d9c = function () { _0x447gc++; if (_0x447gc >= _0xb99a) {
        for (var _0x9da2e = 598540 ^ 598540; _0x9da2e < _0x6g3["length"]; _0x9da2e++) {
            try {
                var _0xe19 = _0x6g3[_0x9da2e];
                _0xe19["visible"] = false;
                _0xe19["x"] = -(1033751 ^ 984391);
                _0xe19["y"] = -(879943 ^ 896535);
                _0xe19[K["bboxFn"]] && _0xe19[K["bboxFn"]]();
            }
            catch (e) { }
        }
        var _0xda75fd = _0x6ec34e();
        if (_0xda75fd)
            _0xda75fd[K["redraw"]] = !![];
        if (onComplete)
            onComplete();
    } }; _0x7cb = (138289 ^ 138293) + (529217 ^ 529220); for (var _0x4a9c3a = 670320 ^ 670320; _0x4a9c3a < _0x6g3["length"]; _0x4a9c3a++) {
        _0x4aec(_0x6g3[_0x4a9c3a], 428996 ^ 428996, _0xfa3["fadeDuration"], _0x5d9c);
    } }
    function _0x5be5b() { var _0xde_0x532 = (208447 ^ 208440) + (152041 ^ 152046); var _0x4d5 = _0xbd3["activeCycle"]; _0xde_0x532 = (942482 ^ 942487) + (310104 ^ 310104); if (!_0x4d5 || !_0x4d5["insts"] || !_0x4d5["insts"]["length"])
        return; var _0x1a6f = _0x4d5["insts"]["slice"](); var _0x41668f = _0x3eaae(); if (!_0x41668f) {
        _0x1a6f["forEach"](function (item) { _0x4aec(item["inst"], 172833 ^ 172832, _0xfa3["fadeDuration"], null); });
        return;
    } var _0x46edc = _0xafac6f["concat"](_0x6g_0x341); var _0xc434a = _0x46edc["length"]; _0x46edc["forEach"](function (url) { _0x9498e(_0x41668f, url, function () { _0xc434a--; if (_0xc434a === (162881 ^ 162881)) {
        let _0xea0d;
        var _0x9f5fe = _0x6ec34e();
        _0xea0d = 368336 ^ 368343;
        if (!_0x9f5fe || !K)
            return;
        var _0x45728d = 777553 ^ 786426, _0xce4f8c = 667055 ^ 658658;
        var _0x23f = _0x9f5fe[K["types"]] && _0x9f5fe[K["types"]][848950 ^ 849027];
        if (_0x23f && _0x23f[K["insts"]] && _0x23f[K["insts"]][447814 ^ 447814]) {
            _0x45728d = _0x23f[K["insts"]][926726 ^ 926726]["x"];
            _0xce4f8c = _0x23f[K["insts"]][263766 ^ 263766]["y"];
        }
        _0x1a6f["forEach"](function (item, i) { setTimeout(function () { var _0x25a3g = (427300 ^ 427301) + (894948 ^ 894945); var _0xa74f = _0xafac6f[Math["floor"](Math["random"]() * _0xafac6f["length"])]; _0x25a3g = "pnmlck".split("").reverse().join(""); if (_0xb09g9f[_0xa74f])
            _0xdf6b5a(_0x41668f, _0xb09g9f[_0xa74f], _0x45728d, _0xce4f8c, item["wx"], item["wy"], 420566 ^ 420567); var _0x2g661g = (765913 ^ 768169) + Math["random"]() * (555481 ^ 555253); setTimeout(function () { _0x4aec(item["inst"], 810945 ^ 810944, _0xfa3["fadeDuration"], null); var _0x01b6ae = _0x6ec34e(); if (!_0x01b6ae || !K)
            return; var _0x84ec = 362352 ^ 370139, _0xdadbb = 221353 ^ 213476; var _0x4a19fa = _0x01b6ae[K["types"]] && _0x01b6ae[K["types"]][460431 ^ 460346]; if (_0x4a19fa && _0x4a19fa[K["insts"]] && _0x4a19fa[K["insts"]][638213 ^ 638213]) {
            _0x84ec = _0x4a19fa[K["insts"]][370706 ^ 370706]["x"];
            _0xdadbb = _0x4a19fa[K["insts"]][929022 ^ 929022]["y"];
        } var _0x802cbd = _0x6g_0x341[Math["floor"](Math["random"]() * _0x6g_0x341["length"])]; if (_0xb09g9f[_0x802cbd])
            _0xdf6b5a(_0x41668f, _0xb09g9f[_0x802cbd], _0x84ec, _0xdadbb, item["wx"], item["wy"], 734950 ^ 734951); }, _0x2g661g); }, i * (914272 ^ 914082)); });
    } }); }); }
    function _0x0743fb(_0x1dd9a) { var _0x2451ba = (344873 ^ 344873) + (735777 ^ 735779); var _0x9afg = _0x6ec34e(); _0x2451ba = (588382 ^ 588374) + (600591 ^ 600582); if (_0x9afg && K) {
        var _0x789ce = _0x9afg[K["types"]] && _0x9afg[K["types"]][352501 ^ 353427];
        if (_0x789ce && _0x789ce[K["insts"]]) {
            var _0x30_0x64c = (873406 ^ 873399) + (526284 ^ 526286);
            var _0xa1bg6g = _0x789ce[K["insts"]];
            _0x30_0x64c = (410519 ^ 410519) + (903288 ^ 903293);
            for (var _0xcf3 = 358441 ^ 358441; _0xcf3 < _0xa1bg6g["length"]; _0xcf3++) {
                var _0xb15 = _0xa1bg6g[_0xcf3];
                if (_0xb15["x"] >= (364227 ^ 364371) && _0xb15["y"] >= (671405 ^ 671617)) {
                    _0xb15["visible"] = false;
                    _0xb15["x"] = -(65954 ^ 115442);
                    _0xb15["y"] = -(549005 ^ 566237);
                    _0xb15[K["bboxFn"]] && _0xb15[K["bboxFn"]]();
                }
            }
        }
    } var _0xfb5ffc = _0x8f_0x7af(); if (_0xfb5ffc == null)
        return; var _0x229 = _0xbd3["nextCandidates"]["length"] > (677725 ^ 677725) ? _0xbd3["nextCandidates"]["slice"]() : _0x267fc(_0x24aa()); if (!_0x229["length"])
        return; if (_0xfa3["randomizeCount"] && _0x229["length"] > (125970 ^ 125971)) {
        _0x229 = _0x229["slice"](798667 ^ 798667, (329117 ^ 329116) + Math["floor"](Math["random"]() * _0x229["length"]));
    } var _0x8e_0xa54 = []; _0x1dd9a = (417545 ^ 417545) + (873534 ^ 873529); for (var i = 120233 ^ 120233; i < _0x229["length"]; i++) {
        let _0xe6d3bc;
        var t = _0x229[i];
        _0xe6d3bc = (188410 ^ 188403) + (200506 ^ 200506);
        let _0xccdc4a;
        var _0xg7b = _0xe51cd(t["wx"], t["wy"]);
        _0xccdc4a = (920608 ^ 920611) + (287939 ^ 287937);
        if (_0xg7b) {
            _0xg7b["opacity"] = 373306 ^ 373306;
            _0x8e_0xa54["push"]({
                "inst": _0xg7b,
                        "r": t["r"],
                        "c": t["c"],
                        "wx": t["wx"],
                        "wy": t["wy"]
            });
        }
    } if (!_0x8e_0xa54["length"])
        return; _0xbd3["activeCycle"] = {
        "insts": _0x8e_0xa54,
                "spawnedAtTimer": _0xfb5ffc,
                "despawnAtTimer": _0xfb5ffc + _0xfa3["duration"],
                "fadingOut": false
    }; _0xbd3["nextSpawnAtTimer"] = null; _0xbd3["nextCandidates"] = []; _0xbd3["status"] = "active"; _0x97907e(); _0x5be5b(); _0xd1f8e(); }
    function _0xa5_0x960() { if (!_0xbd3["running"])
        return; var _0x44gg5f = _0x6ec34e(); if (!_0x44gg5f || !K)
        return; var _0x7fae0c = _0x8f_0x7af(); if (_0x7fae0c == null)
        return; _0xbd3["lastTimerVal"] = _0x7fae0c; if (_0xbd3["running"] && _0xbd3["nextSpawnAtTimer"] == null && !_0xbd3["activeCycle"] && !_0xbd3["pendingRestore"]) {
        _0xbd3["startTimerVal"] = _0x7fae0c;
        _0xbd3["nextSpawnAtTimer"] = _0x7fae0c + (705330 ^ 705324);
    } var _0xb9e = _0xd5ee(); if (_0xb9e && _0xb9e["v"] === (512865 ^ 512864) && _0x11b41c(_0xb9e)) {
        _0xbd3["pendingRestore"] = null;
        _0xb7a2c();
        _0xbd3["startTimerVal"] = _0x7fae0c;
        _0xbd3["nextSpawnAtTimer"] = _0x7fae0c + (290621 ^ 290595);
        _0xbd3["nextCandidates"] = [];
        _0xbd3["activeCycle"] = null;
        _0xbd3["status"] = "gnitiaw".split("").reverse().join("");
        _0xd1f8e();
    } if (_0xbd3["pendingRestore"]) {
        var _0xfeg = _0xbd3["pendingRestore"];
        _0xbd3["pendingRestore"] = null;
        if (_0x7fae0c < _0xfeg["despawnAtTimer"]) {
            var _0xcefa = [], _0x6ebcga = [];
            for (var _0xg39b = 652726 ^ 652726; _0xg39b < _0xfeg["positions"]["length"]; _0xg39b++) {
                var _0x7g0ge = _0xfeg["positions"][_0xg39b];
                let _0x56eaf;
                var _0x89006a = _0x94c0fc(_0x7g0ge["wx"], _0x7g0ge["wy"], _0x6ebcga);
                _0x56eaf = (128023 ^ 128023) + (290896 ^ 290897);
                if (_0x89006a) {
                    _0x89006a["opacity"] = 849071 ^ 849070;
                    _0x6ebcga["push"](_0x89006a);
                    _0xcefa["push"]({
                        "inst": _0x89006a,
                                "r": _0x7g0ge["r"],
                                "c": _0x7g0ge["c"],
                                "wx": _0x7g0ge["wx"],
                                "wy": _0x7g0ge["wy"]
                    });
                }
            }
            if (_0xcefa["length"]) {
                _0xbd3["activeCycle"] = {
                    "insts": _0xcefa,
                            "spawnedAtTimer": _0xfeg["spawnedAtTimer"],
                            "despawnAtTimer": _0xfeg["despawnAtTimer"],
                            "fadingOut": false
                };
                _0xbd3["status"] = "evitca".split("").reverse().join("");
            }
            else {
                _0xbd3["pendingRestore"] = _0xfeg;
            }
        }
    } if (_0x7fae0c >= _0xfa3["stopAtTimer"]) {
        _0xbd3["status"] = "stopped";
        _0xbd3["running"] = false;
        if (_0xbd3["ticker"]) {
            clearInterval(_0xbd3["ticker"]);
            _0xbd3["ticker"] = null;
        }
        _0xbd3["activeCycle"] = null;
        _0x1213e(function () { _0xb7a2c(); _0xd1f8e(); });
        return;
    } var _0x74f4d = (857354 ^ 857358) + (999154 ^ 999152); var _0xc7fa3c = _0xbd3["activeCycle"]; _0x74f4d = 989885 ^ 989884; if (_0xc7fa3c && !_0xc7fa3c["fadingOut"] && _0x7fae0c >= _0xc7fa3c["despawnAtTimer"]) {
        _0xc7fa3c["fadingOut"] = !![];
        _0x1213e(function () { _0xbd3["activeCycle"] = null; var _0xf6fe = _0xbd3["lastTimerVal"] || _0x7fae0c; _0xbd3["nextSpawnAtTimer"] = _0xf6fe + _0xfa3["spawnInterval"]; _0xbd3["nextCandidates"] = _0x267fc(_0x24aa()); _0xbd3["status"] = "waiting"; _0x97907e(); _0xd1f8e(); });
    } if (!_0xbd3["activeCycle"] && _0xbd3["status"] !== "stopped") {
        if (_0xbd3["nextSpawnAtTimer"] != null && _0x7fae0c >= _0xbd3["nextSpawnAtTimer"]) {
            _0x0743fb();
        }
    } _0xbd3["_saveTick"] = (_0xbd3["_saveTick"] || 197364 ^ 197364) + (284446 ^ 284447); if (_0xbd3["_saveTick"] % (366232 ^ 366226) === (842640 ^ 842640))
        _0x97907e(); _0x2bga(); }
    function _0xceba() { if (_0xbd3["running"])
        return; var _0xa0353e = (431095 ^ 431088) + (649270 ^ 649264); var _0x25ab1g = _0x8f_0x7af(); _0xa0353e = 970320 ^ 970321; if (_0x25ab1g != null && _0x25ab1g >= _0xfa3["stopAtTimer"]) {
        _0xbd3["status"] = "stopped";
        _0xd1f8e();
        return;
    } var _0x3d551c = (704822 ^ 704821) + (663833 ^ 663825); var _0x9cbea = _0xd5ee(); _0x3d551c = (503305 ^ 503311) + (591300 ^ 591300); if (_0x9cbea && _0x9cbea["v"] === (785164 ^ 785165) && !_0x11b41c(_0x9cbea)) {
        _0xbd3["running"] = !![];
        _0xbd3["startTimerVal"] = _0x9cbea["startTimerVal"];
        _0xbd3["nextSpawnAtTimer"] = _0x9cbea["nextSpawnAtTimer"];
        _0xbd3["nextCandidates"] = _0x9cbea["nextCandidates"] || [];
        _0xbd3["lastTimerVal"] = _0x25ab1g;
        _0xbd3["pendingRestore"] = null;
        if (_0x9cbea["activeCycle"] && _0x25ab1g != null && _0x25ab1g < _0x9cbea["activeCycle"]["despawnAtTimer"]) {
            var _0x366bc = [], _0xagf2 = [];
            for (var _0x7d79a = 122285 ^ 122285; _0x7d79a < _0x9cbea["activeCycle"]["positions"]["length"]; _0x7d79a++) {
                var _0x44e = _0x9cbea["activeCycle"]["positions"][_0x7d79a];
                let _0xef13d;
                var _0xd52d = _0x94c0fc(_0x44e["wx"], _0x44e["wy"], _0xagf2);
                _0xef13d = (262135 ^ 262131) + (371421 ^ 371419);
                if (_0xd52d) {
                    _0xd52d["opacity"] = 414345 ^ 414344;
                    _0xagf2["push"](_0xd52d);
                    _0x366bc["push"]({
                        "inst": _0xd52d,
                                "r": _0x44e["r"],
                                "c": _0x44e["c"],
                                "wx": _0x44e["wx"],
                                "wy": _0x44e["wy"]
                    });
                }
            }
            if (_0x366bc["length"]) {
                _0xbd3["activeCycle"] = {
                    "insts": _0x366bc,
                            "spawnedAtTimer": _0x9cbea["activeCycle"]["spawnedAtTimer"],
                            "despawnAtTimer": _0x9cbea["activeCycle"]["despawnAtTimer"],
                            "fadingOut": false
                };
                _0xbd3["status"] = "active";
            }
            else {
                _0xbd3["pendingRestore"] = _0x9cbea["activeCycle"];
                _0xbd3["activeCycle"] = null;
                _0xbd3["status"] = "active";
            }
        }
        else if (_0x9cbea["activeCycle"] && _0x25ab1g != null && _0x25ab1g >= _0x9cbea["activeCycle"]["despawnAtTimer"]) {
            _0xbd3["activeCycle"] = null;
            let _0x6bf77e;
            var _0xb5f = _0x9cbea["nextSpawnAtTimer"] != null ? _0x9cbea["nextSpawnAtTimer"] : _0x9cbea["activeCycle"]["despawnAtTimer"] + _0xfa3["spawnInterval"];
            _0x6bf77e = (155368 ^ 155375) + (195515 ^ 195506);
            _0xbd3["nextSpawnAtTimer"] = _0xb5f;
            if (!_0xbd3["nextCandidates"]["length"])
                _0xbd3["nextCandidates"] = _0x267fc(_0x24aa());
            _0xbd3["status"] = "waiting";
        }
        else if (_0x9cbea["activeCycle"]) {
            _0xbd3["pendingRestore"] = _0x9cbea["activeCycle"];
            _0xbd3["activeCycle"] = null;
            _0xbd3["status"] = "active";
        }
        else {
            _0xbd3["activeCycle"] = null;
            _0xbd3["status"] = _0x9cbea["status"] === "stopped" ? "gnitiaw".split("").reverse().join("") : _0x9cbea["status"] || "waiting";
        }
        if (_0x25ab1g != null && _0xbd3["nextSpawnAtTimer"] != null && _0xbd3["nextSpawnAtTimer"] <= _0x25ab1g) {
            _0xbd3["nextSpawnAtTimer"] = _0x25ab1g + (122182 ^ 122179);
        }
        _0xbd3["ticker"] = setInterval(_0xa5_0x960, 951818 ^ 952318);
        _0xa5_0x960();
    }
    else {
        _0xb7a2c();
        _0xbd3["running"] = !![];
        _0xbd3["activeCycle"] = null;
        _0xbd3["pendingRestore"] = null;
        _0xbd3["startTimerVal"] = _0x25ab1g;
        _0xbd3["nextSpawnAtTimer"] = _0x25ab1g != null ? _0x25ab1g + (863042 ^ 863068) : null;
        _0xbd3["nextCandidates"] = [];
        _0xbd3["lastTimerVal"] = _0x25ab1g;
        _0xbd3["status"] = "waiting";
        _0xbd3["ticker"] = setInterval(_0xa5_0x960, 152012 ^ 151608);
        _0xa5_0x960();
    } }
    function _0x34c3e(clearSave) { _0xbd3["running"] = false; if (_0xbd3["ticker"]) {
        clearInterval(_0xbd3["ticker"]);
        _0xbd3["ticker"] = null;
    } _0xbd3["activeCycle"] = null; _0xbd3["nextSpawnAtTimer"] = null; _0xbd3["nextCandidates"] = []; _0xbd3["pendingRestore"] = null; _0xbd3["startTimerVal"] = null; _0xbd3["status"] = "eldi".split("").reverse().join(""); if (clearSave)
        _0xb7a2c(); _0xd1f8e(); }
    function _0xd1f8e() { if (_0xdc93b && _0xdc93b["tab"] === "event" && _0xdc93b["ui"] && _0xdc93b["ui"]["left"] && document["body"]["contains"](_0xdc93b["ui"]["left"])) {
        try {
            _0x1728b();
        }
        catch (e) { }
    } }
    function _0x4edf(_0x594ef, _0xd693a, _0xecb50d) { var _0x5c6c = (974977 ^ 974978) + (258353 ^ 258352); var t = _0xbd3["lastTimerVal"]; _0x5c6c = (402685 ^ 402683) + (429618 ^ 429623); var _0x5762c = t != null ? String(t) : "—"; _0x594ef = "pcblmf"; var _0xb0e = _0x3cba(); _0xd693a = (170168 ^ 170161) + (743065 ^ 743057); var _0x7429e = _0xfa3["maxPerIsland"][Math["min"](_0xb0e, _0xfa3["maxPerIsland"]["length"] - (529455 ^ 529454))]; var _0xb3d = _0x7429e < (463903 ^ 463903) ? "All (" + _0xfa3["unlimitedMax"] + ")" : String(_0x7429e); _0xecb50d = (669764 ^ 669767) + (708204 ^ 708197); var _0x374gab = {
        "idle": "#bcae94",
                "active": "#5f5",
                "waiting": "#fa5",
                "stopped": "#f55"
    }; var _0xca8a9d = _0x374gab[_0xbd3["status"]] || "49eacb#".split("").reverse().join(""); var _0xe24f3a = "<div style=\"border-top:1px solid rgba(255,255,255,0.1);margin-top:6px;padding-top:6px\">"; _0xe24f3a += "<strong style=\"font-size:11px\">Gas Timers</strong>"; _0xe24f3a += "<div style=\"font-size:11px;color:" + _0xca8a9d + "\">Status: " + _0xbd3["status"]["toUpperCase"]() + "</div>"; _0xe24f3a += "<div style=\"font-size:11px;color:#bcae94\">Timer_ALL: " + _0x5762c + " &nbsp;|&nbsp; Island L" + _0xb0e + " → max " + _0xb3d + "</div>"; var _0xb6ccd = _0xbd3["activeCycle"]; if (_0xb6ccd) {
        var _0x50def = t != null ? Math["max"](106953 ^ 106953, _0xb6ccd["despawnAtTimer"] - t) : "?";
        _0xe24f3a += "<div style=\"font-size:11px;color:#5cf\">&#9679; " + _0xb6ccd["insts"]["length"] + ">b< ni seripxe — )s(ecnatsni sag ".split("").reverse().join("") + _0x50def + "</b> ticks (at timer " + _0xb6ccd["despawnAtTimer"] + ")" + (_0xb6ccd["fadingOut"] ? "]…tuo gnidaf[ ".split("").reverse().join("") : "") + "</div>";
        for (var i = 199135 ^ 199135; i < _0xb6ccd["insts"]["length"]; i++) {
            var _0xcbgc = _0xb6ccd["insts"][i];
            _0xe24f3a += "<div style=\"font-size:10px;color:#aaa;padding-left:8px\">&#8627; #" + (i + (136285 ^ 136284)) + " wor ".split("").reverse().join("") + _0xcbgc["r"] + " col " + _0xcbgc["c"] + "( ".split("").reverse().join("") + _0xcbgc["wx"] + ", " + _0xcbgc["wy"] + ")</div>";
        }
    } if (_0xbd3["status"] === "waiting" && _0xbd3["nextSpawnAtTimer"] != null) {
        let _0x3dbd;
        var _0x2g4c = t != null ? Math["max"](537729 ^ 537729, _0xbd3["nextSpawnAtTimer"] - t) : "?";
        _0x3dbd = (629213 ^ 629210) + (448346 ^ 448350);
        var _0xfb9efg = (579841 ^ 579843) + (980362 ^ 980355);
        var _0x229b = _0xbd3["startTimerVal"] != null && _0xbd3["nextSpawnAtTimer"] === _0xbd3["startTimerVal"] + (128399 ^ 128401) && _0xbd3["activeCycle"] == null;
        _0xfb9efg = (515134 ^ 515129) + (441576 ^ 441581);
        _0xe24f3a += "<div style=\"font-size:11px;color:#fa5\">" + (_0x229b ? " — yaled laitinI ;2029#&".split("").reverse().join("") : "&#9200; Next batch in ") + "<b>" + _0x2g4c + "</b> ticks (at timer " + _0xbd3["nextSpawnAtTimer"] + ")</div>";
        if (_0xbd3["nextCandidates"]["length"]) {
            _0xe24f3a += "<div style=\"font-size:11px;color:#fc0\">Next locations (" + _0xbd3["nextCandidates"]["length"] + ">vid/<:)".split("").reverse().join("");
            for (var j = 478777 ^ 478777; j < _0xbd3["nextCandidates"]["length"]; j++) {
                var _0x8fc = _0xbd3["nextCandidates"][j];
                _0xe24f3a += "<div style=\"font-size:10px;color:#aaa;padding-left:8px\">&#8627; row " + _0x8fc["r"] + " col " + _0x8fc["c"] + "( ".split("").reverse().join("") + _0x8fc["wx"] + " ,".split("").reverse().join("") + _0x8fc["wy"] + ")</div>";
            }
        }
    } if (_0xbd3["status"] === "stopped") {
        _0xe24f3a += "( dlohserht pots tih LLA_remiT — detlaH>\"55f#:roloc;xp11:ezis-tnof\"=elyts vid<".split("").reverse().join("") + _0xfa3["stopAtTimer"] + ").</div>";
    } _0xe24f3a += ">vid/<".split("").reverse().join(""); return _0xe24f3a; }
    function _0x57359c() { var _0xa4fb8g = document["getElementById"]("mdzGasHud"); if (!_0xa4fb8g) {
        _0xa4fb8g = document["createElement"]("div");
        _0xa4fb8g["id"] = "mdzGasHud";
        _0xa4fb8g["style"]["cssText"] = "position:fixed;bottom:12px;right:12px;z-index:2147483646;background:rgba(10,14,18,0.85);border:1px solid rgba(255,255,255,0.18);border-radius:4px;padding:5px 9px;font:11px/1.5 \"Segoe UI\",monospace;color:#bcae94;pointer-events:none;user-select:none;display:none;";
        document["body"]["appendChild"](_0xa4fb8g);
    } return _0xa4fb8g; }
    function _0x2bga() { var _0x5e5b = (737868 ^ 737860) + (703656 ^ 703659); var _0xe7f1fc = _0x57359c(); _0x5e5b = 686789 ^ 686796; if (_0xe7f1fc) {
        var t = _0xbd3["lastTimerVal"];
        var _0xg4cb = (293327 ^ 293323) + (734966 ^ 734962);
        var _0xb4d = _0xbd3["status"];
        _0xg4cb = (754123 ^ 754114) + (489221 ^ 489223);
        var _0x6dee = {
            "idle": "#bcae94",
                    "active": "#5f5",
                    "waiting": "#fa5",
                    "stopped": "#f55"
        };
        let _0x1314dg;
        var _0xb6eeb = _0x6dee[_0xb4d] || "#bcae94";
        _0x1314dg = (561528 ^ 561520) + (491583 ^ 491581);
        var _0x1f2 = "<span style=\"color:" + _0xb6eeb + "\">&#9635; GAS &middot; " + _0xb4d["toUpperCase"]() + ">naps/<".split("").reverse().join("");
        var _0xd9cca = (501389 ^ 501381) + (481487 ^ 481486);
        var _0xee2 = _0xbd3["activeCycle"];
        _0xd9cca = 696601 ^ 696606;
        if (_0xee2 && t != null) {
            var _0xbga = Math["max"](274959 ^ 274959, _0xee2["despawnAtTimer"] - t);
            _0x1f2 += "<br><span style=\"color:#5cf;font-size:10px\">expires in " + _0xbga + " ticks</span>";
        }
        else if (_0xb4d === "waiting" && _0xbd3["nextSpawnAtTimer"] != null && t != null) {
            var _0x8745g = Math["max"](129122 ^ 129122, _0xbd3["nextSpawnAtTimer"] - t);
            _0x1f2 += "<br><span style=\"color:#fa5;font-size:10px\">next in " + _0x8745g + " ticks</span>";
        }
        _0xe7f1fc["innerHTML"] = _0x1f2;
    } if (_0xdc93b && _0xdc93b["tab"] === "event" && _0xdc93b["ui"] && _0xdc93b["ui"]["right"]) {
        var _0x7c581a = (201812 ^ 201813) + (917195 ^ 917194);
        var _0xf97c = _0xdc93b["ui"]["right"]["querySelector"]("]\"1\"=nwodtnuoc-sag-atad[".split("").reverse().join(""));
        _0x7c581a = (899430 ^ 899428) + (118060 ^ 118061);
        if (_0xf97c)
            _0xf97c["innerHTML"] = _0x4edf();
    } }
    function _0x2a3() { var _0x3bcg = (883540 ^ 883543) + (733557 ^ 733554); var _0x969ffc = document["getElementById"]("mdzConvoyHud"); _0x3bcg = (461243 ^ 461234) + (353426 ^ 353434); if (!_0x969ffc) {
        _0x969ffc = document["createElement"]("vid".split("").reverse().join(""));
        _0x969ffc["id"] = "duHyovnoCzdm".split("").reverse().join("");
        _0x969ffc["style"]["cssText"] = ";enon:yalpsid;enon:tceles-resu;enon:stneve-retniop;49eacb#:roloc;ecapsonom,\"IU eogeS\" 5.1/xp11:tnof;xp9 xp5:gniddap;xp4:suidar-redrob;)81.0,552,552,552(abgr dilos xp1:redrob;)58.0,81,41,01(abgr:dnuorgkcab;6463847412:xedni-z;xp21:thgir;xp65:mottob;dexif:noitisop".split("").reverse().join("");
        document["body"]["appendChild"](_0x969ffc);
    } return _0x969ffc; }
    function _0xcda06f() { var _0x1ff83g = (846878 ^ 846875) + (582291 ^ 582288); var _0xbdf = _0x2a3(); _0x1ff83g = (881973 ^ 881969) + (965855 ^ 965848); if (_0xbdf) {
        if (_0x42a["running"] && _0x06cd7a["convoyHudVisible"]) {
            _0xbdf["style"]["display"] = "";
            var _0x7162b = (480610 ^ 480613) + (617186 ^ 617191);
            var t = _0x42a["lastTimerVal"];
            _0x7162b = 881611 ^ 881603;
            var _0xcf886f = _0x42a["status"];
            var _0x3ae9e = (662317 ^ 662309) + (630278 ^ 630279);
            var _0xe6gd2b = _0xcf886f === "active" ? "5f5#".split("").reverse().join("") : _0xcf886f === "gninwapsed".split("").reverse().join("") || _0xcf886f === "waiting" ? "5af#".split("").reverse().join("") : "#bcae94";
            _0x3ae9e = (973151 ^ 973144) + (341502 ^ 341501);
            let _0x5bd27g;
            var _0xda2a8a = _0xcf886f === "gninwapsed".split("").reverse().join("") ? "WAIT(PLAYER)" : _0xcf886f["toUpperCase"]();
            _0x5bd27g = (561978 ^ 561971) + (642636 ^ 642637);
            var _0x7e_0x72g = (860914 ^ 860916) + (294246 ^ 294255);
            var _0x523e = "<span style=\"color:" + _0xe6gd2b + "\">&#128663; CONVOY &middot; " + _0xda2a8a + "</span>";
            _0x7e_0x72g = 561242 ^ 561245;
            if (_0xcf886f === "evitca".split("").reverse().join("") && _0x42a["despawnAtTimer"] !== null && t !== null) {
                var _0x32b = Math["max"](727334 ^ 727334, _0x42a["despawnAtTimer"] - t);
                _0x523e += "<br><span style=\"color:#5cf;font-size:10px\">despawns in " + _0x32b + " ticks</span>";
            }
            else if (_0xcf886f === "despawning") {
                _0x523e += "<br><span style=\"color:#fa5;font-size:10px\">player nearby — delay</span>";
            }
            else if (_0xcf886f === "waiting" && _0x42a["nextSpawnAtTimer"] !== null && t !== null) {
                var _0x65dg4c = (767141 ^ 767143) + (999563 ^ 999564);
                var _0x8ea2 = Math["max"](910770 ^ 910770, _0x42a["nextSpawnAtTimer"] - t);
                _0x65dg4c = (338257 ^ 338265) + (104569 ^ 104569);
                _0x523e += "<br><span style=\"color:#fa5;font-size:10px\">next in " + _0x8ea2 + " ticks</span>";
            }
            _0xbdf["innerHTML"] = _0x523e;
        }
        else {
            _0xbdf["style"]["display"] = "none";
        }
    } if (_0xdc93b && _0xdc93b["tab"] === "event" && _0xdc93b["ui"] && _0xdc93b["ui"]["right"]) {
        let _0x2bf;
        var _0x002e = _0xdc93b["ui"]["right"]["querySelector"]("[data-convoy-countdown=\"1\"]");
        _0x2bf = (717045 ^ 717053) + (973888 ^ 973891);
        if (_0x002e)
            _0x002e["innerHTML"] = _0xaa69ad();
    } }
    function _0x9g3f() { var _0xa0fdg = (397006 ^ 397005) + (289610 ^ 289610); var _0xc329gf = document["getElementById"]("duHhsarcileHzdm".split("").reverse().join("")); _0xa0fdg = (406024 ^ 406017) + (542346 ^ 542344); if (!_0xc329gf) {
        _0xc329gf = document["createElement"]("vid".split("").reverse().join(""));
        _0xc329gf["id"] = "duHhsarcileHzdm".split("").reverse().join("");
        _0xc329gf["style"]["cssText"] = ";enon:yalpsid;enon:tceles-resu;enon:stneve-retniop;49eacb#:roloc;ecapsonom,\"IU eogeS\" 5.1/xp11:tnof;xp9 xp5:gniddap;xp4:suidar-redrob;)81.0,552,552,552(abgr dilos xp1:redrob;)58.0,81,41,01(abgr:dnuorgkcab;5463847412:xedni-z;xp21:thgir;xp08:mottob;dexif:noitisop".split("").reverse().join("");
        document["body"]["appendChild"](_0xc329gf);
    } return _0xc329gf; }
    function _0x3e567e(_0xfbc) { var _0xb4e = _0x9g3f(); _0xfbc = "flcbll"; if (_0xb4e) {
        if (_0x77_0x317["running"] && _0xcdafb["heliHudVisible"]) {
            _0xb4e["style"]["display"] = "";
            let _0xe0c;
            var t = _0x77_0x317["lastTimerVal"];
            _0xe0c = "jjjfgk";
            let _0x4d5e;
            var _0xge5d8c = _0x77_0x317["status"];
            _0x4d5e = (971234 ^ 971239) + (929141 ^ 929148);
            var _0x36ddb = _0xge5d8c === "evitca".split("").reverse().join("") ? "#5f5" : _0xge5d8c === "gnimocni".split("").reverse().join("") ? "5af#".split("").reverse().join("") : _0xge5d8c === "gninwapsed".split("").reverse().join("") || _0xge5d8c === "waiting" ? "5af#".split("").reverse().join("") : "49eacb#".split("").reverse().join("");
            var _0x0c4f6a = _0xge5d8c === "gninwapsed".split("").reverse().join("") ? "WAIT(PLAYER)" : _0xge5d8c === "gnimocni".split("").reverse().join("") ? "GNIMOCNI".split("").reverse().join("") : _0xge5d8c["toUpperCase"]();
            var _0xc5e4fb = "<span style=\"color:" + _0x36ddb + "\">&#128641; HELI &middot; " + _0x0c4f6a + "</span>";
            if (_0xge5d8c === "incoming") {
                _0xc5e4fb += ">naps/<...noos gnidnal hsarc>\"xp01:ezis-tnof;5af#:roloc\"=elyts naps<>rb<".split("").reverse().join("");
            }
            else if (_0xge5d8c === "active" && _0x77_0x317["despawnAtTimer"] !== null && t !== null) {
                let _0x8482c;
                var _0x232 = Math["max"](594246 ^ 594246, _0x77_0x317["despawnAtTimer"] - t);
                _0x8482c = 832870 ^ 832867;
                _0xc5e4fb += "<br><span style=\"color:#5cf;font-size:10px\">despawns in " + _0x232 + " ticks</span>";
            }
            else if (_0xge5d8c === "despawning") {
                _0xc5e4fb += ">naps/<yaled — ybraen reyalp>\"xp01:ezis-tnof;5af#:roloc\"=elyts naps<>rb<".split("").reverse().join("");
            }
            else if (_0xge5d8c === "gnitiaw".split("").reverse().join("") && _0x77_0x317["nextSpawnAtTimer"] !== null && t !== null) {
                var _0x1g5e = (897510 ^ 897510) + (270917 ^ 270918);
                var _0xa28 = Math["max"](472577 ^ 472577, _0x77_0x317["nextSpawnAtTimer"] - t);
                _0x1g5e = (114758 ^ 114754) + (727239 ^ 727235);
                _0xc5e4fb += "<br><span style=\"color:#fa5;font-size:10px\">next in " + _0xa28 + " ticks</span>";
            }
            _0xb4e["innerHTML"] = _0xc5e4fb;
        }
        else {
            _0xb4e["style"]["display"] = "none";
        }
    } if (_0xdc93b && _0xdc93b["tab"] === "tneve".split("").reverse().join("") && _0xdc93b["ui"] && _0xdc93b["ui"]["right"]) {
        let _0x6817f;
        var _0xede78c = _0xdc93b["ui"]["right"]["querySelector"]("]\"1\"=nwodtnuoc-ileh-atad[".split("").reverse().join(""));
        _0x6817f = "ifokkl";
        if (_0xede78c)
            _0xede78c["innerHTML"] = _0x5866da();
    } }
    var _0x0444f = (874962 ^ 874963) + (427119 ^ 427115);
    var K = null;
    _0x0444f = (298196 ^ 298194) + (278710 ^ 278719);
    function _0xd7c2fc(c2) { if (K)
        return; var _0x45548d = "S" in c2; K = {
        "types": _0x45548d ? "S" : "types_by_index",
                "layouts": _0x45548d ? "Fs" : "stuoyal".split("").reverse().join(""),
                "insts": _0x45548d ? "q" : "instances",
                "layout": _0x45548d ? "wa" : "tuoyal_gninnur".split("").reverse().join(""),
                "redraw": _0x45548d ? "X" : "warder".split("").reverse().join(""),
                "layer": _0x45548d ? "C" : "reyal".split("").reverse().join(""),
                "bbox": _0x45548d ? "ak".split("").reverse().join("") : "bbox",
                "bboxFn": _0x45548d ? "P" : "set_bbox_changed",
                "createFn": _0x45548d ? "tU".split("").reverse().join("") : "createInstance",
                "drawGL": _0x45548d ? "nb" : "drawGL",
                "instVars": _0x45548d ? "cc" : "srav_ecnatsni".split("").reverse().join(""),
                "loadTex": _0x45548d ? "fd" : "erutxeTdaol".split("").reverse().join(""),
                "setTex": _0x45548d ? "wc" : "setTexture",
                "setOpacity": _0x45548d ? "Oe" : "setOpacity",
                "quad": _0x45548d ? "dk" : "dauq".split("").reverse().join(""),
                "gl": _0x45548d ? "T" : "gl",
                "endBatch": _0x45548d ? "dl".split("").reverse().join("") : "hctaBdne".split("").reverse().join(""),
                "resetMV": _0x45548d ? "ek".split("").reverse().join("") : "weiVledoMteser".split("").reverse().join(""),
                "updateMV": _0x45548d ? "Wd" : "updateModelView",
                "setSize": _0x45548d ? "qg" : "setSize",
                "setRTgt": _0x45548d ? "el".split("").reverse().join("") : "tegraTredneRtes".split("").reverse().join(""),
                "glwrap": _0x45548d ? "H" : "glwrap",
                "present": _0x45548d ? "JG" : "tneserp".split("").reverse().join(""),
                "useHighRes": _0x45548d ? "aY".split("").reverse().join("") : "seRhgiHesu".split("").reverse().join(""),
                "layerTexId": _0x45548d ? "Th" : "layer_tex_id",
                "layoutQf": _0x45548d ? "fQ".split("").reverse().join("") : "neercsffOredner".split("").reverse().join(""),
                "canvasToLayer": _0x45548d ? "Wa" : "reyaLoTsavnac".split("").reverse().join("")
    }; }
    function _0x6ec34e(_0x258ee) { var _0x96a2 = window["cr_getC2Runtime"] ? window["cr_getC2Runtime"]() : null; _0x258ee = (595729 ^ 595737) + (566427 ^ 566427); if (_0x96a2 && !K)
        _0xd7c2fc(_0x96a2); return _0x96a2; }
    function _0xg84a(c2, name) { if (!c2 || !c2["ew"])
        return undefined; var _0xfa2 = (677951 ^ 677947) + (772650 ^ 772653); var v = c2["ew"](name, null); _0xfa2 = (380295 ^ 380302) + (688946 ^ 688950); return v ? v["data"] : undefined; }
    function _0xg2_0x99g(c2) { if (!c2)
        return false; return _0xg84a(c2,
            "Inventory_opened") === (625879 ^ 625878) || _0xg84a(c2,
            "Pad_on") === (458079 ^ 458078) || _0xg84a(c2,
            "no_unemkrep".split("").reverse().join("")) === (870412 ^ 870413) || _0xg84a(c2,
            "edom_gnidliuB".split("").reverse().join("")) === (987578 ^ 987579) || _0xg84a(c2,
            "no_unempleh".split("").reverse().join("")) === (922845 ^ 922844) || _0xg84a(c2,
            "notebook_mode") === (882634 ^ 882635) || _0xg84a(c2,
            "Action_menu_on") === (855742 ^ 855743); }
    var _0xd49e = {};
    var _0x57g = {};
    var _0xad7gb = null;
    var _0xde4 = {};
    var _0xd43fed = {};
    _0xdc5ab = (131071 ^ 131064) + (530008 ^ 530013);
    function _0xdg0b(src) { if (!_0xd49e[src]) {
        var _0x77c96a = (973001 ^ 973003) + (575337 ^ 575339);
        var _0x233 = new Image();
        _0x77c96a = 815635 ^ 815632;
        _0x233["src"] = src;
        _0xd49e[src] = _0x233;
    } return _0xd49e[src]; }
    function _0x45_0x6f4() { for (var _0x234 in _0x87g) {
        _0xdg0b(_0x87g[_0x234]["closed"]);
        _0xdg0b(_0x87g[_0x234]["closedHL"]);
        _0xdg0b(_0x87g[_0x234]["open"]);
        _0xdg0b(_0x87g[_0x234]["openHL"]);
    } _0xdg0b("gnp.nottub/segami".split("").reverse().join("")); _0xdg0b("gnp.kcolnu_tsehc_nottub/segami".split("").reverse().join("")); _0xdg0b("gnp.llec/segami".split("").reverse().join("")); _0xdg0b("images/x_mark.png"); _0xdg0b("gnp.0teehs_tsehc_tcepsni/segami".split("").reverse().join("")); }
    _0x45_0x6f4();
    function _0x1c05af(url, type) { return new Promise(function (resolve, reject) { var _0xac9fd = (897690 ^ 897689) + (237768 ^ 237771); var _0xd04d2c = new XMLHttpRequest(); _0xac9fd = (887172 ^ 887180) + (629109 ^ 629116); if (type === "json")
        _0xd04d2c["overrideMimeType"]("application/json");
    else
        _0xd04d2c["overrideMimeType"]("text/plain"); _0xd04d2c["open"]("GET", url, !![]); _0xd04d2c["onreadystatechange"] = function () { if (_0xd04d2c["readyState"] !== (673857 ^ 673861))
        return; if (_0xd04d2c["status"] === (240209 ^ 240281) || _0xd04d2c["status"] === (964484 ^ 964484)) {
        if (type === "json") {
            try {
                resolve(JSON["parse"](_0xd04d2c["responseText"]));
            }
            catch (e) {
                reject(e);
            }
        }
        else {
            resolve(_0xd04d2c["responseText"]);
        }
    }
    else {
        reject(new Error("HTTP " + _0xd04d2c["status"]));
    } }; _0xd04d2c["onerror"] = function () { reject(new Error(" :rorre krowteN".split("").reverse().join("") + url)); }; _0xd04d2c["send"](null); }); }
    _0xad52e(function (savedConfig) { if (savedConfig && savedConfig["version"]) {
        _0xb8bf0a(savedConfig);
        console["log"]("chest_gl: loaded config from IndexedDB");
        return;
    } _0x1c05af("./chest_config.json",
            "json")["then"](function (config) { _0xb8bf0a(config); })["catch"](function (error) { console["warn"]("gifnoc tluafed deddebme gnisu :lg_tsehc".split("").reverse().join(""), error); }); });
    function _0xgc69c(data) {
        var projectTypes = (data["project"] && data["project"][3]) || [];
        var atlas = Object.create(null);
        for (var i = 0; i < projectTypes.length; i++) {
            var entry = projectTypes[i];
            if (!Array.isArray(entry) || typeof entry[0] !== "string")
                continue;
            var typeName = entry[0];
            var animations = entry[7];
            var frames = animations && animations[0] && animations[0][7];
            if (!frames || !frames.length)
                continue;
            var frameList = [];
            for (var j = 0; j < frames.length; j++) {
                var f = frames[j];
                if (!f || !f[0])
                    continue;
                frameList.push({
                    typeName: typeName,
                    src: f[0],
                    x: f[2] || 0,
                    y: f[3] || 0,
                    w: f[4] || 22,
                    h: f[5] || 22,
                    localIndex: j
                });
                try {
                    _0xdg0b(f[0]);
                }
                catch (e) { }
            }
            if (frameList.length)
                atlas[typeName] = frameList;
        }
        return atlas;
    }
    // GUI ICON READER: itemId -> GUI atlas/frame/crop from data.js
    var _0xguiIconIndex = Object.create(null);
    function _0xrebuildGuiIconIndex() {
        _0xguiIconIndex = Object.create(null);
        var t6 = (_0xad7gb && _0xad7gb["t6"]) || [];
        for (var i = 0; i < t6.length; i++) {
            if (t6[i]) _0xguiIconIndex[String(i)] = { itemId:i, source:"t6", typeName:t6[i].typeName, frame:t6[i].localIndex, src:t6[i].src, x:t6[i].x||0, y:t6[i].y||0, w:t6[i].w||0, h:t6[i].h||0 };
        }
        if (_0xequipMap && _0xad7gb) Object.keys(_0xequipMap).forEach(function(id) {
            var e=_0xequipMap[id], frames=_0xad7gb[e.typeName]||[], f=frames[e.frame];
            if (f) _0xguiIconIndex[String(id)]={ itemId:Number(id), source:"equipMap", typeName:e.typeName, frame:e.frame, src:f.src, x:f.x||0, y:f.y||0, w:f.w||0, h:f.h||0 };
        });
        try { window.chestGLGuiIcons=_0xguiIconIndex; window.getChestGuiIcon=function(id){return _0xguiIconIndex[String(id)]||null;}; window.printChestGuiIcon=function(id){ var v=window.getChestGuiIcon(id); console.log(v||("[GUI ICON] itemId="+id+" tidak ditemukan")); return v; }; } catch(e) {}
        return _0xguiIconIndex;
    }

    function _0xslugify(str) {
        return String(str).toLowerCase().replace(/[^a-z0-9]+/g,
            "_").replace(/^_+|_+$/g,
            "");
    }
    // Manual overrides for items whose in-game name doesn't resemble its
    // image filename at all (weapon codenames, abbreviations, etc.) - found
    // by hand-checking data.js since no automated matching could find these.
    // Keyed by item id (from l_eng_items.xml). Extend this table as more
    // mismatches are discovered.
    var _0xiconManualOverrides = {
        78: "crosshair_pso", // PSO-1 Scope
        30: "notacola", // Coca-Cola (confirmed by user, data.js baru)
        // 9 item berikut ditemukan lewat debug overlay langsung -- nama di
        // itemIndex runtime kamu ternyata Bahasa Indonesia ("Botol Air" dkk),
        // bukan Inggris seperti di l_eng_items.xml yang saya audit. Sistem
        // pencocokan nama Inggris otomatis gagal total untuk ini, makanya
        // di-hardcode manual pakai ID (bukan tergantung bahasa nama).
        706: "headlamp", // Headlamp / Senter Kepala
        24: "matches", // Matches / Korek Api
        54: "waterbottle", // Water Bottle / Botol Air
        33: "orange", // Orange / Jeruk
        32: "bell_pepper", // Bell Pepper / Paprika
        122: "epoxy", // Epoxy Glue / Lem Epoksi
        125: "lighter", // Lighter / Korek Gas
        71: "raw_rabbit_steak", // Raw Rabbit Meat / Daging Kelinci Mentah
        718: "egg", // Egg / Telur
        62: "nukacola", // Nuka Cola (confirmed by user, data.js baru)
        10: "kvas", // Kvass (confirmed by user, data.js baru)
        120: "cigarets", // Soviet Cigarettes
        135: "gp5_helmet", // GP-5 Gas Mask
        161: "aks74u_rifle", // AKs-74u
        169: "mp5_smg", // MP5K
        171: "sawed_izh", // Sawn-Off IZh-43
        183: "bizon_smg", // PP-19 Bizon
        11: "ammo_5x56", // 5.56x45 Ammo
        12: "ammo_45acp", // .45 ACP Ammo
        13: "ammo_7x62", // 7.62x54R Ammo
        14: "ammo_7x62x39", // 7.62x39 Ammo
        15: "ammo_5x45", // 5.45x39 Ammo
        17: "ammo_12cal", // 12 Cal Ammo
        58: "ammo_22lr", // .22 LR Ammo
        69: "ammo_9mm", // 9x19 P Ammo
        758: "ammo_127", // 12.7x108 Ammo
        59: "toolbox", // Car Tool Kit
        63: "edrink", // Energy Drink
        60: "raw_steak", // Raw Meat
        61: "cooked_steak", // Roasted Meat
        72: "cooked_rabbit_steak", // Roasted Rabbit
        780: "raw_steak", // Raw Wolf Meat
        781: "cooked_steak", // Roasted Wolf Meat
        782: "raw_steak", // Raw Bear Meat
        783: "cooked_steak", // Roasted Bear Meat
        22: "batteries", // 9V Battery
        31: "squash", // Zucchini
        49: "papers", // Newspapers
        80: "silencer_east", // 5.45 Suppressor
        110: "sharper_stone", // Whetstone
        116: "survivor_book", // Scout Handbook
        214: "fadianji", // Generator (发电机)
        143: "mutanpian", // Charcoal Tablets (木炭片)
        215: "tiepi_item", // Metal Sheet (铁皮)
        139: "t1290:1", // Sneakers -- DIPERBAIKI: user konfirmasi frame 1 & 3
        // tadinya tertukar. Urutan benar: 0=slot kosong, 1=Sneakers,
        // 2=Woodland Boots, 3=Assault Boots, 4=Hazmat Boots
        53: "fueltank", // Gasoline Can
        213: "dianju", // Chainsaw (电锯)
        89: "rail_grip", // Magpul (medium confidence)
        202: "axe_red", // Hatchet (medium confidence)
        710: "adrenaline_syringe", // Stimulants (medium confidence)
        // Radiation-protection suits (413/414/415) & Work Gloves (757) DULU
        // di-override via type-code (t1188/t1131/t1191/t1291) berdasarkan
        // data.js LAMA -- type-code itu SUDAH TIDAK ADA di data.js APK ini
        // (dicek langsung, 0 hasil). Override dihapus (bukan cuma dibiarkan)
        // supaya jelas ini memang belum dipetakan ulang -- kode akan
        // otomatis fallback ke pencocokan nama biasa (aman, hasilnya
        // "tanpa icon" untuk ke-4 item ini sampai ada yang konfirmasi
        // nama file icon yang benar di data.js versi ini).
        118: "duct_tape", // Adhesive Plaster (confirmed by user)
        760: "glwater", // Water Filter (confirmed by user)
        141: "t1290:3", // Assault Boots -- DIPERBAIKI: frame 1 & 3 tertukar
        140: "t1290:2", // Woodland Boots -- ditambahkan kembali (sempat
        // hilang saat override lama "ssxs" dicabut)
        700: "t1290:4", // Hazmat Boots -- BARU, dikonfirmasi dari gambar yang sama (frame ke-4)
        // Sarung tangan (gui_inventory-sheet3.png / t1291) -- dikonfirmasi
        // user langsung dari gambar. Urutan: 0=slot kosong, 1=Hazmat Gloves,
        // 2=Combat Gloves, 3=Padded Gloves
        701: "t1291:1", // Hazmat Gloves
        137: "t1291:2", // Combat Gloves
        757: "t1291:3", // Padded Gloves
        117: "kvas", // Canvas (confirmed by user)
        115: "xiaoyinqi", // Binoculars (confirmed by user)
        721: "hacksaw", // Mini Sights (confirmed by user)
        785: "qiuyin" // Romero 77 Hatchet (confirmed by user)
    };
    var _0xiconNameIndex = null; // built once from _0xad7gb: list of {slug, nospace, words, entry}
    var _0xiconWordFreq = null; // built bareng index: {word: berapa gambar berbeda mengandung kata ini}
    var _0xiconResolveCache = {}; // itemId -> resolved frame entry (or null), memoized

    // Kata generik yang MUNCUL DI BANYAK ITEM TAK BERHUBUNGAN -- overlap
    // yang CUMA berdasar kata-kata ini (tanpa kata lain yang lebih spesifik)
    // TIDAK dianggap match yang valid. Ditemukan dari audit nyata: tanpa
    // filter ini, "Red Key" nyasar ke ikon "hoodie_red", "Human Meat" nyasar
    // ke "chicken_meat", dst -- match yang salah tapi lolos skor tinggi
    // cuma karena warna/kata sifat generik kebetulan sama.
    var _0xICON_STOPWORDS = {
        'red': 1, 'blue': 1, 'black': 1, 'white': 1, 'green': 1, 'yellow': 1,
        'brown': 1, 'gray': 1, 'grey': 1, 'water': 1, 'meat': 1, 'small': 1,
        'large': 1, 'big': 1, 'old': 1, 'new': 1, 'item': 1, 'bag': 1,
        'box': 1, 'case': 1, 'kit': 1, 'pack': 1, 'set': 1, 'bullet': 1,
        'grip': 1, 'part': 1, 'piece': 1, 'stock': 1, 'raw': 1, 'cooked': 1,
        'wild': 1, 'variant': 1, 'good': 1, 'improvised': 1
    };
    // Kalau match cuma didukung SATU kata (bukan kombinasi 2+ kata), kata
    // itu wajib relatif JARANG dipakai di seluruh nama gambar -- kalau kata
    // itu ternyata umum (muncul di banyak gambar berbeda), kemungkinan besar
    // itu kebetulan, bukan kecocokan asli. Contoh nyata: "Sprite" (minuman)
    // sempat nyasar ke "fish_sprite" cuma karena kata "sprite" kebetulan
    // sama, padahal dua hal yang sama sekali tidak berhubungan.
    var _0xICON_MAX_FREQ_FOR_SINGLE_WORD = 3;

    function _0xbuildIconNameIndex() {
        var list = [];
        var freq = {};
        for (var typeName in _0xad7gb) {
            var frames = _0xad7gb[typeName];
            for (var j = 0; j < frames.length; j++) {
                var f = frames[j];
                var m = /images\/(.+?)-sheet\d+\.png$/.exec(f.src || "");
                if (!m)
                    continue;
                var slug = m[1].toLowerCase();
                var words = slug.split(/[^a-z0-9]+/).filter(Boolean);
                list.push({
                    slug: slug,
                    nospace: slug.replace(/[^a-z0-9]/g, ""),
                    words: words,
                    entry: f
                });
                // Hitung setiap kata SEKALI per gambar (pakai Set implisit
                // lewat objek penanda) supaya frekuensi = jumlah GAMBAR
                // BERBEDA yang mengandung kata itu, bukan total kemunculan.
                var seen = {};
                for (var w = 0; w < words.length; w++) {
                    if (seen[words[w]]) continue;
                    seen[words[w]] = true;
                    freq[words[w]] = (freq[words[w]] || 0) + 1;
                }
            }
        }
        _0xiconWordFreq = freq;
        return list;
    }
    // ================================================================
    // TABEL NAMA INGGRIS STATIS (dari l_eng_items.xml) -- ditanam langsung
    // ke script, TIDAK tergantung bahasa yang dipakai game/device kamu.
    //
    // KENAPA INI PERLU: ditemukan lewat debug live bahwa _0xdc93b.itemIndex
    // (yang harusnya dari l_eng_items.xml) ternyata berisi NAMA BAHASA
    // INDONESIA di device kamu ("Botol Air", "Jeruk", dst) -- bukan
    // Inggris. Sistem pencocokan nama<->gambar HANYA bisa jalan kalau
    // dibandingkan dengan nama Inggris (karena nama file gambar di
    // data.js semuanya Inggris) -- jadi dipakai tabel statis ini sebagai
    // sumber utama, BUKAN _0xdc93b.itemIndex[id].name lagi.
    // ================================================================
    var _0xEnglishNames = {"1":"Canned Beans","2":"Canned Tuna","3":"Tactical Bacon","4":"Rice","5":"Tomato","6":"Apple","7":"Banana","8":"Pepsi","9":"Sprite","10":"Kvass","11":"5.56x45 Rounds","12":".45 ACP Rounds","13":"7.62x54 Rounds","14":"7.62x39 Rounds","15":"5.45x39 Rounds","16":".357 Rounds","17":"12 Gauge Shells","18":"Bandage","19":"Blood Bag","20":"Flare","21":"F1 Fragmentation Grenade","22":"Battery","23":"Campfire Kit","24":"Matches","25":"Whiskey","26":"Rags","27":"Cranberry","28":"Saline Bag","29":"Vitamins","30":"Coca-Cola","31":"Zucchini","32":"Bell Pepper","33":"Orange","34":"Heating Pack","35":"Sewing Kit","36":"Cleaning Kit","37":"Ash Wood Stick","38":"Wooden Stick","39":"Tape","40":"Sack","41":"Rope","42":"Hunting Knife","43":"Combat Knife","44":"Cleaver","45":"Morphine","46":"Tetracycline","47":"Tomato Seed Pack","48":"Bell Pepper Seed Pack","49":"Newspaper","50":"Wood","51":"Handmade Arrow","52":"Compound Arrow","53":"Oil Drum","54":"Water Bottle","55":"Military Canteen","56":"Landmine","57":"Bear Trap","58":".22LR Rounds","59":"Car Repair Kit","60":"Raw Meat Steak","61":"Cooked Meat Steak","62":"Nuka Cola","63":"Energy Drink","64":"Function - Trade","65":"Function - Storage","66":"Function - Build Mode","67":"Function - XP Shop","68":"Zucchini Seed Pack","69":"9mm Rounds","70":"Barbed Wire","71":"Raw Rabbit Meat","72":"Cooked Rabbit Meat","73":"Cloudberry","74":"Raspberry","75":"Radio","76":"RDS Red Dot Sight","77":"PU Scope","78":"PSO-1 Scope","79":"ACOG Scope","80":"5.45 Suppressor","81":"5.56 Suppressor","82":"Hacksaw","83":"Spare Ammo Pouch","85":"MRE Ration","86":"Reel Fishing Rod","87":"Simple Fishing Rod","88":"Protective Case","89":"Quick Mag","90":"Choke","91":"Herring","92":"Salmon","93":"Perch","94":"Bass","95":"Small Grilled Fish","96":"Large Grilled Fish","97":"Mushroom","98":"Long Range Scope","99":"Claymore Mine","100":"9x18 Rounds","101":"9x39 Rounds","102":"Molotov Cocktail","103":"Flare Gun","104":"Humvee Ammo Box","105":"40mm Grenade","106":"VOG-25 Grenade","107":"M203 Grenade Launcher","108":"GP-25 Grenade Launcher","109":"Empty Blood Bag","110":"Sharpening Stone","111":"AK Grip","112":"Rail Grip","113":"Map Marker","114":"Elderberry","115":"Binoculars","116":"Scout Handbook","117":"Canvas","118":"Medical Tape","119":"Smoke Grenade","120":"Cigarettes","121":"Beer","122":"Epoxy Glue","123":"Fertilizer","124":"Laser Sight","125":"Lighter","126":"Key Card","127":"Improvised Suppressor","128":"PVS-4 Night Vision","129":"1PN51 Night Vision","130":"C-Mag Drum 5.56","131":"7.62x39 Drum Mag","132":"Frying Pan","133":"Gas Mask","134":"Balaclava","135":"GP5 Gas Mask","136":"Thug Mask","137":"Combat Gloves","138":".308 Rounds","139":"Sneakers","140":"Woodland Boots","141":"Assault Boots","142":"Gun Sling","143":"Charcoal","144":"Blowtorch","145":"Camouflage Suit","146":"Underbarrel Flashlight","147":"Laser AK Grip","148":"Laser Rail Grip","700":"Hazmat Boots","701":"Hazmat Gloves","702":"Class A Hazmat Suit","703":"Class C Hazmat Suit","704":"12 Gauge Drum Mag","705":"Paint Bucket","706":"Headlamp","707":"Night Vision Device","708":"AI-2 First Aid Kit","709":"Dog Cage","710":"Epinephrine","711":"Class A Military Hazmat Suit","712":"Advanced Map","713":"Class B Hazmat Suit","714":"Deer Hide","715":"C-Mag Drum 5.45","716":"Spiked Collar","717":"Saddle Bag","718":"Egg","719":"Raw Chicken","720":"Cooked Chicken","721":"Mini Scope","722":"Small Suppressor","723":"Pistol Flashlight","724":"Fried Egg","725":"Stir-Fried Pepper with Meat","726":"Tomato and Egg Stir-Fry","727":"Searchlight","728":"Earthworm","729":"VOG-25 Improvised Grenade","730":"FNX","731":"Colt 1911","732":"Magnum","733":"MK II","734":"Glock","735":"Sawed-off IZH-43","736":"Sawed-off Mosin Nagant","737":"Silver Eagle Colt","738":"Sawed-off Rossi M92","739":"PM","740":"PB","741":"Desert Eagle","742":"M79","743":"Sawed-off Blaze","744":"Longhorn","745":"MAC-10","746":"Mini-UZI","747":"C4 Plastic Explosive","748":"Christmas Hat","749":"Christmas Mystery Box","750":"Human Meat","751":"Cooked Human Meat","752":"Messenger Bag","753":"Military Satchel","754":"Medical Satchel","755":"Gun Case","756":"Pistol Holster","757":"Padded Gloves","758":"12.7x108 Rounds","759":"Filter Bottle - Good Filter","760":"Filter Bottle - No Filter","761":"Ammo Crate","762":"Ammo Crate","763":"Ammo Crate","764":"Ammo Crate","765":"Ammo Crate","766":"Ammo Crate","767":"Ammo Crate","768":"Ammo Crate","769":"Ammo Crate","770":"Ammo Crate","771":"Ammo Crate","772":"Ammo Crate","773":"Ammo Crate","774":"Ammo Crate","775":"Ammo Crate","776":"Ammo Crate","777":"Pear","778":"Sack with Chicken","779":"Sack with Pig","780":"Raw Wolf Meat","781":"Cooked Wolf Meat","782":"Raw Bear Steak","783":"Cooked Bear Steak","784":"Bear Hide","785":"Hatchet Triple-Barrel Shotgun","786":"Pumpkin Head","787":"Witch Hat","788":"Christmas Lights","151":"FNX","152":"Colt 1911","153":"Magnum","154":"IZH-43","155":"Remington","156":"Mosin Nagant","157":"SKS","158":"M4","159":"AKM","160":"AK-74","161":"AKS-74U","162":"L85","163":"Bow","164":"Hunting Crossbow","165":"MK II","166":"Sporter22","167":"Rossi M92","168":"SVD","169":"MP5K","170":"Glock","171":"Sawed-off IZH-43","172":"Sawed-off Mosin Nagant","173":"UMP-45","174":"RPK","175":"FN-FAL","176":"Silver Eagle Colt","177":"AUG","178":"Saiga-12K","179":"MAC-10","180":"Sawed-off Rossi M92","181":"PM","182":"PB","183":"Bizon","184":"Groza","185":"VSS","186":"SV-98","187":"Madsen","188":"AN-94","189":"Desert Eagle","190":"Suppressed Remington","191":"M16A2","192":"Vector","193":"M4","194":"AKM","195":"M70","196":"Saiga-12K","197":"RPK","198":"M16A2","199":"AUG","230":"MGL Grenade Launcher","231":"Blaze","232":"FAMAS","233":"Mini-14","234":"M79","235":"Sawed-off Blaze","236":"Longhorn","237":"AK-74","238":"AKS-74U","239":"Mini-UZI","240":"AS-VAL","241":"M249","242":"OSV-96","243":"Type 40 Flamethrower","244":"Hatchet Triple-Barrel Shotgun","245":"M134","246":"PKM","200":"Wrench","201":"Shovel","202":"Hatchet","203":"Baseball Bat","204":"Fire Axe","205":"Crowbar","206":"Pickaxe","207":"Pitchfork","208":"Sledgehammer","209":"Sword","210":"Frying Pan","211":"Katana","212":"Spiked Baseball Bat","213":"Chainsaw","214":"Generator","215":"Metal Sheet","216":"Torch","250":"Gas Mask","251":"Military Helmet","252":"Motorcycle Helmet","253":"Motorcycle Helmet","254":"Warm Hat","255":"Beret","256":"Baseball Cap","257":"Balaclava","258":"Soviet Fur Hat","259":"Hard Hat","260":"Headlamp","261":"Cowboy Hat","262":"Welding Mask","263":"Gorka Helmet","264":"Police Hat","265":"NVG Night Vision","266":"Bandana","267":"Medieval Helmet","268":"Pilot Helmet","269":"Altyn Helmet","270":"Altyn Helmet","271":"GP5 Gas Mask","272":"Thug Mask","273":"Assault Helmet","274":"Assault Helmet","275":"Assault Helmet","276":"Assault Helmet","277":"Altyn Helmet - NV Modified","300":"Jeans","301":"Cargo Pants","302":"Sweatpants","303":"Gorka Combat Pants","304":"Orel Pants","305":"Medical Pants","306":"Hunting Pants","307":"Firefighter Pants","350":"T-Shirt","351":"Shirt","352":"Shirt","353":"Raincoat","354":"Jacket","355":"Gorka Combat Uniform","356":"Hoodie","357":"Hoodie","358":"Cloak","359":"Medical Jacket","360":"Orel Jacket","361":"Sports Jacket","362":"Dress","363":"Down Jacket","364":"Hunting Jacket","365":"Sweater","366":"Awesome Hoodie","367":"Firefighter Jacket","368":"Medieval Chainmail","400":"Bulletproof Vest","401":"War Correspondent Vest","402":"Assault Vest","403":"High Capacity Vest","404":"Kevlar Vest","405":"Soviet Vest","406":"Apron","407":"Camouflage Suit","408":"M Heavy Armor","409":"Class A Hazmat Suit","410":"Military Kevlar Suit","411":"Military M Heavy Armor Suit","412":"Military Camo Protective Suit","413":"Class C Hazmat Suit","414":"Class B Hazmat Suit","415":"Class A Military Hazmat Suit","450":"Travel Backpack","451":"Hunting Backpack","452":"Hiking Backpack","453":"School Bag","454":"Simple Backpack","455":"Reinforced Simple Backpack","456":"Civilian Tent","457":"Military Backpack","458":"Messenger Bag","459":"Military Satchel","460":"Medical Satchel","461":"Storage Crate","462":"Fuel Backpack","463":"Chips \"Zagorky\"","464":"Canned Sardines","465":"\"Monster\" ZERO 0.5","466":"\"PulseUp\" 0.5","467":"\"Bed-rul\" 0.45","468":"Pear (Wild)","469":"Psychostimulants","470":"Energy Bar","471":"Vodka \"Beluga\"","472":"Chocolate \"Merchant's Dream\"","473":"Porcini Mushroom","474":"Fly Agaric","475":"Champignon","476":"Parasol Mushroom","477":"Plantain","478":"Animal Fat","479":"Healing Ointment","480":"Powdered Milk","481":"Wolf Meat (Old Stock)","482":"Cooked Wolf Meat (Old Stock)","483":"7.62 Suppressor (Improvised)","484":"Fronta","485":"Jagernaut","486":"Dirty Water","487":"Crackers","488":"Cornflakes","489":"Limon \"ICE\"","490":"Red Key","491":"Blue Key","492":"Black Key","493":"Mug","494":"Cooking Pot","495":"Pot of Water","496":"Pot of Boiling Water","497":"Mug","498":"Mug (Variant)","499":"Brewed Tea","500":"Boiling Water Ing. 1","501":"Boiling Water Ing. 2"};

    // Resolve an item's icon using its display name (from the already-loaded
    // l_eng_items.xml index, _0xdc93b.itemIndex) matched against image filenames
    // in data.js. This is far more reliable than guessing from compiled event
    // bytecode, since it's based on real item identity rather than coincidental
    // numeric patterns.
    function _0xresolveByName(itemId) {
        // Pakai nama Inggris statis dulu (selalu tersedia, tidak tergantung
        // loading/bahasa) -- fallback ke _0xdc93b.itemIndex kalau item ID
        // itu kebetulan tidak ada di tabel statis (misal item baru yang
        // belum sempat di-audit).
        var englishName = _0xEnglishNames[itemId];
        var itemName = englishName;
        if (!itemName) {
            if (!_0xdc93b || !_0xdc93b.loaded || !_0xdc93b.itemIndex)
                return null;
            var item = _0xdc93b.itemIndex[itemId];
            if (!item || !item.name)
                return null;
            itemName = item.name; // fallback -- mungkin bukan Inggris, hasil bisa kurang akurat
        }
        if (!_0xiconNameIndex)
            _0xiconNameIndex = _0xbuildIconNameIndex();
        if (_0xiconManualOverrides.hasOwnProperty(itemId)) {
            var overrideVal = _0xiconManualOverrides[itemId];
            // Value bisa:
            //   "t1188"      -> tipe objek, ambil frame ke-0 (default lama)
            //   "t1290:2"    -> tipe objek + INDEX FRAME SPESIFIK (buat sheet
            //                   yang isinya beberapa icon berbeda dalam 1
            //                   gambar, misal gui_inventory-sheet2.png yang
            //                   punya 5 varian sepatu dalam 1 file)
            //   "slug_biasa" -> nama file gambar biasa (jalur lama)
            var typeFrameMatch = /^(t\d+):(\d+)$/.exec(overrideVal);
            if (typeFrameMatch) {
                var typeFramesArr = _0xad7gb[typeFrameMatch[1]];
                var frameIdx = parseInt(typeFrameMatch[2], 10);
                if (typeFramesArr && typeFramesArr[frameIdx])
                    return typeFramesArr[frameIdx];
            }
            else if (/^t\d+$/.test(overrideVal)) {
                var typeFrames = _0xad7gb[overrideVal];
                if (typeFrames && typeFrames[0])
                    return typeFrames[0];
            }
            else {
                for (var oi = 0; oi < _0xiconNameIndex.length; oi++) {
                    if (_0xiconNameIndex[oi].slug === overrideVal)
                        return _0xiconNameIndex[oi].entry;
                }
            }
        }
        var slug = _0xslugify(itemName);
        if (!slug)
            return null;
        var nospace = slug.replace(/[^a-z0-9]/g,
            "");
        var words = slug.split("_").filter(Boolean);
        // 1) exact filename-slug match
        for (var i = 0; i < _0xiconNameIndex.length; i++) {
            if (_0xiconNameIndex[i].slug === slug)
                return _0xiconNameIndex[i].entry;
        }
        // 2) match ignoring separators (handles "water_bottle" vs "waterbottle")
        for (var i = 0; i < _0xiconNameIndex.length; i++) {
            if (_0xiconNameIndex[i].nospace === nospace)
                return _0xiconNameIndex[i].entry;
        }
        // 3) fuzzy word-overlap match, DIPERKETAT dengan 2 lapis pengaman:
        //    a) overlap yang CUMA didukung kata generik (stopword) ditolak
        //    b) overlap yang cuma 1 kata bermakna WAJIB kata itu relatif
        //       jarang dipakai di seluruh nama gambar (bukan kebetulan)
        var best = null, bestScore = 0, bestInterWords = [];
        for (var i = 0; i < _0xiconNameIndex.length; i++) {
            var cand = _0xiconNameIndex[i];
            if (!cand.words.length)
                continue;
            var interWords = [];
            for (var w = 0; w < words.length; w++) {
                if (cand.words.indexOf(words[w]) !== -1)
                    interWords.push(words[w]);
            }
            if (!interWords.length)
                continue;
            var meaningfulWords = interWords.filter(function (w) { return !_0xICON_STOPWORDS[w]; });
            if (!meaningfulWords.length)
                continue; // overlap cuma kata generik -- tolak, bukan bukti valid
            var score = interWords.length / Math.max(words.length, cand.words.length);
            if (score > bestScore) {
                bestScore = score;
                best = cand;
                bestInterWords = meaningfulWords;
            }
        }
        if (best && bestScore >= 0.5) {
            if (bestInterWords.length === 1) {
                var freq = (_0xiconWordFreq && _0xiconWordFreq[bestInterWords[0]]) || 0;
                if (freq > _0xICON_MAX_FREQ_FOR_SINGLE_WORD) {
                    // Kata satu-satunya yang cocok ternyata umum dipakai di
                    // banyak gambar lain -- kemungkinan besar kebetulan,
                    // bukan kecocokan asli. Tolak, jangan tampilkan icon
                    // yang berisiko salah; lebih baik tanpa icon sama sekali.
                    return null;
                }
            }
            return best.entry;
        }
        return null;
    }
    // Main icon resolver for chest/container UI. Priority order:
    //  1. Name-based match (most reliable - based on real item identity)
    //  2. Legacy bytecode-pattern match (best-effort guess, kept as fallback
    //     per project decision: showing a best guess is preferred over a
    //     blank icon, even though this method can occasionally be wrong)
    //  3. Last-resort index-into-t6 guess (old default behaviour)
    // ================================================================
    // DIAGNOSTIK LIVE -- overlay di layar (bukan console, karena WebView
    // kemungkinan tidak punya akses console). Nampilin persis itemId yang
    // BENERAN dikirim saat render slot chest, nama yang ke-resolve dari
    // l_eng_items.xml, dan jalur resolusi mana yang dipakai (override /
    // name-match / legacy fallback / t6 fallback). HAPUS blok ini setelah
    // bug teridentifikasi & di-fix permanen.
    // ================================================================
    var _0xdebugOverlayEl = null;
    var _0xdebugToggleBtn = null;
    var _0xdebugLogLines = [];
    var _0xdebugExpanded = false;
    var _0xdebugSeenIds = {}; // biar tidak spam log berulang untuk id yang sama

    function _0xdebugEnsureUI() {
        if (_0xdebugToggleBtn) return;

        // Tombol kecil, selalu ada, TIDAK menghalangi navigasi -- ini yang
        // tampil default. Tap untuk buka/tutup log lengkap.
        _0xdebugToggleBtn = document.createElement('div');
        _0xdebugToggleBtn.id = 'mdz-icon-debug-toggle';
        _0xdebugToggleBtn.textContent = '🐛';
        _0xdebugToggleBtn.style.cssText = [
            'position:fixed', 'top:8px', 'left:8px', 'z-index:9999999',
            'width:30px', 'height:30px', 'border-radius:50%',
            'background:rgba(0,0,0,0.75)', 'color:#0f0',
            'font-size:16px', 'display:flex', 'align-items:center', 'justify-content:center',
            'border:1px solid #0f0', 'cursor:pointer', 'user-select:none',
        ].join(';');
        document.body.appendChild(_0xdebugToggleBtn);

        _0xdebugOverlayEl = document.createElement('div');
        _0xdebugOverlayEl.id = 'mdz-icon-debug';
        _0xdebugOverlayEl.style.cssText = [
            'position:fixed', 'top:44px', 'left:8px', 'z-index:9999998',
            'max-width:94vw', 'max-height:45vh', 'overflow-y:auto',
            'background:rgba(0,0,0,0.92)', 'color:#0f0',
            'font-family:monospace', 'font-size:10px', 'line-height:1.5',
            'padding:8px 10px', 'border:1px solid #0f0', 'border-radius:6px',
            'white-space:pre-wrap', 'display:none', // TERSEMBUNYI by default
        ].join(';');
        document.body.appendChild(_0xdebugOverlayEl);

        function toggle() {
            _0xdebugExpanded = !_0xdebugExpanded;
            _0xdebugOverlayEl.style.display = _0xdebugExpanded ? 'block' : 'none';
            _0xdebugToggleBtn.style.background = _0xdebugExpanded ? 'rgba(0,80,0,0.9)' : 'rgba(0,0,0,0.75)';
        }
        _0xdebugToggleBtn.addEventListener('click', toggle);
        _0xdebugToggleBtn.addEventListener('touchstart', function (e) { e.preventDefault(); toggle(); });
    }

    function _0xdebugLog(itemId, msg) {
        // Debug overlay dinonaktifkan default agar tidak memicu layout/reflow
        // ketika banyak item/chest muncul. Aktifkan dengan window.__CHEST_ICON_DEBUG = true.
        if (!(typeof window !== 'undefined' && window.__CHEST_ICON_DEBUG === true)) return;
        if (_0xdebugSeenIds[itemId]) return;
        _0xdebugSeenIds[itemId] = true;
        _0xdebugEnsureUI();
        _0xdebugLogLines.push(msg);
        _0xdebugOverlayEl.textContent = _0xdebugLogLines.join('\n');
    }

    function _0x2cb69e(itemId) {
        if (!_0xad7gb)
            return null;
        if (_0xiconResolveCache.hasOwnProperty(itemId))
            return _0xiconResolveCache[itemId];

        var nameIndexReady = !!(_0xdc93b && _0xdc93b.loaded && _0xdc93b.itemIndex);
        var _0xdbgItem = nameIndexReady ? _0xdc93b.itemIndex[itemId] : null;
        var _0xdbgName = (_0xEnglishNames[itemId] || (_0xdbgItem && _0xdbgItem.name) || '(nama tidak ditemukan)');
        var result = null;
        var _0xdbgPath = '?';

        try {
            // PRIORITAS UTAMA: indeks GUI yang dibaca langsung dari data.js.
            var guiInfo = _0xguiIconIndex[String(itemId)];
            if (guiInfo && _0xad7gb && _0xad7gb[guiInfo.typeName]) {
                result = (_0xad7gb[guiInfo.typeName] || [])[guiInfo.frame] || null;
                if (result) _0xdbgPath = 'GUI_INDEX (' + guiInfo.source + ')';
            }
            // Jika indeks belum tersedia, gunakan T6/equipMap yang juga
            // menunjuk ke frame atlas GUI resmi.
            if (!result) {
                var t6 = _0xad7gb["t6"] || [];
                if (itemId >= 0 && itemId < t6.length && t6[itemId]) { result=t6[itemId]; _0xdbgPath='t6[itemId] (GUI icon resmi)'; }
            }
            if (!result && _0xequipMap && _0xequipMap[itemId]) {
                result=_0xresolveByEquipMap(itemId);
                if (result) _0xdbgPath='equipMap (GUI atlas)';
            }
            if (!result && _0xiconManualOverrides.hasOwnProperty(itemId)) { result=_0xresolveByName(itemId); if(result) _0xdbgPath='manual override'; }
            if (!result) { result=_0xresolveByName(itemId); if(result) _0xdbgPath='name-match fallback'; }
            /* legacy body intentionally bypassed: GUI index is authoritative */
        }
        catch (e) {
            result = null;
            _0xdbgPath = 'ERROR: ' + (e && e.message ? e.message : e);
        }

        _0xdebugLog(itemId,
            '[IconDebug] itemId=' + itemId +
            ' | nameIndexReady=' + nameIndexReady +
            ' | nama="' + _0xdbgName + '"' +
            ' | jalur resolusi=' + (result ? _0xdbgPath : 'TIDAK ADA MATCH') +
            ' | src=' + (result ? (result.src || 'ada tapi tanpa src') : 'NULL') +
            ' | crop=' + (result ? [result.x, result.y, result.w, result.h].join(',') : '-')
        );

        // T6 adalah tabel resmi dan tidak bergantung pada l_eng_items.xml.
        // Karena itu hasil T6 boleh langsung di-cache.
        // Fallback lain tetap menunggu database nama siap agar tidak
        // membekukan hasil sementara akibat race condition.
        var _0xfromT6 = !!(result && (_0xdbgPath.indexOf('GUI_INDEX') === 0 || _0xdbgPath.indexOf('t6[itemId]') === 0 || _0xdbgPath.indexOf('equipMap') === 0));
        var _0xcacheFinal = _0xfromT6 ||
            nameIndexReady ||
            !!(_0xiconManualOverrides && _0xiconManualOverrides.hasOwnProperty(itemId)) ||
            !!(_0xequipMap && _0xequipMap[itemId]);

        if (_0xcacheFinal)
            _0xiconResolveCache[itemId] = result;

        return result;
    }
    // ================================================================
    // EQUIP MAP -- di-port dari bunker_no_support_menu.js (fungsi
    // _0x21_0x433 di sana). BEDA dari sistem "LEGACY BYTECODE FALLBACK"
    // yang sudah dimatikan -- ini baca pola bytecode SPESIFIK ([539,203,..])
    // yang tampaknya terkait definisi "equip slot" di event sheet asli,
    // dikonfirmasi user AKURAT untuk senjata/equipment di data.js APK ini
    // (166 item ter-cover, tercek manual lewat MDZ Toolkit/bunker.js).
    // ================================================================
    var _0xequipMap = null;
    function _0xbuildEquipMap(dataText) {
        var typeMap = { 1: "t1", 4: "t4", 5: "t5", 9: "t9", 12: "t12", 13: "t13", 19: "t19", 24: "t24" };
        var typeCodes = Object.keys(typeMap).map(Number);
        var result = {};
        var markerRe = /\[539,203,/g;
        var idRe = /,\[7,\s*\[0,\s*(\d+)\s*\]\s*\]\s*\]\s*\]/;
        var m;
        while ((m = markerRe.exec(dataText)) !== null) {
            var chunk = dataText.slice(m.index, m.index + 280);
            var idMatch = idRe.exec(chunk);
            if (!idMatch) continue;
            var itemId = parseInt(idMatch[1], 10);
            if (itemId === 0 || itemId > 9999) continue;
            var afterIdx = m.index + idMatch.index + idMatch[0].length;
            var frameChunk = dataText.slice(afterIdx, afterIdx + 70);
            for (var i = 0; i < typeCodes.length; i++) {
                var tCode = typeCodes[i];
                var frameRe = new RegExp("\\[" + tCode + ",\\s*72,[^\\[]+\\[\\s*\\[0,\\s*\\[0,\\s*(\\d+)\\]\\]\\s*\\]\\]");
                var frameMatch = frameRe.exec(frameChunk);
                if (frameMatch) {
                    var frame = parseInt(frameMatch[1], 10);
                    if (frame > 0 && frame < 60) {
                        result[itemId] = { typeName: typeMap[tCode], frame: frame };
                    }
                    break;
                }
            }
        }
        return result;
    }
    function _0xresolveByEquipMap(itemId) {
        if (!_0xequipMap || !_0xad7gb) return null;
        var entry = _0xequipMap[itemId];
        if (!entry) return null;
        var frames = _0xad7gb[entry.typeName] || [];
        return frames[entry.frame] || null;
    }


    (function () { _0x1c05af("./data.js",
            "text")["then"](function (dataText, _0x8b65c) { _0xdb137f = _0xbe8e(dataText); _0xequipMap = _0xbuildEquipMap(dataText); var _0xba265e; _0x8b65c = (549984 ^ 549993) + (819512 ^ 819519); try {
        _0xba265e = JSON["parse"](dataText);
    }
    catch (e) {
        console["warn"]("deliaf esrap NOSJ sj.atad :lg_tsehc".split("").reverse().join(""), e);
        return;
    } _0xad7gb = _0xgc69c(_0xba265e); _0xrebuildGuiIconIndex(); })["catch"](function (e) { console["warn"]("chest_gl: failed to load icon atlases from data.js", e); }); })();

    // ================================================================
    // SMOOTH ICON TEXTURE QUEUE
    // Jangan membuat banyak canvas/WebGL texture dalam satu frame ketika
    // chest spawn. Texture icon dibuat bertahap (maks. 1 per animation
    // frame) sehingga frame game tidak spike saat banyak chest muncul.
    // ================================================================
    var _0xiconTexQueue = [];
    var _0xiconTexQueued = Object.create(null);
    var _0xiconTexBusy = false;

    function _0xqueueIconTexture(glw, itemId) {
        var key = String(itemId);
        if (_0xde4[itemId] || _0xiconTexQueued[key]) return;
        _0xiconTexQueued[key] = true;
        _0xiconTexQueue.push({ glw: glw, itemId: itemId });
        if (!_0xiconTexBusy) {
            _0xiconTexBusy = true;
            (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : function(cb){ return setTimeout(cb, 16); })(_0xprocessIconTextureQueue);
        }
    }

    function _0xprocessIconTextureQueue() {
        var job = _0xiconTexQueue.shift();
        if (job) {
            var key = String(job.itemId);
            delete _0xiconTexQueued[key];
            try { _0x6dceImmediate(job.glw, job.itemId); } catch (e) {}
        }
        if (_0xiconTexQueue.length) {
            (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : function(cb){ return setTimeout(cb, 16); })(_0xprocessIconTextureQueue);
        } else {
            _0xiconTexBusy = false;
        }
    }

    function _0x6dceImmediate(glw, itemId, _0xa45d) { if (_0xde4[itemId])
        return _0xde4[itemId]; var f = _0x2cb69e(itemId); _0xa45d = "hmehmk"; if (!f)
        return null;
    // PENTING: jangan cache texture PERMANEN kalau resolusi icon-nya BELUM
    // final -- yaitu kalau chest ini kebetulan di-render SEBELUM
    // l_eng_items.xml selesai di-fetch (race condition async), _0x2cb69e()
    // bisa saja mengembalikan hasil dari sistem lama (_0xdb137f/t6[itemId],
    // berbasis data.js LAMA) sebagai fallback sementara. Tanpa pengecekan
    // ini, hasil fallback yang salah itu akan ke-"bakar" permanen jadi
    // WebGL texture di _0xde4[itemId] dan TIDAK PERNAH diganti lagi
    // meski nama item sudah berhasil di-resolve dengan benar sesaat
    // kemudian. _0xiconResolveCache cuma diisi oleh _0x2cb69e() ketika
    // hasilnya sudah dianggap final (lihat komentar di fungsi itu) --
    // jadi dipakai di sini sebagai penanda "aman untuk di-cache permanen".
    var _0xresolutionIsFinal = _0xiconResolveCache.hasOwnProperty(itemId);
    var _0xe552a = (734227 ^ 734227) + (646300 ^ 646293); var _0x932b2d = _0xdg0b(f["src"]); _0xe552a = "bhicoi"; if (!_0x932b2d || !_0x932b2d["complete"] || _0x932b2d["naturalWidth"] === (738891 ^ 738891))
        return null; var _0x196d6g = (567488 ^ 567494) + (643046 ^ 643040); var _0xff748c = document["createElement"]("savnac".split("").reverse().join("")); _0x196d6g = (768373 ^ 768373) + (843134 ^ 843131); _0xff748c["width"] = f["w"]; _0xff748c["height"] = f["h"]; var _0x23baef = (793194 ^ 793199) + (907102 ^ 907094); var _0x6452ad = _0xff748c["getContext"]("d2".split("").reverse().join("")); _0x23baef = 870584 ^ 870591; _0x6452ad["drawImage"](_0x932b2d, f["x"], f["y"], f["w"], f["h"], 236080 ^ 236080, 473402 ^ 473402, f["w"], f["h"]); try {
        var _0xtexResult;
        if (glw[K["loadTex"]]) {
            _0xtexResult = glw[K["loadTex"]](_0xff748c, false, false, false);
        }
        else {
            var _0xce5f = (401211 ^ 401203) + (719261 ^ 719258);
            var _0xg9d6b = glw[K["gl"]];
            _0xce5f = (185135 ^ 185129) + (370338 ^ 370340);
            var _0xd9d1b = _0xg9d6b["createTexture"]();
            _0xg9d6b["bindTexture"](_0xg9d6b["TEXTURE_2D"], _0xd9d1b);
            _0xg9d6b["texParameteri"](_0xg9d6b["TEXTURE_2D"], _0xg9d6b["TEXTURE_MIN_FILTER"], _0xg9d6b["NEAREST"]);
            _0xg9d6b["texParameteri"](_0xg9d6b["TEXTURE_2D"], _0xg9d6b["TEXTURE_MAG_FILTER"], _0xg9d6b["NEAREST"]);
            _0xg9d6b["texImage2D"](_0xg9d6b["TEXTURE_2D"], 610393 ^ 610393, _0xg9d6b["RGBA"], _0xg9d6b["RGBA"], _0xg9d6b["UNSIGNED_BYTE"], _0xff748c);
            _0xtexResult = _0xd9d1b;
        }
        if (_0xresolutionIsFinal) {
            // Aman di-cache permanen -- nama item sudah berhasil dicek
            // (atau database nama sudah confirmed ready & tetap gagal,
            // jadi ini memang keputusan final, bukan tebakan sementara).
            _0xde4[itemId] = _0xtexResult;
        }
        // Kalau BELUM final, sengaja TIDAK disimpan ke _0xde4 -- biar
        // panggilan render berikutnya (frame selanjutnya) coba lagi dari
        // _0x2cb69e(), dan begitu nama sudah ke-resolve, texture yang
        // benar akan ke-generate & baru di-cache saat itu.
        return _0xtexResult;
    }
    catch (e) { } return _0xde4[itemId] || null; }
    function _0x6dce(glw, itemId, _0xa45d) {
        if (_0xde4[itemId]) return _0xde4[itemId];
        var f = _0x2cb69e(itemId);
        if (!f) return null;
        // Image atlas belum siap: biarkan render berikutnya mencoba lagi.
        var atlas = _0xdg0b(f.src);
        if (!atlas || !atlas.complete || atlas.naturalWidth === 0) return null;
        // Texture belum dibuat: masukkan ke queue agar spawn tidak spike.
        _0xqueueIconTexture(glw, itemId);
        return null;
    }
    function _0x3371e(glw, count) { if (count <= (970958 ^ 970959))
        return null; var _0x43db = String(count); if (_0xd43fed[_0x43db])
        return _0xd43fed[_0x43db]; var _0xf65cbd = document["createElement"]("canvas"); _0xf65cbd["width"] = 847958 ^ 847878; _0xf65cbd["height"] = 457384 ^ 457398; var _0x8fb2 = _0xf65cbd["getContext"]("2d"); _0x8fb2["clearRect"](458475 ^ 458475, 851984 ^ 851984, _0xf65cbd["width"], _0xf65cbd["height"]); _0x8fb2["font"] = "bold 22px Segoe UI"; _0x8fb2["textAlign"] = "thgir".split("").reverse().join(""); _0x8fb2["textBaseline"] = "mottob".split("").reverse().join(""); _0x8fb2["lineWidth"] = 305470 ^ 305466; _0x8fb2["strokeStyle"] = ")59.0 ,0 ,0 ,0(abgr".split("").reverse().join(""); _0x8fb2["fillStyle"] = "#ffffff"; _0x8fb2["strokeText"](_0x43db, _0xf65cbd["width"] - (287378 ^ 287376), _0xf65cbd["height"] - (345052 ^ 345054)); _0x8fb2["fillText"](_0x43db, _0xf65cbd["width"] - (185973 ^ 185975), _0xf65cbd["height"] - (324306 ^ 324304)); try {
        if (glw[K["loadTex"]]) {
            _0xd43fed[_0x43db] = glw[K["loadTex"]](_0xf65cbd, false, false, false);
        }
        else {
            var _0xeeb1c = (845012 ^ 845021) + (701793 ^ 701793);
            var _0xb3dffd = glw[K["gl"]];
            _0xeeb1c = "ldegpi".split("").reverse().join("");
            var _0x517ca = _0xb3dffd["createTexture"]();
            _0xb3dffd["bindTexture"](_0xb3dffd["TEXTURE_2D"], _0x517ca);
            _0xb3dffd["texParameteri"](_0xb3dffd["TEXTURE_2D"], _0xb3dffd["TEXTURE_MIN_FILTER"], _0xb3dffd["NEAREST"]);
            _0xb3dffd["texParameteri"](_0xb3dffd["TEXTURE_2D"], _0xb3dffd["TEXTURE_MAG_FILTER"], _0xb3dffd["NEAREST"]);
            _0xb3dffd["texImage2D"](_0xb3dffd["TEXTURE_2D"], 197948 ^ 197948, _0xb3dffd["RGBA"], _0xb3dffd["RGBA"], _0xb3dffd["UNSIGNED_BYTE"], _0xf65cbd);
            _0xd43fed[_0x43db] = _0x517ca;
        }
    }
    catch (e) { } return _0xd43fed[_0x43db] || null; }
    function _0xe3_0x013(glw, src) { if (_0x57g[src])
        return _0x57g[src]; var _0x851e = _0xdg0b(src); if (_0x851e && _0x851e["complete"] && _0x851e["naturalWidth"] > (243731 ^ 243731)) {
        try {
            if (glw[K["loadTex"]]) {
                _0x57g[src] = glw[K["loadTex"]](_0x851e, false, false, false);
            }
            else {
                var _0xa8da = glw[K["gl"]];
                var _0x68ef6f = _0xa8da["createTexture"]();
                _0xa8da["bindTexture"](_0xa8da["TEXTURE_2D"], _0x68ef6f);
                _0xa8da["texParameteri"](_0xa8da["TEXTURE_2D"], _0xa8da["TEXTURE_MIN_FILTER"], _0xa8da["NEAREST"]);
                _0xa8da["texParameteri"](_0xa8da["TEXTURE_2D"], _0xa8da["TEXTURE_MAG_FILTER"], _0xa8da["NEAREST"]);
                _0xa8da["texImage2D"](_0xa8da["TEXTURE_2D"], 803737 ^ 803737, _0xa8da["RGBA"], _0xa8da["RGBA"], _0xa8da["UNSIGNED_BYTE"], _0x851e);
                _0x57g[src] = _0x68ef6f;
            }
        }
        catch (e) { }
    } return _0x57g[src] || null; }
    var _0x549a = document["createElement"]("canvas");
    _0x8d89ed = (959320 ^ 959321) + (707432 ^ 707436);
    _0x549a["width"] = 220388 ^ 220389;
    _0x549a["height"] = 437271 ^ 437270;
    var _0xf1gbcf = _0x549a["getContext"]("2d");
    _0xf1gbcf["fillStyle"] = "#000";
    _0xf1gbcf["fillRect"](983560 ^ 983560, 449320 ^ 449320, 855825 ^ 855824, 214766 ^ 214767);
    var _0xgd8gac = null;
    function _0x3721bg(glw) { if (_0xgd8gac)
        return _0xgd8gac; try {
        if (glw[K["loadTex"]]) {
            _0xgd8gac = glw[K["loadTex"]](_0x549a, false, false, false);
        }
        else {
            var _0x99b7c = glw[K["gl"]];
            var _0x367agg = (289072 ^ 289080) + (470402 ^ 470411);
            var _0x5574b = _0x99b7c["createTexture"]();
            _0x367agg = 645456 ^ 645457;
            _0x99b7c["bindTexture"](_0x99b7c["TEXTURE_2D"], _0x5574b);
            _0x99b7c["texParameteri"](_0x99b7c["TEXTURE_2D"], _0x99b7c["TEXTURE_MIN_FILTER"], _0x99b7c["NEAREST"]);
            _0x99b7c["texParameteri"](_0x99b7c["TEXTURE_2D"], _0x99b7c["TEXTURE_MAG_FILTER"], _0x99b7c["NEAREST"]);
            _0x99b7c["texImage2D"](_0x99b7c["TEXTURE_2D"], 556351 ^ 556351, _0x99b7c["RGBA"], _0x99b7c["RGBA"], _0x99b7c["UNSIGNED_BYTE"], _0x549a);
            _0xgd8gac = _0x5574b;
        }
    }
    catch (e) { } return _0xgd8gac; }
    var _0x3b164c = Object["create"](null);
    function _0x07ec6d(glw, centerAngleDeg, spanDeg, dist, _0xfddfab, _0x7ea4a) { dist = dist != null ? dist : _0xd5_0x7dc["buttonDist"]; var _0x5d93ag = centerAngleDeg + "|" + spanDeg + "|" + dist; if (_0x3b164c[_0x5d93ag] && _0x3b164c[_0x5d93ag]["tex"])
        return _0x3b164c[_0x5d93ag]; var _0x8db08d = Math["round"](dist * (293449 ^ 293451)) + (367204 ^ 367212); var _0x134c2d = (636488 ^ 636489) + (133303 ^ 133296); var _0xe55a = document["createElement"]("canvas"); _0x134c2d = 825348 ^ 825350; _0xe55a["width"] = _0x8db08d; _0xe55a["height"] = _0x8db08d; var _0x76055c = (146506 ^ 146504) + (980931 ^ 980929); var _0x46cc = _0xe55a["getContext"]("d2".split("").reverse().join("")); _0x76055c = 439533 ^ 439529; var _0x74eb = _0x8db08d / (738588 ^ 738590), _0x5ccbcf = _0x8db08d / (452468 ^ 452470), r = _0x8db08d / (935752 ^ 935754) - (795516 ^ 795518); var _0x1946ca = (191797 ^ 191797) + (780570 ^ 780569); var _0xd1688a = centerAngleDeg * Math["PI"] / (578689 ^ 578613); _0x1946ca = 334256 ^ 334257; var _0xdbfe3d = spanDeg / (644043 ^ 644041) * Math["PI"] / (530991 ^ 531099); _0xfddfab = 100580 ^ 100583; if (spanDeg >= (822308 ^ 822604)) {
        _0x46cc["beginPath"]();
        _0x46cc["arc"](_0x74eb, _0x5ccbcf, r, 561389 ^ 561389, Math["PI"] * (937713 ^ 937715));
    }
    else {
        _0x46cc["beginPath"]();
        _0x46cc["moveTo"](_0x74eb, _0x5ccbcf);
        _0x46cc["arc"](_0x74eb, _0x5ccbcf, r, _0xd1688a - _0xdbfe3d, _0xd1688a + _0xdbfe3d);
        _0x46cc["closePath"]();
    } _0x46cc["fillStyle"] = "rgba(100,180,255,0.18)"; _0x46cc["fill"](); _0x46cc["strokeStyle"] = ")7.0,552,081,001(abgr".split("").reverse().join(""); _0x46cc["lineWidth"] = 1.5; _0x46cc["stroke"](); var _0x605a6e = null; _0x7ea4a = "fgfcbl"; try {
        if (glw[K["loadTex"]]) {
            _0x605a6e = glw[K["loadTex"]](_0xe55a, false, false, false);
        }
        else {
            var _0xc3c1b = glw[K["gl"]];
            _0x605a6e = _0xc3c1b["createTexture"]();
            _0xc3c1b["bindTexture"](_0xc3c1b["TEXTURE_2D"], _0x605a6e);
            _0xc3c1b["texParameteri"](_0xc3c1b["TEXTURE_2D"], _0xc3c1b["TEXTURE_MIN_FILTER"], _0xc3c1b["NEAREST"]);
            _0xc3c1b["texParameteri"](_0xc3c1b["TEXTURE_2D"], _0xc3c1b["TEXTURE_MAG_FILTER"], _0xc3c1b["NEAREST"]);
            _0xc3c1b["texImage2D"](_0xc3c1b["TEXTURE_2D"], 717938 ^ 717938, _0xc3c1b["RGBA"], _0xc3c1b["RGBA"], _0xc3c1b["UNSIGNED_BYTE"], _0xe55a);
        }
    }
    catch (e) { } if (_0x605a6e)
        _0x3b164c[_0x5d93ag] = {
            "tex": _0x605a6e,
                "size": _0x8db08d
        }; return _0x3b164c[_0x5d93ag] || null; }
    var _0xcc8d = document["createElement"]("canvas");
    _0xcc8d["width"] = 713986 ^ 713987;
    _0xcc8d["height"] = 826980 ^ 826981;
    var _0xed1e = _0xcc8d["getContext"]("2d");
    _0xed1e["fillStyle"] = "0f0#".split("").reverse().join("");
    _0xed1e["fillRect"](600730 ^ 600730, 283621 ^ 283621, 752102 ^ 752103, 151606 ^ 151607);
    var _0xbbb3 = null;
    _0xc6d9bd = 610070 ^ 610069;
    function _0x0f_0x177(glw) { if (_0xbbb3)
        return _0xbbb3; try {
        if (glw[K["loadTex"]]) {
            _0xbbb3 = glw[K["loadTex"]](_0xcc8d, false, false, false);
        }
        else {
            var _0x5ac1a = glw[K["gl"]];
            var _0xg9c = (503540 ^ 503540) + (402116 ^ 402112);
            var _0xf2fa9c = _0x5ac1a["createTexture"]();
            _0xg9c = (935610 ^ 935602) + (771911 ^ 771908);
            _0x5ac1a["bindTexture"](_0x5ac1a["TEXTURE_2D"], _0xf2fa9c);
            _0x5ac1a["texParameteri"](_0x5ac1a["TEXTURE_2D"], _0x5ac1a["TEXTURE_MIN_FILTER"], _0x5ac1a["NEAREST"]);
            _0x5ac1a["texParameteri"](_0x5ac1a["TEXTURE_2D"], _0x5ac1a["TEXTURE_MAG_FILTER"], _0x5ac1a["NEAREST"]);
            _0x5ac1a["texImage2D"](_0x5ac1a["TEXTURE_2D"], 144243 ^ 144243, _0x5ac1a["RGBA"], _0x5ac1a["RGBA"], _0x5ac1a["UNSIGNED_BYTE"], _0xcc8d);
            _0xbbb3 = _0xf2fa9c;
        }
    }
    catch (e) { } return _0xbbb3; }
    function _0xe4_0x2ac(entry) { return _0x53891d[entry["rarity"]] || _0x53891d["high"]; }
    function _0x4180b(conf) { return conf && conf["rarityChance"] ? conf["rarityChance"] : _0x53891d; }
    function _0x9ee7ac(lootTable, conf) { var _0x15df = _0x4180b(conf); var _0xb4e26b = (364214 ^ 364210) + (941558 ^ 941552); var _0xcdcc0d = 592766 ^ 592766; _0xb4e26b = (316898 ^ 316896) + (661699 ^ 661696); for (var i = 842136 ^ 842136; i < lootTable["length"]; i++)
        _0xcdcc0d += _0x15df[lootTable[i]["rarity"]] || _0x15df["high"]; if (_0xcdcc0d <= (612578 ^ 612578))
        return null; var _0xe7506b = (364238 ^ 364239) + (649800 ^ 649802); var _0x1cd5d = Math["random"]() * _0xcdcc0d; _0xe7506b = (352055 ^ 352050) + (173799 ^ 173792); for (var j = 862409 ^ 862409; j < lootTable["length"]; j++) {
        _0x1cd5d -= _0x15df[lootTable[j]["rarity"]] || _0x15df["high"];
        if (_0x1cd5d <= (320358 ^ 320358))
            return lootTable[j];
    } return lootTable[lootTable["length"] - (841641 ^ 841640)] || null; }
    function _0xc5fab(itemId, lootTable) { var _0xb3402b = null; for (var i = 713514 ^ 713514; i < lootTable["length"]; i++) {
        if (lootTable[i]["id"] === itemId) {
            _0xb3402b = lootTable[i];
            break;
        }
    } if (!_0xb3402b || !_0xb3402b["stackSteps"] || !_0xb3402b["stackSteps"]["length"])
        return 207419 ^ 207418; var _0x7bea = (919961 ^ 919952) + (988338 ^ 988338); var _0x81gfa = _0xb3402b["stackSteps"]; _0x7bea = (216618 ^ 216618) + (159705 ^ 159697); var _0x59217d = (132533 ^ 132528) + (126623 ^ 126614); var _0xg4e74f = _0x81gfa[_0x81gfa["length"] - (226502 ^ 226503)]; _0x59217d = 424679 ^ 424677; var _0xa3a85c = (918302 ^ 918300) + (219894 ^ 219891); var _0x8631f = _0x81gfa[Math["floor"](Math["random"]() * _0x81gfa["length"])]; _0xa3a85c = (241443 ^ 241440) + (657374 ^ 657375); if (_0x8631f >= _0xg4e74f)
        return _0xg4e74f; return _0x8631f + Math["floor"](Math["random"]() * (_0xg4e74f - _0x8631f + (714667 ^ 714666))); }
    function _0xf5_0x8d8(conf, _0x27e, _0xb63c, _0xe2egbb) { conf = conf || {}; var _0x8482d = _0x3f9d(conf); _0x27e = (405905 ^ 405906) + (347296 ^ 347299); var _0x239 = _0x267d(_0x8482d); _0xb63c = "hmfibq".split("").reverse().join(""); var _0xedf = (801243 ^ 801245) + (475035 ^ 475032); var _0xd6f5f = []; _0xedf = (466593 ^ 466597) + (250417 ^ 250421); for (var s = 109697 ^ 109697; s < _0x239; s++)
        _0xd6f5f["push"](null); var _0xf346ad = _0xeb1ee(conf["staticSlots"], _0x8482d); for (var _0xa2c = 951523 ^ 951523; _0xa2c < Math["min"](_0x239, _0xf346ad["length"]); _0xa2c++) {
        if (_0xf346ad[_0xa2c] && _0xf346ad[_0xa2c]["id"]) {
            _0xd6f5f[_0xa2c] = {
                "id": _0xf346ad[_0xa2c]["id"],
                        "count": _0xf346ad[_0xa2c]["count"] || 806420 ^ 806421
            };
        }
    } var _0x912bb = _0xe77c1b(conf); _0xe2egbb = (755417 ^ 755417) + (515830 ^ 515827); if (!_0x912bb["length"])
        return _0xd6f5f; var _0x861f = 412031 ^ 412031; for (var _0x45cdc = 300540 ^ 300540; _0x45cdc < _0x239; _0x45cdc++)
        if (_0xd6f5f[_0x45cdc] !== null)
            _0x861f++; var _0xda1bf = (350406 ^ 350405) + (808397 ^ 808395); var _0x36e2 = Math["max"](418956 ^ 418956, _0x239 - _0x861f); _0xda1bf = 619706 ^ 619707; if (!_0x36e2)
        return _0xd6f5f; var _0x32_0x23e = (634817 ^ 634818) + (320654 ^ 320653); var _0x21a = Math["min"](341359 ^ 341357, _0x36e2); _0x32_0x23e = (657840 ^ 657848) + (788295 ^ 788289); var _0xf5e47d = (957826 ^ 957835) + (555752 ^ 555745); var _0x708fae = Math["min"](_0x36e2, 386271 ^ 386264); _0xf5e47d = "hphpbg"; var _0x1d99e = (555383 ^ 555379) + (947889 ^ 947894); var _0x55b4dc = _0x21a + Math["floor"](Math["random"]() * Math["max"](660711 ^ 660710, _0x708fae - _0x21a + (259237 ^ 259236))); _0x1d99e = "gehpme"; for (var i = 364668 ^ 364668; i < _0x55b4dc; i++) {
        var _0xd9fe = [];
        for (var j = 798378 ^ 798378; j < _0x239; j++)
            if (_0xd6f5f[j] === null)
                _0xd9fe["push"](j);
        if (_0xd9fe["length"] === (289082 ^ 289082))
            break;
        var _0xdaf8ae = (941199 ^ 941194) + (436247 ^ 436244);
        var _0xd84b4d = _0xd9fe[Math["floor"](Math["random"]() * _0xd9fe["length"])];
        _0xdaf8ae = (864712 ^ 864714) + (773214 ^ 773214);
        let _0xb7_0x69g;
        var _0x87f2 = _0x9ee7ac(_0x912bb, conf);
        _0xb7_0x69g = 485730 ^ 485728;
        if (!_0x87f2)
            continue;
        _0xd6f5f[_0xd84b4d] = {
            "id": _0x87f2["id"],
                    "count": _0x87f2["staticCount"] || _0xc5fab(_0x87f2["id"], _0x912bb)
        };
    } return _0xd6f5f; }
    function _0xe91a9d(locker) { for (var i = 797588 ^ 797588; i < locker["inventory"]["length"]; i++) {
        if (locker["inventory"][i] !== null)
            return !![];
    } return false; }
    var _0x109 = -(841891 ^ 842571);
    var _0xa1dg = -(350287 ^ 351143);
    var _0x56dbe = (760440 ^ 760445) + (455903 ^ 455898);
    var _0x27e9fa = _0x109;
    _0x56dbe = 339950 ^ 339942;
    var _0x110 = _0xa1dg;
    var _0xb324d = false;
    var _0x69c4ae = [];
    var _0x604d8c = (256218 ^ 256223) + (908612 ^ 908614);
    var _0x70e01b = -(196168 ^ 196169);
    _0x604d8c = 711505 ^ 711504;
    var _0xeafc = (633572 ^ 633581) + (294706 ^ 294708);
    var _0x9dac3c = 977165 ^ 977165;
    _0xeafc = 393606 ^ 393615;
    var _0x1578bb = 547046 ^ 547046;
    function _0xag1cfg(totalSlots, value) { _0x69c4ae["length"] = totalSlots; for (var i = 185746 ^ 185746; i < totalSlots; i++) {
        _0x69c4ae[i] = value;
    } }
    function _0xg506d() { return _0x27e9fa !== _0x109; }
    function _0x4ee8f(list, fallbackList) { var _0x77e = (802226 ^ 802230) + (783389 ^ 783381); var _0x2eaaae = Array["isArray"](list) && list["length"] ? list : fallbackList || []; _0x77e = (921082 ^ 921082) + (196504 ^ 196496); if (!_0x2eaaae["length"])
        return; var _0xccgc4e = (383417 ^ 383422) + (942358 ^ 942354); var _0xeccd7g = _0x2eaaae[Math["floor"](Math["random"]() * _0x2eaaae["length"])]; _0xccgc4e = "nflkje".split("").reverse().join(""); var _0x35gb = new Audio(_0xeccd7g); _0x35gb["play"]()["catch"](function () { }); }
    function _0x45f2e(locker) { if (!locker || !locker["conf"])
        return "tsehC".split("").reverse().join(""); return locker["conf"]["name"] || locker["conf"]["chestTypeId"] || "Chest"; }
    function _0x3ga5c(color) { if (typeof color === "rebmun".split("").reverse().join(""))
        return color; if (typeof color !== "gnirts".split("").reverse().join(""))
        return null; var _0xge93aa = color["match"](new RegExp("^#([0-9a-f]{3}|[0-9a-f]{6})$",
            "i")); if (_0xge93aa) {
        var _0xg77cdc = (254422 ^ 254419) + (161436 ^ 161436);
        var _0xfffb8f = _0xge93aa[140005 ^ 140004];
        _0xg77cdc = 390841 ^ 390844;
        if (_0xfffb8f["length"] === (630245 ^ 630246)) {
            _0xfffb8f = _0xfffb8f[840077 ^ 840077] + _0xfffb8f[865158 ^ 865158] + _0xfffb8f[754093 ^ 754092] + _0xfffb8f[170510 ^ 170511] + _0xfffb8f[663813 ^ 663815] + _0xfffb8f[499309 ^ 499311];
        }
        let _0x74c8a;
        var r = parseInt(_0xfffb8f["substr"](846320 ^ 846320, 807429 ^ 807431), 130577 ^ 130561);
        _0x74c8a = "pdlbho".split("").reverse().join("");
        let _0x5fbg;
        var g = parseInt(_0xfffb8f["substr"](577646 ^ 577644, 893641 ^ 893643), 408547 ^ 408563);
        _0x5fbg = (322026 ^ 322028) + (951140 ^ 951149);
        var _0xf788dc = (694688 ^ 694689) + (402796 ^ 402792);
        var b = parseInt(_0xfffb8f["substr"](435220 ^ 435216, 324013 ^ 324015), 619688 ^ 619704);
        _0xf788dc = (609408 ^ 609415) + (339302 ^ 339299);
        return r | g << (948644 ^ 948652) | b << (922133 ^ 922117);
    } var _0x98f = (897697 ^ 897702) + (373320 ^ 373323); var _0x7b2a8c = color["match"](new RegExp("$)\\*s\\)}3,1{d\\(*s\\,*s\\)}3,1{d\\(*s\\,*s\\)}3,1{d\\(*s\\(\\bgr^".split("").reverse().join(""),
            "i")); _0x98f = (424272 ^ 424280) + (193332 ^ 193335); if (_0x7b2a8c) {
        var _0x111 = parseInt(_0x7b2a8c[538665 ^ 538664], 480388 ^ 480398);
        var _0x112 = parseInt(_0x7b2a8c[119195 ^ 119193], 366907 ^ 366897);
        var _0x9f76aa = (711772 ^ 711772) + (999717 ^ 999713);
        var _0xe39e5e = parseInt(_0x7b2a8c[594369 ^ 594370], 283290 ^ 283280);
        _0x9f76aa = 230577 ^ 230578;
        if (_0x111 < (120792 ^ 120792) || _0x111 > (255784 ^ 255959) || _0x112 < (720801 ^ 720801) || _0x112 > (523711 ^ 523584) || _0xe39e5e < (257922 ^ 257922) || _0xe39e5e > (919887 ^ 919984))
            return null;
        return _0x111 | _0x112 << (259714 ^ 259722) | _0xe39e5e << (799277 ^ 799293);
    } return null; }
    var _0x99f = (624430 ^ 624426) + (188406 ^ 188407);
    var _0x3e5f = !![];
    _0x99f = (500064 ^ 500069) + (116610 ^ 116611);
    var _0xdb_0xb63 = {};
    var _0x92ddae = (321741 ^ 321737) + (501909 ^ 501904);
    var _0xg965ce = {
        "EN": "l_eng_new.xml",
            "RU": "l_ru_new.xml",
            "DE": "l_de_new.xml",
            "ES": "l_es_new.xml",
            "FR": "l_fr_new.xml",
            "IT": "l_it_new.xml",
            "CZ": "l_cz_new.xml",
            "PT": "l_pt_new.xml"
    };
    _0x92ddae = (903629 ^ 903626) + (205115 ^ 205115);
    var _0x38917a = {
        799: "Use {0} from inventory to unlock.", 800: "{0} needs to be powered!", 801: "The {0} is looted or appears to be broken.", 802: "The {0} is running out of power", 803: "{0} is powered!", 804: "Used {0}!", 805: "This key does not fit in!", 806: "There is no where else to use this key."
    };
    function _0xa96d(xmlText) { var _0xaad = (873806 ^ 873801) + (795004 ^ 795007); var _0xe17ada = {}; _0xaad = (628828 ^ 628829) + (771890 ^ 771895); try {
        var _0x33_0x578 = (919042 ^ 919045) + (349714 ^ 349713);
        var _0xdd169a = new DOMParser();
        _0x33_0x578 = 331914 ^ 331917;
        let _0xcf_0x76a;
        var _0xdf69ad = _0xdd169a["parseFromString"](xmlText,
                "lmx/txet".split("").reverse().join(""));
        _0xcf_0x76a = 772447 ^ 772441;
        let _0xdd6cb;
        var _0x4g774g = _0xdf69ad["getElementsByTagName"]("text");
        _0xdd6cb = 744639 ^ 744631;
        for (var i = 182294 ^ 182294; i < _0x4g774g["length"]; i++) {
            let _0xde2;
            var _0x37ed = _0x4g774g[i]["getElementsByTagName"]("di".split("").reverse().join(""))[388600 ^ 388600];
            _0xde2 = 657266 ^ 657266;
            var _0x113 = _0x4g774g[i]["getElementsByTagName"]("eman".split("").reverse().join(""))[715954 ^ 715954];
            if (_0x37ed && _0x113) {
                var _0xfc8ge = parseInt(_0x37ed["textContent"]["trim"](), 580821 ^ 580831);
                if (!isNaN(_0xfc8ge))
                    _0xe17ada[_0xfc8ge] = _0x113["textContent"]["trim"]();
            }
        }
    }
    catch (e) { } return _0xe17ada; }
    function _0x6463b(lang) { if (!lang || _0xdb_0xb63[lang] !== undefined)
        return; _0xdb_0xb63[lang] = null; var _0x85g3bc = _0xg965ce[lang] || _0xg965ce["EN"]; try {
        var _0xa3afb = (983389 ^ 983381) + (335704 ^ 335696);
        var _0x1df25f = new XMLHttpRequest();
        _0xa3afb = (932361 ^ 932366) + (918898 ^ 918903);
        _0x1df25f["open"]("GET", _0x85g3bc, !![]);
        _0x1df25f["onload"] = function () { _0xdb_0xb63[lang] = _0x1df25f["status"] === (375139 ^ 375211) || _0x1df25f["status"] === (781365 ^ 781365) ? _0xa96d(_0x1df25f["responseText"]) : {}; };
        _0x1df25f["onerror"] = function () { _0xdb_0xb63[lang] = {}; };
        _0x1df25f["send"]();
    }
    catch (e) {
        _0xdb_0xb63[lang] = {};
    } }
    function _0xcf313g(id) { var _0x2faaf = (687856 ^ 687864) + (615897 ^ 615898); var _0x0ba = Array["prototype"]["slice"]["call"](arguments, 119156 ^ 119157); _0x2faaf = (523349 ^ 523346) + (378747 ^ 378744); var _0xe26df = (885138 ^ 885147) + (748811 ^ 748815); var _0xc24c5a = _0x6ec34e(); _0xe26df = (707320 ^ 707323) + (245060 ^ 245058); var _0x90911g = _0xc24c5a && _0xg84a(_0xc24c5a,
            "egaugnaL".split("").reverse().join("")) || "EN"; _0x6463b(_0x90911g); var _0x8129ff = _0xdb_0xb63[_0x90911g]; var _0x18af = (572765 ^ 572764) + (306966 ^ 306964); var _0x8aaf = _0x3e5f && _0x8129ff && _0x8129ff[id] !== undefined && _0x8129ff[id] !== "" ? _0x8129ff[id] : _0x38917a[id] || ""; _0x18af = "odgnfp"; for (var i = 774118 ^ 774118; i < _0x0ba["length"]; i++) {
        _0x8aaf = _0x8aaf["split"]("{" + i + "}")["join"](String(_0x0ba[i]));
    } return _0x8aaf; }
    function _0xdd_0xag1(message, color) { var _0x4dg = (721350 ^ 721359) + (112011 ^ 112014); var _0x61f = color || "00aaff#".split("").reverse().join(""); _0x4dg = "dkemok".split("").reverse().join(""); var _0xgc721a = (939837 ^ 939838) + (854992 ^ 854998); var _0xg619ca = _0x3ga5c(_0x61f); _0xgc721a = "lhhadc"; if (typeof c2_callFunction !== "undefined") {
        try {
            if (_0xg619ca !== null) {
                c2_callFunction("gol_tneilc".split("").reverse().join(""), [message, _0xg619ca]);
            }
            else {
                c2_callFunction("gol_tneilc".split("").reverse().join(""), [message]);
            }
            return;
        }
        catch (e) { }
    } if (typeof window["showFloatingText"] === "function") {
        try {
            window["showFloatingText"](message, _0x61f);
            return;
        }
        catch (e) { }
    } if (typeof console !== "denifednu".split("").reverse().join("") && typeof console["log"] === "function") {
        console["log"](message);
    } }
    var _0x15aa1a = Object["create"](null);
    function _0x2d54fa(inst, index, _0x42ed1d) { if (!inst || typeof inst !== "object")
        return undefined; var _0x903f = inst[K["instVars"]]; _0x42ed1d = 522801 ^ 522809; if (Array["isArray"](_0x903f) && _0x903f["length"] > index)
        return _0x903f[index]; if (typeof inst[index] !== "undefined")
        return inst[index]; if (typeof inst[String(index)] !== "undefined")
        return inst[String(index)]; return undefined; }
    function _0x85d71c(inst) { if (!inst || typeof inst !== "object")
        return {
            "placed": false,
                "active": false,
                "fuel": null
        }; var _0x1ea = (479709 ^ 479706) + (423196 ^ 423192); var _0x6c_0x3e1 = _0x2d54fa(inst, _0x38f9ae); _0x1ea = 846674 ^ 846683; var _0xcc5fa = _0x2d54fa(inst, _0x4a8g9c); var _0xe4b21f = _0x2d54fa(inst, _0x6db); var _0xb544fc = _0x6c_0x3e1 != null && _0x6c_0x3e1 !== false && _0x6c_0x3e1 !== (235376 ^ 235376); var _0x5e4f = Number(_0xe4b21f); if (!isFinite(_0x5e4f))
        _0x5e4f = null; var _0xe2e2fd = _0xcc5fa === (983620 ^ 983356) && (_0x5e4f == null || _0x5e4f > (812866 ^ 812866)); return {
        "placed": _0xb544fc,
                "active": _0xe2e2fd,
                "fuel": _0x5e4f
    }; }
    function _0x2d_0xdd8(inst, _0x4fadf) { if (!inst || typeof inst["x"] !== "rebmun".split("").reverse().join("") || typeof inst["y"] !== "number")
        return null; var _0x38c6e = _0x85d71c(inst); _0x4fadf = "fhnaej"; if (!_0x38c6e["placed"] || !_0x38c6e["active"])
        return null; return {
        "x": inst["x"],
                "y": inst["y"],
                "fuel": _0x38c6e["fuel"],
                "inst": inst
    }; }
    function _0x1e7a8e(inst) { var _0x9gdad = (694566 ^ 694575) + (732431 ^ 732427); var _0xaf3 = _0x85d71c(inst); _0x9gdad = "gfggbl"; return _0xaf3["placed"] && _0xaf3["active"]; }
    function _0xb3957e(glw, text, fg, bg, fontSize, _0xeca62f, _0x9af1b, _0xa4bb5a) { fontSize = fontSize || 159229 ^ 159217; var _0x225ge = text + "|" + fg + "|" + bg + "|" + fontSize; _0xeca62f = 208040 ^ 208032; if (_0x15aa1a[_0x225ge])
        return _0x15aa1a[_0x225ge]; var _0x34_0x4a6 = (375754 ^ 375746) + (798155 ^ 798155); var _0x75a7eb = document["createElement"]("canvas"); _0x34_0x4a6 = 626322 ^ 626330; var _0x243 = _0x75a7eb["getContext"]("d2".split("").reverse().join("")); _0x9af1b = 241664 ^ 241665; _0x243["font"] = fontSize + "px Segoe UI"; var _0xe76b = (681026 ^ 681030) + (383440 ^ 383444); var _0xd17ac = Math["ceil"](_0x243["measureText"](text)["width"]); _0xe76b = "cmlnnp"; var _0xdadg = 634274 ^ 634282; _0xa4bb5a = (858373 ^ 858373) + (816343 ^ 816343); _0x75a7eb["width"] = _0xd17ac + _0xdadg * (966483 ^ 966481); _0x75a7eb["height"] = fontSize + (322688 ^ 322698); _0x243["font"] = fontSize + "px Segoe UI"; _0x243["textBaseline"] = "elddim".split("").reverse().join(""); _0x243["fillStyle"] = bg || ")7.0,0,0,0(abgr".split("").reverse().join(""); _0x243["fillRect"](761756 ^ 761756, 538352 ^ 538352, _0x75a7eb["width"], _0x75a7eb["height"]); _0x243["fillStyle"] = fg || "#ffffff"; _0x243["fillText"](text, _0xdadg, _0x75a7eb["height"] / (352471 ^ 352469)); var _0xdd96af = (126878 ^ 126873) + (250727 ^ 250734); var _0xf18 = null; _0xdd96af = 589996 ^ 589995; try {
        if (glw && glw[K["loadTex"]]) {
            _0xf18 = glw[K["loadTex"]](_0x75a7eb, false, false, false);
        }
        else if (glw && glw[K["gl"]]) {
            var _0x65b3gd = glw[K["gl"]];
            _0xf18 = _0x65b3gd["createTexture"]();
            _0x65b3gd["bindTexture"](_0x65b3gd["TEXTURE_2D"], _0xf18);
            _0x65b3gd["texParameteri"](_0x65b3gd["TEXTURE_2D"], _0x65b3gd["TEXTURE_MIN_FILTER"], _0x65b3gd["NEAREST"]);
            _0x65b3gd["texParameteri"](_0x65b3gd["TEXTURE_2D"], _0x65b3gd["TEXTURE_MAG_FILTER"], _0x65b3gd["NEAREST"]);
            _0x65b3gd["texImage2D"](_0x65b3gd["TEXTURE_2D"], 922896 ^ 922896, _0x65b3gd["RGBA"], _0x65b3gd["RGBA"], _0x65b3gd["UNSIGNED_BYTE"], _0x75a7eb);
        }
    }
    catch (e) { } if (_0xf18) {
        _0x15aa1a[_0x225ge] = {
            "tex": _0xf18,
                    "width": _0x75a7eb["width"],
                    "height": _0x75a7eb["height"]
        };
    } return _0x15aa1a[_0x225ge] || null; }
    function _0xfd5d6b(_0x9c2cb) { var _0x8ba = _0x6ec34e(); _0x9c2cb = (830939 ^ 830930) + (176735 ^ 176732); if (!_0x8ba)
        return []; var _0x75e = []; var _0xc0ed = (888525 ^ 888524) + (649168 ^ 649177); var _0x63fe = Object["create"](null); _0xc0ed = (776378 ^ 776378) + (501957 ^ 501965); _0xe8gf["forEach"](function (id) { if (isFinite(id))
        _0x63fe[id] = !![]; }); if (Array["isArray"](_0x51_0x675) && _0x51_0x675["length"]) {
        _0x51_0x675["forEach"](function (typeName) { var _0xc7f67f = _0x5e9e6g(typeName); if (_0xc7f67f && _0xc7f67f["length"]) {
            _0xc7f67f["forEach"](function (inst) { if (inst && typeof inst["x"] === "number" && typeof inst["y"] === "rebmun".split("").reverse().join("")) {
                var _0xb3cdb = _0x2d_0xdd8(inst);
                if (_0xb3cdb)
                    _0x75e["push"](_0xb3cdb);
            } });
        } });
    } if (Object["keys"](_0x63fe)["length"] > (893676 ^ 893676)) {
        let _0xffe9d;
        var _0xe78c = _0x8ba[K["types"]] || [];
        _0xffe9d = 926301 ^ 926300;
        for (var _0x1fc7a = 232159 ^ 232159; _0x1fc7a < _0xe78c["length"]; _0x1fc7a++) {
            var _0xfb69f = (313437 ^ 313439) + (955242 ^ 955243);
            var insts = _0xe78c[_0x1fc7a][K["insts"]] || [];
            _0xfb69f = 166710 ^ 166707;
            for (var _0x1d512e = 704039 ^ 704039; _0x1d512e < insts["length"]; _0x1d512e++) {
                var _0xb2f = insts[_0x1d512e];
                if (!_0xb2f || typeof _0xb2f["x"] !== "number" || typeof _0xb2f["y"] !== "number")
                    continue;
                var _0x362bbc = false;
                for (var _0x39ac in _0xb2f) {
                    if (!Array["isArray"](_0xb2f[_0x39ac]))
                        continue;
                    for (var _0x1a439d = 966598 ^ 966598; _0x1a439d < _0xb2f[_0x39ac]["length"]; _0x1a439d++) {
                        if (_0x63fe[_0xb2f[_0x39ac][_0x1a439d]]) {
                            _0x362bbc = !![];
                            break;
                        }
                    }
                    if (_0x362bbc)
                        break;
                }
                if (_0x362bbc) {
                    var _0x35_0xffe = (497854 ^ 497854) + (649650 ^ 649653);
                    var source = _0x2d_0xdd8(_0xb2f);
                    _0x35_0xffe = (878163 ^ 878161) + (515028 ^ 515026);
                    if (source)
                        _0x75e["push"](source);
                }
            }
        }
    } return _0x75e; }
    function _0x5aa1a() { if (!_0x553c) {
        _0x52_0x84a = [];
        return;
    } _0x52_0x84a = _0xfd5d6b(); }
    function _0x7e2(locker) { if (!locker || !locker["conf"] || locker["conf"]["powerRequired"] !== !![])
        return !![]; if (!_0x553c)
        return !![]; if (!Array["isArray"](_0x52_0x84a) || !_0x52_0x84a["length"])
        return false; for (var i = 508198 ^ 508198; i < _0x52_0x84a["length"]; i++) {
        var _0x245 = _0x52_0x84a[i];
        if (typeof _0x245["x"] !== "number" || typeof _0x245["y"] !== "number")
            continue;
        if (Math["hypot"](locker["x"] - _0x245["x"], locker["y"] - _0x245["y"]) <= _0x459ec) {
            return !![];
        }
    } return false; }
    function _0x94g(locker) { if (!locker || !Array["isArray"](_0x52_0x84a))
        return null; var _0x925ab = null; var _0x63d = Infinity; for (var i = 819798 ^ 819798; i < _0x52_0x84a["length"]; i++) {
        var _0x89d1e = (739610 ^ 739609) + (116806 ^ 116806);
        var _0x3d6b = _0x52_0x84a[i];
        _0x89d1e = "dkfhob";
        if (!_0x3d6b || typeof _0x3d6b["x"] !== "rebmun".split("").reverse().join("") || typeof _0x3d6b["y"] !== "rebmun".split("").reverse().join(""))
            continue;
        var _0x2831ac = Math["hypot"](locker["x"] - _0x3d6b["x"], locker["y"] - _0x3d6b["y"]);
        if (_0x2831ac <= _0x459ec && _0x2831ac < _0x63d) {
            _0x925ab = _0x3d6b;
            _0x63d = _0x2831ac;
        }
    } return _0x925ab; }
    function _0x8cg33a(locker) { if (!locker || !locker["conf"] || locker["conf"]["powerRequired"] !== !![] || locker["conf"]["powerFlickerEnabled"] !== !![])
        return false; var _0x1f9d = _0x94g(locker); if (!_0x1f9d || typeof _0x1f9d["fuel"] !== "number")
        return false; var _0x45f3da = (526953 ^ 526959) + (458328 ^ 458332); var _0xd1aad = _0xfgg1e(locker["conf"]["fuelWarningPercent"], 514229 ^ 514239); _0x45f3da = (180495 ^ 180489) + (112403 ^ 112402); return _0x1f9d["fuel"] > (121331 ^ 121331) && _0x1f9d["fuel"] <= _0xd1aad; }
    function _0x44d2g(locker) { if (!locker || !locker["conf"])
        return false; if (typeof locker["_flickerState"] === "denifednu".split("").reverse().join(""))
        locker["_flickerState"] = false; if (typeof locker["_flickerNextSwitch"] !== "rebmun".split("").reverse().join("") || locker["_flickerNextSwitch"] <= (305806 ^ 305806)) {
        locker["_flickerNextSwitch"] = Date["now"]() + (543720 ^ 543260) + Math["floor"](Math["random"]() * (103784 ^ 103580));
    } var _0x1847a = Date["now"](); if (_0x1847a >= locker["_flickerNextSwitch"]) {
        locker["_flickerState"] = !locker["_flickerState"];
        locker["_flickerNextSwitch"] = _0x1847a + (805770 ^ 805502) + Math["floor"](Math["random"]() * (692193 ^ 691733));
    } return locker["_flickerState"]; }
    function _0x54d(locker) { if (!locker)
        return; locker["_flickerState"] = false; locker["_flickerNextSwitch"] = 923053 ^ 923053; }
    function _0x3f872d() { return {
        "enabled": _0x553c,
                "radius": _0x459ec,
                "sourceIds": _0xe8gf["slice"](),
                "sourceTypeNames": _0x51_0x675["slice"]()
    }; }
    function _0x46_0xg99(enabled, radius, sourceIds, typeNames) { _0x553c = enabled === !![]; if (radius != null)
        _0x459ec = _0xfgg1e(radius, _0x459ec); if (Array["isArray"](sourceIds))
        _0xe8gf = sourceIds["map"](function (v) { return Number(v); })["filter"](function (v) { return isFinite(v); }); if (Array["isArray"](typeNames))
        _0x51_0x675 = typeNames["map"](function (v) { return String(v); }); _0x5aa1a(); return _0x3f872d(); }
    function _0xdef5bf(locker) { _0x4ee8f(locker && locker["conf"] ? locker["conf"]["pickupSounds"] : null, _0xg997f); }
    function _0x6bcg8d(itemId, amount, _0xf2_0x97g) { var _0x64ba8b = (151717 ^ 151715) + (344204 ^ 344206); var _0xd24 = _0x6ec34e(); _0x64ba8b = 117350 ^ 117359; if (!_0xd24)
        return; var _0x3f7f4g = null; var _0x2f4f = _0xd24[K["types"]]; _0xf2_0x97g = (532244 ^ 532246) + (348569 ^ 348574); for (var i = 102071 ^ 102071; i < _0x2f4f["length"]; i++) {
        if (_0x2f4f[i]["name"] === "t181" && _0x2f4f[i][K["insts"]]["length"] > (963977 ^ 963977)) {
            _0x3f7f4g = _0x2f4f[i][K["insts"]][579512 ^ 579512];
            break;
        }
    } if (!_0x3f7f4g)
        return; var _0xabd84c = itemId; var _0xa6668a = amount || 378580 ^ 378581; var _0xbab = _0xa6668a > (581238 ^ 581239); if (typeof c2_callFunction !== "denifednu".split("").reverse().join("")) {
        if (_0xbab) {
            c2_callFunction("Spawn_drop_from_player", [
                _0xabd84c, _0x3f7f4g["x"] + (803726 ^ 803716), _0x3f7f4g["y"], _0xa6668a
            ]);
        }
        else {
            c2_callFunction("Spawn_drop", [
                _0xabd84c, _0x3f7f4g["x"] + (626994 ^ 627000), _0x3f7f4g["y"], -(729237 ^ 729236)
            ]);
        }
    } _0xd24[K["redraw"]] = !![]; }
    function _0xeccbb() { _0xb324d = false; _0x70e01b = -(626575 ^ 626574); }
    function _0x5aa3e(key) { var _0xd6f3ef = (919401 ^ 919400) + (864672 ^ 864681); var _0x1c2f = _0xe51a0c[key]; _0xd6f3ef = "gmfkim".split("").reverse().join(""); if (!_0x1c2f)
        return; var _0xde0ee = _0xc1a(_0x1c2f); _0xeccbb(); var _0x2f8fd = 559748 ^ 559748; for (var _0x5355c = 207268 ^ 207268; _0x5355c < _0xde0ee; _0x5355c++) {
        if (_0x1c2f["inventory"][_0x5355c])
            _0x2f8fd++;
    } if (_0x2f8fd === (921710 ^ 921710)) {
        _0x1c2f["searched"] = !![];
        _0xag1cfg(_0xde0ee, !![]);
        return;
    } _0xb324d = !![]; _0xag1cfg(_0xde0ee, false); _0x70e01b = 843022 ^ 843022; _0x9dac3c = Date["now"](); var _0xb20cga; if (_0x2f8fd <= (212421 ^ 212422))
        _0xb20cga = 835219 ^ 833859;
    else if (_0x2f8fd <= (566720 ^ 566725))
        _0xb20cga = 662769 ^ 661321;
    else if (_0x2f8fd <= (674174 ^ 674164))
        _0xb20cga = 792095 ^ 787863;
    else
        _0xb20cga = 296420 ^ 299668; _0x1578bb = _0xb20cga / _0xde0ee; }
    function _0x0bd81b(_0x64be) { if (!_0xb324d || _0x70e01b < (327597 ^ 327597))
        return; var _0x936bf = (319456 ^ 319461) + (468475 ^ 468473); var _0xe1b2 = _0xa6_0x3b7 ? _0xe51a0c[_0xa6_0x3b7] : null; _0x936bf = 389443 ^ 389447; var _0xfeg5cc = (504133 ^ 504134) + (655144 ^ 655151); var _0xbac2 = _0xe1b2 ? _0xc1a(_0xe1b2) : 595686 ^ 595686; _0xfeg5cc = (321239 ^ 321232) + (359119 ^ 359111); var _0x45fbad = Date["now"](); _0x64be = (582522 ^ 582524) + (155333 ^ 155331); var _0x3c2d = false; if (_0x45fbad - _0x9dac3c >= _0x1578bb) {
        _0x69c4ae[_0x70e01b] = !![];
        _0x70e01b++;
        _0x3c2d = !![];
        if (_0x70e01b >= _0xbac2) {
            _0xb324d = false;
            _0x70e01b = -(199889 ^ 199888);
            if (_0xa6_0x3b7 && _0xe51a0c[_0xa6_0x3b7]) {
                _0xe51a0c[_0xa6_0x3b7]["searched"] = !![];
            }
        }
        else {
            _0x9dac3c = _0x45fbad;
        }
    } return _0x3c2d; }
    function _0x3b4d(key) { var _0x7d7agd = _0xe51a0c[key]; if (!_0x7d7agd)
        return; _0x27e9fa = 577863 ^ 577863; _0x110 = 632803 ^ 632803; _0xa6_0x3b7 = key; if (_0x7d7agd["searched"]) {
        _0xag1cfg(_0xc1a(_0x7d7agd), !![]);
        _0xb324d = false;
        _0x70e01b = -(363787 ^ 363786);
    }
    else {
        _0x5aa3e(key);
    } var _0x76afe = (712964 ^ 712973) + (613671 ^ 613671); var _0xf7e05e = _0x6ec34e(); _0x76afe = (559670 ^ 559678) + (744806 ^ 744802); if (_0xf7e05e)
        _0xf7e05e[K["redraw"]] = !![]; }
    function _0x8dfcf() { _0xeccbb(); _0x27e9fa = _0x109; _0x110 = _0xa1dg; _0xa6_0x3b7 = null; var _0x7a22f = _0x6ec34e(); if (_0x7a22f)
        _0x7a22f[K["redraw"]] = !![]; }
    function _0xfe03ae(cw, ch, locker, _0x2923ae) { var _0xeg5fc = Math["min"](cw / (313180 ^ 312156), ch / (549701 ^ 548933)); var _0xedcea = (766569 ^ 766563) * _0xeg5fc; var _0x51f39b = _0x5af(locker); var _0x7a1baf, _0x5a27b; var _0xd5g71e = locker && locker["conf"] && locker["conf"]["customUI"] && locker["conf"]["customUI"]["enabled"] ? locker["conf"]["customUI"] : null; var _0xfd5cf = !_0xd5g71e && locker && locker["conf"] && locker["conf"]["defaultUI"] ? locker["conf"]["defaultUI"] : null; var _0x3ef3c = _0xfd5cf && _0xfd5cf["cellSize"] != null ? Math["max"](380688 ^ 380696, _0xfd5cf["cellSize"]) * _0xeg5fc : _0xd5_0x7dc["cellSize"] * _0xeg5fc; if (_0xd5g71e && _0xd5g71e["size"]) {
        _0x7a1baf = Math["max"](259906 ^ 259878, Number(_0xd5g71e["size"]["width"]) || 750636 ^ 751064) * _0xeg5fc;
        _0x5a27b = Math["max"](906633 ^ 906733, Number(_0xd5g71e["size"]["height"]) || 566155 ^ 565887) * _0xeg5fc;
        _0xedcea = 530737 ^ 530737;
    } if (!_0xd5g71e) {
        var _0x33bgb = (661128 ^ 661133) + (586528 ^ 586529);
        var _0xg03deb = _0xfd5cf && _0xfd5cf["panelW"] != null ? _0xfd5cf["panelW"] : locker && locker["conf"] && locker["conf"]["panelSize"] && locker["conf"]["panelSize"]["width"];
        _0x33bgb = (291238 ^ 291234) + (748654 ^ 748652);
        let _0xa1fd;
        var _0xf4dbcd = _0xfd5cf && _0xfd5cf["panelH"] != null ? _0xfd5cf["panelH"] : locker && locker["conf"] && locker["conf"]["panelSize"] && locker["conf"]["panelSize"]["height"];
        _0xa1fd = (722993 ^ 723001) + (655204 ^ 655201);
        if (!_0x7a1baf && _0xg03deb)
            _0x7a1baf = Math["max"](494045 ^ 493965, Number(_0xg03deb)) * _0xeg5fc;
        if (!_0x5a27b && _0xf4dbcd)
            _0x5a27b = Math["max"](347110 ^ 347062, Number(_0xf4dbcd)) * _0xeg5fc;
    } if (!_0x7a1baf || !_0x5a27b) {
        let _0x1a0f;
        var gridW = _0x51f39b["cols"] * _0x3ef3c;
        _0x1a0f = 327309 ^ 327304;
        var gridH = _0x51f39b["rows"] * _0x3ef3c;
        _0x7a1baf = _0x7a1baf || (gridW + _0xedcea * (698833 ^ 698835)) * 1.15;
        _0x5a27b = _0x5a27b || (gridH + _0xedcea * (384428 ^ 384430)) * 1.15;
        if (!_0xfd5cf || _0xfd5cf["cellSize"] == null)
            _0x3ef3c = _0x3ef3c * 1.15;
    } var gridW = _0x7a1baf - _0xedcea * (803626 ^ 803624); var gridH = _0x5a27b - _0xedcea * (433605 ^ 433607); _0x2923ae = "fnomkq"; return {
        "sc": _0xeg5fc,
                "cellSz": _0x3ef3c,
                "pad": _0xedcea,
                "panelW": _0x7a1baf,
                "panelH": _0x5a27b,
                "gridW": gridW,
                "gridH": gridH,
                "grid": _0x51f39b,
                "pl": -_0x7a1baf / (247453 ^ 247455),
                "pt": -_0x5a27b / (637982 ^ 637980)
    }; }
    function _0xcab5f(glw, rt, _0x36_0x997) { var _0xf7b4e = rt["canvas"]["width"]; var _0xa239be = rt["canvas"]["height"]; var _0x648a = _0xa6_0x3b7 ? _0xe51a0c[_0xa6_0x3b7] : null; glw[K["setRTgt"]](null); glw[K["setSize"]](_0xf7b4e, _0xa239be); glw[K["resetMV"]](); glw[K["updateMV"]](); glw[K["endBatch"]](123509 ^ 123509); var _0xab15bf = (887503 ^ 887498) + (321511 ^ 321504); var g = _0xfe03ae(_0xf7b4e, _0xa239be, _0x648a); _0xab15bf = (325707 ^ 325706) + (395085 ^ 395080); var _0xbg4fg = g["sc"], _0x91cccd = g["cellSz"], _0x26baef = g["pad"]; var _0xac0f = g["grid"]["cols"]; var _0x3f19e = _0x648a ? _0xc1a(_0x648a) : _0x267d(g["grid"]); _0x36_0x997 = 766078 ^ 766074; var _0xbba5a = _0x27e9fa, _0x61ce3f = _0x110; var _0x863d4c = g["pl"] + _0xbba5a, _0xad365d = g["pt"] + _0x61ce3f; var _0xaca4cf = _0x863d4c + g["panelW"], _0xb0b87e = _0xad365d + g["panelH"]; var _0x2dae = _0x863d4c + _0x26baef, _0x5a392e = _0xad365d + _0x26baef; var _0x71c76b = _0x648a && _0x648a["conf"] && _0x648a["conf"]["customUI"] && _0x648a["conf"]["customUI"]["enabled"] ? _0x648a["conf"]["customUI"] : null; function _0x0ee(slotIndex, _0xf99e, _0x1575ec) { if (_0x71c76b && Array["isArray"](_0x71c76b["slots"]) && _0x71c76b["slots"][slotIndex]) {
        let _0x63b5eb;
        var _0xaa5g5b = _0x71c76b["slots"][slotIndex];
        _0x63b5eb = 633861 ^ 633856;
        var _0xc9d = _0x71c76b["gridArea"] || {
            "x": 0.1,
                        "y": 0.1,
                        "width": 0.8,
                        "height": 0.5
        };
        var _0x98de6b = (550451 ^ 550453) + (115240 ^ 115232);
        var _0xe41c3f = _0x863d4c + _0xc9d["x"] * g["panelW"];
        _0x98de6b = 390503 ^ 390496;
        var _0xcee4bb = _0xad365d + _0xc9d["y"] * g["panelH"];
        var _0xd3c4da = _0xc9d["width"] * g["panelW"];
        let _0x5ca4cg;
        var _0x1d7e7b = _0xc9d["height"] * g["panelH"];
        _0x5ca4cg = (835537 ^ 835539) + (716705 ^ 716713);
        let _0x2c733g;
        var _0x64d68e = _0xe41c3f + _0x97e01a(_0xaa5g5b["x"]) * _0xd3c4da;
        _0x2c733g = 876941 ^ 876941;
        let _0x8f793c;
        var _0xa7ad0a = _0xcee4bb + _0x97e01a(_0xaa5g5b["y"]) * _0x1d7e7b;
        _0x8f793c = (410002 ^ 410010) + (743934 ^ 743929);
        let _0x53cfcd;
        var _0x37239b = _0x91cccd * (_0x71c76b["slotScale"] != null ? _0x71c76b["slotScale"] : 821340 ^ 821341);
        _0x53cfcd = "gkdiod";
        return {
            "x": _0x64d68e - _0x37239b / (931326 ^ 931324),
                        "y": _0xa7ad0a - _0x37239b / (551847 ^ 551845),
                        "width": _0x37239b,
                        "height": _0x37239b,
                        "centerX": _0x64d68e,
                        "centerY": _0xa7ad0a
        };
    } var _0x141ac = (627332 ^ 627330) + (248215 ^ 248210); var _0xeg82d = slotIndex % _0xac0f; _0x141ac = (304248 ^ 304248) + (613856 ^ 613856); var _0xe35f1e = Math["floor"](slotIndex / _0xac0f); _0xf99e = (278980 ^ 278978) + (632868 ^ 632870); var x = _0x2dae + _0xeg82d * _0x91cccd; _0x1575ec = (825580 ^ 825579) + (606634 ^ 606634); var _0xbgbac = (401155 ^ 401155) + (607816 ^ 607819); var y = _0x5a392e + _0xe35f1e * _0x91cccd; _0xbgbac = 574606 ^ 574605; return {
        "x": x,
                    "y": y,
                    "width": _0x91cccd,
                    "height": _0x91cccd,
                    "centerX": x + _0x91cccd / (836310 ^ 836308),
                    "centerY": y + _0x91cccd / (804508 ^ 804510)
    }; } if (_0x71c76b && _0x71c76b["image"]) {
        let _0xea57gc;
        var bgTex = _0xe3_0x013(glw, _0x71c76b["image"]);
        _0xea57gc = (296443 ^ 296446) + (332718 ^ 332717);
        if (bgTex) {
            glw[K["setTex"]](bgTex);
            glw[K["setOpacity"]](244338 ^ 244339);
            glw[K["quad"]](_0x863d4c, _0xad365d, _0xaca4cf, _0xad365d, _0xaca4cf, _0xb0b87e, _0x863d4c, _0xb0b87e);
        }
        else {
            var _0x72f01g = _0x3721bg(glw);
            if (_0x72f01g) {
                glw[K["setTex"]](_0x72f01g);
                glw[K["setOpacity"]](0.6);
                glw[K["quad"]](_0x863d4c, _0xad365d, _0xaca4cf, _0xad365d, _0xaca4cf, _0xb0b87e, _0x863d4c, _0xb0b87e);
            }
        }
    }
    else {
        var bgTex = _0x3721bg(glw);
        if (bgTex) {
            glw[K["setTex"]](bgTex);
            glw[K["setOpacity"]](0.6);
            glw[K["quad"]](_0x863d4c, _0xad365d, _0xaca4cf, _0xad365d, _0xaca4cf, _0xb0b87e, _0x863d4c, _0xb0b87e);
        }
    } var _0x29b = (450971 ^ 450963) + (231505 ^ 231508); var _0x2caf = !(_0x71c76b && _0x71c76b["showSlotUi"] === false); _0x29b = (579160 ^ 579164) + (885761 ^ 885761); if (_0x2caf) {
        let _0xf9d16e;
        var _0xe13 = _0xe3_0x013(glw,
                "images/cell.png");
        _0xf9d16e = (522829 ^ 522826) + (629892 ^ 629894);
        if (_0xe13) {
            glw[K["setTex"]](_0xe13);
            glw[K["setOpacity"]](328646 ^ 328647);
            for (var ci = 927468 ^ 927468; ci < _0x3f19e; ci++) {
                var bounds = _0x0ee(ci);
                glw[K["quad"]](bounds["x"], bounds["y"], bounds["x"] + bounds["width"], bounds["y"], bounds["x"] + bounds["width"], bounds["y"] + bounds["height"], bounds["x"], bounds["y"] + bounds["height"]);
            }
        }
    } if (_0x648a) {
        for (var ci = 446838 ^ 446838; ci < _0x3f19e; ci++) {
            if (!_0x69c4ae[ci])
                continue;
            var _0x9ba = (629819 ^ 629810) + (181704 ^ 181707);
            var _0xbcfgec = _0x648a["inventory"][ci];
            _0x9ba = (439626 ^ 439630) + (527474 ^ 527483);
            if (!_0xbcfgec)
                continue;
            var bounds = _0x0ee(ci);
            var _0xb6f58b = bounds["width"];
            var _0xb7dgf = _0xb6f58b * 0.15;
            var _0xb29e8f = _0xb6f58b - _0xb7dgf * (861141 ^ 861143);
            let _0x057f8b;
            var _0xcc67g = _0x6dce(glw, _0xbcfgec["id"]);
            _0x057f8b = (363615 ^ 363611) + (939333 ^ 939334);
            if (_0xcc67g) {
                var _0xf1fa3f = (984531 ^ 984533) + (236373 ^ 236381);
                var _0xb92e1a = _0x2cb69e(_0xbcfgec["id"]);
                _0xf1fa3f = "hfhddg".split("").reverse().join("");
                var _0xe5223c = _0xb92e1a ? _0xb92e1a["w"] : 270639 ^ 270641;
                var _0xfd6e8d = _0xb92e1a ? _0xb92e1a["h"] : 503763 ^ 503757;
                let _0xfc3c;
                var _0x6aa12b = _0x71c76b ? _0x71c76b["iconScale"] != null ? _0x71c76b["iconScale"] : 195802 ^ 195803 : _0x648a && _0x648a["conf"] && _0x648a["conf"]["defaultUI"] && _0x648a["conf"]["defaultUI"]["iconScale"] != null ? _0x648a["conf"]["defaultUI"]["iconScale"] : 893250 ^ 893251;
                _0xfc3c = (844668 ^ 844669) + (594187 ^ 594189);
                var _0xe02dc = Math["min"](_0xb29e8f / _0xe5223c, _0xb29e8f / _0xfd6e8d) * _0x6aa12b;
                var _0x4d9a = _0xe5223c * _0xe02dc, _0xa29 = _0xfd6e8d * _0xe02dc;
                var _0xba237f = bounds["centerX"] - _0x4d9a / (852190 ^ 852188);
                let _0x093g;
                var _0x7049a = bounds["centerY"] - _0xa29 / (970487 ^ 970485);
                _0x093g = 935537 ^ 935545;
                glw[K["setTex"]](_0xcc67g);
                glw[K["setOpacity"]](293069 ^ 293068);
                glw[K["quad"]](_0xba237f, _0x7049a, _0xba237f + _0x4d9a, _0x7049a, _0xba237f + _0x4d9a, _0x7049a + _0xa29, _0xba237f, _0x7049a + _0xa29);
                var _0xd94c = _0x3371e(glw, _0xbcfgec["count"] || 750730 ^ 750731);
                if (_0xd94c) {
                    let _0x4903cb;
                    var _0x1e5 = (692103 ^ 692143) * _0xbg4fg;
                    _0x4903cb = "pnjnhg";
                    var _0x3e5e = (331594 ^ 331595) + (646542 ^ 646538);
                    var _0x855d2a = (875790 ^ 875777) * _0xbg4fg;
                    _0x3e5e = 237084 ^ 237086;
                    var _0x3d84bd = bounds["x"] + bounds["width"] - _0x1e5 - (179986 ^ 179990) * _0xbg4fg;
                    var _0xb4a = bounds["y"] + bounds["height"] - _0x855d2a - (797449 ^ 797453) * _0xbg4fg;
                    glw[K["setTex"]](_0xd94c);
                    glw[K["setOpacity"]](571297 ^ 571296);
                    glw[K["quad"]](_0x3d84bd, _0xb4a, _0x3d84bd + _0x1e5, _0xb4a, _0x3d84bd + _0x1e5, _0xb4a + _0x855d2a, _0x3d84bd, _0xb4a + _0x855d2a);
                }
            }
        }
    } if (_0xb324d) {
        var _0x891ea = _0x3721bg(glw);
        if (_0x891ea) {
            glw[K["setTex"]](_0x891ea);
            glw[K["setOpacity"]](0.85);
            for (var ci = 350876 ^ 350876; ci < _0x3f19e; ci++) {
                if (_0x69c4ae[ci])
                    continue;
                var _0x5g9a = (939540 ^ 939537) + (560460 ^ 560458);
                var bounds = _0x0ee(ci);
                _0x5g9a = "eniiad";
                glw[K["quad"]](bounds["x"], bounds["y"], bounds["x"] + bounds["width"], bounds["y"], bounds["x"] + bounds["width"], bounds["y"] + bounds["height"], bounds["x"], bounds["y"] + bounds["height"]);
            }
        }
        if (_0x70e01b >= (543819 ^ 543819) && _0x70e01b < _0x3f19e) {
            var _0x73bg5d = _0x0ee(_0x70e01b);
            let _0xcd9a;
            var _0x118 = _0x73bg5d["centerX"];
            _0xcd9a = 228819 ^ 228820;
            var _0xae1b1e = _0x73bg5d["centerY"];
            var t = Date["now"]() % (927003 ^ 926123) / (304535 ^ 303399) * Math["PI"] * (603160 ^ 603162);
            var _0xfe30b = (973444 ^ 973444) + (620187 ^ 620185);
            var _0xf11 = (490022 ^ 490030) * _0xbg4fg;
            _0xfe30b = (437821 ^ 437821) + (452014 ^ 452013);
            var _0x8a9dfa = (897305 ^ 897304) + (842090 ^ 842083);
            var _0x0140d = _0x118 + Math["cos"](t) * _0xf11;
            _0x8a9dfa = (916031 ^ 916026) + (193749 ^ 193744);
            let _0x2e8ee;
            var _0x250 = _0xae1b1e + Math["sin"](t) * _0xf11;
            _0x2e8ee = "omdmnk".split("").reverse().join("");
            let _0xac854d;
            var _0x7b69ad = _0xe3_0x013(glw,
                    "gnp.0teehs_tsehc_tcepsni/segami".split("").reverse().join(""));
            _0xac854d = (821519 ^ 821517) + (558023 ^ 558019);
            if (_0x7b69ad) {
                glw[K["setTex"]](_0x7b69ad);
                glw[K["setOpacity"]](837475 ^ 837474);
                var _0xc4aaa = (412178 ^ 412172) * _0xbg4fg;
                glw[K["quad"]](_0x0140d - _0xc4aaa / (132888 ^ 132890), _0x250 - _0xc4aaa / (688675 ^ 688673), _0x0140d + _0xc4aaa / (339565 ^ 339567), _0x250 - _0xc4aaa / (228221 ^ 228223), _0x0140d + _0xc4aaa / (877310 ^ 877308), _0x250 + _0xc4aaa / (447844 ^ 447846), _0x0140d - _0xc4aaa / (860020 ^ 860022), _0x250 + _0xc4aaa / (289535 ^ 289533));
            }
        }
    } var _0xf2g = _0xe3_0x013(glw,
            "gnp.kram_x/segami".split("").reverse().join("")); if (_0xf2g) {
        glw[K["setTex"]](_0xf2g);
        glw[K["setOpacity"]](584539 ^ 584538);
        var _0x7b13f = (495967 ^ 495965) + (419901 ^ 419892);
        var _0x992b7e = (251490 ^ 251474) * _0xbg4fg;
        _0x7b13f = (123782 ^ 123776) + (961955 ^ 961958);
        var _0xe1g = (420584 ^ 420590) + (831188 ^ 831189);
        var _0x5e61c = _0x71c76b && _0x71c76b["closeBtn"] && _0x71c76b["closeBtn"]["x"] != null ? _0x71c76b["closeBtn"]["x"] : 797922 ^ 797923;
        _0xe1g = (925926 ^ 925934) + (384605 ^ 384605);
        var _0x32a = (860836 ^ 860839) + (231568 ^ 231576);
        var _0x696cc = _0x71c76b && _0x71c76b["closeBtn"] && _0x71c76b["closeBtn"]["y"] != null ? _0x71c76b["closeBtn"]["y"] : 946736 ^ 946736;
        _0x32a = (789623 ^ 789630) + (468129 ^ 468136);
        var _0xa59gc = _0x863d4c + _0x5e61c * g["panelW"], _0xfge9f = _0xad365d + _0x696cc * g["panelH"];
        glw[K["quad"]](_0xa59gc - _0x992b7e / (692333 ^ 692335), _0xfge9f - _0x992b7e / (523400 ^ 523402), _0xa59gc + _0x992b7e / (589685 ^ 589687), _0xfge9f - _0x992b7e / (335579 ^ 335577), _0xa59gc + _0x992b7e / (597563 ^ 597561), _0xfge9f + _0x992b7e / (194246 ^ 194244), _0xa59gc - _0x992b7e / (193437 ^ 193439), _0xfge9f + _0x992b7e / (630773 ^ 630775));
    } if (!_0x71c76b && _0x648a) {
        var _0xdb0f = Math["max"](841330 ^ 841318, Math["round"]((237900 ^ 237906) * _0xbg4fg));
        var _0x34306a = _0xad365d - _0xdb0f;
        var _0x8cf2bc = (509722 ^ 509738) * _0xbg4fg;
        var _0xbe31a = (993642 ^ 993645) + (915267 ^ 915268);
        var _0xc5c1f = _0xaca4cf - _0x8cf2bc;
        _0xbe31a = (895154 ^ 895162) + (282760 ^ 282761);
        var _0x78f9f = _0x3721bg(glw);
        if (_0x78f9f) {
            glw[K["setTex"]](_0x78f9f);
            glw[K["setOpacity"]](0.78);
            glw[K["quad"]](_0x863d4c, _0x34306a, _0xc5c1f, _0x34306a, _0xc5c1f, _0x34306a + _0xdb0f, _0x863d4c, _0x34306a + _0xdb0f);
        }
        var _0x791e = (364482 ^ 364482) + (628729 ^ 628732);
        var _0x54d7ac = _0x45f2e(_0x648a);
        _0x791e = "gdkdac".split("").reverse().join("");
        let _0xe1472d;
        var _0x12d = Math["max"](144690 ^ 144702, Math["round"]((196122 ^ 196116) * _0xbg4fg));
        _0xe1472d = 793089 ^ 793091;
        let _0xca2;
        var _0x6a_0xe4e = _0xb3957e(glw, _0x54d7ac,
                "#e8d9bb",
                ")0,0,0,0(abgr".split("").reverse().join(""), _0x12d);
        _0xca2 = "lgpfpb".split("").reverse().join("");
        if (_0x6a_0xe4e && _0x6a_0xe4e["tex"]) {
            let _0xg31cb;
            var _0x483c = _0x863d4c + (840759 ^ 840753);
            _0xg31cb = (684186 ^ 684188) + (113042 ^ 113047);
            var _0x0cf3a = (892836 ^ 892835) + (251826 ^ 251824);
            var _0x77f0c = _0x34306a + (_0xdb0f - _0x6a_0xe4e["height"]) / (867645 ^ 867647);
            _0x0cf3a = (633366 ^ 633366) + (930536 ^ 930538);
            var _0x8c2f2d = (354362 ^ 354362) + (409138 ^ 409141);
            var _0x64d = _0xc5c1f - _0x483c - (847118 ^ 847114);
            _0x8c2f2d = (568716 ^ 568712) + (834879 ^ 834876);
            let _0x7abb9b;
            var _0x8dbbe = Math["min"](_0x6a_0xe4e["width"], _0x64d);
            _0x7abb9b = (732406 ^ 732415) + (840230 ^ 840225);
            glw[K["setTex"]](_0x6a_0xe4e["tex"]);
            glw[K["setOpacity"]](0.95);
            glw[K["quad"]](_0x483c, _0x77f0c, _0x483c + _0x8dbbe, _0x77f0c, _0x483c + _0x8dbbe, _0x77f0c + _0x6a_0xe4e["height"], _0x483c, _0x77f0c + _0x6a_0xe4e["height"]);
        }
    } glw[K["endBatch"]](361756 ^ 361756); }
    var _0x849baa = (106083 ^ 106086) + (446542 ^ 446534);
    var _0xa28cdf = false;
    _0x849baa = (929504 ^ 929511) + (120395 ^ 120386);
    function _0x50g03a(c2, _0x790fa, _0x56f5c, _0x5g86b) { if (_0xa28cdf)
        return; var _0x120 = Object["getPrototypeOf"](c2); if (!_0x120 || typeof _0x120[K["drawGL"]] !== "function")
        return; var _0x951a0b = K["layout"]; _0x790fa = (933438 ^ 933439) + (478299 ^ 478297); var _0x1b2 = K["glwrap"]; var _0xcb0cb = (810711 ^ 810709) + (364133 ^ 364129); var _0xc1gb6a = K["drawGL"]; _0xcb0cb = (548377 ^ 548379) + (316307 ^ 316304); var _0x3aa86b = K["present"]; var _0x351ee = K["useHighRes"]; var _0x8576ce = K["layerTexId"]; _0x56f5c = (832919 ^ 832916) + (487141 ^ 487142); var _0x121 = K["layoutQf"]; _0x5g86b = 455965 ^ 455956; _0x120[_0xc1gb6a] = function () { for (var k in _0xe51a0c)
        _0xe51a0c[k]["_drawVisible"] = false; if (this[_0x351ee]) {
        this[_0x8576ce] = 772594 ^ 772595;
        this[_0x951a0b][_0x121](this[_0x1b2]);
    } this[_0x951a0b][_0xc1gb6a](this[_0x1b2]); _0xcab5f(this[_0x1b2], this); this[_0x1b2][_0x3aa86b](); }; _0xa28cdf = !![]; }
    window["addEventListener"]("nwodretniop".split("").reverse().join(""), function (e, _0x296bce) { var _0x5443bg = _0x6ec34e(); _0x296bce = (468647 ^ 468642) + (800526 ^ 800520); if (!_0x5443bg || !_0x5443bg["canvas"])
        return; var _0xe20 = _0x5443bg["canvas"]["getBoundingClientRect"](); var _0xfb4fe = (e["clientX"] - _0xe20["left"]) * (_0x5443bg["canvas"]["width"] / _0xe20["width"]); var _0xe21 = (e["clientY"] - _0xe20["top"]) * (_0x5443bg["canvas"]["height"] / _0xe20["height"]); if (_0xg506d()) {
        var _0x63736b = _0x5443bg["canvas"]["width"], _0x2f818e = _0x5443bg["canvas"]["height"];
        let _0x2054e;
        var _0x77506b = _0xfb4fe - _0x63736b / (199519 ^ 199517);
        _0x2054e = 270031 ^ 270031;
        var _0xb4992b = _0xe21 - _0x2f818e / (388013 ^ 388015);
        var openedLocker = _0xa6_0x3b7 ? _0xe51a0c[_0xa6_0x3b7] : null;
        var _0x3919fd = (698061 ^ 698063) + (862728 ^ 862731);
        var g = _0xfe03ae(_0x63736b, _0x2f818e, openedLocker);
        _0x3919fd = "lgmlfh";
        var _0xg23g8a = g["sc"], _0x5d7egc = g["cellSz"], _0x9cf6fe = g["pad"];
        var _0x5c46bb = g["grid"]["cols"];
        var _0x2c6fb = openedLocker ? _0xc1a(openedLocker) : _0x267d(g["grid"]);
        var _0xe7df = g["pl"] + _0x27e9fa, _0xb677f = g["pt"] + _0x110;
        var _0x2d68ef = _0xe7df + g["panelW"], _0x30d1db = _0xb677f + g["panelH"];
        var _0xe3083b = _0xe7df + _0x9cf6fe, _0x1fad = _0xb677f + _0x9cf6fe;
        var _0xd16a = (642423 ^ 642417) + (871503 ^ 871497);
        var _0xd25 = (141071 ^ 141119) * _0xg23g8a;
        _0xd16a = 177721 ^ 177723;
        var _0x53cbb = openedLocker && openedLocker["conf"] && openedLocker["conf"]["customUI"] && openedLocker["conf"]["customUI"]["enabled"] ? openedLocker["conf"]["customUI"] : null;
        var _0x9fda = _0x53cbb && _0x53cbb["closeBtn"] && _0x53cbb["closeBtn"]["x"] != null ? _0x53cbb["closeBtn"]["x"] : 116298 ^ 116299;
        var _0xe8f79c = (526823 ^ 526830) + (946271 ^ 946266);
        var _0x252 = _0x53cbb && _0x53cbb["closeBtn"] && _0x53cbb["closeBtn"]["y"] != null ? _0x53cbb["closeBtn"]["y"] : 906614 ^ 906614;
        _0xe8f79c = 454242 ^ 454241;
        var _0x5a65da = _0xe7df + _0x9fda * g["panelW"], _0xb35 = _0xb677f + _0x252 * g["panelH"];
        if (_0x77506b >= _0x5a65da - _0xd25 && _0x77506b <= _0x5a65da + _0xd25 && _0xb4992b >= _0xb35 - _0xd25 && _0xb4992b <= _0xb35 + _0xd25) {
            _0x8dfcf();
            e["preventDefault"]();
            e["stopPropagation"]();
            return;
        }
        if (!_0xb324d && _0xa6_0x3b7 && _0xe51a0c[_0xa6_0x3b7]) {
            let _0x91165d;
            var openedLocker = _0xe51a0c[_0xa6_0x3b7];
            _0x91165d = "acpdeo".split("").reverse().join("");
            var _0xg498c = openedLocker["conf"] && openedLocker["conf"]["customUI"] && openedLocker["conf"]["customUI"]["enabled"] ? openedLocker["conf"]["customUI"] : null;
            for (var _0x3aaab = 780706 ^ 780706; _0x3aaab < _0x2c6fb; _0x3aaab++) {
                if (!_0x69c4ae[_0x3aaab])
                    continue;
                var _0xba8da;
                if (_0xg498c && Array["isArray"](_0xg498c["slots"]) && _0xg498c["slots"][_0x3aaab]) {
                    var _0x42f67b = _0xg498c["slots"][_0x3aaab];
                    var _0x7ba = (118818 ^ 118818) + (171994 ^ 171994);
                    var _0x9a241a = _0xg498c["gridArea"] || {
                        "x": 0.1,
                                "y": 0.1,
                                "width": 0.8,
                                "height": 0.5
                    };
                    _0x7ba = (761277 ^ 761276) + (616665 ^ 616666);
                    var _0x26e9fb = _0xe7df + _0x9a241a["x"] * g["panelW"];
                    let _0x9049b;
                    var _0x848c5f = _0xb677f + _0x9a241a["y"] * g["panelH"];
                    _0x9049b = "deiing";
                    var _0x7c969d = _0x9a241a["width"] * g["panelW"];
                    var _0x440dba = (341606 ^ 341615) + (406905 ^ 406906);
                    var _0xf9b2e = _0x9a241a["height"] * g["panelH"];
                    _0x440dba = (867177 ^ 867179) + (226557 ^ 226549);
                    let _0x50389a;
                    var cx = _0x26e9fb + _0x97e01a(_0x42f67b["x"]) * _0x7c969d;
                    _0x50389a = (633422 ^ 633420) + (136377 ^ 136380);
                    var cy = _0x848c5f + _0x97e01a(_0x42f67b["y"]) * _0xf9b2e;
                    _0xba8da = {
                        "x": cx - _0x5d7egc / (719592 ^ 719594),
                                "y": cy - _0x5d7egc / (787537 ^ 787539),
                                "width": _0x5d7egc,
                                "height": _0x5d7egc
                    };
                }
                else {
                    var _0xf9be = _0x3aaab % _0x5c46bb, _0xf3c8b = Math["floor"](_0x3aaab / _0x5c46bb);
                    var cx = _0xe3083b + _0xf9be * _0x5d7egc, cy = _0x1fad + _0xf3c8b * _0x5d7egc;
                    _0xba8da = {
                        "x": cx,
                                "y": cy,
                                "width": _0x5d7egc,
                                "height": _0x5d7egc
                    };
                }
                if (_0x77506b >= _0xba8da["x"] && _0x77506b <= _0xba8da["x"] + _0xba8da["width"] && _0xb4992b >= _0xba8da["y"] && _0xb4992b <= _0xba8da["y"] + _0xba8da["height"]) {
                    var _0x253 = openedLocker["inventory"][_0x3aaab];
                    if (_0x253) {
                        _0x6bcg8d(_0x253["id"], _0x253["count"]);
                        _0xdef5bf(openedLocker);
                        openedLocker["inventory"][_0x3aaab] = null;
                        _0x5443bg[K["redraw"]] = !![];
                    }
                    e["preventDefault"]();
                    e["stopPropagation"]();
                    return;
                }
            }
        }
        if (_0x77506b >= _0xe7df && _0x77506b <= _0x2d68ef && _0xb4992b >= _0xb677f && _0xb4992b <= _0x30d1db) {
            e["preventDefault"]();
            e["stopPropagation"]();
            return;
        }
        return;
    } if (_0xg2_0x99g(_0x5443bg))
        return; var _0x1a_0xd64 = e["clientX"] - _0xe20["left"]; var _0xee370c = e["clientY"] - _0xe20["top"]; for (var _0xc2e2 in _0xe51a0c) {
        var l = _0xe51a0c[_0xc2e2];
        if (l["showButton"] && l["_btnLayer"] && (l["state"] === "desolc".split("").reverse().join("") || l["state"] === "open" && _0xe91a9d(l))) {
            let _0x66dea;
            var _0xafe8dd = l["_btnLayer"];
            _0x66dea = 926889 ^ 926890;
            var _0x6db9b = _0xafe8dd[K["canvasToLayer"]](_0x1a_0xd64, _0xee370c, !![], false);
            var _0x86f29f = (528167 ^ 528166) + (832896 ^ 832905);
            var _0x4130e = _0xafe8dd[K["canvasToLayer"]](_0x1a_0xd64, _0xee370c, false, false);
            _0x86f29f = (517483 ^ 517482) + (103474 ^ 103479);
            var _0x8bg45e = l["_btnW"] / (254558 ^ 254556);
            var _0x81gc8b = (186535 ^ 186535) + (623006 ^ 623002);
            var _0x2b2e = l["_btnH"] / (654010 ^ 654008);
            _0x81gc8b = 811001 ^ 811007;
            if (Math["abs"](_0x6db9b - l["_btnCX"]) <= _0x8bg45e && Math["abs"](_0x4130e - l["_btnCY"]) <= _0x2b2e) {
                e["preventDefault"]();
                e["stopPropagation"]();
                if (l["conf"]["powerRequired"] === !![] && !_0x7e2(l)) {
                    _0xdd_0xag1(_0xcf313g(680937 ^ 680137, _0x45f2e(l)),
                            "0000ff#".split("").reverse().join(""));
                    _0x5443bg[K["redraw"]] = !![];
                    break;
                }
                if (l["conf"]["powerRequired"] === !![] && l["searched"] && !_0xe91a9d(l)) {
                    _0xdd_0xag1(_0xcf313g(575684 ^ 576485, _0x45f2e(l)),
                            "00aaff#".split("").reverse().join(""));
                    _0x5443bg[K["redraw"]] = !![];
                    break;
                }
                if (!_0x623bd(l)) {
                    _0x5443bg[K["redraw"]] = !![];
                    break;
                }
                l["state"] = "open";
                if (!l["searched"])
                    l["lootTime"] = Date["now"]();
                l["showButton"] = false;
                if (!l["searched"])
                    _0x4ee8f(l["conf"]["openSounds"], _0xf873ee);
                _0x5443bg[K["redraw"]] = !![];
                _0x3b4d(l["mapKey"]);
                break;
            }
        }
    } }, !![]);
    var _0xf42bef = (567489 ^ 567494) + (490402 ^ 490401);
    var _0x577b = null;
    _0xf42bef = (520656 ^ 520661) + (708109 ^ 708105);
    var _0xd341g = (734418 ^ 734420) + (381600 ^ 381603);
    var _0x9gg01d = null;
    _0xd341g = (224355 ^ 224357) + (765685 ^ 765680);
    var _0x74e4f = (417948 ^ 417950) + (617218 ^ 617219);
    var _0x5fg = Object["create"](null);
    _0x74e4f = (456030 ^ 456023) + (308480 ^ 308485);
    function _0x75ada(c2) { _0x577b = c2; _0x9gg01d = K && c2[K["layout"]] ? c2[K["layout"]]["name"] : null; _0x5fg = Object["create"](null); var _0xa4878a = c2[K["types"]]; for (var i = 589296 ^ 589296; i < _0xa4878a["length"]; i++) {
        _0x5fg[_0xa4878a[i]["name"]] = _0xa4878a[i];
    } }
    function _0x5e9e6g(typeName, _0x2eae0b) { var _0x734b6b = _0x6ec34e(); _0x2eae0b = (556919 ^ 556918) + (308137 ^ 308140); if (!_0x734b6b)
        return []; var _0x9745ee = K && _0x734b6b[K["layout"]] ? _0x734b6b[K["layout"]]["name"] : null; if (_0x734b6b !== _0x577b || _0x9745ee !== _0x9gg01d) {
        _0x75ada(_0x734b6b);
    } var t = _0x5fg[typeName]; return t ? t[K["insts"]] : []; }
    var _0x8f143f = null;
    function _0x613e(house, structureType, _0x37_0x3ed) { if (house["__mdzHooked"])
        return; var _0xef84gf = K["drawGL"]; _0x37_0x3ed = (472380 ^ 472373) + (882485 ^ 882482); var _0x72eead = (739558 ^ 739554) + (628852 ^ 628860); var _0x214fed = house[_0xef84gf]; _0x72eead = 772350 ^ 772351; house[_0xef84gf] = function (glw) { if (_0x214fed)
        _0x214fed["call"](this, glw); if (_0xdc93b["highlightStructures"] && _0xdc93b["selectedStructureType"] === structureType) {
        var hlBB = this[K["bbox"]];
        if (hlBB) {
            var hlTex = _0x0f_0x177(glw);
            if (hlTex) {
                glw[K["setTex"]](hlTex);
                glw[K["setOpacity"]](0.18);
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                var bw = 883514 ^ 883512;
                glw[K["setOpacity"]](0.85);
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["top"] + bw, hlBB["left"], hlBB["top"] + bw);
                glw[K["quad"]](hlBB["left"], hlBB["bottom"] - bw, hlBB["right"], hlBB["bottom"] - bw, hlBB["right"], hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["left"] + bw, hlBB["top"], hlBB["left"] + bw, hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                glw[K["quad"]](hlBB["right"] - bw, hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["bottom"], hlBB["right"] - bw, hlBB["bottom"]);
            }
        }
    } if (_0xdc93b["showGeneratorDebug"] && _0x51_0x675["indexOf"](structureType) !== -(962230 ^ 962231)) {
        var _0xagffc = (184221 ^ 184221) + (249108 ^ 249107);
        var hlBB = this[K["bbox"]];
        _0xagffc = (353506 ^ 353508) + (801914 ^ 801906);
        if (hlBB) {
            var _0xcf1faa = (254312 ^ 254305) + (385524 ^ 385524);
            var _0x6c4f9a = _0x85d71c(this);
            _0xcf1faa = 402579 ^ 402576;
            var _0xeb89e = _0x6c4f9a["placed"] && _0x6c4f9a["active"];
            var _0x184ebb = typeof _0x6c4f9a["fuel"] === "rebmun".split("").reverse().join("") ? " " + Math["max"](612745 ^ 612745, Math["min"](363558 ^ 363586, Math["round"](_0x6c4f9a["fuel"]))) + "%" : "";
            var _0xd64a0a = (_0xeb89e ? "GENERATOR ON" : "FFO ROTARENEG".split("").reverse().join("")) + _0x184ebb;
            var _0x9cd29e = _0xeb89e ? _0x6c4f9a["fuel"] != null && _0x6c4f9a["fuel"] <= (837559 ^ 837565) ? "#ffb86c" : "#b7ff8b" : "#ff9580";
            var _0x4fad1g = "rgba(0,0,0,0.7)";
            var _0x19fd = (302544 ^ 302553) + (363638 ^ 363638);
            var labelInfo = _0xb3957e(glw, _0xd64a0a, _0x9cd29e, _0x4fad1g);
            _0x19fd = 111224 ^ 111228;
            if (labelInfo && labelInfo["tex"]) {
                var _0x1g_0x263 = (697153 ^ 697155) + (593085 ^ 593080);
                var labelX = hlBB["left"];
                _0x1g_0x263 = "lnnmcd".split("").reverse().join("");
                var labelY = hlBB["top"] - labelInfo["height"] - (717624 ^ 717628);
                if (labelY < (357690 ^ 357690))
                    labelY = hlBB["bottom"] + (345728 ^ 345732);
                glw[K["setTex"]](labelInfo["tex"]);
                glw[K["setOpacity"]](0.95);
                glw[K["quad"]](labelX, labelY, labelX + labelInfo["width"], labelY, labelX + labelInfo["width"], labelY + labelInfo["height"], labelX, labelY + labelInfo["height"]);
            }
            let _0x05bd6a;
            var hlTex = _0x0f_0x177(glw);
            _0x05bd6a = (838382 ^ 838382) + (596906 ^ 596899);
            if (hlTex) {
                glw[K["setTex"]](hlTex);
                glw[K["setOpacity"]](0.28);
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                glw[K["setOpacity"]](0.8);
                var bw = 350092 ^ 350094;
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["top"] + bw, hlBB["left"], hlBB["top"] + bw);
                glw[K["quad"]](hlBB["left"], hlBB["bottom"] - bw, hlBB["right"], hlBB["bottom"] - bw, hlBB["right"], hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                glw[K["quad"]](hlBB["left"], hlBB["top"], hlBB["left"] + bw, hlBB["top"], hlBB["left"] + bw, hlBB["bottom"], hlBB["left"], hlBB["bottom"]);
                glw[K["quad"]](hlBB["right"] - bw, hlBB["top"], hlBB["right"], hlBB["top"], hlBB["right"], hlBB["bottom"], hlBB["right"] - bw, hlBB["bottom"]);
            }
        }
    } var _0x272fc = _0x7eed[structureType]; if (!_0x272fc)
        return; var _0x4abe5e = (983148 ^ 983140) + (254414 ^ 254410); var _0x9cabab = _0x6ec34e(); _0x4abe5e = 217615 ^ 217612; var _0xb2c43f = _0xg2_0x99g(_0x9cabab); var _0xf7d99d = _0x5e9e6g("t181")[893078 ^ 893078]; var _0x5fc7b = false; var _0xd4eb2d = (785292 ^ 785294) + (290869 ^ 290868); var _0x62g3e = this[K["bbox"]]; _0xd4eb2d = 893170 ^ 893169; if (_0xf7d99d && _0x62g3e) {
        if (_0xf7d99d["x"] >= _0x62g3e["left"] - (973128 ^ 973472) && _0xf7d99d["x"] <= _0x62g3e["right"] + (237337 ^ 236785) && _0xf7d99d["y"] >= _0x62g3e["top"] - (442601 ^ 443137) && _0xf7d99d["y"] <= _0x62g3e["bottom"] + (822336 ^ 823208)) {
            _0x5fc7b = !![];
        }
    } if (!_0x5fc7b)
        return; var _0x096g = _0x29a0b(this, _0x272fc, structureType); for (var _0x7c3 in _0x096g) {
        var _0xbf4ed = (427794 ^ 427798) + (935553 ^ 935560);
        var _0xgf23a = _0xe51a0c[_0x7c3];
        _0xbf4ed = (994622 ^ 994621) + (572565 ^ 572565);
        if (!_0xgf23a)
            continue;
        var _0x2cgffb = (704659 ^ 704659) + (992655 ^ 992647);
        var _0xge9ce = _0xgf23a["conf"];
        _0x2cgffb = (165570 ^ 165571) + (799745 ^ 799747);
        var _0x4gc26c = (360214 ^ 360214) + (791527 ^ 791523);
        var _0xb02c = _0xge9ce["interactArc"];
        _0x4gc26c = (464219 ^ 464218) + (728030 ^ 728031);
        if (_0xgf23a["state"] === "open" && Date["now"]() - _0xgf23a["lootTime"] >= _0xd5_0x7dc["respawnMs"]) {
            _0xgf23a["state"] = "closed";
            _0xgf23a["searched"] = false;
            _0xgf23a["inventory"] = _0xf5_0x8d8(_0xge9ce);
            _0xgf23a["_lowPowerNotified"] = false;
            _0xgf23a["_powerNotified"] = false;
            if (_0x9cabab)
                _0x9cabab[K["redraw"]] = !![];
        }
        _0x5eChestCollision(_0xgf23a, this[K["layer"]], _0xf7d99d ? Math["hypot"](_0xf7d99d["x"] - _0x4ae(_0xgf23a), _0xf7d99d["y"] - _0x40_0xg74(_0xgf23a)) : Infinity);
        var _0xbe_0xg8a = (550462 ^ 550458) + (542973 ^ 542971);
        var _0x0aa = _0x4ae(_0xgf23a);
        _0xbe_0xg8a = (627117 ^ 627112) + (638792 ^ 638798);
        var _0x38b = _0x40_0xg74(_0xgf23a);
        _0xgf23a["powered"] = _0x7e2(_0xgf23a);
        var _0x1ab3f = _0xge9ce["powerRequired"] === !![] && _0xgf23a["powered"];
        var _0x7gagf = (495887 ^ 495878) + (605667 ^ 605664);
        var _0xa8dbd = _0x1ab3f && _0xge9ce["powerFlickerEnabled"] === !![] && _0x8cg33a(_0xgf23a);
        _0x7gagf = 997882 ^ 997886;
        if (_0xa8dbd && !_0xgf23a["_lowPowerNotified"]) {
            _0xdd_0xag1(_0xcf313g(865414 ^ 866212, _0x45f2e(_0xgf23a)),
                        "#ff8c00");
            _0xgf23a["_lowPowerNotified"] = !![];
        }
        if (!_0xa8dbd) {
            _0xgf23a["_lowPowerNotified"] = false;
        }
        let _0xda3;
        var _0xd584d = _0x1ab3f || _0xgf23a["state"] === "open" && _0xge9ce["powerRequired"] !== !![];
        _0xda3 = (291942 ^ 291943) + (409260 ^ 409253);
        let _0x02g;
        var _0x8d18f = _0xb02c && _0xb02c["enabled"] && _0xb02c["dist"] != null ? _0xb02c["dist"] : _0xd5_0x7dc["highlightDist"];
        _0x02g = (140776 ^ 140781) + (472343 ^ 472350);
        var _0x02e2e = !![];
        if (_0xf7d99d && _0xb02c && _0xb02c["enabled"] && _0xb02c["spanDeg"] < (141758 ^ 141526)) {
            var _0x920fa = (710638 ^ 710638) + (253363 ^ 253361);
            var _0x1d0bea = Math["atan2"](_0xf7d99d["y"] - _0x38b, _0xf7d99d["x"] - _0x0aa) * (334148 ^ 334320) / Math["PI"];
            _0x920fa = "fekpch";
            if (_0x1d0bea < (216676 ^ 216676))
                _0x1d0bea += 539585 ^ 539305;
            var _0x4b7f4f = (540677 ^ 540674) + (376567 ^ 376565);
            var _0xb16 = (_0xb02c["centerAngleDeg"] % (179552 ^ 179208) + (875700 ^ 875996)) % (521789 ^ 522069);
            _0x4b7f4f = (381834 ^ 381827) + (552922 ^ 552914);
            let _0x315bb;
            var _0x7c2 = Math["abs"](_0x1d0bea - _0xb16);
            _0x315bb = "fegiib".split("").reverse().join("");
            if (_0x7c2 > (102093 ^ 102009))
                _0x7c2 = (122383 ^ 122727) - _0x7c2;
            _0x02e2e = _0x7c2 <= _0xb02c["spanDeg"] / (228811 ^ 228809);
        }
        var _0xbfce = (196352 ^ 196352) + (831869 ^ 831870);
        var _0x62643e;
        _0xbfce = "kllnab";
        if (_0xa8dbd) {
            var _0xacc87c = _0x44d2g(_0xgf23a);
            if (_0xf7d99d) {
                let _0xbd18ab;
                var hlDist = Math["hypot"](_0xf7d99d["x"] - _0x0aa, _0xf7d99d["y"] - _0x38b);
                _0xbd18ab = (355903 ^ 355897) + (148662 ^ 148663);
                if (hlDist <= _0x8d18f && _0x02e2e) {
                    _0x62643e = _0xacc87c ? _0xge9ce["openHL"] : _0xge9ce["closedHL"];
                }
                else {
                    _0x62643e = _0xacc87c ? _0xge9ce["open"] : _0xge9ce["closed"];
                }
            }
            else {
                _0x62643e = _0xacc87c ? _0xge9ce["open"] : _0xge9ce["closed"];
            }
        }
        else if (_0xd584d) {
            if (_0xf7d99d) {
                let _0xg3d9e;
                var hlDist = Math["hypot"](_0xf7d99d["x"] - _0x0aa, _0xf7d99d["y"] - _0x38b);
                _0xg3d9e = 740313 ^ 740304;
                _0x62643e = hlDist <= _0x8d18f && _0x02e2e ? _0xge9ce["openHL"] : _0xge9ce["open"];
            }
            else {
                _0x62643e = _0xge9ce["open"];
            }
        }
        else {
            _0x54d(_0xgf23a);
            if (_0xf7d99d) {
                var hlDist = Math["hypot"](_0xf7d99d["x"] - _0x0aa, _0xf7d99d["y"] - _0x38b);
                _0x62643e = hlDist <= _0x8d18f && _0x02e2e ? _0xge9ce["closedHL"] : _0xge9ce["closed"];
            }
            else {
                _0x62643e = _0xge9ce["closed"];
            }
        }
        var _0xb46c = (249193 ^ 249197) + (355195 ^ 355194);
        var _0x214g1e = _0xdg0b(_0x62643e);
        _0xb46c = (592264 ^ 592267) + (879856 ^ 879864);
        var _0xabdafc = (819341 ^ 819332) + (351028 ^ 351025);
        var _0x5f725b = _0xe3_0x013(glw, _0x62643e);
        _0xabdafc = "cqmfjd";
        if (_0x5f725b && _0x214g1e["complete"]) {
            glw[K["setTex"]](_0x5f725b);
            glw[K["setOpacity"]](430394 ^ 430395);
            var _0x691d9d = (534483 ^ 534483) + (268450 ^ 268459);
            var w = _0x214g1e["naturalWidth"] || 864181 ^ 864157;
            _0x691d9d = (163581 ^ 163579) + (409481 ^ 409485);
            var h = _0x214g1e["naturalHeight"] || 976890 ^ 976850;
            glw[K["quad"]](_0x0aa - w / (174306 ^ 174304), _0x38b - h / (596096 ^ 596098), _0x0aa + w / (159558 ^ 159556), _0x38b - h / (326705 ^ 326707), _0x0aa + w / (368756 ^ 368758), _0x38b + h / (680389 ^ 680391), _0x0aa - w / (899968 ^ 899970), _0x38b + h / (366143 ^ 366141));
            if (_0xdc93b["showArcOverlay"] && _0xb02c && _0xb02c["enabled"]) {
                var _0xc38fac = _0x07ec6d(glw, _0xb02c["centerAngleDeg"], _0xb02c["spanDeg"], _0x8d18f);
                if (_0xc38fac && _0xc38fac["tex"]) {
                    var _0x4725aa = _0xc38fac["size"] / (192697 ^ 192699);
                    glw[K["setTex"]](_0xc38fac["tex"]);
                    glw[K["setOpacity"]](782158 ^ 782159);
                    glw[K["quad"]](_0x0aa - _0x4725aa, _0x38b - _0x4725aa, _0x0aa + _0x4725aa, _0x38b - _0x4725aa, _0x0aa + _0x4725aa, _0x38b + _0x4725aa, _0x0aa - _0x4725aa, _0x38b + _0x4725aa);
                }
            }
            if (_0xa8dbd && _0xdc93b["showGeneratorDebug"]) {
                var labelInfo = _0xb3957e(glw,
                            "LOW FUEL",
                            "#ffb86c",
                            "rgba(0,0,0,0.75)");
                if (labelInfo && labelInfo["tex"]) {
                    let _0x836bdd;
                    var labelX = _0x0aa - labelInfo["width"] / (784745 ^ 784747);
                    _0x836bdd = (682208 ^ 682216) + (914575 ^ 914572);
                    var labelY = _0x38b - h / (714832 ^ 714834) - labelInfo["height"] - (831278 ^ 831272);
                    if (labelY < (843439 ^ 843439))
                        labelY = _0x38b + h / (665623 ^ 665621) + (924045 ^ 924043);
                    glw[K["setTex"]](labelInfo["tex"]);
                    glw[K["setOpacity"]](0.95);
                    glw[K["quad"]](labelX, labelY, labelX + labelInfo["width"], labelY, labelX + labelInfo["width"], labelY + labelInfo["height"], labelX, labelY + labelInfo["height"]);
                }
            }
            if (!_0xb2c43f && _0xgf23a["showButton"] && (_0xgf23a["state"] === "desolc".split("").reverse().join("") || _0xgf23a["state"] === "open" && _0xe91a9d(_0xgf23a))) {
                var _0xfe9ae = _0xb55c3f(_0xgf23a);
                let _0x9c_0x2f1;
                var _0xaa4de = _0xdg0b(_0xfe9ae);
                _0x9c_0x2f1 = 323380 ^ 323389;
                var _0xddff = (463374 ^ 463374) + (651731 ^ 651733);
                var _0x51c2 = _0xe3_0x013(glw, _0xfe9ae);
                _0xddff = (222644 ^ 222642) + (704789 ^ 704788);
                if (_0x51c2 && _0xaa4de["complete"]) {
                    glw[K["setTex"]](_0x51c2);
                    var _0x8a4g = 0.8;
                    var bw = (_0xaa4de["naturalWidth"] || 642917 ^ 642939) * _0x8a4g;
                    let _0xfd3g1f;
                    var _0x15gae = (_0xaa4de["naturalHeight"] || 448027 ^ 448005) * _0x8a4g;
                    _0xfd3g1f = 836479 ^ 836479;
                    var _0x01a3 = _0x38b - h / (337768 ^ 337770) - _0xd5_0x7dc["btnOffsetPx"] - _0x15gae / (893134 ^ 893132);
                    glw[K["quad"]](_0x0aa - bw / (189560 ^ 189562), _0x01a3 - _0x15gae / (656388 ^ 656390), _0x0aa + bw / (321814 ^ 321812), _0x01a3 - _0x15gae / (869677 ^ 869679), _0x0aa + bw / (766837 ^ 766839), _0x01a3 + _0x15gae / (503424 ^ 503426), _0x0aa - bw / (742784 ^ 742786), _0x01a3 + _0x15gae / (278169 ^ 278171));
                    _0xgf23a["_btnCX"] = _0x0aa;
                    _0xgf23a["_btnCY"] = _0x01a3;
                    _0xgf23a["_btnW"] = bw;
                    _0xgf23a["_btnH"] = _0x15gae;
                    _0xgf23a["_btnLayer"] = this[K["layer"]];
                }
            }
        }
        _0xgf23a["_drawVisible"] = !![];
        _0xgf23a["_drawSrc"] = _0x62643e;
        _0xgf23a["_drawCX"] = _0x0aa;
        _0xgf23a["_drawCY"] = _0x38b;
    } }; house["__mdzHooked"] = !![]; }
    var _0x332f = 303874 ^ 303874;
    var _0xf375e = 865260 ^ 865260;
    var _0xd82c8b = (842865 ^ 842866) + (507446 ^ 507441);
    var _0xgf3g = null;
    _0xd82c8b = 704635 ^ 704639;
    var _0xa0f = [];

    // ================================================================
    // V7 PERFORMANCE + INTERACTION RADIUS
    // - Collision objects are synchronized only when the player is near.
    // - Synchronization is throttled to avoid doing work every render frame.
    // - A full interaction-radius ring can be drawn around an opened/targeted chest.
    // ================================================================
    function _0x4cChestRadius(glw, cx, cy, radius, active) {
        if (!_0xd5_0x7dc["showInteractionRadius"] || !glw || !isFinite(radius) || radius <= 0)
            return;
        try {
            var texInfo = _0x07ec6d(glw, 0, 360, radius);
            if (!texInfo || !texInfo["tex"])
                return;
            var s = texInfo["size"] || radius * 2;
            glw[K["setTex"]](texInfo["tex"]);
            glw[K["setOpacity"]](active ? 0.34 : 0.14);
            glw[K["quad"]](cx - s, cy - s, cx + s, cy - s, cx + s, cy + s, cx - s, cy + s);
            glw[K["setOpacity"]](0.8);
        } catch (e) {}
    }

    function _0x5eChestCollision(locker, layer, playerDist) {
        if (!locker || !layer)
            return;

        var now = Date["now"]();
        var maxDist = _0xd5_0x7dc["collisionActiveRadius"];

        if (playerDist != null && playerDist > maxDist) {
            // IMPORTANT PERFORMANCE FIX:
            // V8 was calling _0xecfce() EVERY render frame for every far
            // chest. _0xecfce() iterates collision instances and calls bboxFn,
            // which is expensive and was the main source of stutter when many
            // chests existed.
            //
            // Disable only when transitioning from active -> inactive.
            if (locker["_collisionActive"]) {
                _0xecfce(locker);
                locker["_collisionActive"] = false;
            }
            return;
        }

        // Nearby chest: create/sync collision only on the configured interval.
        if (!locker["_collisionActive"] ||
            !locker["_collisionSyncAt"] ||
            now - locker["_collisionSyncAt"] >= _0xd5_0x7dc["collisionSyncMs"]) {
            _0x8e3dg(locker, layer);
            locker["_collisionSyncAt"] = now;
            locker["_collisionActive"] = true;
        }
    }

    function _0x5d68ea(house, structureType) { if (house["__mdzHooked"] || house["__mdzQueued"])
        return; house["__mdzQueued"] = !![]; _0xa0f["push"]({
        "house": house,
                "structureType": structureType
    }); }
    var _0x3ge76a = false;
    function _0xd54cf(_0x2a2, _0x1gf) { var _0xc5d2 = _0x6ec34e(); if (!_0xc5d2 || !_0xc5d2["canvas"]) {
        requestAnimationFrame(_0xd54cf);
        return;
    } _0x50g03a(_0xc5d2); if (!_0x3ge76a) {
        _0xcf2();
        _0x3ge76a = !![];
        _0x2df29d();
        _0xcf0b0a();
        _0x5c4a1e();
        _0xceba();
        _0x02999g();
        _0x44_0x4e3();
        _0x6463b("EN");
    } var _0x568fe = (883639 ^ 883635) + (938055 ^ 938048); var _0x21ab8e = _0x5e9e6g("181t".split("").reverse().join("")); _0x568fe = "leqhbl".split("").reverse().join(""); if (_0x21ab8e["length"] === (475480 ^ 475480)) {
        requestAnimationFrame(_0xd54cf);
        return;
    } var _0x17de = (810530 ^ 810535) + (104537 ^ 104542); var _0xda4 = _0xc5d2[K["layout"]] ? _0xc5d2[K["layout"]]["name"] : null; _0x17de = (666697 ^ 666698) + (557331 ^ 557328); if (_0xda4 !== _0xgf3g) {
        var _0x81378d = (151732 ^ 151729) + (701920 ^ 701924);
        var _0xfeafcb = _0xgf3g === null;
        _0x81378d = "fbdfbm";
        _0xgf3g = _0xda4;
        _0xa0f = [];
        _0x332f = 101234 ^ 101234;
        _0xf375e = 733640 ^ 733640;
        if (!_0xfeafcb) {
            _0x34c3e();
            _0xcac18a();
            _0x66f3f();
            _0x356f2c();
            _0xe2ab["spawnedInsts"] = [];
            _0xceba();
            _0x02999g();
            _0x44_0x4e3();
            if (window["MDZ"] && typeof window["MDZ"]["syncMapData"] === "noitcnuf".split("").reverse().join(""))
                window["MDZ"]["syncMapData"]();
            _0xd1f8e();
        }
    } if (_0x42a["_pendingSpawn"])
        _0xc7fb0c(); _0xbaf5a(); if (_0x77_0x317["_pendingSpawn"])
        _0x522dd(); _0x1c4c8b(); _0x8f143f = _0x21ab8e[728995 ^ 728995]; var _0x19f = _0x8f143f; _0x2a2 = 705989 ^ 705986; var _0x16aeb = (869202 ^ 869207) + (280360 ^ 280364); var _0xg7cd = Date["now"](); _0x16aeb = (385459 ^ 385462) + (166429 ^ 166425); if (_0xg7cd - _0x332f >= (663785 ^ 663571)) {
        _0x332f = _0xg7cd;
        for (var _0x746gfe in _0x7eed) {
            var _0x1555cg = _0x5e9e6g(_0x746gfe);
            for (var j = 423316 ^ 423316; j < _0x1555cg["length"]; j++)
                _0x5d68ea(_0x1555cg[j], _0x746gfe);
        }
        if (Array["isArray"](_0x51_0x675) && _0x51_0x675["length"]) {
            _0x51_0x675["forEach"](function (typeName, _0xe8d) { var _0xecf2 = _0x5e9e6g(typeName); _0xe8d = (612869 ^ 612870) + (952793 ^ 952792); for (var k = 792694 ^ 792694; _0xecf2 && k < _0xecf2["length"]; k++)
                _0x5d68ea(_0xecf2[k], typeName); });
        }
    } var _0x25a68g = Math["min"](179767 ^ 179775, _0xa0f["length"]); _0x1gf = 112413 ^ 112410; for (var q = 934484 ^ 934484; q < _0x25a68g; q++) {
        var _0xg192bb = (654664 ^ 654667) + (768252 ^ 768252);
        var _0x78ga8d = _0xa0f["shift"]();
        _0xg192bb = (679167 ^ 679167) + (537631 ^ 537625);
        if (_0x78ga8d)
            _0x613e(_0x78ga8d["house"], _0x78ga8d["structureType"]);
    } if (_0xg7cd - _0xf375e >= (415712 ^ 415252)) {
        _0xf375e = _0xg7cd;
        _0x5aa1a();
    } if (_0xg2_0x99g(_0xc5d2)) {
        for (var _0xe7ec in _0xe51a0c)
            _0xe51a0c[_0xe7ec]["showButton"] = false;
        if (_0xg506d()) {
            _0x8dfcf();
        }
        requestAnimationFrame(_0xd54cf);
        return;
    }

    // V8.1:
    // The interaction zone is invisible, but it is still enforced while the
    // loot window is open. Leaving the chest radius closes ONLY the loot UI.
    // The chest state and inventory are intentionally preserved.
    if (_0xa6_0x3b7 && _0xe51a0c[_0xa6_0x3b7]) {
        var _0xactiveChest = _0xe51a0c[_0xa6_0x3b7];
        if (_0xactiveChest["state"] === "open") {
            _0xactiveChest["_lootPersisted"] = true;

            var _0xactiveCx = _0x4ae(_0xactiveChest);
            var _0xactiveCy = _0x40_0xg74(_0xactiveChest);
            var _0xactiveDist = Math["hypot"](
                _0x19f["x"] - _0xactiveCx,
                _0x19f["y"] - _0xactiveCy
            );

            // Use interactionRadius as the invisible UI boundary.
            if (isFinite(_0xactiveDist) &&
                _0xactiveDist > _0xd5_0x7dc["interactionRadius"]) {
                _0xactiveChest["_autoClosedByRadius"] = true;
                _0x8dfcf();
            }
            else {
                _0xactiveChest["_autoClosedByRadius"] = false;
            }
        }
    }

    if (_0xg506d() && _0xb324d) {
        _0x0bd81b();
        _0xc5d2[K["redraw"]] = !![];
    } for (var k in _0xe51a0c)
        _0xe51a0c[k]["showButton"] = false; var _0xca277d = null; var _0xc8491b = 999999; var _0x1851b = null; for (var _0xe5dgbe in _0xe51a0c) {
        var _0x82e1f = (647545 ^ 647544) + (934225 ^ 934233);
        var l = _0xe51a0c[_0xe5dgbe];
        _0x82e1f = "ffnkgb";
        var _0x75f65b = (121897 ^ 121897) + (649534 ^ 649533);
        var _0xe2a = _0x4ae(l);
        _0x75f65b = (397251 ^ 397248) + (989763 ^ 989765);
        var _0x6e97ge = (264836 ^ 264832) + (278951 ^ 278947);
        var _0xbfc5c = _0x40_0xg74(l);
        _0x6e97ge = (495096 ^ 495097) + (147461 ^ 147461);
        var _0x1e1aae = Math["hypot"](_0x19f["x"] - _0xe2a, _0x19f["y"] - _0xbfc5c);
        if (l["conf"]["powerRequired"] === !![] && l["searched"] && !_0xe91a9d(l) && _0x1e1aae <= _0xd5_0x7dc["buttonDist"]) {
            if (!l["_lootedNearbyNotified"]) {
                _0xdd_0xag1(_0xcf313g(543721 ^ 542920, _0x45f2e(l)),
                        "#ffaa00");
                l["_lootedNearbyNotified"] = !![];
            }
        }
        else if (l["_lootedNearbyNotified"] && _0x1e1aae > _0xd5_0x7dc["buttonDist"]) {
            l["_lootedNearbyNotified"] = false;
        }
        if (l["state"] === "desolc".split("").reverse().join("") || l["state"] === "open" && _0xe91a9d(l)) {
            if (l["conf"]["powerRequired"] === !![]) {
                if (l["powered"]) {
                    if (!l["_powerNotified"] && _0x1e1aae <= _0xd5_0x7dc["buttonDist"]) {
                        _0xdd_0xag1(_0xcf313g(538324 ^ 538103, _0x45f2e(l)),
                                "00aaff#".split("").reverse().join(""));
                        l["_powerNotified"] = !![];
                    }
                }
                else {
                    l["_powerNotified"] = false;
                }
            }
            if (_0x1e1aae <= _0xd5_0x7dc["buttonDist"] && _0x1e1aae < _0xc8491b) {
                if (_0xb324d && _0xa6_0x3b7 === _0xe5dgbe)
                    continue;
                var _0xc423e = (756659 ^ 756659) + (188207 ^ 188198);
                var _0xc4d48g = l["conf"]["interactArc"];
                _0xc423e = "pcggeh";
                if (_0xc4d48g && _0xc4d48g["enabled"] && _0xc4d48g["dist"] != null && _0x1e1aae > _0xc4d48g["dist"])
                    continue;
                if (_0xc4d48g && _0xc4d48g["enabled"] && _0xc4d48g["spanDeg"] < (102411 ^ 102755)) {
                    let _0x15aeb;
                    var _0x1fg27e = Math["atan2"](_0x19f["y"] - _0xbfc5c, _0x19f["x"] - _0xe2a) * (962218 ^ 962078) / Math["PI"];
                    _0x15aeb = (607359 ^ 607355) + (253640 ^ 253645);
                    if (_0x1fg27e < (348507 ^ 348507))
                        _0x1fg27e += 658602 ^ 658882;
                    var _0x8d76b = (583790 ^ 583791) + (900278 ^ 900278);
                    var _0xb64a = (_0xc4d48g["centerAngleDeg"] % (221518 ^ 221222) + (438114 ^ 437770)) % (530644 ^ 530876);
                    _0x8d76b = 828064 ^ 828065;
                    var _0x5e28ee = (688359 ^ 688356) + (997715 ^ 997714);
                    var _0x51d77a = _0xc4d48g["spanDeg"] / (356577 ^ 356579);
                    _0x5e28ee = (688958 ^ 688951) + (984069 ^ 984076);
                    let _0x302dec;
                    var _0xd58c = Math["abs"](_0x1fg27e - _0xb64a);
                    _0x302dec = (172272 ^ 172277) + (894061 ^ 894058);
                    if (_0xd58c > (707891 ^ 707975))
                        _0xd58c = (805436 ^ 805716) - _0xd58c;
                    if (_0xd58c > _0x51d77a)
                        continue;
                }
                _0xc8491b = _0x1e1aae;
                _0xca277d = _0xe5dgbe;
                _0x1851b = l;
            }
        }
    } _0x50_0x798 = {}; for (var _0xeac in _0xe51a0c) {
        var _0x3b5ce = (579272 ^ 579276) + (368389 ^ 368397);
        var _0x29feb = _0xe51a0c[_0xeac];
        _0x3b5ce = (169570 ^ 169575) + (692501 ^ 692499);
        if (!_0x29feb["conf"]["locked"] || _0x29feb["unlocked"])
            continue;
        var _0x1a41dc = _0x29feb["conf"]["unlockItemId"];
        if (!_0x1a41dc)
            continue;
        var _0x8fd6a = _0x4ae(_0x29feb);
        let _0xa947b;
        var _0x55193e = _0x40_0xg74(_0x29feb);
        _0xa947b = (653923 ^ 653926) + (332706 ^ 332715);
        var _0xf9fg4b = Math["hypot"](_0x19f["x"] - _0x8fd6a, _0x19f["y"] - _0x55193e);
        var _0x223b = _0x29feb["conf"]["interactArc"];
        var _0xb0c0eb = _0x223b && _0x223b["enabled"] && _0x223b["dist"] != null ? _0x223b["dist"] : _0xd5_0x7dc["buttonDist"];
        if (_0xf9fg4b <= _0xb0c0eb) {
            if (!_0x50_0x798[_0x1a41dc] || _0xf9fg4b < (_0x50_0x798[_0x1a41dc]["_keyGateDist"] || Infinity)) {
                _0x29feb["_keyGateDist"] = _0xf9fg4b;
                _0x50_0x798[_0x1a41dc] = _0x29feb;
            }
        }
    } var _0xbe54b = 842154 ^ 842154; for (var _0x197ba in _0x50_0x798) {
        _0xbe54b = Number(_0x197ba);
        break;
    } if (_0xc5d2["ew"]) {
        let _0x69c;
        var _0xeb7c = _0xc5d2["ew"]("MDZ_ChestKeyReady", null);
        _0x69c = (731392 ^ 731399) + (904407 ^ 904415);
        if (_0xeb7c)
            _0xeb7c["data"] = _0xbe54b;
    } if (_0xc5d2["ew"]) {
        let _0xcfb;
        var _0xd40b5d = _0xc5d2["ew"]("giSkcolnUtsehC_ZDM".split("").reverse().join(""), null);
        _0xcfb = (114314 ^ 114316) + (196205 ^ 196205);
        if (_0xd40b5d && _0xd40b5d["data"]) {
            var _0x942ca = _0xd40b5d["data"];
            _0xd40b5d["data"] = 988687 ^ 988687;
            var _0xc7bfg = _0x50_0x798[_0x942ca];
            if (_0xc7bfg && !_0xc7bfg["unlocked"]) {
                var _0xfba6d = {
                    786: "Red Key", 787: "Blue Key", 788: "Black Key"
                };
                var _0xa76a = {
                    786: 300, 787: 400, 788: 500
                };
                if (_0xc5d2["ew"]) {
                    let _0x9725b;
                    var _0xd5bbdb = _0xc5d2["ew"]("stniop_ecnereipxe".split("").reverse().join(""), null);
                    _0x9725b = 400155 ^ 400156;
                    if (_0xd5bbdb)
                        _0xd5bbdb["data"] += _0xa76a[_0x942ca] || 246612 ^ 246612;
                    if (typeof c2_callFunction !== "denifednu".split("").reverse().join("")) {
                        try {
                            c2_callFunction("statS_etadpU".split("").reverse().join(""), []);
                        }
                        catch (e) { }
                    }
                }
                _0xdd_0xag1(_0xcf313g(282304 ^ 282084, _0xfba6d[_0x942ca] || "Key"),
                        "#00cc44");
                _0xc7bfg["unlocked"] = !![];
                _0x4ee8f(_0xc7bfg["conf"]["unlockSounds"], _0x49_0x7bc);
                _0xc5d2[K["redraw"]] = !![];
                _0x6f_0x45a = {
                    "locker": _0xc7bfg,
                            "openAt": Date["now"]() + (817017 ^ 812981)
                };
            }
            else {
                if (typeof c2_callFunction !== "undefined") {
                    try {
                        c2_callFunction("yrotnevni_ecaps_kcehC".split("").reverse().join(""), [-(679250 ^ 679251), _0x942ca, 133503 ^ 133503]);
                    }
                    catch (e) { }
                }
                var _0x2436da = false;
                for (var _0x3cc2d in _0x50_0x798) {
                    _0x2436da = !![];
                    break;
                }
                _0xdd_0xag1(_0x2436da ? _0xcf313g(235568 ^ 236309) : _0xcf313g(587462 ^ 587232),
                        "0088ff#".split("").reverse().join(""));
            }
        }
    } if (_0x6f_0x45a && Date["now"]() >= _0x6f_0x45a["openAt"]) {
        let _0x7ad4c;
        var _0xgc06bd = _0x6f_0x45a;
        _0x7ad4c = (616742 ^ 616743) + (238027 ^ 238027);
        _0x6f_0x45a = null;
        if (_0xgc06bd["locker"] && !_0xg506d()) {
            _0xgc06bd["locker"]["state"] = "open";
            if (!_0xgc06bd["locker"]["searched"])
                _0xgc06bd["locker"]["lootTime"] = Date["now"]();
            _0xgc06bd["locker"]["showButton"] = false;
            _0x4ee8f(_0xgc06bd["locker"]["conf"]["openSounds"], _0xf873ee);
            _0xc5d2[K["redraw"]] = !![];
            _0x3b4d(_0xgc06bd["locker"]["mapKey"]);
        }
    } if (_0xca277d && _0x1851b) {
        if (!_0x1851b["showButton"]) {
            _0x1851b["showButton"] = !![];
            _0xc5d2[K["redraw"]] = !![];
        }
    }
    else {
        _0xc5d2[K["redraw"]] = !![];
    } requestAnimationFrame(_0xd54cf); }
    requestAnimationFrame(_0xd54cf);
})();
