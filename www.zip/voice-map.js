window.NPC_VOICE_TEXT_MAP = {
  "Hello! Survivor...": 200,
  "There are enemies nearby!": 202,
  "Hello there!": 205,
  "Hey! can you help us?": 206,
  "Don't shoot! we are friendly...": 207,
  "Greetings.": 208,
  "Thank you!": 209,
  "Hi! We heard about you! You was helping people in trouble and we want to gift you for your deeds! Take this:": 210
};
